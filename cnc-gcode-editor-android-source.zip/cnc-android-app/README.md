<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/170b40d6-b244-4dc7-8f27-1406891bc232

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Enhanced edition (100-step guide and CNC file workflow)

- Assembly roadmap expanded from 30 to 100 steps with bilingual Urdu/English checks.
- Progress/navigation limits now follow the actual number of assembly steps.
- The Design Size Editor includes a four-stage file workflow: upload, edit, preview/validate, and export/download.
- Supported import formats are shown in the editor. Always verify units, origin, controller compatibility, safe Z, workholding, and perform a dry run before machining. G-code is machine-specific and should not be assumed safe just because it imports successfully.


### G-Code editing workspace

The Design Size Editor now provides a text workspace for importing `.nc`, `.tap`, `.gcode`, `.cnc`, and `.txt` files, editing their G-code lines, and downloading the edited text. The editor performs only basic heuristic checks; it is not a full parser or machine simulator. Verify controller dialect, units (G20/G21), work coordinate offsets, tool/spindle commands, safe Z, limits and workholding, and run a dry run before cutting. CAD/vector imports are not automatically converted into production-ready toolpaths by this text editor.
