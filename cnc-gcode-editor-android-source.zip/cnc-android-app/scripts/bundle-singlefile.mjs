import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(__dirname, '..');
const distDir = path.resolve(rootDir, 'dist');
const assetsDir = path.resolve(distDir, 'assets');

console.log('🚀 Generating Single Standalone index.html for Kodular WebViewer...');

if (!fs.existsSync(distDir)) {
  console.error('❌ dist/ directory not found! Run npm run build first.');
  process.exit(1);
}

// 1. Read dist/index.html
const indexHtmlPath = path.resolve(distDir, 'index.html');
let htmlContent = fs.readFileSync(indexHtmlPath, 'utf-8');

// 2. Find CSS files
const assetFiles = fs.readdirSync(assetsDir);
const cssFiles = assetFiles.filter((f) => f.endsWith('.css'));
const jsFiles = assetFiles.filter((f) => f.endsWith('.js'));

if (cssFiles.length === 0 || jsFiles.length === 0) {
  console.error('❌ No CSS or JS asset files found in dist/assets!');
  process.exit(1);
}

console.log(`📦 Found CSS: ${cssFiles.join(', ')}`);
console.log(`📦 Found JS: ${jsFiles.join(', ')}`);

// Concatenate all CSS
let allCss = '';
for (const cssFile of cssFiles) {
  const cssPath = path.resolve(assetsDir, cssFile);
  allCss += fs.readFileSync(cssPath, 'utf-8') + '\n';
}

// Concatenate all JS (safe for inline script tag)
let allJs = '';
for (const jsFile of jsFiles) {
  const jsPath = path.resolve(assetsDir, jsFile);
  let jsContent = fs.readFileSync(jsPath, 'utf-8');
  // Prevent premature script tag closing
  jsContent = jsContent.replace(/<\/script>/gi, '<\\/script>');
  allJs += jsContent + '\n';
}

// 3. Remove external stylesheet links and script tags
htmlContent = htmlContent.replace(/<link[^>]*rel=["']stylesheet["'][^>]*href=["'][^"']*assets\/[^"']*["'][^>]*>/gi, '');
htmlContent = htmlContent.replace(/<script[^>]*src=["'][^"']*assets\/[^"']*["'][^>]*><\/script>/gi, '');

// 4. Inject inlined <style> in <head>
const styleTag = `\n    <!-- INLINED STYLES FOR STANDALONE KODULAR DEPLOYMENT -->\n    <style>\n${allCss}\n    </style>\n  </head>`;
htmlContent = htmlContent.replace(/<\/head>/i, styleTag);

// 5. Inject inlined <script type="module"> before </body>
const scriptTag = `\n    <!-- INLINED APP BUNDLE SCRIPT FOR STANDALONE KODULAR DEPLOYMENT -->\n    <script type="module">\n${allJs}\n    </script>\n  </body>`;
htmlContent = htmlContent.replace(/<\/body>/i, scriptTag);

// 6. Write to destination files:
// a) /kodular_index.html at root
const rootKodularPath = path.resolve(rootDir, 'kodular_index.html');
fs.writeFileSync(rootKodularPath, htmlContent, 'utf-8');

// b) /dist/standalone_index.html in dist
const distKodularPath = path.resolve(distDir, 'standalone_index.html');
fs.writeFileSync(distKodularPath, htmlContent, 'utf-8');

// c) /public/kodular_index.html for static download via server
const publicDir = path.resolve(rootDir, 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}
const publicKodularPath = path.resolve(publicDir, 'kodular_index.html');
fs.writeFileSync(publicKodularPath, htmlContent, 'utf-8');

const fileSizeMB = (Buffer.byteLength(htmlContent, 'utf-8') / (1024 * 1024)).toFixed(2);
console.log(`✅ Success! Standalone single index.html bundled successfully (${fileSizeMB} MB)`);
console.log(`📁 File saved at: ${rootKodularPath}`);
console.log(`📁 Downloadable at: /kodular_index.html`);
