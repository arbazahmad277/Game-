export interface UserSession {
  email: string;
  displayName: string;
  verifiedAt: string;
  workshopRole?: string;
  workshopName?: string;
  avatarUrl?: string;
  phone?: string;
}
