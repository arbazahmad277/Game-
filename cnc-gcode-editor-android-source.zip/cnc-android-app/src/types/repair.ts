export interface VideoChapter {
  time: string;
  seconds: number;
  title: string;
  desc: string;
  animationPhase: 'inspect' | 'disassemble' | 'align' | 'torque';
  toolNeeded?: string;
  specValue?: string;
}

export interface VideoSource {
  src: string;
  type: string;
  label?: string;
}

export interface VideoGuideData {
  title: string;
  duration: string;
  durationSeconds: number;
  chapters: VideoChapter[];
  videoUrl?: string;
  fallbackVideoUrl?: string;
  sources?: VideoSource[];
}

export interface RepairLog {
  id: string;
  ticketNumber: string;
  stepId: number;
  stepTitleEn: string;
  stepTitleUrdu: string;
  date: string;
  symptoms: string;
  severity: 'Low' | 'Moderate' | 'High' | 'Critical';
  status: 'Resolved' | 'In Progress' | 'Inspection Required';
  mediaUrl?: string;
  mediaType?: 'image' | 'video';
  diagnosticImageUrl?: string;
  diagnosisText: string;
  technicianNotes?: string;
  videoGuide?: VideoGuideData;
  torqueApplied?: string;
  toleranceVerified?: string;
}
