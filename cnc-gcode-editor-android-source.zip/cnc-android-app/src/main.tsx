import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

const htmlSplash = document.getElementById('custom-splash');
if (htmlSplash) {
  htmlSplash.style.display = 'none';
}

createRoot(document.getElementById('root')!).render(<App />);

