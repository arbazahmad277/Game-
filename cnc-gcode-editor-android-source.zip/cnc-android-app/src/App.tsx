/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CNC_STEPS, CNCStep } from './data/cncSteps';
import { InteractiveCADViewer } from './components/InteractiveCADViewer';
import { AutoCADSequenceRunner } from './components/AutoCADSequenceRunner';
import { StepDetailPanel } from './components/StepDetailPanel';
import { StepNavigator } from './components/StepNavigator';
import { CADEditModal } from './components/CADEditModal';
import { VisualTroubleshooter } from './components/VisualTroubleshooter';
import { RepairHistoryLog } from './components/RepairHistoryLog';
import { MachineOperationTab } from './components/MachineOperationTab';
import { DesignSizeEditorTab } from './components/DesignSizeEditorTab';
import { DeveloperSupportPanel } from './components/DeveloperSupportPanel';
import { SplashScreen } from './components/SplashScreen';
import { AuthScreen } from './components/AuthScreen';
import { BottomNavBar, ActiveAppTab } from './components/BottomNavBar';
import { ProfileTab } from './components/ProfileTab';
import { UserSession } from './types/auth';
import { RepairLog } from './types/repair';
import {
  getStoredUserSession,
  saveUserSession,
  clearUserSession,
  getCompletedSteps,
  saveCompletedSteps,
  toggleStepCompleted,
  getStoredRepairLogs,
  saveRepairLogs,
  getStoredLanguage,
  saveStoredLanguage,
  cacheAllStepsOffline,
  isOfflineDataReady,
} from './utils/storage';
import {
  Cpu,
  Layers,
  Sparkles,
  Download,
  Languages,
  CheckCircle2,
  FileDown,
  Camera,
  FileText,
  AlertTriangle,
  Wrench,
  Zap,
  ShieldCheck,
  UserCheck,
  Check,
  Ruler,
} from 'lucide-react';

const INITIAL_REPAIR_LOGS: RepairLog[] = [
  {
    id: 'rep-seed-1',
    ticketNumber: 'CNC-LOG-1024',
    stepId: 7,
    stepTitleEn: 'Dual Y-Axis Ball Screws (SFU1605/1610) & Fixed BK12 Bearing Mounts',
    stepTitleUrdu: 'ڈوئل وائی ایکسس بال اسکرو (SFU1605) اور BK12 فکسڈ بیرنگ بلاکس',
    date: '2026-10-04 11:30 AM',
    symptoms: 'Y-Axis Ballscrew binding observed at 800mm travel. Audible squeal and missed steps under rapid jog.',
    severity: 'High',
    status: 'Resolved',
    mediaUrl: '/src/assets/images/cnc_gantry_assembly_cad_1791448922691.jpg',
    mediaType: 'image',
    diagnosticImageUrl: '/src/assets/images/cnc_gantry_assembly_cad_1791448922691.jpg',
    diagnosisText: `🔍 **Visual Diagnostic Analysis:**
- Root Cause: BK12 angular contact locknut under-torqued causing 0.04mm axial play and binding.
- Action Taken: Re-aligned BF12 floating bearing, degreased ballnut wiper, torqued M12 locknut to 22 N·m with Loctite 243.
- Verification: TIR measured at 0.012mm across 1000mm. Smooth silent motion confirmed.`,
    technicianNotes: 'Applied Mobilith SHC 100 grease. Backlash verified at zero. Ready for production.',
    torqueApplied: '22 N·m Locknut, 9.0 N·m Mounts',
    toleranceVerified: '0.012 mm TIR',
  },
  {
    id: 'rep-seed-2',
    ticketNumber: 'CNC-LOG-1056',
    stepId: 20,
    stepTitleEn: '2.2kW Water-Cooled Spindle Motor Installation & ER20 Collet Check',
    stepTitleUrdu: '2.2kW واٹر کولڈ اسپنڈل موٹر کی تنصیب اور ER20 ٹول ہولڈر چیک',
    date: '2026-10-06 03:15 PM',
    symptoms: 'Scalloping and circular ridge lines on hardwood surfacing passes. Spindle nod angle out of square.',
    severity: 'Moderate',
    status: 'Resolved',
    mediaUrl: '/src/assets/images/cnc_zaxis_spindle_cad_1791448936583.jpg',
    mediaType: 'image',
    diagnosticImageUrl: '/src/assets/images/cnc_zaxis_spindle_cad_1791448936583.jpg',
    diagnosisText: `🔍 **Spindle Tramming Inspection:**
- Root Cause: Spindle collar tilted forward by 0.08mm across 200mm sweep circle.
- Action Taken: Installed 0.05mm precision brass foil shims behind lower mount flange. Re-torqued M8 bolts in criss-cross pattern to 22 N·m.
- Verification: Dual dial indicator sweep showed zero needle deviation across 200mm radius.`,
    technicianNotes: 'Surfacing test on MDF spoilboard yielded flawless mirror finish with zero ridges.',
    torqueApplied: '22 N·m Mount, 14 N·m Pinch Collar',
    toleranceVerified: '0.010 mm Tramming',
  },
];

export default function App() {
  // 1. Splash Screen State (2 seconds animation)
  const [showSplash, setShowSplash] = useState<boolean>(true);

  // 2. Authentication State (One-time Gmail OTP verification with localStorage persistence)
  const [userSession, setUserSession] = useState<UserSession | null>(() => getStoredUserSession());

  // 3. WhatsApp-Style 4-Tab Navigation ('assembly' | 'operation' | 'troubleshoot' | 'profile')
  const [activeTab, setActiveTab] = useState<ActiveAppTab>('assembly');

  // Assembly Guide State (Steps 1-100)
  const [currentStepId, setCurrentStepId] = useState<number>(1);
  const [lang, setLang] = useState<'ur' | 'en' | 'both'>(() => getStoredLanguage());
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);

  // Completed Steps Persistent Tracker (1-100)
  const [completedSteps, setCompletedSteps] = useState<Record<number, boolean>>(() => getCompletedSteps());

  // Persistent Repair Logs
  const [repairLogs, setRepairLogs] = useState<RepairLog[]>(() => getStoredRepairLogs(INITIAL_REPAIR_LOGS));

  // Pre-seed milestone CAD images
  const [generatedImages, setGeneratedImages] = useState<Record<number, string>>({
    1: '/src/assets/images/cnc_base_frame_cad_1791448908736.jpg',
    7: '/src/assets/images/cnc_gantry_assembly_cad_1791448922691.jpg',
    16: '/src/assets/images/cnc_zaxis_spindle_cad_1791448936583.jpg',
    25: '/src/assets/images/cnc_electronics_wiring_cad_1791448948411.jpg',
    30: '/src/assets/images/cnc_completed_router_cad_1791448958543.jpg',
  });

  // Ensure offline dataset is cached in localStorage on startup
  useEffect(() => {
    if (!isOfflineDataReady()) {
      cacheAllStepsOffline();
    }
  }, []);

  // Sync Language change to storage
  const handleLanguageChange = (newLang: 'ur' | 'en' | 'both') => {
    setLang(newLang);
    saveStoredLanguage(newLang);
  };

  // Sync Completed Steps to storage
  const handleToggleComplete = (stepId: number) => {
    const updated = toggleStepCompleted(stepId);
    setCompletedSteps({ ...updated });
  };

  // Sync Repair Logs to storage
  const handleSaveRepairLog = (newLog: RepairLog) => {
    const updated = [newLog, ...repairLogs.filter((l) => l.id !== newLog.id)];
    setRepairLogs(updated);
    saveRepairLogs(updated);
  };

  const handleUpdateRepairLog = (updated: RepairLog) => {
    const nextLogs = repairLogs.map((l) => (l.id === updated.id ? updated : l));
    setRepairLogs(nextLogs);
    saveRepairLogs(nextLogs);
  };

  const handleDeleteRepairLog = (id: string) => {
    const nextLogs = repairLogs.filter((l) => l.id !== id);
    setRepairLogs(nextLogs);
    saveRepairLogs(nextLogs);
  };

  const handleClearAllLogs = () => {
    setRepairLogs([]);
    saveRepairLogs([]);
  };

  const currentStep = CNC_STEPS.find((s) => s.id === currentStepId) || CNC_STEPS[0];

  const handleImageGenerated = (stepNumber: number, imageUrl: string) => {
    setGeneratedImages((prev) => ({
      ...prev,
      [stepNumber]: imageUrl,
    }));
  };

  const handleNextStep = () => {
    if (currentStepId < CNC_STEPS.length) {
      setCurrentStepId((prev) => prev + 1);
    }
  };

  const handlePrevStep = () => {
    if (currentStepId > 1) {
      setCurrentStepId((prev) => prev - 1);
    }
  };

  // Logout / Switch Account
  const handleLogout = () => {
    clearUserSession();
    setUserSession(null);
  };

  // Download complete workshop package
  const handleBatchDownload = () => {
    const manifest = {
      title: 'Arbaz Wood Craft - CNC Router 100-Step Blueprint Collection & Workshop Backup',
      userEmail: userSession?.email || 'arbazahmad277@gmail.com',
      exportDate: new Date().toISOString(),
      totalSteps: CNC_STEPS.length,
      completedStepsCount: Object.values(completedSteps).filter(Boolean).length,
      completedStepsMap: completedSteps,
      repairHistoryCount: repairLogs.length,
      repairLogs: repairLogs,
      steps: CNC_STEPS.map((step) => ({
        step: step.id,
        phase: step.phaseNameEn,
        titleUrdu: step.titleUrdu,
        titleEn: step.titleEn,
        completed: Boolean(completedSteps[step.id]),
        specs: step.specs,
        cadPrompt: step.cadPrompt,
        hasImage: Boolean(generatedImages[step.id]),
        imageUrl: generatedImages[step.id] || step.defaultImage,
      })),
    };

    const blob = new Blob([JSON.stringify(manifest, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ArbazWoodCraft_CNC_Router_Backup_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const completedStepsCount = Object.values(completedSteps).filter(Boolean).length;

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-[#070d18] text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950 pb-20">
      {/* 1. BRANDED ANIMATED SPLASH SCREEN (2 Seconds Startup Animation) */}
      {showSplash && (
        <SplashScreen
          brandName="Arbaz Wood Craft"
          subtitle="CNC Router Smart Assistant"
          onFinish={() => setShowSplash(false)}
        />
      )}

      {/* 2. ONE-TIME GMAIL AUTHENTICATION WITH EMAIL OTP (Shown if no session saved) */}
      {!showSplash && !userSession && (
        <AuthScreen
          defaultEmail="arbazahmad277@gmail.com"
          onAuthenticated={(session) => setUserSession(session)}
        />
      )}

      {/* MAIN APPLICATION (Visible once authenticated) */}
      {!showSplash && userSession && (
        <>
          {/* Top Brand Navbar */}
          <header className="sticky top-0 z-40 bg-slate-950/95 border-b border-cyan-900/60 backdrop-blur-md px-3 sm:px-6 py-2 w-full max-w-full overflow-x-hidden">
            <div className="max-w-7xl mx-auto flex flex-wrap sm:flex-nowrap items-center justify-between gap-2 sm:gap-3">
              {/* Logo & Brand Identity */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 border border-cyan-400/40 text-xl shrink-0">
                  🪵
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-sm sm:text-base font-black tracking-tight text-white flex items-center gap-1.5 font-sans">
                      <span className="text-cyan-400">Arbaz Wood Craft</span>
                      <span className="text-slate-600 hidden sm:inline">|</span>
                      <span className="hidden sm:inline">
                        {lang === 'en' ? 'CNC Router Assembly & Operations' : lang === 'both' ? 'CNC اسیمبلی و آپریشن (Assembly & Ops)' : 'CNC اسیمبلی و آپریشن'}
                      </span>
                    </h1>
                    <span className="text-[10px] font-mono bg-cyan-950 text-cyan-300 border border-cyan-700/60 px-2 py-0.5 rounded uppercase">
                      Smart Assistant
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 font-mono truncate hidden md:block">
                    3-Axis CNC Router &bull; {completedStepsCount}/{CNC_STEPS.length} {lang === 'en' ? 'Steps Done' : 'مراحل مکمل'} &bull; {userSession.email}
                  </p>
                </div>
              </div>

              {/* Right Toolbar: Language Switcher, Repair Log & Account Pill */}
              <div className="flex items-center gap-2">
                {/* Language Switcher */}
                <div className="flex items-center bg-slate-900 p-0.5 rounded-lg border border-cyan-900/60 text-xs">
                  <button
                    onClick={() => handleLanguageChange('ur')}
                    className={`px-2 py-1 rounded transition text-xs cursor-pointer ${
                      lang === 'ur'
                        ? 'bg-cyan-500 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-cyan-300'
                    }`}
                  >
                    اردو
                  </button>
                  <button
                    onClick={() => handleLanguageChange('both')}
                    className={`px-2 py-1 rounded transition text-xs cursor-pointer ${
                      lang === 'both'
                        ? 'bg-cyan-500 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-cyan-300'
                    }`}
                  >
                    دونوں
                  </button>
                  <button
                    onClick={() => handleLanguageChange('en')}
                    className={`px-2 py-1 rounded transition text-xs cursor-pointer ${
                      lang === 'en'
                        ? 'bg-cyan-500 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-cyan-300'
                    }`}
                  >
                    Eng
                  </button>
                </div>

                {/* Repair Log Modal Button */}
                <button
                  onClick={() => setIsHistoryOpen(true)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-xs transition cursor-pointer"
                  title="View Repair Logs"
                >
                  <FileText className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="hidden sm:inline">
                    {lang === 'en' ? 'Repair Logs' : lang === 'both' ? 'مرمت لاگ (Logs)' : 'مرمت لاگ'}
                  </span>
                  <span className="bg-cyan-950 text-cyan-300 text-[10px] font-mono px-1 rounded border border-cyan-800">
                    {repairLogs.length}
                  </span>
                </button>

                {/* Verified Account Avatar / Shortcut to Profile Tab */}
                <button
                  onClick={() => setActiveTab('profile')}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs transition cursor-pointer ${
                    activeTab === 'profile'
                      ? 'bg-cyan-950 border-cyan-400 text-cyan-300'
                      : 'bg-slate-900 border-slate-700 text-slate-300 hover:border-slate-500'
                  }`}
                  title="Profile & Settings"
                >
                  <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="hidden lg:inline text-xs truncate max-w-[120px]">
                    {userSession.displayName}
                  </span>
                </button>
              </div>
            </div>
          </header>

          {/* Main Container Switching Among the 4 Active Tabs */}
          <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
            {/* TAB 1: 🛠️ "مشین بنائیں" (Assembly Guide - Steps 1 to 100) */}
            {activeTab === 'assembly' && (
              <div className="space-y-6">
                {/* Continuous Automated CAD Generator Hero HUD */}
                <AutoCADSequenceRunner
                  currentStepIndex={currentStepId}
                  onSelectStep={(stepNum) => setCurrentStepId(stepNum)}
                  generatedImages={generatedImages}
                  onImageGenerated={handleImageGenerated}
                  lang={lang}
                  isRunning={isRunning}
                  setIsRunning={setIsRunning}
                />

                {/* Workspace Layout: Left Viewer + Details, Right Steps Navigation */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                  {/* Main Visualizer and Instructions Column (8 Cols) */}
                  <div className="lg:col-span-8 space-y-6">
                    {/* Interactive 3D CAD Blueprint Viewport */}
                    <InteractiveCADViewer
                      step={currentStep}
                      generatedImageUrl={generatedImages[currentStep.id]}
                      isGenerating={isRunning}
                      onOpenEditModal={() => setIsEditModalOpen(true)}
                      lang={lang}
                    />

                    {/* Detailed Workshop Step Guide */}
                    <StepDetailPanel
                      step={currentStep}
                      lang={lang}
                      onNextStep={handleNextStep}
                      onPrevStep={handlePrevStep}
                      isFirst={currentStepId === 1}
                      isLast={currentStepId === CNC_STEPS.length}
                    />
                  </div>

                  {/* Step Navigation Sidebar Column (4 Cols) */}
                  <div className="lg:col-span-4 sticky top-20 space-y-4">
                    <StepNavigator
                      currentStepId={currentStepId}
                      onSelectStep={(stepNum) => setCurrentStepId(stepNum)}
                      generatedImages={generatedImages}
                      lang={lang}
                      completedSteps={completedSteps}
                      onToggleComplete={handleToggleComplete}
                    />

                    {/* Quick Trigger Cards for Tab 2 & Tab 3 */}
                    <div
                      onClick={() => setActiveTab('operation')}
                      className="p-3.5 rounded-xl bg-gradient-to-r from-cyan-950/60 to-slate-900 border border-cyan-800/60 hover:border-cyan-400 cursor-pointer transition shadow-lg group"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="flex items-center gap-1.5 text-xs font-mono font-bold text-cyan-300">
                          <Cpu className="w-4 h-4 text-cyan-400" />
                          <span>{lang === 'en' ? 'Run Machine & G-Code?' : lang === 'both' ? 'مشین چلائیں (Run & G-Code)?' : 'مشین چلائیں اور G-Code؟'}</span>
                        </span>
                        <span className="text-[10px] text-cyan-400 font-mono group-hover:translate-x-1 transition">
                          {lang === 'en' ? 'Open &rarr;' : 'اوپن کریں &rarr;'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 font-sans">
                        {lang === 'en'
                          ? 'Speeds & feeds for Sheesham, Walnut, MDF, G-code generator & 3-Axis jogger.'
                          : 'شیشم، اخروٹ اور ایم ڈی ایف کے فیڈ ریٹس، G-code جنریٹر اور 3-Axis جوگنگ۔'}
                      </p>
                    </div>

                    <div
                      onClick={() => setActiveTab('troubleshoot')}
                      className="p-3.5 rounded-xl bg-gradient-to-r from-red-950/60 to-slate-900 border border-red-800/60 hover:border-red-400 cursor-pointer transition shadow-lg group"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="flex items-center gap-1.5 text-xs font-mono font-bold text-red-300">
                          <Camera className="w-4 h-4 text-red-400" />
                          <span>{lang === 'en' ? 'Troubleshoot (AI Camera)?' : lang === 'both' ? 'مشین ٹھیک کریں (AI Camera)?' : 'مشین ٹھیک کریں (AI کیمرہ)؟'}</span>
                        </span>
                        <span className="text-[10px] text-red-400 font-mono group-hover:translate-x-1 transition">
                          {lang === 'en' ? 'Open &rarr;' : 'اوپن کریں &rarr;'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 font-sans">
                        {lang === 'en'
                          ? 'Instant camera capture, AI error diagnosis, and step-by-step masterclass video guides.'
                          : 'لائیو کیمرہ معائنہ، آواز سے تشریح اور اینیمیٹڈ مرمت ویڈیو گائیڈ۔'}
                      </p>
                    </div>

                    <div
                      onClick={() => setActiveTab('design_editor')}
                      className="p-3.5 rounded-xl bg-gradient-to-r from-blue-950/60 to-slate-900 border border-blue-800/60 hover:border-blue-400 cursor-pointer transition shadow-lg group"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="flex items-center gap-1.5 text-xs font-mono font-bold text-blue-300">
                          <Ruler className="w-4 h-4 text-cyan-400" />
                          <span>{lang === 'en' ? 'Size & Design Editor?' : lang === 'both' ? 'سائز اور ڈیزائن (CAD & RLF)?' : 'سائز اور ڈیزائن ایڈیٹر؟'}</span>
                        </span>
                        <span className="text-[10px] text-cyan-400 font-mono group-hover:translate-x-1 transition">
                          {lang === 'en' ? 'Open &rarr;' : 'اوپن کریں &rarr;'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 font-sans">
                        {lang === 'en'
                          ? 'Resize CAD, RLF, and G-code to fit your wooden panel/dila dimensions and download .nc files.'
                          : 'آر ایل ایف اور جی کوڈ کا سائز اپنے لکڑی کے تختے کے مطابق ایڈجسٹ کریں اور فائل حاصل کریں۔'}
                      </p>
                    </div>

                    {/* Developer & Support Panel */}
                    <DeveloperSupportPanel layout="sidebar" lang={lang} />
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: ⚙️ "مشین چلائیں" (Operation, G-Code & CAD) */}
            {activeTab === 'operation' && (
              <MachineOperationTab
                lang={lang}
                onSelectAssemblyStep={(stepId) => {
                  setCurrentStepId(stepId);
                  setActiveTab('assembly');
                }}
              />
            )}

            {/* TAB 3: 📷 "مشین ٹھیک کریں" (AI Troubleshooting & Camera) */}
            {activeTab === 'troubleshoot' && (
              <VisualTroubleshooter
                currentStep={currentStep}
                lang={lang}
                onSaveToHistory={handleSaveRepairLog}
                onOpenHistory={() => setIsHistoryOpen(true)}
              />
            )}

            {/* TAB 4: 📐 "سائز اور ڈیزائن ایڈیٹر" (3D CAD / RLF / G-Code Resizer & Design Creator) */}
            {activeTab === 'design_editor' && (
              <DesignSizeEditorTab
                lang={lang}
                onSelectAssemblyStep={(stepId) => {
                  setCurrentStepId(stepId);
                  setActiveTab('assembly');
                }}
              />
            )}

            {/* TAB 5: 👤 "پروفائل" (Profile & Google Account) */}
            {activeTab === 'profile' && (
              <ProfileTab
                session={userSession}
                completedStepsCount={completedStepsCount}
                totalStepsCount={CNC_STEPS.length}
                lang={lang}
                onLanguageChange={handleLanguageChange}
                onLogout={handleLogout}
                onDownloadAllData={handleBatchDownload}
                onUpdateSession={(updated) => setUserSession(updated)}
              />
            )}
          </main>

          {/* Prompt Customization & Image Edit Modal */}
          <CADEditModal
            step={currentStep}
            currentImage={generatedImages[currentStep.id] || currentStep.defaultImage}
            isOpen={isEditModalOpen}
            onClose={() => setIsEditModalOpen(false)}
            onApplyImage={(newUrl) => handleImageGenerated(currentStep.id, newUrl)}
            lang={lang}
          />

          {/* Repair History & Activity Log Modal */}
          <RepairHistoryLog
            logs={repairLogs}
            onUpdateLog={handleUpdateRepairLog}
            onDeleteLog={handleDeleteRepairLog}
            onClearAll={handleClearAllLogs}
            lang={lang}
            isOpen={isHistoryOpen}
            onClose={() => setIsHistoryOpen(false)}
          />

          {/* 4. WHATSAPP-STYLE FIXED BOTTOM NAVIGATION BAR (4 Active Tabs in 1 Row) */}
          <BottomNavBar
            activeTab={activeTab}
            onTabChange={(newTab) => setActiveTab(newTab)}
            completedStepsCount={completedStepsCount}
            lang={lang}
          />
        </>
      )}
    </div>
  );
}
