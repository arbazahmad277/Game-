/**
 * Speech Recognition and Text-To-Speech (TTS) utilities
 * Optimized for Workshop Environment with robust Urdu (ur-PK / ur-IN) and English (en-US) support
 */

// Helper to strip markdown and symbols for clean spoken voice
export function cleanTextForSpeech(raw: string): string {
  if (!raw) return '';
  return raw
    .replace(/\*\*(.*?)\*\*/g, '$1') // Bold
    .replace(/\*(.*?)\*/g, '$1')     // Italic
    .replace(/`([^`]+)`/g, '$1')     // Code
    .replace(/^#+\s+/gm, '')         // Headers
    .replace(/^[-*•]\s+/gm, '')      // Bullets
    .replace(/🔍|⚠️|⚙️|🛠️|📐|⚡|🔊|🎤|🛑|✅|🎯|🚀|📋|💡|📌/g, '') // Emojis
    .replace(/[()]/g, ' ')
    .replace(/\n+/g, '. ')          // Line breaks to pause
    .replace(/\s{2,}/g, ' ')
    .trim();
}

let activeUtterance: SpeechSynthesisUtterance | null = null;
let speechKeepAliveInterval: any = null;
let cachedVoices: SpeechSynthesisVoice[] = [];

// Initialize voice listener
if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  const updateVoices = () => {
    try {
      cachedVoices = window.speechSynthesis.getVoices();
    } catch (e) {
      console.warn('Error reading speechSynthesis voices:', e);
    }
  };

  updateVoices();
  if (window.speechSynthesis.onvoiceschanged !== undefined) {
    window.speechSynthesis.onvoiceschanged = updateVoices;
  }
}

export function getAvailableVoices(): SpeechSynthesisVoice[] {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    if (cachedVoices.length === 0) {
      cachedVoices = window.speechSynthesis.getVoices();
    }
    return cachedVoices;
  }
  return [];
}

export function stopSpeaking(): void {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    if (speechKeepAliveInterval) {
      clearInterval(speechKeepAliveInterval);
      speechKeepAliveInterval = null;
    }
    try {
      window.speechSynthesis.cancel();
    } catch (e) {
      console.warn('Error cancelling speech synthesis:', e);
    }
    activeUtterance = null;
  }
}

export function isSpeechSynthesisActive(): boolean {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    return window.speechSynthesis.speaking;
  }
  return false;
}

/**
 * Text-to-Speech in Urdu or English with automatic voice selection and Chrome anti-stall guard
 */
export function speakText(
  text: string,
  lang: 'ur' | 'en' = 'ur',
  onEnd?: () => void,
  onError?: (err: any) => void
): () => void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    console.warn('SpeechSynthesis is not supported in this browser.');
    onError?.('SpeechSynthesis unsupported');
    return () => {};
  }

  // Cancel any active speech cleanly
  stopSpeaking();

  const clean = cleanTextForSpeech(text);
  if (!clean) {
    onEnd?.();
    return () => {};
  }

  try {
    const utterance = new SpeechSynthesisUtterance(clean);
    activeUtterance = utterance;

    // Language prioritization: ur-PK, ur-IN, or phonetic Hindi fallback (hi-IN)
    const targetLang = lang === 'ur' ? 'ur-PK' : 'en-US';
    utterance.lang = targetLang;
    utterance.rate = lang === 'ur' ? 0.92 : 1.0; // Slightly measured rate for clear workshop instructions
    utterance.pitch = 1.0;

    const voices = getAvailableVoices();
    if (voices.length > 0) {
      if (lang === 'ur') {
        // Priority 1: Exact Urdu voice
        const exactUrdu = voices.find(
          (v) =>
            v.lang.toLowerCase().replace('_', '-').startsWith('ur') ||
            v.name.toLowerCase().includes('urdu')
        );
        // Priority 2: Hindi voice (phonetically identical Devanagari/Urdu engine in modern OS)
        const hindiVoice = voices.find(
          (v) =>
            v.lang.toLowerCase().replace('_', '-').startsWith('hi') ||
            v.name.toLowerCase().includes('hindi')
        );
        // Priority 3: South Asian English or default voice
        const fallbackVoice = voices.find(
          (v) =>
            v.lang.toLowerCase().includes('en-in') ||
            v.lang.toLowerCase().includes('en-pk')
        );

        if (exactUrdu) {
          utterance.voice = exactUrdu;
          utterance.lang = exactUrdu.lang;
        } else if (hindiVoice) {
          utterance.voice = hindiVoice;
          utterance.lang = 'hi-IN';
        } else if (fallbackVoice) {
          utterance.voice = fallbackVoice;
        }
      } else {
        const enVoice = voices.find(
          (v) =>
            (v.lang.toLowerCase().startsWith('en') && v.name.includes('Natural')) ||
            v.lang.toLowerCase().startsWith('en-us') ||
            v.lang.toLowerCase().startsWith('en-gb')
        );
        if (enVoice) {
          utterance.voice = enVoice;
        }
      }
    }

    const cleanup = () => {
      if (speechKeepAliveInterval) {
        clearInterval(speechKeepAliveInterval);
        speechKeepAliveInterval = null;
      }
      activeUtterance = null;
    };

    utterance.onend = () => {
      cleanup();
      onEnd?.();
    };

    utterance.onerror = (e) => {
      // Ignore canceled error caused by user stopping
      if (e.error !== 'canceled' && e.error !== 'interrupted') {
        console.warn('SpeechSynthesis error:', e.error);
        onError?.(e);
      }
      cleanup();
    };

    // Chrome anti-stall heartbeat: Chrome stops SpeechSynthesis after ~15 seconds without pause/resume
    speechKeepAliveInterval = setInterval(() => {
      if (window.speechSynthesis && window.speechSynthesis.speaking) {
        window.speechSynthesis.pause();
        window.speechSynthesis.resume();
      } else {
        cleanup();
      }
    }, 10000);

    window.speechSynthesis.speak(utterance);

    return () => {
      stopSpeaking();
    };
  } catch (err) {
    console.warn('Failed to start speech synthesis:', err);
    onError?.(err);
    return () => {};
  }
}

/**
 * Check if browser supports Speech Recognition
 */
export function isSpeechRecognitionSupported(): boolean {
  if (typeof window === 'undefined') return false;
  return Boolean(
    (window as any).SpeechRecognition ||
    (window as any).webkitSpeechRecognition
  );
}

export interface SpeechRecognizerOptions {
  lang?: 'ur' | 'en';
  onResult: (transcript: string, isFinal: boolean) => void;
  onError?: (errorMessage: string, rawError?: any) => void;
  onStart?: () => void;
  onEnd?: () => void;
  continuous?: boolean;
}

/**
 * Factory for creating configured Speech Recognition instances
 */
export function createSpeechRecognizer(options: SpeechRecognizerOptions) {
  if (!isSpeechRecognitionSupported()) {
    options.onError?.('Web Speech API is not supported in this browser.');
    return null;
  }

  const SpeechRecognitionClass =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

  try {
    const recognizer = new SpeechRecognitionClass();
    recognizer.lang = options.lang === 'en' ? 'en-US' : 'ur-PK';
    recognizer.continuous = options.continuous ?? false;
    recognizer.interimResults = true;
    recognizer.maxAlternatives = 1;

    recognizer.onstart = () => {
      options.onStart?.();
    };

    recognizer.onresult = (event: any) => {
      let finalTranscript = '';
      let interimTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript;
        } else {
          interimTranscript += transcript;
        }
      }

      if (finalTranscript) {
        options.onResult(finalTranscript, true);
      } else if (interimTranscript) {
        options.onResult(interimTranscript, false);
      }
    };

    recognizer.onerror = (event: any) => {
      let msg = 'مائیکروفون میں خرابی واقع ہوئی ہے۔';
      if (event.error === 'not-allowed') {
        msg = 'براؤزر نے مائیکروفون کی اجازت نہیں دی (Permission Denied)۔ براہ کرم براؤزر کی سیٹنگز سے مائیک کی اجازت دیں۔';
      } else if (event.error === 'no-speech') {
        msg = 'کوئی آواز موصول نہیں ہوئی۔ براہ کرم دوبارہ واضح بولیں۔';
      } else if (event.error === 'network') {
        msg = 'اسپیچ سرور کے ساتھ انٹرنیٹ کنکشن کا مسئلہ پیش آیا۔';
      }
      options.onError?.(msg, event);
    };

    recognizer.onend = () => {
      options.onEnd?.();
    };

    return recognizer;
  } catch (err: any) {
    options.onError?.(err?.message || 'Failed to initialize speech recognition', err);
    return null;
  }
}
