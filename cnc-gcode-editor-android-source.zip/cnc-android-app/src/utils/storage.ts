import { UserSession } from '../types/auth';
import { CNC_STEPS, CNCStep } from '../data/cncSteps';
import { RepairLog } from '../types/repair';

const STORAGE_KEYS = {
  AUTH_SESSION: 'arbaz_cnc_auth_session_v1',
  COMPLETED_STEPS: 'arbaz_cnc_completed_steps_v1',
  CHECKLIST: 'arbaz_cnc_checklist_items_v1',
  CUSTOM_NOTES: 'arbaz_cnc_custom_notes_v1',
  REPAIR_LOGS: 'cnc_repair_history_logs',
  OFFLINE_CACHE: 'arbaz_cnc_offline_steps_cache_v1',
  OFFLINE_READY: 'arbaz_cnc_offline_ready_v1',
  LANGUAGE: 'arbaz_cnc_language_pref_v1',
  SAVED_GCODES: 'arbaz_cnc_saved_gcodes_v1',
  WORKSHOP_SETTINGS: 'arbaz_cnc_workshop_settings_v1',
};

// ================= AUTHENTICATION SESSION =================

export function getStoredUserSession(): UserSession | null {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.AUTH_SESSION);
    if (!data) return null;
    return JSON.parse(data) as UserSession;
  } catch (err) {
    console.error('Error reading auth session from storage:', err);
    return null;
  }
}

export function saveUserSession(session: UserSession): void {
  try {
    localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, JSON.stringify(session));
  } catch (err) {
    console.error('Error saving auth session to storage:', err);
  }
}

export function clearUserSession(): void {
  try {
    localStorage.removeItem(STORAGE_KEYS.AUTH_SESSION);
  } catch (err) {
    console.error('Error clearing auth session:', err);
  }
}

// ================= STEP COMPLETION PROGRESS (1-30) =================

export function getCompletedSteps(): Record<number, boolean> {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.COMPLETED_STEPS);
    if (!data) {
      // Default step 1 is marked as completed or started
      return { 1: true };
    }
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading completed steps:', err);
    return { 1: true };
  }
}

export function saveCompletedSteps(completedMap: Record<number, boolean>): void {
  try {
    localStorage.setItem(STORAGE_KEYS.COMPLETED_STEPS, JSON.stringify(completedMap));
  } catch (err) {
    console.error('Error saving completed steps:', err);
  }
}

export function toggleStepCompleted(stepId: number): Record<number, boolean> {
  const current = getCompletedSteps();
  current[stepId] = !current[stepId];
  saveCompletedSteps(current);
  return current;
}

// ================= STEP CHECKLIST =================

export function getStoredChecklist(): Record<string, boolean> {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.CHECKLIST);
    return data ? JSON.parse(data) : {};
  } catch (err) {
    console.error('Error reading checklist:', err);
    return {};
  }
}

export function saveChecklist(checklist: Record<string, boolean>): void {
  try {
    localStorage.setItem(STORAGE_KEYS.CHECKLIST, JSON.stringify(checklist));
  } catch (err) {
    console.error('Error saving checklist:', err);
  }
}

// ================= CUSTOM NOTES & SPECS PER STEP =================

export function getStoredNotes(): Record<number, string> {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.CUSTOM_NOTES);
    return data ? JSON.parse(data) : {};
  } catch (err) {
    console.error('Error reading notes:', err);
    return {};
  }
}

export function saveStepNote(stepId: number, note: string): void {
  try {
    const current = getStoredNotes();
    current[stepId] = note;
    localStorage.setItem(STORAGE_KEYS.CUSTOM_NOTES, JSON.stringify(current));
  } catch (err) {
    console.error('Error saving note:', err);
  }
}

// ================= OFFLINE CACHE FOR ALL 30 STEPS =================

export function isOfflineDataReady(): boolean {
  try {
    const flag = localStorage.getItem(STORAGE_KEYS.OFFLINE_READY);
    return flag === 'true';
  } catch {
    return false;
  }
}

export function cacheAllStepsOffline(): { count: number; timestamp: string } {
  try {
    const payload = {
      version: '1.0',
      cachedAt: new Date().toISOString(),
      totalSteps: CNC_STEPS.length,
      steps: CNC_STEPS,
    };
    localStorage.setItem(STORAGE_KEYS.OFFLINE_CACHE, JSON.stringify(payload));
    localStorage.setItem(STORAGE_KEYS.OFFLINE_READY, 'true');
    return { count: CNC_STEPS.length, timestamp: payload.cachedAt };
  } catch (err) {
    console.error('Error caching steps offline:', err);
    return { count: CNC_STEPS.length, timestamp: new Date().toISOString() };
  }
}

export function getCachedStepsOffline(): CNCStep[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.OFFLINE_CACHE);
    if (!data) return CNC_STEPS;
    const parsed = JSON.parse(data);
    return parsed.steps || CNC_STEPS;
  } catch {
    return CNC_STEPS;
  }
}

// ================= REPAIR HISTORY LOGS =================

export function getStoredRepairLogs(initialFallback: RepairLog[]): RepairLog[] {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.REPAIR_LOGS);
    if (saved) return JSON.parse(saved);
  } catch (e) {
    console.warn('Failed to load logs from localStorage');
  }
  return initialFallback;
}

export function saveRepairLogs(logs: RepairLog[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.REPAIR_LOGS, JSON.stringify(logs));
  } catch (e) {
    console.warn('Failed to save logs to localStorage');
  }
}

// ================= LANGUAGE PREFERENCE =================

export function getStoredLanguage(): 'ur' | 'en' | 'both' {
  try {
    const lang = localStorage.getItem(STORAGE_KEYS.LANGUAGE);
    if (lang === 'ur' || lang === 'en' || lang === 'both') return lang;
  } catch {}
  return 'ur';
}

export function saveStoredLanguage(lang: 'ur' | 'en' | 'both'): void {
  try {
    localStorage.setItem(STORAGE_KEYS.LANGUAGE, lang);
  } catch {}
}

// ================= SAVED G-CODE PROGRAMS =================

export interface SavedGcodeProgram {
  id: string;
  name: string;
  description: string;
  date: string;
  material: string;
  code: string;
  estimatedTime: string;
}

export const DEFAULT_GCODE_PROGRAMS: SavedGcodeProgram[] = [
  {
    id: 'gcode-spoilboard',
    name: 'Spoilboard Resurfacing (1000x800mm)',
    description: 'Flycutter / Surfacing bit leveling pass across entire MDF spoilboard with 40% stepover',
    date: '2026-10-10',
    material: 'MDF 18mm',
    estimatedTime: '8 min',
    code: `(--- ARBAZ WOOD CRAFT: SPOILBOARD SURFACING ---)
G21 (Metric Units)
G90 (Absolute Coordinates)
G17 (XY Plane)
G0 Z25.000 (Safe Height)
M3 S18000 (Spindle On 18,000 RPM)
G4 P3.0 (Wait for Spindle Spool-up)
G0 X0.000 Y0.000
G1 Z-0.500 F600 (Plunge 0.5mm into Spoilboard)
G1 X1000.000 F3500
G1 Y40.000
G1 X0.000
G1 Y80.000
G1 X1000.000
G1 Y120.000
G1 X0.000
G1 Y160.000
G1 X1000.000
G0 Z25.000 (Retract)
M5 (Spindle Off)
G0 X0.000 Y0.000 (Return Home)
M30 (End Program)`,
  },
  {
    id: 'gcode-box-joint',
    name: 'Sheesham Wood Dovetail & Pocket Pass',
    description: 'Precision 6mm spiral upcut bit cutting 12mm depth pockets for traditional furniture joints',
    date: '2026-10-10',
    material: 'Sheesham Hardwood',
    estimatedTime: '14 min',
    code: `(--- ARBAZ WOOD CRAFT: SHEESHAM WOOD POCKET ---)
G21 (Metric)
G90 (Absolute)
G0 Z20.000
M3 S16000 (16000 RPM for dense Sheesham)
G4 P2.0
G0 X50.000 Y50.000
G1 Z-3.000 F800 (Pass 1)
G1 X150.000 F2400
G1 Y100.000
G1 X50.000
G1 Y50.000
G1 Z-6.000 F800 (Pass 2)
G1 X150.000 F2400
G1 Y100.000
G1 X50.000
G1 Y50.000
G0 Z25.000
M5
G0 X0.000 Y0.000
M30`,
  },
  {
    id: 'gcode-circle-cutout',
    name: 'Circular Boss / Rosette Medallion (Diameter 200mm)',
    description: 'Circular helical pocketing for ceiling or door wooden medallions',
    date: '2026-10-10',
    material: 'Walnut / Deodar Wood',
    estimatedTime: '6 min',
    code: `(--- ARBAZ WOOD CRAFT: CIRCULAR ROSETTE ---)
G21 G90 G17
G0 Z20.000
M3 S18000
G0 X100.000 Y0.000
G1 Z-4.000 F700
G2 X100.000 Y0.000 I-100.000 J0.000 F2800 (Circular Arc)
G1 Z-8.000 F700
G2 X100.000 Y0.000 I-100.000 J0.000 F2800
G0 Z25.000
M5
G0 X0 Y0
M30`,
  },
];

export function getStoredGcodePrograms(): SavedGcodeProgram[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SAVED_GCODES);
    if (!data) return DEFAULT_GCODE_PROGRAMS;
    return JSON.parse(data);
  } catch {
    return DEFAULT_GCODE_PROGRAMS;
  }
}

export function saveGcodeProgram(program: SavedGcodeProgram): void {
  try {
    const current = getStoredGcodePrograms();
    const updated = [program, ...current.filter((p) => p.id !== program.id)];
    localStorage.setItem(STORAGE_KEYS.SAVED_GCODES, JSON.stringify(updated));
  } catch (err) {
    console.error('Error saving G-code program:', err);
  }
}
