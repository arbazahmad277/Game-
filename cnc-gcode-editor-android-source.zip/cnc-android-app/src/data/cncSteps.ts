/**
 * Comprehensive 30-Step Industrial CNC Router Assembly Roadmap
 * مکمل 30 سٹیپ CNC روٹر اسیمبلی گائیڈ اور 3D CAD نقشہ جات
 */

export interface CNCStep {
  id: number;
  phaseId: number;
  phaseNameUrdu: string;
  phaseNameEn: string;
  titleUrdu: string;
  titleEn: string;
  shortSummaryUrdu: string;
  shortSummaryEn: string;
  descriptionUrdu: string;
  descriptionEn: string;
  cadPrompt: string;
  tools: string[];
  components: string[];
  specs: {
    torque?: string;
    tolerance?: string;
    fastener?: string;
    criticalCheck: string;
  };
  proTipUrdu: string;
  proTipEn: string;
  defaultImage: string;
  svgSchemaType:
    | 'base_frame'
    | 'cross_members'
    | 'leveling_feet'
    | 'y_rails'
    | 'sub_bed'
    | 'bearing_blocks'
    | 'ball_screws_y'
    | 'floating_bearings'
    | 'stepper_y'
    | 'endstops_y'
    | 'gantry_risers'
    | 'gantry_beam'
    | 'x_rails'
    | 'ball_screw_x'
    | 'stepper_x'
    | 'z_backplate'
    | 'z_rails'
    | 'z_leadscrew'
    | 'spindle_mount'
    | 'spindle_motor'
    | 'drag_chains'
    | 'limit_switches'
    | 'dial_tramming'
    | 'lubrication'
    | 'control_box'
    | 'power_supplies'
    | 'stepper_drivers'
    | 'vfd_inverter'
    | 'software_tuning'
    | 'spoilboard_firstcut';
}

export const CNC_STEPS: CNCStep[] = [
  // ================= PHASE 1: Base Frame & Bed Structure (سٹیپ 1 تا 5) =================
  {
    id: 1,
    phaseId: 1,
    phaseNameUrdu: 'فیز 1: بنیادی فریم اور بیڈ اسٹرکچر',
    phaseNameEn: 'Phase 1: Base Frame & Bed Structure',
    titleUrdu: 'بنیادی فریم ایلومینیم ایکسٹروژنز اور 90 ڈگری جوائنٹس',
    titleEn: 'Base Frame Aluminium Extrusions Assembly (4040/4080 Profiles)',
    shortSummaryUrdu: 'چاروں مین بیرونی پروفائلز کو کاسٹ ایلومینیم کونے بریکٹس اور ٹی نٹس سے جوڑیں۔',
    shortSummaryEn: 'Assemble outer 4040/4080 extrusion perimeter using heavy cast corner brackets and drop-in T-nuts.',
    descriptionUrdu: 'سب سے پہلے ایک ہموار اور چپٹی سطح پر دونوں لمبی 4080 سائیڈ بیمز اور دونوں عرضی 4040 بیمز کو رکھیں۔ ڈراپ ان ٹی-نٹس اور M5x10mm بٹن ہیڈ بولٹس کی مدد سے 90 ڈگری کاسٹ ایلومینیم کونے بریکٹس فکس کریں۔ دونوں ڈائیگنلز (Diagonals) کو میٹر ٹیپ سے ناپیں تاکہ فرق 0.5 ملی میٹر سے کم ہو۔',
    descriptionEn: 'Lay out the two longitudinal 4080 profiles and two transverse 4040 cross members on a flat granite or workbench. Fasten internal heavy cast brackets using M5x10mm screws and drop-in roll-in T-nuts. Measure diagonal distances corner-to-corner; ensure disparity is within ±0.5 mm before final torquing.',
    cadPrompt: 'Isometric 3D CAD blueprint technical engineering drawing of CNC router Step 1: Base frame outer rectangle 4040 aluminum extrusions with cast 90-degree corner gussets, M5 button head bolts, exploded joint view, dark cyan technical blueprint grid background, glowing cyan precision lines, millimeter dimensions.',
    tools: ['Machinist Square 300mm', '4mm Allen Hex Key', 'Steel Measuring Tape', 'Digital Caliper'],
    components: ['4080 Aluminium Profile (x2 1000mm)', '4040 Aluminium Profile (x2 750mm)', 'Cast Corner Brackets (x8)', 'M5 Drop-in T-Nuts (x16)', 'M5x10mm BHCS (x16)'],
    specs: {
      torque: '9.0 N·m',
      tolerance: '±0.5 mm diagonal squareness',
      fastener: 'M5 Class 10.9 Steel',
      criticalCheck: 'Verify perfect 90° internal corner right angles before tightening.',
    },
    proTipUrdu: 'بولٹس کو پہلے ہلکا سا ٹائٹ کریں، ڈائیگنل ناپیں، پھر مخالف سمتوں میں باری باری فل ٹارک لگائیں۔',
    proTipEn: 'Cross-torque fasteners gradually in a diagonal sequence rather than tightening one corner completely at once.',
    defaultImage: '/src/assets/images/cnc_base_frame_cad_1791448908736.jpg',
    svgSchemaType: 'base_frame',
  },
  {
    id: 2,
    phaseId: 1,
    phaseNameUrdu: 'فیز 1: بنیادی فریم اور بیڈ اسٹرکچر',
    phaseNameEn: 'Phase 1: Base Frame & Bed Structure',
    titleUrdu: 'فریم کے درمیانی کراس ممبرز اور اسٹرکچرل ری انفورسمنٹ',
    titleEn: 'Cross Members & Bed Stiffeners Installation',
    shortSummaryUrdu: 'بیڈ کے نیچے 3 اضافی 4040 پروفائلز فکس کریں تاکہ ہیوی کٹنگ فورس میں بینڈنگ نہ آئے۔',
    shortSummaryEn: 'Install 3 intermediate 4040 transverse support beams across the base frame for extreme rigidity.',
    descriptionUrdu: 'فریم کے درمیان برابر فاصلے (ہر 200 ملی میٹر بعد) پر تین 4040 پروفائلز داخل کریں۔ ان کے دونوں سروں پر ہائی اسٹرینتھ ایل-بریکٹس لگائیں۔ یہ بیڈ کو کٹنگ اور گینٹری کے وزن کے دوران لچکنے (sagging) سے روکتے ہیں۔',
    descriptionEn: 'Slide three transverse 4040 bed supports equally spaced along the chassis. Secure with heavy hidden internal corner joints and angle brackets. This prevents frame sag under heavy aluminum and hardwood carving workloads.',
    cadPrompt: '3D CAD technical blueprint schematic of CNC Step 2: Intermediate cross member support ribs inside CNC base frame, isometric wireframe view, dimension callouts showing 200mm spacing, exploded bracket hardware, dark blue blueprint grid with cyan lines.',
    tools: ['4mm Hex Wrench', 'Feeler Gauge', 'Precision Level'],
    components: ['4040 Cross Extrusions (x3 750mm)', 'Internal Hidden T-Joints (x6)', 'M6 Grub Screws (x12)'],
    specs: {
      torque: '10.5 N·m',
      tolerance: '0.1 mm coplanar bed surface',
      fastener: 'M6 Grade 12.9 Set Screws',
      criticalCheck: 'Top surfaces of all cross members must sit completely flush with outer perimeter rails.',
    },
    proTipUrdu: 'تمام کراس ممبرز کی اوپری سطح کو اسٹریٹ ایج رولر رکھ کر چیک کریں کہ کوئی اونچا یا نیچا نہ ہو۔',
    proTipEn: 'Run a precision straight edge across all 5 cross members to ensure zero crown or dip.',
    defaultImage: '/src/assets/images/cnc_base_frame_cad_1791448908736.jpg',
    svgSchemaType: 'cross_members',
  },
  {
    id: 3,
    phaseId: 1,
    phaseNameUrdu: 'فیز 1: بنیادی فریم اور بیڈ اسٹرکچر',
    phaseNameEn: 'Phase 1: Base Frame & Bed Structure',
    titleUrdu: 'اینٹی وائبریشن لیولنگ فٹ اور فاؤنڈیشن ماؤنٹس',
    titleEn: 'Base Leveling Feet & Vibration Dampening Pads',
    shortSummaryUrdu: 'فریم کے چاروں کونوں پر ربر پیڈز والے M12 ایڈجسٹ ایبل لیولنگ فٹ فکس کریں۔',
    shortSummaryEn: 'Thread heavy-duty M12 vibration-damped leveling feet into threaded end plates at all 4 frame corners.',
    descriptionUrdu: 'فریم کے چاروں سروں پر ٹیپ شدہ M12 اینڈ کیپس یا کارنر اینکر پلیٹس لگائیں۔ ربر پیڈ والے ہیوی ڈیوٹی لیولنگ فٹ گھما کر اندر کریں اور مشین کو ورک بینچ پر ببل لیول کے ذریعے ہر طرف سے پرفیکٹ ہوریزونٹل سیدھ میں لائیں۔',
    descriptionEn: 'Install M12 threaded bottom plates into the 4 corners of the outer chassis. Screw in vibration-dampening articulated rubber feet. Place a precision bubble level across X and Y axes and adjust the foot collars until the chassis is perfectly planar.',
    cadPrompt: '3D CAD technical engineering view of CNC Step 3: Base corner M12 articulated leveling foot with nitrile vibration dampening pad, lock nut collar, threaded base bracket assembly, isometric CAD exploded view, dark blueprint theme.',
    tools: ['19mm Open Spanner', 'Machinist Bubble Spirit Level 0.02mm/m'],
    components: ['M12 Rubber Dampened Leveling Feet (x4)', 'M12 End Tap Mounting Plates (x4)', 'M12 Jam Nuts (x4)'],
    specs: {
      torque: 'Lock nut jam tight',
      tolerance: '< 0.05 mm tilt per meter',
      fastener: 'M12 Zinc Plated Steel Thread',
      criticalCheck: 'Verify that all 4 feet bear uniform ground weight without any rocking diagonal rocking.',
    },
    proTipUrdu: 'لاک نٹ (Jam Nut) کو ضرور سخت کریں تاکہ موٹرز کے ہائی اسپیڈ وائبریشن سے پاؤں خود بخود ڈھیلے نہ ہوں۔',
    proTipEn: 'Tighten the locking jam nuts firmly against the chassis plate to lock the height calibration.',
    defaultImage: '/src/assets/images/cnc_base_frame_cad_1791448908736.jpg',
    svgSchemaType: 'leveling_feet',
  },
  {
    id: 4,
    phaseId: 1,
    phaseNameUrdu: 'فیز 1: بنیادی فریم اور بیڈ اسٹرکچر',
    phaseNameEn: 'Phase 1: Base Frame & Bed Structure',
    titleUrdu: 'وائی ایکسس (Y-Axis) لکیری ریلز ماؤنٹنگ اور الائنمنٹ',
    titleEn: 'Y-Axis Linear Rail Mounting Surfaces & Squaring (MGN15 / HGR20)',
    shortSummaryUrdu: 'فریم کی لمبائی پر دونوں MGN15 یا HGR20 اسٹیل لکیری ریلز کو ڈائل گیج سے سیدھا کر کے لگائیں۔',
    shortSummaryEn: 'Mount precision steel linear guide rails onto the top surfaces of the longitudinal frame extrusions.',
    descriptionUrdu: '4080 سائیڈ پروفائلز کی اوپری نالیوں میں M4/M5 ٹی-نٹس ڈالیں۔ لکیری ریلز کو اوپر رکھیں۔ ایک ریل کو ڈیٹم (Datum) فریم کنارے کے ساتھ بالکل فکس کریں۔ دوسری ریل کے بولٹس ہلکے چھوڑیں تاکہ گینٹری موشن کے ذریعے ڈائل انڈیکیٹر الائنمنٹ کی جا سکے۔',
    descriptionEn: 'Clean extrusion rail slots thoroughly with isopropanol. Insert M4/M5 roll-in T-nuts and position the precision linear rails. Fully torque the master reference rail along the machined extrusion lip, leaving the slave rail snug for dial indicator tramming.',
    cadPrompt: '3D CAD blueprint diagram Step 4: CNC Y-axis precision HGR20 linear guide rails being bolted onto 4080 aluminum extrusions, dial test indicator needle calibration against reference edge, cyan glowing vector lines on dark blueprint background.',
    tools: ['Magnetic Base Dial Indicator', '3mm Hex Key', 'Torque Screwdriver', 'Degreaser Cloth'],
    components: ['HGR20/MGN15 Linear Guide Rails (x2 1000mm)', 'M4x12mm Socket Head Screws (x40)', 'M4 Roll-in Spring T-Nuts (x40)'],
    specs: {
      torque: '4.5 N·m',
      tolerance: '< 0.02 mm parallelism along 1000mm',
      fastener: 'M4 Grade 12.9 Black Oxide',
      criticalCheck: 'Zero binding or drag when sliding reference blocks manually from end to end.',
    },
    proTipUrdu: 'ریل کے ہر بولٹ کو بیچ سے شروع کر کے دونوں کناروں کی طرف باری باری ٹائٹ کریں تاکہ ریل میں لہر نہ بنے۔',
    proTipEn: 'Fasten rail bolts starting from the absolute center and work outward toward both ends to avoid bowing.',
    defaultImage: '/src/assets/images/cnc_base_frame_cad_1791448908736.jpg',
    svgSchemaType: 'y_rails',
  },
  {
    id: 5,
    phaseId: 1,
    phaseNameUrdu: 'فیز 1: بنیادی فریم اور بیڈ اسٹرکچر',
    phaseNameEn: 'Phase 1: Base Frame & Bed Structure',
    titleUrdu: 'ٹی سلاٹ ایلومینیم بیڈ بیس پلیٹس کی فکسنگ',
    titleEn: 'T-Slot Aluminium Wasteboard Sub-Bed Base Plates',
    shortSummaryUrdu: 'کراس ممبرز پر ہیوی ٹی سلاٹ ایلومینیم سلیٹس کس دیں جو ورک پیس کلیمپنگ اور بیس فراہم کریں۔',
    shortSummaryEn: 'Fasten heavy extruded aluminum T-track sub-bed slats over the cross members to form rigid clamping foundation.',
    descriptionUrdu: 'فریم کے اندرونی کراس ممبرز کے اوپر ایلومینیم ٹی-سلاٹ پروفائل سلیبز بچھائیں۔ ان کو کاؤنٹر سنک بولٹس کے ساتھ فریم پر ٹائٹ کریں۔ یہ سلیٹس میٹریل کلیمپ کرنے کے لیے ٹی-بولٹس پکڑتی ہیں اور فریم کو زبردست مروڑ والی مضبوطی (torsional stiffness) دیتی ہیں۔',
    descriptionEn: 'Bolt modular T-slot aluminum tooling plates across the cross-members using countersunk M6 flat-head screws. This rigid sub-bed locks the chassis geometry and provides anchored slots for hold-down clamps and future spoilboard mounting.',
    cadPrompt: '3D CAD technical engineering model Step 5: Heavy duty aluminum T-slot bed slats mounted to CNC frame, showing T-tracks, countersunk fasteners, isometric technical schematic, dark CAD grid background with dimensional arrows.',
    tools: ['5mm Allen Wrench', 'Torx Key T30', 'Machinist Square'],
    components: ['Aluminium T-Slot Bed Slats (x5)', 'M6x16mm Countersunk Screws (x30)', 'M6 Hammer Nuts (x30)'],
    specs: {
      torque: '8.0 N·m',
      tolerance: '< 0.1 mm flatness',
      fastener: 'M6 Flat Head DIN 7991',
      criticalCheck: 'Countersunk bolt heads must sit fully recessed below the T-slot surface.',
    },
    proTipUrdu: 'بولٹس کے ہیڈ سلیٹ کی سطح سے نیچے ہونے چاہئیں ورنہ ملنگ کے دوران کٹر بولٹ سے ٹکرا سکتا ہے۔',
    proTipEn: 'Double check with your fingertip that every countersunk screw sits 0.5mm beneath the slat top surface.',
    defaultImage: '/src/assets/images/cnc_base_frame_cad_1791448908736.jpg',
    svgSchemaType: 'sub_bed',
  },

  // ================= PHASE 2: Y-Axis Motion System & Drive (سٹیپ 6 تا 10) =================
  {
    id: 6,
    phaseId: 2,
    phaseNameUrdu: 'فیز 2: وائی ایکسس موشن سسٹم اور ڈرائیو',
    phaseNameEn: 'Phase 2: Y-Axis Motion System & Drive',
    titleUrdu: 'وائی ایکسس لکیری بیئرنگ بلاکس کی تنصیب اور ریل انسرشن',
    titleEn: 'Y-Axis Linear Guide Blocks (HGH20CA) & Grease Port Prep',
    shortSummaryUrdu: 'لکیری ریلز پر احتیاط سے بال بیرنگ بلاکس چڑھائیں اور پلاسٹک گائیڈز کو آہستہ سے باہر دھکیلیں۔',
    shortSummaryEn: 'Carefully slide recirculating ball bearing carriages onto linear rails without dropping loose steel balls.',
    descriptionUrdu: 'دونوں Y ریلز پر دو دو HGH20CA بیرنگ بلاکس سلائیڈ کریں۔ دھیان رکھیں کہ فیکٹری پلاسٹک آربر کو ریل کے سرے سے ملا کر بلاک کو ریل پر دھکیلیں تاکہ کوئی اسٹیل بال باہر نہ گرے۔ بلاک پر M6 گریس نپل کسیں اور سلائیڈ کی ہمواری چیک کریں۔',
    descriptionEn: 'Align each bearing carriage plastic retainer bridge with the chamfered rail end and smoothly slide two carriages onto each rail. Never force or misalign, or tiny steel balls will escape. Install grease zerks and apply a light wipe of ISO VG68 oil.',
    cadPrompt: '3D CAD technical blueprint Step 6: Recirculating ball bearing carriage HGH20CA sliding onto linear guide rail with plastic mandrel guide, grease nipple lubrication port callout, exploded bearing balls cutaway view, dark cyan blueprint background.',
    tools: ['Clean Lint-Free Cloth', 'Grease Zerk 7mm Wrench', 'Magnifying Glass'],
    components: ['HGH20CA / MGN15H Bearing Blocks (x4)', 'M6 Grease Fittings (x4)', 'Dust Scraper Seals (x4)'],
    specs: {
      torque: 'Grease zerk 2.0 N·m',
      tolerance: 'Zero backlash smooth glide',
      fastener: 'M6 Brass Grease Zerk',
      criticalCheck: 'Smooth free-gliding travel without catching, friction spikes, or rough gritty resistance.',
    },
    proTipUrdu: 'اگر بلاک پھنس رہا ہو تو ریل کے سرے پر لبریکنٹ لگائیں، زور سے مت دھکیلیں۔',
    proTipEn: 'Oil the chamfered end of the rail before insertion; never attempt to mount without the factory plastic guide.',
    defaultImage: '/src/assets/images/cnc_gantry_assembly_cad_1791448922691.jpg',
    svgSchemaType: 'bearing_blocks',
  },
  {
    id: 7,
    phaseId: 2,
    phaseNameUrdu: 'فیز 2: وائی ایکسس موشن سسٹم اور ڈرائیو',
    phaseNameEn: 'Phase 2: Y-Axis Motion System & Drive',
    titleUrdu: 'ڈوئل وائی ایکسس بال اسکرو (SFU1605) اور BK12 فکسڈ بیرنگ بلاکس',
    titleEn: 'Dual Y-Axis Ball Screws (SFU1605/1610) & Fixed BK12 Bearing Mounts',
    shortSummaryUrdu: 'موٹر والے سرے پر پریسیژن اینگولر کنٹیکٹ BK12 بیرنگ بلاک فکس کریں جو تمام محوری دباؤ برداشت کرے۔',
    shortSummaryEn: 'Install rigid BK12 fixed angular contact bearing units on motor end of frame to absorb axial thrust.',
    descriptionUrdu: 'SFU1605 گراؤنڈ بال اسکرو کے مشینی سرے کو BK12 ڈوئل اینگولر بیرنگ بلاک میں داخل کریں۔ بیرنگ کے اندر لاک نٹ اور M4 اسپائڈر سیٹ اسکرو کو پرفیکٹ پری لوڈ کے ساتھ ٹائٹ کریں۔ بیرنگ بلاک کو فریم پر M6 بولٹس سے الائن کر کے ماؤنٹ کریں۔',
    descriptionEn: 'Press the machined journals of both SFU1605 ballscrews into BK12 fixed bearing blocks equipped with dual matched angular contact bearings. Secure the precision ground locknut to establish bearing preload and torque locking set screw.',
    cadPrompt: '3D CAD engineering blueprint Step 7: Precision ground SFU1605 ball screw inserted into BK12 angular contact fixed bearing block, locknut preload schematic, isometric exploded hardware view, cyan technical line art on blueprint grid.',
    tools: ['Pin Spanner Wrench', '5mm Hex Key', 'Threadlocker Blue (Loctite 243)'],
    components: ['SFU1605 Precision Ball Screws (x2 1050mm)', 'BK12 Fixed Bearing Blocks (x2)', 'M12x1mm Precision Locknuts (x2)'],
    specs: {
      torque: 'Locknut 22 N·m + Loctite',
      tolerance: '< 0.01 mm axial play',
      fastener: 'M6 Socket Head Cap Screws',
      criticalCheck: 'Zero axial slop or forward/reverse end-play when pushed hard by hand.',
    },
    proTipUrdu: 'لاک نٹ کے تھریڈز پر نیلا اینٹی لوزنگ لاکیٹ لگائیں تاکہ سالہا سال کی ریورس موشن میں ڈھیلا نہ ہو۔',
    proTipEn: 'Degrease the threads and apply medium-strength Loctite 243 to prevent locknut backing out under heavy rapid travels.',
    defaultImage: '/src/assets/images/cnc_gantry_assembly_cad_1791448922691.jpg',
    svgSchemaType: 'ball_screws_y',
  },
  {
    id: 8,
    phaseId: 2,
    phaseNameUrdu: 'فیز 2: وائی ایکسس موشن سسٹم اور ڈرائیو',
    phaseNameEn: 'Phase 2: Y-Axis Motion System & Drive',
    titleUrdu: 'دوسرے سرے کے BF12 فلوٹنگ بیرنگ ماؤنٹس اور بال اسکرو رن آؤٹ',
    titleEn: 'Driven End BF12 Floating Bearing Mounts & Axial Runout Check',
    shortSummaryUrdu: 'دوسرے سرے پر سنگل ڈیپ گروو BF12 بیرنگ لگائیں اور اسکرو کو گھما کر اس کا رن آؤٹ چیک کریں۔',
    shortSummaryEn: 'Secure the BF12 floating bearing at the far ends with snap rings to accommodate thermal expansion.',
    descriptionUrdu: 'بال اسکرو کے پچھلے سرے پر BF12 بیرنگ چڑھا کر سرکلپ (Snap Ring) سے لاک کریں۔ یہ بیرنگ فلوٹنگ ہوتا ہے تاکہ درجہ حرارت کی تبدیلی اور تھرمل ایکسپینشن کی وجہ سے بال اسکرو مڑ نہ جائے۔ اسکرو کو ہاتھ سے گھما کر ڈائل گیج پر رن آؤٹ چیک کریں۔',
    descriptionEn: 'Slip the BF12 deep-groove ball bearing over the tail journal and install the external circlip. This floating mount allows longitudinal thermal expansion without buckling the screw. Spin the screw by hand and verify radial runout is under 0.03mm.',
    cadPrompt: '3D CAD technical blueprint Step 8: BF12 floating bearing block with retaining circlip snap ring on end of ball screw shaft, dial indicator checking radial runout, isometric CAD view with engineering callouts.',
    tools: ['External Circlip Pliers', 'Dial Indicator Gauge', '5mm Hex Wrench'],
    components: ['BF12 Floating Bearing Units (x2)', '10mm External Snap Rings (x2)', 'M6x25mm Mounting Bolts (x4)'],
    specs: {
      torque: '9.0 N·m on frame mounts',
      tolerance: '< 0.03 mm radial runout',
      fastener: 'Spring Steel Circlip DIN 471',
      criticalCheck: 'Snap ring must seat completely inside the machined shaft groove.',
    },
    proTipUrdu: 'اگر گھمانے پر اسکرو میں ووبل (Wobble) نظر آئے تو BF12 بلاک کے فریم بولٹس ڈھیلے کر کے گھمائیں اور پھر کَسیں۔',
    proTipEn: 'Leave the BF12 mounting bolts finger-tight, spin the ball screw rapidly to self-center, then torque down.',
    defaultImage: '/src/assets/images/cnc_gantry_assembly_cad_1791448922691.jpg',
    svgSchemaType: 'floating_bearings',
  },
  {
    id: 9,
    phaseId: 2,
    phaseNameUrdu: 'فیز 2: وائی ایکسس موشن سسٹم اور ڈرائیو',
    phaseNameEn: 'Phase 2: Y-Axis Motion System & Drive',
    titleUrdu: 'وائی ایکسس NEMA 23/34 اسٹیپر موٹرز اور لچکدار کپلرز',
    titleEn: 'NEMA 23/34 Stepper Motor Mounts & Flexible Jaw Couplers',
    shortSummaryUrdu: 'ڈوئل ہائی ٹارک اسٹیپر موٹرز کو ایلومینیم بریکٹس اور پولی یورپتھین اسپائیڈر کپلرز سے جوڑیں۔',
    shortSummaryEn: 'Mount dual high-torque NEMA steppers to the frame brackets using CNC machined flexible jaw couplers.',
    descriptionUrdu: 'BK12 بریکٹ کے پیچھے NEMA موٹر ماؤنٹنگ پلیٹ کسیں۔ 8mm سے 10mm ایلومینیم پلم فلیکسیبل کپلر موٹر شافٹ اور بال اسکرو شافٹ کے درمیان لگائیں۔ کپلر کے دونوں بولٹس میں تھریڈ لاکر لگا کر فل ٹائٹ کریں۔ موٹر شافٹ کا فلیٹ کٹ کپلر کے بولٹ کے سامنے ہونا چاہیے۔',
    descriptionEn: 'Install NEMA 23 (or 34) stepper motors onto the motor standoffs. Mate the 8mm motor shaft to the 10mm ballscrew journal using an elastomer spider flexible jaw coupler. Ensure the clamping bolt bites squarely onto the motor shaft D-flat.',
    cadPrompt: '3D CAD technical drawing Step 9: NEMA 23 closed loop stepper motor with 8mm to 10mm aluminum plum jaw flexible coupler, red polyurethane elastomer spider dampener, motor mounting bracket, dark blueprint background with wireframe annotations.',
    tools: ['3mm & 4mm Hex Keys', 'Motor Shaft Feeler Spacers'],
    components: ['NEMA 23 High Torque Steppers (x2 3.0N·m)', 'Flexible Jaw Couplers 8x10mm (x2)', 'Aluminium Motor Spacers (x8)', 'M5x35mm Bolts (x8)'],
    specs: {
      torque: 'Motor bolts 5.0 N·m, Coupler clamps 4.2 N·m',
      tolerance: '< 0.1 mm shaft coaxiality',
      fastener: 'M5 Grade 10.9 Zinc Plated',
      criticalCheck: 'Leave a 2mm gap inside coupler so motor shaft never presses metal-to-metal against ballscrew.',
    },
    proTipUrdu: 'موٹر شافٹ اور بال اسکرو کے درمیان کپلر کے اندر 2 ملی میٹر کا گیپ رکھیں تاکہ وائبریشن براہ راست موٹر بیئرنگ پر نہ جائے۔',
    proTipEn: 'Never bottom out both shafts inside the coupler; maintain a 2mm axial expansion relief zone.',
    defaultImage: '/src/assets/images/cnc_gantry_assembly_cad_1791448922691.jpg',
    svgSchemaType: 'stepper_y',
  },
  {
    id: 10,
    phaseId: 2,
    phaseNameUrdu: 'فیز 2: وائی ایکسس موشن سسٹم اور ڈرائیو',
    phaseNameEn: 'Phase 2: Y-Axis Motion System & Drive',
    titleUrdu: 'وائی ایکسس مکینیکل ہومنگ بمپرز اور ہارڈ اینڈ اسٹاپس',
    titleEn: 'Y-Axis Endstops & Mechanical Crash Bumpers',
    shortSummaryUrdu: 'ریل کے دونوں کناروں پر ربر بمپرز لگائیں تاکہ گینٹری موشن کے حادثے میں بیرنگ بلاکس ریل سے باہر نہ گریں۔',
    shortSummaryEn: 'Fasten rigid mechanical travel stops with polyurethane buffers at extreme travel limits on both sides.',
    descriptionUrdu: 'دونوں Y ریلز کے انتہائی کناروں پر سخت ایلومینیم اینڈ اسٹاپ بریکٹس لگائیں جن پر نیوپرین ربر بفرز لگے ہوں۔ یہ گینٹری کو فریم سے ٹکرانے سے محفوظ رکھتے ہیں اور حادثاتی جی کوڈ خرابی کے دوران بال اسکرو کو لاک ہونے سے بچاتے ہیں۔',
    descriptionEn: 'Bolt positive mechanical hard stops with high-density polyurethane bump stops at the absolute travel boundaries of the Y-axis. This guarantees that in the event of controller runaway, the carriages cannot derail from the linear rails.',
    cadPrompt: '3D CAD technical blueprint Step 10: CNC mechanical travel hard stop with black polyurethane rubber bumper, M5 T-slot mounting bracket, travel limit markers, isometric schematic on technical blueprint grid.',
    tools: ['4mm Hex Key', 'Measuring Ruler'],
    components: ['Aluminium Hard Stops (x4)', 'Polyurethane Rubber Bumpers (x4)', 'M5x16mm Cap Screws (x8)'],
    specs: {
      torque: '6.5 N·m',
      tolerance: 'Equal travel cushion ±0.5 mm',
      fastener: 'M5 High Tensile',
      criticalCheck: 'Verify that both left and right carriages strike bumpers simultaneously.',
    },
    proTipUrdu: 'بمپرز کو اس پوزیشن پر سیٹ کریں کہ الیکٹریکل لِمٹ سوئچ ان سے 5 ملی میٹر پہلے ٹریگر ہو۔',
    proTipEn: 'Position hard stops so electrical limit switches trip 5mm before metal contact occurs.',
    defaultImage: '/src/assets/images/cnc_gantry_assembly_cad_1791448922691.jpg',
    svgSchemaType: 'endstops_y',
  },

  // ================= PHASE 3: Gantry Assembly & X-Axis Beam (سٹیپ 11 تا 15) =================
  {
    id: 11,
    phaseId: 3,
    phaseNameUrdu: 'فیز 3: گینٹری اسیمبلی اور ایکس ایکسس بیم',
    phaseNameEn: 'Phase 3: Gantry Assembly & X-Axis Beam',
    titleUrdu: 'ہیوی ڈیوٹی گینٹری رائزرز سائیڈ پلیٹس کی ماؤنٹنگ',
    titleEn: 'Heavy-Duty Gantry Riser Side Plates Installation (15mm Mic-6 Plate)',
    shortSummaryUrdu: '15 ملی میٹر موٹی CNC مشینی گینٹری سائیڈ پلیٹس کو Y-Axis کے بیئرنگ کیریجز پر فکس کریں۔',
    shortSummaryEn: 'Bolt precision machined aluminum side riser uprights onto the dual Y-axis linear bearing carriages.',
    descriptionUrdu: '15 ملی میٹر موٹی ایلومینیم گینٹری سائیڈ پلیٹس لیں۔ ان کے نچلے حصے پر HGH20 بیئرنگ کیریجز کے سوراخوں کو ملائیں اور بال اسکرو کے بال نٹ ہاؤسنگ (Ballnut Flange) کو پلیٹ کے اندرونی سوراخ سے M5 بولٹس کے ساتھ کَسیں۔ دونوں پلیٹس کو بالکل عمودی 90 ڈگری پر سیٹ کریں۔',
    descriptionEn: 'Position the 15mm thick CNC-milled Mic-6 aluminum gantry riser plates onto the Y-axis bearing blocks. Secure through-holes into the bearing carriage threads and bolt the SFU1605 ballnut flange to the lower plate face. Check vertical perpendicularity with an engineer square.',
    cadPrompt: 'Isometric 3D CAD blueprint Step 11: 15mm thick CNC milled aluminum gantry riser side plates bolted onto Y-axis linear bearing blocks and ball nut flange, exploded fastener view, precision dimensional annotations on dark cyan CAD viewport.',
    tools: ['Machinist Try Square', '5mm & 6mm Hex Keys', 'Calibrated Torque Wrench'],
    components: ['Mic-6 Cast Aluminium Riser Plates (x2 Left & Right)', 'SFU1605 Ballnut Flange Mounts (x2)', 'M6x20mm Grade 12.9 Bolts (x16)'],
    specs: {
      torque: '12.0 N·m on carriage blocks',
      tolerance: '< 0.03 mm vertical perpendicularity',
      fastener: 'M6 Grade 12.9 High-Tensile',
      criticalCheck: 'Plates must stand exactly parallel to each other across the full machine width.',
    },
    proTipUrdu: 'بولٹس کو ابھی 80 فیصد ٹائٹ کریں، جب مین بیم لگ جائے تب فائنل ٹارک دیں تاکہ اسٹرین نہ آئے۔',
    proTipEn: 'Keep riser fasteners at 80% torque until the cross gantry beam is seated, preventing preload binding.',
    defaultImage: '/src/assets/images/cnc_gantry_assembly_cad_1791448922691.jpg',
    svgSchemaType: 'gantry_risers',
  },
  {
    id: 12,
    phaseId: 3,
    phaseNameUrdu: 'فیز 3: گینٹری اسیمبلی اور ایکس ایکسس بیم',
    phaseNameEn: 'Phase 3: Gantry Assembly & X-Axis Beam',
    titleUrdu: 'مرکزی گینٹری بیم (8080/80160) کراس بار کی تنصیب اور اسکوائرنگ',
    titleEn: 'Main Heavy Aluminium Gantry Beam (8080/80160) Installation',
    shortSummaryUrdu: 'دونوں رائزرز کے درمیان ہیوی 8080 ایلومینیم بیم رکھیں اور فریم کے ساتھ اسکوائر کر کے کسیں۔',
    shortSummaryEn: 'Mount the massive 8080/80160 gantry extrusion crossbar between the two side uprights and square to base.',
    descriptionUrdu: 'مشین کی سب سے اہم ریڑھ کی ہڈی یہ گینٹری بیم ہے۔ اسے دونوں سائیڈ پلیٹس کے درمیان رکھ کر M8 کاؤنٹر سنک یا ساکٹ بولٹس کے ذریعے جوڑیں۔ ایک بڑا پریسیشن انجینئر اسکوائر بیڈ اور گینٹری کے درمیان رکھ کر چیک کریں کہ گینٹری فریم کے ساتھ بالکل 90 ڈگری پر ہو۔',
    descriptionEn: 'Hoist the heavy 8080/80160 gantry extrusion beam between the upright riser plates. Fasten with heavy M8 bolts through precision reamed locating pin holes. Place a precision cylindrical square on the sub-bed and measure perpendicularity to under 0.02mm before locking down.',
    cadPrompt: '3D CAD technical engineering view Step 12: Heavy 8080 aluminum extrusion gantry beam spanning between side riser plates, precision cylindrical square verifying 90-degree angle to bed, exploded M8 bolt assemblies, dark blueprint technical style.',
    tools: ['Cylindrical Master Square', '6mm Hex Socket Wrench', 'Feeler Gauge Strips'],
    components: ['8080 High-Wall Aluminium Beam (1000mm)', 'Steel Dowel Alignment Pins (x4)', 'M8x30mm Cap Screws (x12)', 'Heavy Spring Washers (x12)'],
    specs: {
      torque: '25.0 N·m on M8 bolts',
      tolerance: '< 0.02 mm across 1000mm span',
      fastener: 'M8 Grade 12.9 Alloy Steel',
      criticalCheck: 'Gantry must slide back and forth with effortless finger push before drives are locked.',
    },
    proTipUrdu: 'گینٹری کو ہاتھ سے دھکیل کر چیک کریں کہ پوری لمبائی پر کہیں بھی ریلز یا بیرنگ پھنس نہ رہے ہوں۔',
    proTipEn: 'Disconnect motor couplers temporarily and glide gantry by hand: drag must remain featherlight across the entire stroke.',
    defaultImage: '/src/assets/images/cnc_gantry_assembly_cad_1791448922691.jpg',
    svgSchemaType: 'gantry_beam',
  },
  {
    id: 13,
    phaseId: 3,
    phaseNameUrdu: 'فیز 3: گینٹری اسیمبلی اور ایکس ایکسس بیم',
    phaseNameEn: 'Phase 3: Gantry Assembly & X-Axis Beam',
    titleUrdu: 'ایکس ایکسس (X-Axis) ڈوئل لکیری ریلز کی الائنمنٹ',
    titleEn: 'X-Axis Dual Linear Guide Rails Installation (Upper & Lower)',
    shortSummaryUrdu: 'گینٹری بیم کے سامنے اوپری اور نچلی HGR20 لکیری ریلز کو ڈائل انڈیکیٹر کے ساتھ بالکل سیدھا لگائیں۔',
    shortSummaryEn: 'Mount upper and lower linear rails to the front face of the gantry beam and align with dial indicator.',
    descriptionUrdu: 'گینٹری بیم کے سامنے کے رخ پر اوپر اور نیچے دو متوازی HGR20 ریلز لگائیں۔ نچلی ریل کو ڈیٹم شولڈر کے ساتھ مکمل ٹائٹ کریں۔ اوپری ریل کو ڈائل انڈیکیٹر کی مدد سے نچلی ریل کے عین متوازی (Parallel) 0.015 ملی میٹر کے اندر کَسیں۔',
    descriptionEn: 'Mount twin HGR20 rails to the front face of the gantry beam. Secure the bottom rail against the precision milled reference shoulder. Use a dual dial indicator fixture referenced off the lower rail to sweep the upper rail perfectly parallel to within 0.015mm.',
    cadPrompt: '3D CAD technical blueprint Step 13: Twin horizontal linear rails mounted on the front face of gantry beam, dual dial test indicators tramming rail parallelism, exploded M5 hardware, isometric CAD view with glowing cyan technical outlines.',
    tools: ['Dial Indicator with Dual Magnetic Base', '4mm Hex Wrench', 'Torque Driver'],
    components: ['HGR20 Linear Guide Rails (x2 1000mm)', 'M5x16mm Socket Screws (x48)', 'M5 T-Nuts (x48)'],
    specs: {
      torque: '5.5 N·m',
      tolerance: '< 0.015 mm rail parallelism',
      fastener: 'M5 Grade 12.9 Steel',
      criticalCheck: 'Both rails must be completely coplanar with zero twist across the gantry length.',
    },
    proTipUrdu: 'دونوں ریلز کے درمیان فاصلہ جتنا زیادہ ہوگا، زیڈ ایکسس کا روٹیشنل ٹارک اتنا ہی بہتر برداشت ہوگا۔',
    proTipEn: 'Maximizing the vertical span between upper and lower rails dramatically enhances torsional resistance against heavy plunge milling forces.',
    defaultImage: '/src/assets/images/cnc_gantry_assembly_cad_1791448922691.jpg',
    svgSchemaType: 'x_rails',
  },
  {
    id: 14,
    phaseId: 3,
    phaseNameUrdu: 'فیز 3: گینٹری اسیمبلی اور ایکس ایکسس بیم',
    phaseNameEn: 'Phase 3: Gantry Assembly & X-Axis Beam',
    titleUrdu: 'ایکس ایکسس بال اسکرو (SFU1605) اور اینٹی بیک لیش نٹ ہاؤسنگ',
    titleEn: 'X-Axis Ball Screw (SFU1605) & Anti-Backlash Nut Housing',
    shortSummaryUrdu: 'گینٹری بیم پر سینٹرل بال اسکرو اور اس کا اینٹی بیک لیش بریکٹ بیرنگز سمیت نصب کریں۔',
    shortSummaryEn: 'Install central SFU1605 ballscrew with FK12/FF12 bearing blocks and anti-backlash nut bracket.',
    descriptionUrdu: 'گینٹری بیم کے دونوں سروں پر بال اسکرو کے FK12 فکسڈ اور FF12 سپورٹ بیرنگ بلاکس لگائیں۔ بال اسکرو کا نٹ ہاؤسنگ بریکٹ اندر چڑھائیں۔ اینٹی بیک لیش نٹ کے پری لوڈ اسکرو کو ایڈجسٹ کریں تاکہ موشن میں زیرو لوز پن (Zero backlash) ہو۔',
    descriptionEn: 'Mount the FK12 fixed and FF12 supported bearing blocks on the gantry uprights. Thread the zero-backlash preloaded ballnut into its dedicated aluminum bracket. Verify smooth rotational torque by turning the screw journal between thumb and index finger.',
    cadPrompt: '3D CAD technical blueprint Step 14: X-axis SFU1605 ballscrew assembly with anti-backlash nut housing block, FK12 bearing block cutaway view, isometric engineering blueprint on dark background.',
    tools: ['5mm Hex Key', 'Torx T25', 'Threadlocker Loctite 243'],
    components: ['SFU1605 Ballscrew (1050mm)', 'FK12 & FF12 Bearing Blocks (x1 pair)', 'Cast Ballnut Housing (x1)', 'M5x16mm Bolts (x6)'],
    specs: {
      torque: 'Nut housing bolts 8.5 N·m',
      tolerance: '< 0.005 mm backlash',
      fastener: 'M5 Class 12.9 Screws',
      criticalCheck: 'Smooth spin with no stiff spots across the full horizontal gantry travel.',
    },
    proTipUrdu: 'بال نٹ وائپرز کے اندر تھوڑی گریس بھریں تاکہ ڈسٹ اور ایلومینیم چپس اندر نہ جا سکیں۔',
    proTipEn: 'Pack the internal ballnut seals with Mobilith SHC 100 synthetic grease to bar wood dust ingress.',
    defaultImage: '/src/assets/images/cnc_gantry_assembly_cad_1791448922691.jpg',
    svgSchemaType: 'ball_screw_x',
  },
  {
    id: 15,
    phaseId: 3,
    phaseNameUrdu: 'فیز 3: گینٹری اسیمبلی اور ایکس ایکسس بیم',
    phaseNameEn: 'Phase 3: Gantry Assembly & X-Axis Beam',
    titleUrdu: 'ایکس ایکسس اسٹیپر موٹر ماؤنٹ اور ڈائریکٹ ڈرائیو کپلر',
    titleEn: 'X-Axis Stepper Motor & Direct Drive Mount',
    shortSummaryUrdu: 'گینٹری پلیٹ پر NEMA 23 موٹر فکس کریں اور کپلر کے ذریعے X بال اسکرو سے جوڑیں۔',
    shortSummaryEn: 'Mount NEMA 23 stepper motor to the gantry right riser plate and couple to the X-axis ballscrew.',
    descriptionUrdu: 'گینٹری کی دائیں سائیڈ پلیٹ پر NEMA 23 ہائی ٹارک موٹر کو ایلومینیم اسٹینڈ آفز کے ساتھ ماؤنٹ کریں۔ فلیکسیبل کپلر کے ذریعے موٹر شافٹ کو X-Axis بال اسکرو سے جوڑیں۔ موٹر کی کنکشن کیبلز کو مستقبل کی ڈریگ چین والی سائیڈ کی طرف رخ رکھیں۔',
    descriptionEn: 'Fasten the NEMA 23 stepper motor to the gantry drive flange using aluminum standoffs. Connect the motor shaft to the FK12 ballscrew shaft via a vibration-absorbing jaw coupling. Align wiring breakout port toward the upcoming drag chain carrier.',
    cadPrompt: '3D CAD technical blueprint Step 15: NEMA 23 stepper motor mounted on gantry side plate with flexible aluminum spider coupling to X-axis ballscrew, exploded view with fasteners, dark blueprint background with cyan lines.',
    tools: ['3mm & 4mm Allen Keys', 'Vernier Calipers'],
    components: ['NEMA 23 Stepper Motor 3.0Nm', 'Flexible Coupler 8x10mm', 'M5x30mm Screws (x4)', 'Vibration Isolator Gasket (x1)'],
    specs: {
      torque: 'Motor bolts 4.5 N·m',
      tolerance: '< 0.05 mm shaft alignment',
      fastener: 'M5 Grade 10.9 Zinc Plated',
      criticalCheck: 'Coupler set screws firmly torqued against motor shaft flat surface.',
    },
    proTipUrdu: 'کپلر کے اینٹی وائبریشن ربر ایلیمنٹ کو چیک کریں کہ وہ کٹا یا پھٹا نہ ہو۔',
    proTipEn: 'Ensure the elastomer spider sits seated without pinch or distortion inside the aluminum jaw teeth.',
    defaultImage: '/src/assets/images/cnc_gantry_assembly_cad_1791448922691.jpg',
    svgSchemaType: 'stepper_x',
  },

  // ================= PHASE 4: Z-Axis Carriage & Spindle Mount (سٹیپ 16 تا 20) =================
  {
    id: 16,
    phaseId: 4,
    phaseNameUrdu: 'فیز 4: زیڈ ایکسس کیریج اور اسپنڈل ماؤنٹ',
    phaseNameEn: 'Phase 4: Z-Axis Carriage & Spindle Mount',
    titleUrdu: 'زیڈ ایکسس بیک پلیٹ اور X-Axis لکیری بیئرنگ سلائیڈرز',
    titleEn: 'Z-Axis Backplate & X-Axis Linear Bearings Sub-assembly',
    shortSummaryUrdu: 'X-Axis کے چار بیرنگ بلاکس پر وزنی ایلومینیم Z بیک پلیٹ اور بال نٹ بریکٹ فکس کریں۔',
    shortSummaryEn: 'Fasten high-precision milled aluminum Z-axis backing plate onto the 4 X-axis linear carriage blocks.',
    descriptionUrdu: '12 ملی میٹر ایلومینیم ٹولنگ پلیٹ سے بنی Z بیک پلیٹ لیں۔ اس کے پچھلے رخ کو X-Axis کے چاروں HGH20 بیئرنگ کیریجز کے ساتھ ملائیں۔ کاؤنٹر سنک ہائی ٹینشن M6 بولٹس کے ساتھ اسے مکمل فکس کریں تاکہ کوئی پلے نہ رہے۔',
    descriptionEn: 'Position the 12mm thick CNC-machined Z-axis main carriage plate against the four HGH20 bearing blocks on the X-axis rails. Torque the countersunk M6 bolts evenly in an X-pattern to eliminate any warping stress in the carriage plate.',
    cadPrompt: '3D CAD technical blueprint Step 16: Z-axis aluminum backing plate mounted to 4 linear bearing carriage blocks on X-axis rails, isometric exploded view showing mounting pattern, dark blueprint viewport with cyan line art.',
    tools: ['5mm Allen Wrench', 'Torque Driver', 'Dial Test Indicator'],
    components: ['Z-Axis CNC Milled Backplate (12mm 6061-T6)', 'M6x18mm Countersunk Screws (x16)', 'Ballnut Attachment Flange (x1)'],
    specs: {
      torque: '11.0 N·m',
      tolerance: '< 0.02 mm coplanarity',
      fastener: 'M6 Grade 12.9 DIN 7991',
      criticalCheck: 'Check effortless travel of carriage along full gantry span with zero bind.',
    },
    proTipUrdu: 'بولٹس کو ایک طرف سے نہیں بلکہ کراس پیٹرن (Cross Pattern) میں ٹائٹ کریں تاکہ پلیٹ میں کھنچاؤ نہ آئے۔',
    proTipEn: 'Tighten carriage fasteners in an alternating criss-cross star pattern to preserve backing plate absolute flatness.',
    defaultImage: '/src/assets/images/cnc_zaxis_spindle_cad_1791448936583.jpg',
    svgSchemaType: 'z_backplate',
  },
  {
    id: 17,
    phaseId: 4,
    phaseNameUrdu: 'فیز 4: زیڈ ایکسس کیریج اور اسپنڈل ماؤنٹ',
    phaseNameEn: 'Phase 4: Z-Axis Carriage & Spindle Mount',
    titleUrdu: 'زیڈ ایکسس عمودی لکیری ریلز اور بیئرنگ پلیٹس',
    titleEn: 'Z-Axis Vertical Linear Rails & Sliding Faceplate',
    shortSummaryUrdu: 'بیک پلیٹ کے سامنے کے رخ پر دو پریسیشن عمودی MGN15/HGR15 ریلز اور Z فرنٹ پلیٹ لگائیں۔',
    shortSummaryEn: 'Mount two vertical precision linear guide rails onto the front face of the Z backplate.',
    descriptionUrdu: 'Z بیک پلیٹ کے سامنے دو عمودی ریلز لگائیں جن پر اسپنڈل کی پلیٹ اوپر نیچے حرکت کرے گی۔ ان ریلز کو پریسیشن اسکوائر کے ساتھ X ایکسس کے عین 90 ڈگری پر الائن کریں۔ ان کے اوپر چار بیرنگ بلاکس اور Z موونگ فیس پلیٹ فکس کریں۔',
    descriptionEn: 'Bolt twin vertical HGR15 guide rails onto the machined channels of the Z backplate. Align both rails strictly perpendicular (90.00°) to the X-axis travel direction using a master granite square. Mount the 4 vertical carriage blocks and the moving front toolplate.',
    cadPrompt: '3D CAD technical blueprint Step 17: Vertical twin linear rails and sliding spindle faceplate of CNC Z-axis, showing 90-degree squareness measurement to horizontal X-axis, isometric CAD schematic on dark technical blueprint grid.',
    tools: ['Granite Master Square', '3mm & 4mm Hex Keys', 'Dial Indicator'],
    components: ['HGR15 Linear Rails (x2 250mm)', 'HGH15CA Carriage Blocks (x4)', 'Z Sliding Front Plate (x1)', 'M4x14mm Cap Screws (x20)'],
    specs: {
      torque: '4.8 N·m',
      tolerance: '< 0.01 mm perpendicularity to X-axis',
      fastener: 'M4 Class 12.9 High Tensile',
      criticalCheck: 'Slide Z-plate up and down by hand: must have velvet-smooth resistance with zero play.',
    },
    proTipUrdu: 'Z ریلز کی الائنمنٹ میں ذرا سی خرابی بھی گہری ڈرلنگ یا ملنگ کے وقت ٹول کو توڑ سکتی ہے، وقت لگا کر چیک کریں۔',
    proTipEn: 'Take ample time perfecting vertical Z-rail tramming: even 0.05° tilt causes tool chatter and rapid carbide bit breakage during deep plunging.',
    defaultImage: '/src/assets/images/cnc_zaxis_spindle_cad_1791448936583.jpg',
    svgSchemaType: 'z_rails',
  },
  {
    id: 18,
    phaseId: 4,
    phaseNameUrdu: 'فیز 4: زیڈ ایکسس کیریج اور اسپنڈل ماؤنٹ',
    phaseNameEn: 'Phase 4: Z-Axis Carriage & Spindle Mount',
    titleUrdu: 'زیڈ ایکسس پریسیشن بال اسکرو (SFU1204/1605) اور اسٹیپر موٹر',
    titleEn: 'Z-Axis Precision Ball Screw & Stepper Motor Coupling',
    shortSummaryUrdu: 'Z ایکسس کا عمودی بال اسکرو، اینٹی ڈراپ کپلر اور ہائی ٹارک NEMA 23 موٹر ماؤنٹ کریں۔',
    shortSummaryEn: 'Install vertical precision ballscrew with top BK10 bearing block and couple to top-mounted NEMA 23 stepper.',
    descriptionUrdu: 'Z ایکسس کے اوپری حصے پر موٹر ماؤنٹنگ ٹاپ پلیٹ اور BK10 فکسڈ بیرنگ بلاک لگائیں۔ SFU1204 یا SFU1605 بال اسکرو کو نیچے نٹ کے ساتھ جوڑیں۔ اوپر NEMA 23 موٹر کو کپلر کے ساتھ کسیں۔ موٹر بند ہونے پر اسپنڈل کے خود بخود نیچے گرنے سے بچنے کے لیے پری لوڈ چیک کریں۔',
    descriptionEn: 'Install the top bearing block (BK10) and thread the SFU1204/1605 ballscrew through the Z front plate ballnut. Mount the Z-axis NEMA 23 stepper on the top shelf bracket and couple with a zero-backlash clamp. Test manual rotation to ensure effortless vertical lift.',
    cadPrompt: '3D CAD technical blueprint Step 18: Z-axis vertical ballscrew mechanism, top mounted NEMA 23 stepper motor, rigid bearing housing, exploded view of coupler and anti-drop collar, dark cyan blueprint background.',
    tools: ['3mm, 4mm, 5mm Hex Keys', 'Torque Driver'],
    components: ['SFU1204 Precision Ballscrew (300mm)', 'BK10 / BF10 Bearing Blocks (x1 pair)', 'NEMA 23 High-Torque Stepper', 'Zero-Backlash Coupler 8x10mm'],
    specs: {
      torque: 'Motor bolts 4.5 N·m',
      tolerance: '< 0.005 mm vertical backlash',
      fastener: 'M5 Grade 10.9 Zinc Plated',
      criticalCheck: 'Verify that spindle carriage holds position without sliding downward when power is unpowered.',
    },
    proTipUrdu: 'اگر بھاری اسپنڈل ہو تو گیس اسپرنگ (Gas Strut) یا کاؤنٹر ویٹ لگانے سے موٹر پر بوجھ 70 فیصد کم ہو جاتا ہے۔',
    proTipEn: 'For heavy 2.2kW water-cooled spindles, adding a small 50N gas spring counterbalances mass and prevents rapid motor overheating.',
    defaultImage: '/src/assets/images/cnc_zaxis_spindle_cad_1791448936583.jpg',
    svgSchemaType: 'z_leadscrew',
  },
  {
    id: 19,
    phaseId: 4,
    phaseNameUrdu: 'فیز 4: زیڈ ایکسس کیریج اور اسپنڈل ماؤنٹ',
    phaseNameEn: 'Phase 4: Z-Axis Carriage & Spindle Mount',
    titleUrdu: 'کاسٹ ایلومینیم اسپنڈل ماؤنٹ کلیمپ بریکٹ (65mm / 80mm)',
    titleEn: 'Cast Aluminium Spindle Mount Collar (65mm / 80mm)',
    shortSummaryUrdu: 'Z موونگ پلیٹ پر 80 ملی میٹر کاسٹ ایلومینیم کلیمپ لگائیں اور فیلر گیج سے اسکوائر ایڈجسٹ کریں۔',
    shortSummaryEn: 'Mount heavy-duty 80mm cast aluminum spindle clamp bracket to Z-plate with tramming shims.',
    descriptionUrdu: '80 ملی میٹر اندرونی قطر والا کاسٹ یا سی این سی مشینی اسپنڈل کلیمپ بریکٹ لیں۔ اسے Z فرنٹ فیس پلیٹ پر M8 ہائی ٹینشن بولٹس کے ساتھ ماؤنٹ کریں۔ بریکٹ اور پلیٹ کے درمیان مائیکرو شِمز (Brass Shims 0.02mm) کی گنجائش رکھیں تاکہ فائنل اسپنڈل ٹریمنگ ہو سکے۔',
    descriptionEn: 'Bolt the precision 80mm (or 65mm) cast aluminum spindle clamp collar to the moving Z front plate with four M8 alloy cap screws. Keep brass precision shims handy between clamp and faceplate for micro-tuning nod and tilt tramming during spindle alignment.',
    cadPrompt: '3D CAD technical blueprint Step 19: Heavy 80mm cast aluminum CNC spindle mounting collar with clamping split-bolts, brass tramming shims, isometric exploded view with engineering dimension callouts, dark blueprint background.',
    tools: ['6mm Allen Wrench', 'Brass Shim Stock (0.02mm, 0.05mm)', 'Precision Depth Micrometer'],
    components: ['80mm Heavy Cast Spindle Mount Collar', 'M8x25mm Grade 12.9 Socket Screws (x4)', 'M8 Pinch Bolts (x2)'],
    specs: {
      torque: 'Mount bolts 22 N·m',
      tolerance: '< 0.02 mm bore roundness',
      fastener: 'M8 Grade 12.9 Black Oxide',
      criticalCheck: 'Internal bore must be free of burrs or grit that could distort the spindle motor housing.',
    },
    proTipUrdu: 'کلیمپ کے اندر کا حصہ باریک سینڈ پیپر یا اسپرٹ سے صاف کریں تاکہ کلیمپنگ پریشر برابر تقسیم ہو۔',
    proTipEn: 'Clean the inside bore of the clamp collar thoroughly; any trapped metal filings can create high localized pressure and warp spindle motor bearings.',
    defaultImage: '/src/assets/images/cnc_zaxis_spindle_cad_1791448936583.jpg',
    svgSchemaType: 'spindle_mount',
  },
  {
    id: 20,
    phaseId: 4,
    phaseNameUrdu: 'فیز 4: زیڈ ایکسس کیریج اور اسپنڈل ماؤنٹ',
    phaseNameEn: 'Phase 4: Z-Axis Carriage & Spindle Mount',
    titleUrdu: '2.2kW واٹر کولڈ اسپنڈل موٹر کی تنصیب اور ER20 ٹول ہولڈر چیک',
    titleEn: '2.2kW Water-Cooled Spindle Motor Installation & ER20 Collet Check',
    shortSummaryUrdu: 'کلیمپ میں 24,000 RPM واٹر کولڈ اسپنڈل داخل کر کے کلیمپ کریں اور کولنٹ پائپ کنکشنز لگائیں۔',
    shortSummaryEn: 'Slide 2.2kW high-speed water-cooled spindle motor into collar, torque clamp bolts, connect silicone coolant tubes.',
    descriptionUrdu: '2.2kW (24,000 RPM) واٹر کولڈ اسپنڈل کو کلیمپ کے اندر مطلوبہ اونچائی پر سلائیڈ کریں۔ کلیمپ کے دونوں M8 پنچ بولٹس کو یکساں ٹائٹ کریں۔ اوپر واٹر کولنگ کی 8mm سلیکون ٹیوبز فکس کریں اور کلیپس لگائیں تاکہ ہائی پریشر پر پانی لیک نہ ہو۔ ER20 کولیٹ نٹ چڑھا کر رن آؤٹ چیک کریں۔',
    descriptionEn: 'Carefully slide the 2.2kW 80mm diameter water-cooled spindle into the collar at designated throat depth. Gradually alternate torque on the two pinch bolts to 14 N·m. Push 8mm PU cooling tubes onto barbed fittings and secure with spring hose clamps. Screw on the ER20 collet chuck nut.',
    cadPrompt: '3D CAD technical blueprint Step 20: 2.2kW cylindrical water-cooled CNC spindle motor clamped in 80mm collar, ER20 collet chuck cutaway, dual water cooling hose fittings, isometric technical schematic on dark cyan blueprint background.',
    tools: ['6mm Hex Wrench', 'ER20 Wrench (Type A/UM)', 'Hose Clamp Pliers', 'Dial Indicator'],
    components: ['2.2kW 80mm Water-Cooled Spindle Motor (220V 24000RPM)', 'ER20 Precision Collet & Nut', '8mm OD Silicone/PU Water Tubing (x10m)', 'Spring Hose Clamps (x4)'],
    specs: {
      torque: 'Clamp pinch bolts 14.0 N·m (Never over-tighten!)',
      tolerance: '< 0.005 mm spindle taper runout',
      fastener: 'M8 Grade 12.9 Pinch Screws',
      criticalCheck: 'Always verify coolant flows freely without air bubbles before ever powering on the spindle.',
    },
    proTipUrdu: 'کلیمپ بولٹس کو ضرورت سے زیادہ ٹائٹ مت کریں ورنہ اسپنڈل کی باڈی دب جائے گی اور بیرنگز جلدی خراب ہو جائیں گے۔',
    proTipEn: 'Never over-torque the spindle clamp: excessive clamping force distorts the thin motor casing and pinches precision ceramic angular contact bearings.',
    defaultImage: '/src/assets/images/cnc_zaxis_spindle_cad_1791448936583.jpg',
    svgSchemaType: 'spindle_motor',
  },

  // ================= PHASE 5: Cable Management & Mechanical Calibration (سٹیپ 21 تا 24) =================
  {
    id: 21,
    phaseId: 5,
    phaseNameUrdu: 'فیز 5: کیبل ڈریگ چین اور مکینیکل کیلیبریشن',
    phaseNameEn: 'Phase 5: Cable Management & Mechanical Calibration',
    titleUrdu: 'لچکدار ڈریگ چینز کی روٹنگ (X اور Y ایکسس کیبل ٹریکس)',
    titleEn: 'Flexible Drag Chains Routing (X and Y Axis Cable Tracks)',
    shortSummaryUrdu: 'تمام موٹر کیبلز، اسپنڈل تاروں اور کولنگ پائپس کے لیے 15x30mm فلیکسیبل ڈریگ چینز لگائیں۔',
    shortSummaryEn: 'Install 15x30mm heavy-duty nylon openable cable drag chains along X and Y axes with support aluminum trays.',
    descriptionUrdu: 'X بیم اور Y فریم کی سائیڈ پر کیبل ٹرے لگائیں۔ ان کے اوپر 15x30mm نائیلون ڈریگ چینز ماؤنٹ کریں۔ موٹر وائرز، شیلڈڈ اسپنڈل کیبلز اور واٹر ٹیوبز کو چین کے اندر ترتیب سے ڈالیں۔ سگنل وائرز اور پاور وائرز کے درمیان انٹرنل سیپریٹر لگائیں تاکہ برقی مداخلت (EMI) نہ ہو۔',
    descriptionEn: 'Mount extruded aluminum guide troughs along the gantry beam and chassis side. Fasten 15x30mm reinforced nylon cable carrier drag chains. Route shielded 4-core stepper cables, spindle power cable, and water lines inside, using internal dividers to isolate sensitive sensor wiring from high-voltage AC lines.',
    cadPrompt: '3D CAD technical blueprint Step 21: Heavy-duty nylon articulating cable drag chain carrier flexing along CNC gantry aluminum guide trough, cutaway showing segregated wires and water hoses, dark technical CAD background.',
    tools: ['Small Flathead Screwdriver', 'Cable Tie Tensioner Tool', 'Wire Strippers'],
    components: ['15x30mm Openable Drag Chain (2x 1.2m)', 'Aluminium Cable Support Trays', 'Drag Chain Mounting End Brackets (x4)', 'Internal Chain Dividers (x12)'],
    specs: {
      torque: 'Mounting screws 3.5 N·m',
      tolerance: 'Zero snag or pinch across full 100% travel',
      fastener: 'M4 BHCS Screws',
      criticalCheck: 'Verify that cables have 10% slack at maximum extension and do not rub under tension.',
    },
    proTipUrdu: 'اسپنڈل پاور کیبل کو کبھی بغیر شیلڈ نہ لگائیں اور سگنل وائرز کے ساتھ باندھنے سے پرہیز کریں ورنہ نائز آئے گی۔',
    proTipEn: 'Always use 4-conductor braided shielded cable (CY cable) with grounded shield for the spindle to suppress electromagnetic noise.',
    defaultImage: '/src/assets/images/cnc_electronics_wiring_cad_1791448948411.jpg',
    svgSchemaType: 'drag_chains',
  },
  {
    id: 22,
    phaseId: 5,
    phaseNameUrdu: 'فیز 5: کیبل ڈریگ چین اور مکینیکل کیلیبریشن',
    phaseNameEn: 'Phase 5: Cable Management & Mechanical Calibration',
    titleUrdu: 'تمام ایکسس کے انڈکٹو/مکینیکل لِمٹ سوئچز کی تنصیب',
    titleEn: 'Limit Switches Installation (X, Y, Z Min & Max Homing Sensors)',
    shortSummaryUrdu: 'ہر ایکسس پر ہومنگ اور سافٹ لمٹ پروٹیکشن کے لیے انڈکٹو پروکسیمٹی سینسرز یا مائیکرو سوئچز لگائیں۔',
    shortSummaryEn: 'Mount shielded inductive proximity sensors (NPN-NC) on all axes for accurate homing and safety bounds.',
    descriptionUrdu: 'X، Y اور Z ایکسس کے زیرو پوائنٹس پر 12V/24V انڈکٹو پروکسیمٹی سینسرز (SN04-N) یا سیلڈ مائیکرو سوئچز ماؤنٹ کریں۔ یہ سینسرز میٹل فلیگ کو 4 ملی میٹر فاصلے پر ڈیٹیکٹ کرتے ہیں اور مشین کو پریسیشن ہومنگ اور باؤنڈری کریش سے بچاتے ہیں۔ تمام سینسرز پر عام طور پر نارملی کلوزڈ (NC) سرکٹ استعمال کریں۔',
    descriptionEn: 'Install high-repeatability NPN Normally-Closed inductive proximity sensors (SN04-N or LJ12A3) at the home positions of all axes. Set sensing trigger distance to 2.5mm against steel flag brackets. Normally-closed wiring ensures instant fault detection if a wire snaps.',
    cadPrompt: '3D CAD technical blueprint Step 22: SN04-N inductive proximity sensor mounted on CNC axis with steel trigger flag bracket, wiring schematic callout, isometric CAD view on dark cyan technical blueprint grid.',
    tools: ['Feeler Gauge 2.5mm', '2.5mm Hex Key', 'Digital Multimeter'],
    components: ['SN04-N NPN Normally Closed Sensors (x5)', 'CNC Milled Sensor Mount Brackets (x5)', 'Steel Target Trigger Flags (x5)', 'Shielded 3-Core Sensor Wires'],
    specs: {
      torque: 'Sensor locknuts 3.0 N·m',
      tolerance: '< 0.01 mm homing repeatability',
      fastener: 'M3 Cap Screws & M12 Locknuts',
      criticalCheck: 'Sensor LED indicator lights up reliably when target flag enters 2.5mm sensing envelope.',
    },
    proTipUrdu: 'نارملی اوپن (NO) کی بجائے ہمیشہ نارملی کلوزڈ (NC) وائرنگ کریں تاکہ تار کٹنے پر مشین فوراً الرٹ ہو جائے۔',
    proTipEn: 'Wire sensors in Normally-Closed (NC) series loops: if a wire breaks or connector vibrates loose, the machine alarms safely instead of crashing.',
    defaultImage: '/src/assets/images/cnc_electronics_wiring_cad_1791448948411.jpg',
    svgSchemaType: 'limit_switches',
  },
  {
    id: 23,
    phaseId: 5,
    phaseNameUrdu: 'فیز 5: کیبل ڈریگ چین اور مکینیکل کیلیبریشن',
    phaseNameEn: 'Phase 5: Cable Management & Mechanical Calibration',
    titleUrdu: 'مشین ٹریمنگ، ڈائل انڈیکیٹر اسکوائرنگ اور پرفیکٹ 0.02 ملی میٹر الائنمنٹ',
    titleEn: 'Machine Squaring, Tramming & Dial Indicator Alignment',
    shortSummaryUrdu: 'اسپنڈل میں ڈوئل ڈائل انڈیکیٹر راڈ پکڑائیں اور بیڈ پر گھما کر اسپنڈل کے اینگل کو زیرو ٹالرنس پر لائیں۔',
    shortSummaryEn: 'Mount dual dial test indicator tramming arm into spindle collet and sweep the bed to eliminate nod and tram error.',
    descriptionUrdu: 'اسپنڈل کے کولیٹ میں ٹریمنگ بازو (Tramming Bar) لگائیں جس کے دونوں سروں پر 0.01 ملی میٹر ڈائل گیجز لگے ہوں۔ اسپنڈل کو ہاتھ سے 360 ڈگری گھمائیں اور بیڈ پر آگے پیچھے اور دائیں بائیں ریڈنگ دیکھیں۔ کلیمپ کے پیچھے شِمز ڈال کر فرق 0.02 ملی میٹر سے کم کریں۔',
    descriptionEn: 'Chuck a dual dial indicator spindle tramming bar into the ER20 collet spanning 200mm across the bed. Rotate spindle 360° by hand to measure front-to-back nod and left-to-right tilt. Insert precision brass shim foils behind spindle mount until swept deviation is below 0.02mm.',
    cadPrompt: '3D CAD technical blueprint Step 23: Precision dual dial indicator tramming bar clamped in CNC spindle collet sweeping circular arc across surface plate, dial needle deviation annotations, dark blueprint grid.',
    tools: ['Spindle Tramming Bar with Twin 0.01mm DTI Gauges', 'Granite Surface Plate', 'Precision Shim Foil Pack'],
    components: ['Tramming Fixture Arm 200mm', 'Brass/Steel Precision Foil Shims (0.01mm - 0.1mm)'],
    specs: {
      torque: 'Final spindle bolts 22 N·m after shimming',
      tolerance: '< 0.02 mm across 200 mm sweep circle',
      fastener: 'M8 High Strength Screws',
      criticalCheck: 'Zero needle jump between 0° and 180° front-to-back and 90° to 270° side-to-side.',
    },
    proTipUrdu: 'ٹریمنگ کے بغیر بنی چیزوں میں ملنگ کے بعد دانتے اور سیڑھیاں (ridge marks) نظر آئیں گی، ٹریمنگ لازمی ہے۔',
    proTipEn: 'A properly trammed spindle leaves mirror-flat surfaces with zero scalloping or ridges during wide face-milling passes.',
    defaultImage: '/src/assets/images/cnc_electronics_wiring_cad_1791448948411.jpg',
    svgSchemaType: 'dial_tramming',
  },
  {
    id: 24,
    phaseId: 5,
    phaseNameUrdu: 'فیز 5: کیبل ڈریگ چین اور مکینیکل کیلیبریشن',
    phaseNameEn: 'Phase 5: Cable Management & Mechanical Calibration',
    titleUrdu: 'ریلز، بیئرنگز اور بال اسکروس کی ہائی گریڈ لیتھیم چکنائی',
    titleEn: 'Lubrication, Linear Bearing Greasing & Ball Screw Prep',
    shortSummaryUrdu: 'تمام گریس نپلز پر مینوئل گریس گن سے لیتھیم کمپلیکس گریس پمپ کریں اور سلائیڈ موشن چیک کریں۔',
    shortSummaryEn: 'Inject premium lithium-complex EP2 grease into all bearing carriages and ballscrew ballnuts.',
    descriptionUrdu: 'ایک چھوٹی مینوئل گریس گن لیں جس میں لیتھیم کمپلیکس EP2 یا Mobilith گریس بھری ہو۔ ہر بیئرنگ بلاک کے نپل پر گن لگا کر 1 سے 2 پمپ گریس داخل کریں۔ تمام ایکسیز کو ہاتھ سے آگے پیچھے چلائیں تاکہ گریس اندر تمام بالز پر یکساں پھیل جائے۔ فالتو گریس کو وائپ کریں۔',
    descriptionEn: 'Attach a needle nozzle grease gun loaded with high-quality lithium soap EP2 synthetic grease to all HGH20 and SFU1605 grease zerks. Inject 1.5 cm³ per block until clean grease pushes past the wiper seals. Traverse all axes across their full lengths to distribute the lubricant film.',
    cadPrompt: '3D CAD technical blueprint Step 24: Grease gun coupler engaging bearing block grease nipple, exploded cutaway showing internal recirculating ball channels filled with blue synthetic lubricant, dark blueprint background.',
    tools: ['Mini Grease Gun with Needle Coupler', 'Shop Lint-Free Towels'],
    components: ['Lithium Complex EP2 Grease Cartridge', 'ISO VG68 Slideway Oil (for rails)'],
    specs: {
      torque: 'Finger tight on grease gun tip',
      tolerance: '100% boundary lubrication coverage',
      fastener: 'M6 Zerk Fittings',
      criticalCheck: 'Wipe all excess purged grease from rail tips to prevent dust accumulation.',
    },
    proTipUrdu: 'کبھی بھی WD-40 کو بطور لبریکنٹ استعمال نہ کریں کیونکہ یہ اصل فیکٹری گریس کو پگھلا کر صاف کر دیتا ہے۔',
    proTipEn: 'Never use standard WD-40 or thin aerosol spray: it flushes away heavy lubricating grease and ruins bearings within hours.',
    defaultImage: '/src/assets/images/cnc_electronics_wiring_cad_1791448948411.jpg',
    svgSchemaType: 'lubrication',
  },

  // ================= PHASE 6: Electronics, Power & Inverter VFD (سٹیپ 25 تا 28) =================
  {
    id: 25,
    phaseId: 6,
    phaseNameUrdu: 'فیز 6: الیکٹرانکس، وی ایف ڈی اور کنٹرول سسٹم',
    phaseNameEn: 'Phase 6: Electronics, Power & Inverter VFD',
    titleUrdu: 'انڈسٹریل کنٹرول باکس اینکلوژر، ڈن ریل اور کولنگ فینز لے آؤٹ',
    titleEn: 'Industrial Control Box Enclosure & DIN Rail Layout',
    shortSummaryUrdu: 'میٹل الیکٹریکل کیبنٹ میں ڈن ریلز، کیبل ڈکٹس، مین سرکٹ بریکر اور فلٹرڈ ایگزاسٹ فین لگائیں۔',
    shortSummaryEn: 'Assemble steel electrical cabinet with 35mm DIN rails, slotted wire ducts, main breaker, and filtered fans.',
    descriptionUrdu: 'ایک ڈسٹ پروف میٹل اینکلوژر (IP54) لیں۔ اس کے اندر 35 ملی میٹر ڈن ریلز (DIN Rails) اور پی وی سی وائر ڈکٹ ٹرنکنگ فکس کریں۔ نچلے اور اوپری حصے پر ڈسٹ فلٹر والے 120 ملی میٹر ہائی فلو کولنگ پنکھے لگائیں جو ڈرائیورز اور وی ایف ڈی کی حرارت کو باہر نکال سکیں۔',
    descriptionEn: 'Mount 35mm slotted steel DIN rails and PVC wire management comb ducts inside an IP54 rated steel industrial enclosure. Install twin 120mm dual-ball-bearing exhaust fans with washable foam dust filters to provide positive pressure thermal cooling for drivers and power supplies.',
    cadPrompt: '3D CAD technical schematic Step 25: Industrial steel control cabinet chassis layout with DIN rails, PVC wire comb ducts, 2-pole miniature circuit breaker, 120mm cooling fans, isometric electrical enclosure CAD blueprint.',
    tools: ['Screwdriver PZ2 & Slotted', 'Hole Saw 120mm', 'Wire Duct Cutters'],
    components: ['IP54 Steel Enclosure (500x400x200mm)', '35mm DIN Rail (1m)', 'Slotted Wire Ducts 40x40mm', '120mm 24V PWM Cooling Fans (x2)', 'Fan Dust Filter Grills (x2)'],
    specs: {
      torque: 'DIN rail screws 4.0 N·m',
      tolerance: 'Clean 40mm thermal clearance around all modules',
      fastener: 'M4 Pan Head Machine Screws',
      criticalCheck: 'Single-point star chassis ground stud securely bonded to main metal enclosure door and backplate.',
    },
    proTipUrdu: 'میٹل باکس کی باڈی اور دروازے کو تانبے کی گراؤنڈنگ تار سے ضرور جوڑیں تاکہ کرنٹ لگنے کا خطرہ نہ رہے۔',
    proTipEn: 'Bond the enclosure door to the main backplate with a braided green/yellow copper grounding strap for safety compliance.',
    defaultImage: '/src/assets/images/cnc_electronics_wiring_cad_1791448948411.jpg',
    svgSchemaType: 'control_box',
  },
  {
    id: 26,
    phaseId: 6,
    phaseNameUrdu: 'فیز 6: الیکٹرانکس، وی ایف ڈی اور کنٹرول سسٹم',
    phaseNameEn: 'Phase 6: Electronics, Power & Inverter VFD',
    titleUrdu: '36V/48V سوئچنگ پاور سپلائیز، مینز فیوز اور EMI شور فلٹر',
    titleEn: '36V/48V Switching Power Supplies & Mains EMI Filter',
    shortSummaryUrdu: 'موٹرز کے لیے 48V 10A مینویل پاور سپلائی، کنٹرولر کے لیے 24V سپلائی اور 220V EMI فلٹر لگائیں۔',
    shortSummaryEn: 'Mount Mean Well 48V 10A PSU for steppers, 24V PSU for logic/sensors, and AC line EMI filter.',
    descriptionUrdu: 'مینز 220V ان پٹ پر سب سے پہلے دو پول والا سرکٹ بریکر اور ہائی فریکوئنسی CW4L2 EMI فلٹر لگائیں۔ اس کے بعد اسٹیپر ڈرائیورز کے لیے 48V 10A پاور سپلائی اور لِمٹ سوئچز/کنٹرولر کے لیے الگ 24V 3A سپلائی لگائیں۔ ڈی سی پاور کیبلز موٹی (16-14 AWG) استعمال کریں۔',
    descriptionEn: 'Wire incoming 220VAC line power through a 16A dual-pole MCB and an industrial EMI line noise filter. Supply 48VDC 10A Mean Well power supply to the stepper drivers, and an isolated 24VDC 3A supply to the motion controller and sensors. Wire with heavy 14 AWG silicone stranded copper leads.',
    cadPrompt: '3D CAD technical blueprint Step 26: Mean Well 48V 500W switching power supply and 24V auxiliary power unit with CW4L2 AC mains noise filter, terminal block wiring schematic, dark cyan CAD blueprint style.',
    tools: ['Wire Ferrule Crimping Pliers', 'Digital True RMS Multimeter', 'Insulated Screwdriver Set'],
    components: ['Mean Well 48V 10.4A Power Supply (LRS-500-48)', 'Mean Well 24V 3.2A PSU (HDR-75-24)', 'CW4L2-20A-S Dual Stage EMI Filter', '16A 2-Pole MCB Breaker'],
    specs: {
      torque: 'Terminal screws 1.2 N·m',
      tolerance: '48.0V ± 0.2V DC calibrated output',
      fastener: 'M3.5 Terminal Screws with Bootlace Ferrules',
      criticalCheck: 'Verify DC output voltage with a multimeter before connecting to stepper drivers or motherboard.',
    },
    proTipUrdu: 'تمام تاروں کے سروں پر بوٹ لیس فیرولز (Ferrules) کرمپ کریں، کھلی ہوئی تانبے کی تاریں کبھی ٹرمینل میں نہ کسیں۔',
    proTipEn: 'Always crimp insulated bootlace wire ferrules onto stranded wire ends; bare un-crimped strands can fray and cause short circuits.',
    defaultImage: '/src/assets/images/cnc_electronics_wiring_cad_1791448948411.jpg',
    svgSchemaType: 'power_supplies',
  },
  {
    id: 27,
    phaseId: 6,
    phaseNameUrdu: 'فیز 6: الیکٹرانکس، وی ایف ڈی اور کنٹرول سسٹم',
    phaseNameEn: 'Phase 6: Electronics, Power & Inverter VFD',
    titleUrdu: 'اسٹیپر ڈرائیورز (DM542/DM556) مائیکرو اسٹیپنگ اور CNC کنٹرولر بورڈ',
    titleEn: 'Stepper Drivers (DM542/DM556) & CNC Controller Board (GRBL/Mach3)',
    shortSummaryUrdu: 'ڈرائیورز پر 1600 پلس مائیکرو اسٹیپنگ اور کرنٹ ڈی آئی پی سوئچز سیٹ کریں اور کنٹرولر بورڈ تاریں جوڑیں۔',
    shortSummaryEn: 'Configure DIP switches on digital DM556 stepper drivers for 1/8 microstepping and connect to controller board.',
    descriptionUrdu: 'چار عدد ڈیجیٹل DM542/DM556 ڈرائیورز ماؤنٹ کریں۔ موٹر ریٹنگ کے مطابق DIP سوئچز سے کرنٹ (مثلاً 3.5A Peak) اور مائیکرو اسٹیپنگ (1600 steps/rev) سیٹ کریں۔ 32-bit CNC کنٹرولر بورڈ سے پلس (PUL) اور ڈائریکشن (DIR) سگنل تاریں آپٹو کپلر ڈیفرینشل موڈ میں کنیکٹ کریں۔',
    descriptionEn: 'Mount 4 digital DM542/DM556 DSP stepper drivers. Configure current DIP switches matching motor ratings (3.5A peak, 50% idle standby current reduction) and set microstepping to 1/8 (1600 steps/rev). Wire Step/Dir/Enable pulse signals from the 32-bit motion breakout board using twisted pair leads.',
    cadPrompt: '3D CAD technical blueprint Step 27: Four DM556 digital stepper drivers wired to CNC breakout controller board with twisted pair signal lines, DIP switch configuration table inset, dark cyan blueprint background.',
    tools: ['Precision Slotted 2.5mm Screwdriver', 'Wire Strippers', 'Heat Shrink Gun'],
    components: ['Digital DSP Stepper Drivers DM556 (x4)', '32-Bit CNC Motion Controller Board (USB/Ethernet)', 'Twisted Pair Shielded Signal Cables (24 AWG)', 'Bootlace Ferrules Kit'],
    specs: {
      torque: 'Driver terminals 0.8 N·m',
      tolerance: '1600 pulses/revolution resolution',
      fastener: 'M3 Terminal Screws',
      criticalCheck: 'Double check motor coil phase pairs (A+, A-, B+, B-) with multimeter resistance test before powering on.',
    },
    proTipUrdu: 'موٹر کی تاروں کو جوڑنے سے پہلے ملٹی میٹر کے اوہمز پر چیک کریں تاکہ کوائل کے فیز اے اور بی آپس میں گڑبڑ نہ ہوں۔',
    proTipEn: 'Measure resistance across motor wire pairs with an ohmmeter: connected pairs read 1-3Ω; never swap A and B phases into live terminals.',
    defaultImage: '/src/assets/images/cnc_electronics_wiring_cad_1791448948411.jpg',
    svgSchemaType: 'stepper_drivers',
  },
  {
    id: 28,
    phaseId: 6,
    phaseNameUrdu: 'فیز 6: الیکٹرانکس، وی ایف ڈی اور کنٹرول سسٹم',
    phaseNameEn: 'Phase 6: Electronics, Power & Inverter VFD',
    titleUrdu: '2.2kW وی ایف ڈی انورٹر (VFD)، واٹر پمپ سرکٹ اور ایمرجنسی اسٹاپ',
    titleEn: '2.2kW Variable Frequency Drive (VFD), Water Pump Interlock & E-Stop',
    shortSummaryUrdu: 'HY انورٹر کے پیرامیٹرز سیٹ کریں، 0-10V اسپیڈ کنٹرول تاریں لگائیں اور واٹر پمپ سینسر انٹر لاک کریں۔',
    shortSummaryEn: 'Wire 2.2kW Huanyang VFD inverter, configure 400Hz base frequency, integrate coolant flow interlock and E-Stop.',
    descriptionUrdu: '2.2kW HY وی ایف ڈی انورٹر لگائیں۔ سب سے اہم کام: انورٹر کے اندر PD005 (Base Freq = 400Hz) اور PD004 (Max Freq = 400Hz) سیٹ کرنا ہے، ورنہ 50Hz پر اسپنڈل موٹر چند سیکنڈ میں جل جائے گی۔ کنٹرولر کے ساتھ 0-10V اینالاگ اسپیڈ کنٹرول اور پینل پر ایمرجنسی اسٹاپ (E-Stop) بٹن سیٹ کریں۔',
    descriptionEn: 'Wire the 2.2kW VFD inverter (U, V, W to spindle motor with earth ground). CRITICAL STEP: Program VFD parameters PD005 to 400Hz, PD004 to 400Hz, and PD011 to 100Hz min before running; default 50Hz will incinerate high-speed spindle windings instantly. Wire 0-10V analog speed control and latching E-Stop button.',
    cadPrompt: '3D CAD technical blueprint Step 28: 2.2kW Variable Frequency Drive (VFD) inverter wiring diagram to 3-phase high speed spindle, cooling water flow sensor safety interlock switch, red mushroom E-Stop button, dark cyan blueprint grid.',
    tools: ['Digital Multimeter', 'Tachometer Strobe Tool', 'Insulated Screwdrivers'],
    components: ['2.2kW Huanyang / YL VFD Inverter (220V Single to 3-Phase)', 'Submersible Coolant Pump 75W', 'Coolant Flow Switch Interlock Sensor', 'Latching Twist-to-Release E-Stop Mushroom Button'],
    specs: {
      torque: 'VFD terminals 1.5 N·m',
      tolerance: '0 - 24,000 RPM continuous modulation',
      fastener: 'M4 Clamp Screws',
      criticalCheck: 'CRITICAL: Verify VFD Base & Max frequency parameters are set to 400Hz BEFORE pressing Run.',
    },
    proTipUrdu: 'اگر کولنٹ پمپ بند ہو تو اسپنڈل کو فوری بند کرنے کے لیے فلو سوئچ (Flow Switch) کو وی ایف ڈی کے DCM اور FOR سے انٹر لاک کریں۔',
    proTipEn: 'Wire an inline water flow switch into the VFD external trip input: if coolant flow drops, the VFD instantly shuts off the spindle, saving thousands in repair.',
    defaultImage: '/src/assets/images/cnc_electronics_wiring_cad_1791448948411.jpg',
    svgSchemaType: 'vfd_inverter',
  },

  // ================= PHASE 7: Software, Commissioning & Spoilboard (سٹیپ 29 تا 30) =================
  {
    id: 29,
    phaseId: 7,
    phaseNameUrdu: 'فیز 7: سافٹ ویئر ٹیوننگ اور پہلی کٹنگ',
    phaseNameEn: 'Phase 7: Software Tuning & First Cut',
    titleUrdu: 'CNC موشن کنٹرول سافٹ ویئر، مائیکرو اسٹیپنگ اور اسٹیپس/mm کیلیبریشن',
    titleEn: 'CNC Motion Control Software Configuration & Steps/mm Tuning',
    shortSummaryUrdu: 'کینڈل یا Mach3 میں $100, $101, $102 اسٹیپس فی ملی میٹر کیلکولیٹ کریں اور ایکسلریشن سیٹ کریں۔',
    shortSummaryEn: 'Calculate exact steps/mm in control software (e.g., GRBL/Mach4/LinuxCNC) and calibrate axis travel.',
    descriptionUrdu: 'سافٹ ویئر کنٹرولر میں اسٹیپس فی ملی میٹر کا فارمولا لگائیں: (Steps per rev × Microstepping) ÷ Pitch = (200 × 8) ÷ 5mm = 320 steps/mm۔ مشین پر 300 ملی میٹر سفر کمانڈ کریں اور ڈیجیٹل ورنیئر کیلیپر سے ناپ کر تصدیق کریں۔ فیڈ ریٹ (Max Velocity = 4000 mm/min) اور ایکسلریشن (400 mm/s²) ٹیون کریں۔',
    descriptionEn: 'Configure steps/mm values into the firmware ($100, $101, $102): with 200 step motor, 1/8 microstep (1600 pulses/rev), and 5mm pitch ballscrew, steps/mm = 1600 / 5 = 320.000. Command a 300mm jog and verify with precision dial caliper. Fine-tune acceleration ramps to eliminate step skipping.',
    cadPrompt: '3D CAD technical blueprint Step 29: CNC motion controller GUI interface screen showing steps per mm calibration equation, digital caliper measuring test move against aluminum rail, dark blueprint style with technical annotations.',
    tools: ['Digital Vernier Caliper 300mm / 500mm', 'Laptop with CNC Controller Software', 'USB / Ethernet Cable'],
    components: ['CNC Control Software (bCNC / Candle / Mach3 / UGS)', 'Firmware Configuration Backup USB', 'Calibration Gauge Block (100.00mm)'],
    specs: {
      torque: 'Software digital calibration',
      tolerance: '< 0.02 mm across 300 mm test distance',
      fastener: 'N/A (Firmware parameters)',
      criticalCheck: 'Verify that commanding 100mm move results in exactly 100.00mm physical distance.',
    },
    proTipUrdu: 'کبھی بھی ایکسلریشن کو شروع میں بہت زیادہ مت رکھیں، ورنہ موٹر تیز جھٹکے سے اسٹیپ کھو دے گی (Loss of steps)۔',
    proTipEn: 'Begin with conservative acceleration (250 mm/s²); push speed higher gradually only after 20 hours of fault-free dry runs.',
    defaultImage: '/src/assets/images/cnc_completed_router_cad_1791448958543.jpg',
    svgSchemaType: 'software_tuning',
  },
  {
    id: 30,
    phaseId: 7,
    phaseNameUrdu: 'فیز 7: سافٹ ویئر ٹیوننگ اور پہلی کٹنگ',
    phaseNameEn: 'Phase 7: Software Tuning & First Cut',
    titleUrdu: 'اسپوئل بورڈ سرفیسنگ، اسپنڈل رن آؤٹ فائنل ٹیسٹ اور پہلا کامیاب CNC کٹ',
    titleEn: 'Spoilboard Surface Surfacing & First Test CNC Cut (Commissioning Complete)',
    shortSummaryUrdu: 'MDF اسپوئل بورڈ پر 50 ملی میٹر فلائی کٹر چلا کر لیول کریں اور پریسیشن ٹیسٹ نمونہ کاٹیں۔',
    shortSummaryEn: 'Surface MDF spoilboard with 50mm flycutter to create dead-flat bed, then perform first test machining project.',
    descriptionUrdu: 'ایلومینیم بیڈ کے اوپر 18 ملی میٹر MDF شیٹ کلیمپ کریں۔ 50 ملی میٹر وائڈ فلائی کٹر (Flycutter/Surfacing bit) لگا کر پورے بیڈ پر 0.5 ملی میٹر کٹنگ ڈیپتھ کا فیسنگ پروگرام چلائیں۔ یہ بیڈ کو مشین کی ٹریول کے عین مطابق پرفیکٹ ہموار کر دے گا۔ اس کے بعد ایلومینیم یا لکڑی پر پہلا ٹیسٹ پروجیکٹ کاٹ کر اسمبل کریں۔ مبارک ہو! CNC روٹر مکمل تیار ہے۔',
    descriptionEn: 'Bolt down an 18mm dense MDF spoilboard over the aluminum T-slot sub-bed. Chuck a 50mm carbide insert surfacing flycutter into the spindle and run a zig-zag facing toolpath removing 0.5mm. The surfaced spoilboard is now 100% planar to the cutter trajectory. Mill your first test project. Congratulations! The 3-axis CNC router is fully assembled and commissioned.',
    cadPrompt: '3D CAD technical engineering view Step 30: Fully completed heavy-duty 3-axis CNC router running spoilboard surfacing toolpath with 50mm flycutter bit, illuminated LED dust shoe, glowing cyan technical blueprint outlines, finished assembled machine celebration view.',
    tools: ['50mm Carbide Insert Surfacing Bit', 'Shop Vacuum / Dust Collector', 'Digital Caliper for Finished Part Inspection'],
    components: ['18mm Ultra-Dense MDF Spoilboard', 'Nylon Cam Clamps', 'Test Hardwood or 6061-T6 Aluminum Stock (150x150x10mm)'],
    specs: {
      torque: 'Flycutter collet 40.0 N·m',
      tolerance: '< 0.01 mm step-over ridge flatness',
      fastener: 'Nylon Hold-Down Fixtures',
      criticalCheck: 'Surfaced spoilboard must feel silky-smooth across all overlapping flycutter passes with zero ridge lines.',
    },
    proTipUrdu: 'اسپوئل بورڈ کو فیس کرنے کے بعد اس پر ورنیئر سے چیک کریں، اب آپ کا سی این سی روٹر انڈسٹریل درستگی کے ساتھ کام کے لیے تیار ہے!',
    proTipEn: 'Run your finger across adjacent surfacing toolpath lanes: feeling zero ridges proves your spindle tramming and machine build was executed with master precision!',
    defaultImage: '/src/assets/images/cnc_completed_router_cad_1791448958543.jpg',
    svgSchemaType: 'spoilboard_firstcut',
  },
,
{
  "id": 31,
  "phaseId": 4,
  "phaseNameUrdu": "فیز 4: مکینیکل سیدھ اور وائرنگ",
  "phaseNameEn": "Phase 4: Mechanical Alignment & Wiring",
  "titleUrdu": "فریم کی پیمائش کی دوبارہ تصدیق",
  "titleEn": "Recheck Frame Dimensions",
  "shortSummaryUrdu": "فریم کی چوڑائی، لمبائی، دونوں ڈائیگنلز اور لیول دوبارہ ناپیں؛ اگلے مرحلے سے پہلے اصل پیمائش لکھیں۔",
  "shortSummaryEn": "Measure frame width, length, diagonals and level; record actual values before proceeding.",
  "descriptionUrdu": "فریم کی چوڑائی، لمبائی، دونوں ڈائیگنلز اور لیول دوبارہ ناپیں؛ اگلے مرحلے سے پہلے اصل پیمائش لکھیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Measure frame width, length, diagonals and level; record actual values before proceeding. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 31: Recheck Frame Dimensions, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "base_frame"
},
{
  "id": 32,
  "phaseId": 4,
  "phaseNameUrdu": "فیز 4: مکینیکل سیدھ اور وائرنگ",
  "phaseNameEn": "Phase 4: Mechanical Alignment & Wiring",
  "titleUrdu": "بیڈ کی سطح بندی",
  "titleEn": "Level the Machine Bed",
  "shortSummaryUrdu": "پریسیژن اسٹریٹ ایج اور فیلر گیج سے بیڈ کے اونچے اور نیچے مقامات معلوم کریں۔",
  "shortSummaryEn": "Use a precision straightedge and feeler gauges to locate high and low spots across the bed.",
  "descriptionUrdu": "پریسیژن اسٹریٹ ایج اور فیلر گیج سے بیڈ کے اونچے اور نیچے مقامات معلوم کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Use a precision straightedge and feeler gauges to locate high and low spots across the bed. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 32: Level the Machine Bed, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "cross_members"
},
{
  "id": 33,
  "phaseId": 4,
  "phaseNameUrdu": "فیز 4: مکینیکل سیدھ اور وائرنگ",
  "phaseNameEn": "Phase 4: Mechanical Alignment & Wiring",
  "titleUrdu": "ریلوں کی متوازی سیدھ",
  "titleEn": "Align Rails in Parallel",
  "shortSummaryUrdu": "مشین کی ڈرائنگ اور ڈائل انڈیکیٹر سے پوری لمبائی میں ریلوں کا متوازی ہونا چیک کریں۔",
  "shortSummaryEn": "Verify rail parallelism over the full travel using the machine drawing and dial indicator.",
  "descriptionUrdu": "مشین کی ڈرائنگ اور ڈائل انڈیکیٹر سے پوری لمبائی میں ریلوں کا متوازی ہونا چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Verify rail parallelism over the full travel using the machine drawing and dial indicator. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 33: Align Rails in Parallel, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "leveling_feet"
},
{
  "id": 34,
  "phaseId": 4,
  "phaseNameUrdu": "فیز 4: مکینیکل سیدھ اور وائرنگ",
  "phaseNameEn": "Phase 4: Mechanical Alignment & Wiring",
  "titleUrdu": "ریل بولٹس کی ترتیب وار ٹائٹننگ",
  "titleEn": "Torque Rail Fasteners in Sequence",
  "shortSummaryUrdu": "ریل کے بولٹس مینوفیکچرر کی ترتیب کے مطابق آہستہ آہستہ کسیں اور پھر سیدھ دوبارہ چیک کریں۔",
  "shortSummaryEn": "Tighten rail fasteners gradually in the manufacturer’s specified sequence; recheck alignment afterward.",
  "descriptionUrdu": "ریل کے بولٹس مینوفیکچرر کی ترتیب کے مطابق آہستہ آہستہ کسیں اور پھر سیدھ دوبارہ چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Tighten rail fasteners gradually in the manufacturer’s specified sequence; recheck alignment afterward. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 34: Torque Rail Fasteners in Sequence, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "y_rails"
},
{
  "id": 35,
  "phaseId": 4,
  "phaseNameUrdu": "فیز 4: مکینیکل سیدھ اور وائرنگ",
  "phaseNameEn": "Phase 4: Mechanical Alignment & Wiring",
  "titleUrdu": "گینٹری اسکوائر چیک",
  "titleEn": "Check Gantry Squareness",
  "shortSummaryUrdu": "گینٹری کو دونوں سروں تک لے جا کر حوالہ پیمائشوں کا موازنہ کریں تاکہ ٹیڑھا پن معلوم ہو۔",
  "shortSummaryEn": "Move the gantry to both ends and compare reference measurements for racking or skew.",
  "descriptionUrdu": "گینٹری کو دونوں سروں تک لے جا کر حوالہ پیمائشوں کا موازنہ کریں تاکہ ٹیڑھا پن معلوم ہو۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Move the gantry to both ends and compare reference measurements for racking or skew. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 35: Check Gantry Squareness, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "sub_bed"
},
{
  "id": 36,
  "phaseId": 4,
  "phaseNameUrdu": "فیز 4: مکینیکل سیدھ اور وائرنگ",
  "phaseNameEn": "Phase 4: Mechanical Alignment & Wiring",
  "titleUrdu": "بال اسکرو الائنمنٹ",
  "titleEn": "Align Ball Screws",
  "shortSummaryUrdu": "بجلی منقطع کرکے کپلر کی سیدھ چیک کریں اور بال اسکرو کو ہاتھ سے آزاد گھومنے کی تصدیق کریں۔",
  "shortSummaryEn": "Check coupler alignment and ensure the screw rotates freely by hand with power isolated.",
  "descriptionUrdu": "بجلی منقطع کرکے کپلر کی سیدھ چیک کریں اور بال اسکرو کو ہاتھ سے آزاد گھومنے کی تصدیق کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Check coupler alignment and ensure the screw rotates freely by hand with power isolated. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 36: Align Ball Screws, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "bearing_blocks"
},
{
  "id": 37,
  "phaseId": 4,
  "phaseNameUrdu": "فیز 4: مکینیکل سیدھ اور وائرنگ",
  "phaseNameEn": "Phase 4: Mechanical Alignment & Wiring",
  "titleUrdu": "کپلر اور موٹر ماؤنٹ چیک",
  "titleEn": "Inspect Couplers and Motor Mounts",
  "shortSummaryUrdu": "کپلر کی درست فٹنگ اور موٹر شافٹ کی سیدھ چیک کریں؛ شافٹ پر غیر ضروری دباؤ نہ ہو۔",
  "shortSummaryEn": "Confirm couplers are seated correctly and motor shafts are not forced out of alignment.",
  "descriptionUrdu": "کپلر کی درست فٹنگ اور موٹر شافٹ کی سیدھ چیک کریں؛ شافٹ پر غیر ضروری دباؤ نہ ہو۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Confirm couplers are seated correctly and motor shafts are not forced out of alignment. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 37: Inspect Couplers and Motor Mounts, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "ball_screws_y"
},
{
  "id": 38,
  "phaseId": 4,
  "phaseNameUrdu": "فیز 4: مکینیکل سیدھ اور وائرنگ",
  "phaseNameEn": "Phase 4: Mechanical Alignment & Wiring",
  "titleUrdu": "زیڈ ایکسس ٹریول چیک",
  "titleEn": "Verify Z-Axis Travel",
  "shortSummaryUrdu": "زیڈ ایکسس کو آہستہ محفوظ حد میں چلائیں اور رگڑ یا کیبل کے پھنسنے کو دیکھیں۔",
  "shortSummaryEn": "Jog the Z axis slowly through its safe range and inspect for binding or cable interference.",
  "descriptionUrdu": "زیڈ ایکسس کو آہستہ محفوظ حد میں چلائیں اور رگڑ یا کیبل کے پھنسنے کو دیکھیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Jog the Z axis slowly through its safe range and inspect for binding or cable interference. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 38: Verify Z-Axis Travel, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "floating_bearings"
},
{
  "id": 39,
  "phaseId": 4,
  "phaseNameUrdu": "فیز 4: مکینیکل سیدھ اور وائرنگ",
  "phaseNameEn": "Phase 4: Mechanical Alignment & Wiring",
  "titleUrdu": "اسپنڈل ماؤنٹ کی سیدھ",
  "titleEn": "Align the Spindle Mount",
  "shortSummaryUrdu": "ڈائل انڈیکیٹر یا مناسب اسکوائر سے ماؤنٹ کی سطح اور اسپنڈل کا عمود ہونا چیک کریں۔",
  "shortSummaryEn": "Check mount face and spindle perpendicularity using a dial indicator or suitable square.",
  "descriptionUrdu": "ڈائل انڈیکیٹر یا مناسب اسکوائر سے ماؤنٹ کی سطح اور اسپنڈل کا عمود ہونا چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Check mount face and spindle perpendicularity using a dial indicator or suitable square. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 39: Align the Spindle Mount, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "stepper_y"
},
{
  "id": 40,
  "phaseId": 4,
  "phaseNameUrdu": "فیز 4: مکینیکل سیدھ اور وائرنگ",
  "phaseNameEn": "Phase 4: Mechanical Alignment & Wiring",
  "titleUrdu": "ڈسٹ شو اور سکشن",
  "titleEn": "Install Dust Shoe and Extraction",
  "shortSummaryUrdu": "ڈسٹ شو لگائیں مگر کٹر، لمٹ سوئچ یا کسی ایکسس کی مکمل حرکت میں رکاوٹ نہ آئے۔",
  "shortSummaryEn": "Fit dust collection without obstructing the tool, limit switches, or full axis travel.",
  "descriptionUrdu": "ڈسٹ شو لگائیں مگر کٹر، لمٹ سوئچ یا کسی ایکسس کی مکمل حرکت میں رکاوٹ نہ آئے۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Fit dust collection without obstructing the tool, limit switches, or full axis travel. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 40: Install Dust Shoe and Extraction, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "endstops_y"
},
{
  "id": 41,
  "phaseId": 5,
  "phaseNameUrdu": "فیز 5: کنٹرولر سیٹ اپ اور کیلیبریشن",
  "phaseNameEn": "Phase 5: Controller Setup & Calibration",
  "titleUrdu": "کیبل چین کی روٹنگ",
  "titleEn": "Route Cable Chains",
  "shortSummaryUrdu": "موٹر، اسپنڈل اور سینسر کیبلز مناسب طور پر الگ روٹ کریں اور موڑ کا کم از کم رداس برقرار رکھیں۔",
  "shortSummaryEn": "Route motor, spindle and sensor cables separately where practical; maintain bend radius.",
  "descriptionUrdu": "موٹر، اسپنڈل اور سینسر کیبلز مناسب طور پر الگ روٹ کریں اور موڑ کا کم از کم رداس برقرار رکھیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Route motor, spindle and sensor cables separately where practical; maintain bend radius. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 41: Route Cable Chains, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "gantry_risers"
},
{
  "id": 42,
  "phaseId": 5,
  "phaseNameUrdu": "فیز 5: کنٹرولر سیٹ اپ اور کیلیبریشن",
  "phaseNameEn": "Phase 5: Controller Setup & Calibration",
  "titleUrdu": "ارتھنگ اور بانڈنگ",
  "titleEn": "Verify Protective Earthing",
  "shortSummaryUrdu": "مین بجلی منقطع رکھ کر مستند الیکٹریشن سے حفاظتی ارتھ کنٹینیوٹی اور بانڈنگ چیک کروائیں۔",
  "shortSummaryEn": "With mains disconnected, have a qualified person verify protective earth continuity and bonding.",
  "descriptionUrdu": "مین بجلی منقطع رکھ کر مستند الیکٹریشن سے حفاظتی ارتھ کنٹینیوٹی اور بانڈنگ چیک کروائیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "With mains disconnected, have a qualified person verify protective earth continuity and bonding. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 42: Verify Protective Earthing, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "gantry_beam"
},
{
  "id": 43,
  "phaseId": 5,
  "phaseNameUrdu": "فیز 5: کنٹرولر سیٹ اپ اور کیلیبریشن",
  "phaseNameEn": "Phase 5: Controller Setup & Calibration",
  "titleUrdu": "ایمرجنسی اسٹاپ ٹیسٹ",
  "titleEn": "Test Emergency Stop",
  "shortSummaryUrdu": "اسپنڈل یا حرکت فعال کرنے سے پہلے کنٹرولر مینوئل کے مطابق ایمرجنسی اسٹاپ ٹیسٹ کریں۔",
  "shortSummaryEn": "Test the E-stop according to the controller manual before enabling spindle or motion.",
  "descriptionUrdu": "اسپنڈل یا حرکت فعال کرنے سے پہلے کنٹرولر مینوئل کے مطابق ایمرجنسی اسٹاپ ٹیسٹ کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Test the E-stop according to the controller manual before enabling spindle or motion. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 43: Test Emergency Stop, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "x_rails"
},
{
  "id": 44,
  "phaseId": 5,
  "phaseNameUrdu": "فیز 5: کنٹرولر سیٹ اپ اور کیلیبریشن",
  "phaseNameEn": "Phase 5: Controller Setup & Calibration",
  "titleUrdu": "لمٹ سوئچ ٹیسٹ",
  "titleEn": "Test Limit Switches",
  "shortSummaryUrdu": "کم رفتار پر ہر لمٹ سوئچ الگ ٹرگر کریں اور کنٹرولر پر درست ایکسس کی نشاندہی دیکھیں۔",
  "shortSummaryEn": "Trigger each limit switch individually at low speed and verify the controller reports the correct axis.",
  "descriptionUrdu": "کم رفتار پر ہر لمٹ سوئچ الگ ٹرگر کریں اور کنٹرولر پر درست ایکسس کی نشاندہی دیکھیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Trigger each limit switch individually at low speed and verify the controller reports the correct axis. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 44: Test Limit Switches, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "ball_screw_x"
},
{
  "id": 45,
  "phaseId": 5,
  "phaseNameUrdu": "فیز 5: کنٹرولر سیٹ اپ اور کیلیبریشن",
  "phaseNameEn": "Phase 5: Controller Setup & Calibration",
  "titleUrdu": "موٹر سمت کی تصدیق",
  "titleEn": "Verify Motor Direction",
  "shortSummaryUrdu": "ٹول نکال کر کم جوگ رفتار پر ہر ایکسس کی سمت کنٹرولر ڈسپلے سے ملائیں۔",
  "shortSummaryEn": "With the tool removed and at low jog speed, verify each axis direction against the controller display.",
  "descriptionUrdu": "ٹول نکال کر کم جوگ رفتار پر ہر ایکسس کی سمت کنٹرولر ڈسپلے سے ملائیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "With the tool removed and at low jog speed, verify each axis direction against the controller display. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 45: Verify Motor Direction, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "stepper_x"
},
{
  "id": 46,
  "phaseId": 5,
  "phaseNameUrdu": "فیز 5: کنٹرولر سیٹ اپ اور کیلیبریشن",
  "phaseNameEn": "Phase 5: Controller Setup & Calibration",
  "titleUrdu": "ہومنگ ترتیب",
  "titleEn": "Configure Homing Sequence",
  "shortSummaryUrdu": "کنٹرولر کی دستاویز کے مطابق ہومنگ سمت، پل آف فاصلہ اور آخری سست اپروچ سیٹ کریں۔",
  "shortSummaryEn": "Set homing direction, pull-off distance and slow final approach using controller documentation.",
  "descriptionUrdu": "کنٹرولر کی دستاویز کے مطابق ہومنگ سمت، پل آف فاصلہ اور آخری سست اپروچ سیٹ کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Set homing direction, pull-off distance and slow final approach using controller documentation. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 46: Configure Homing Sequence, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "z_backplate"
},
{
  "id": 47,
  "phaseId": 5,
  "phaseNameUrdu": "فیز 5: کنٹرولر سیٹ اپ اور کیلیبریشن",
  "phaseNameEn": "Phase 5: Controller Setup & Calibration",
  "titleUrdu": "قدم فی ملی میٹر کیلیبریشن",
  "titleEn": "Calibrate Steps per Millimeter",
  "shortSummaryUrdu": "کم فاصلے کی نپی تلی حرکت دے کر اصل ٹریول سے کیلیبریشن کریں اور نتیجہ درج کریں۔",
  "shortSummaryEn": "Command a conservative measured move and calibrate using actual travel; document the result.",
  "descriptionUrdu": "کم فاصلے کی نپی تلی حرکت دے کر اصل ٹریول سے کیلیبریشن کریں اور نتیجہ درج کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Command a conservative measured move and calibrate using actual travel; document the result. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 47: Calibrate Steps per Millimeter, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "z_rails"
},
{
  "id": 48,
  "phaseId": 5,
  "phaseNameUrdu": "فیز 5: کنٹرولر سیٹ اپ اور کیلیبریشن",
  "phaseNameEn": "Phase 5: Controller Setup & Calibration",
  "titleUrdu": "بیک لیش پیمائش",
  "titleEn": "Measure Backlash",
  "shortSummaryUrdu": "ڈائل انڈیکیٹر سے ہر ایکسس کی سمت بدلنے پر غلطی ناپیں اور کمپنسیشن سے پہلے ریکارڈ کریں۔",
  "shortSummaryEn": "Use a dial indicator to measure reversal error on each axis and record results before compensation.",
  "descriptionUrdu": "ڈائل انڈیکیٹر سے ہر ایکسس کی سمت بدلنے پر غلطی ناپیں اور کمپنسیشن سے پہلے ریکارڈ کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Use a dial indicator to measure reversal error on each axis and record results before compensation. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 48: Measure Backlash, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "z_leadscrew"
},
{
  "id": 49,
  "phaseId": 5,
  "phaseNameUrdu": "فیز 5: کنٹرولر سیٹ اپ اور کیلیبریشن",
  "phaseNameEn": "Phase 5: Controller Setup & Calibration",
  "titleUrdu": "ریپیٹ ایبلٹی ٹیسٹ",
  "titleEn": "Test Repeatability",
  "shortSummaryUrdu": "ایک ہی حرکت کئی بار دہرائیں اور واپس آنے کی پیمائش کا موازنہ کریں۔",
  "shortSummaryEn": "Repeat the same move several times and compare the measured return position.",
  "descriptionUrdu": "ایک ہی حرکت کئی بار دہرائیں اور واپس آنے کی پیمائش کا موازنہ کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Repeat the same move several times and compare the measured return position. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 49: Test Repeatability, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "spindle_mount"
},
{
  "id": 50,
  "phaseId": 5,
  "phaseNameUrdu": "فیز 5: کنٹرولر سیٹ اپ اور کیلیبریشن",
  "phaseNameEn": "Phase 5: Controller Setup & Calibration",
  "titleUrdu": "فیڈ ریٹ کی محتاط جانچ",
  "titleEn": "Validate Feed Rate Conservatively",
  "shortSummaryUrdu": "متوقع فیڈ سے کم رفتار شروع کریں، آواز اور کٹ کا معیار دیکھ کر آہستہ بڑھائیں۔",
  "shortSummaryEn": "Begin below expected feed, listen for chatter and inspect cut quality before increasing gradually.",
  "descriptionUrdu": "متوقع فیڈ سے کم رفتار شروع کریں، آواز اور کٹ کا معیار دیکھ کر آہستہ بڑھائیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Begin below expected feed, listen for chatter and inspect cut quality before increasing gradually. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 50: Validate Feed Rate Conservatively, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "spindle_motor"
},
{
  "id": 51,
  "phaseId": 6,
  "phaseNameUrdu": "فیز 6: ٹیسٹ کٹ اور فائل ورک فلو",
  "phaseNameEn": "Phase 6: Test Cuts & File Workflow",
  "titleUrdu": "اسپنڈل کولنگ فلو",
  "titleEn": "Check Spindle Cooling Flow",
  "shortSummaryUrdu": "واٹر کولڈ اسپنڈل کے لیے چلانے سے پہلے کولنٹ فلو اور لیک سے پاک ہوز چیک کریں۔",
  "shortSummaryEn": "For water-cooled spindles, verify correct coolant flow and leak-free hoses before running.",
  "descriptionUrdu": "واٹر کولڈ اسپنڈل کے لیے چلانے سے پہلے کولنٹ فلو اور لیک سے پاک ہوز چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "For water-cooled spindles, verify correct coolant flow and leak-free hoses before running. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 51: Check Spindle Cooling Flow, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "drag_chains"
},
{
  "id": 52,
  "phaseId": 6,
  "phaseNameUrdu": "فیز 6: ٹیسٹ کٹ اور فائل ورک فلو",
  "phaseNameEn": "Phase 6: Test Cuts & File Workflow",
  "titleUrdu": "وی ایف ڈی پیرامیٹرز",
  "titleEn": "Verify VFD Parameters",
  "shortSummaryUrdu": "موٹر اور وی ایف ڈی مینوئل کے مطابق وولٹیج، کرنٹ، فریکوئنسی اور کنٹرول وائرنگ ملائیں۔",
  "shortSummaryEn": "Match motor voltage, current, frequency and control wiring to the motor and VFD manuals.",
  "descriptionUrdu": "موٹر اور وی ایف ڈی مینوئل کے مطابق وولٹیج، کرنٹ، فریکوئنسی اور کنٹرول وائرنگ ملائیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Match motor voltage, current, frequency and control wiring to the motor and VFD manuals. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 52: Verify VFD Parameters, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "limit_switches"
},
{
  "id": 53,
  "phaseId": 6,
  "phaseNameUrdu": "فیز 6: ٹیسٹ کٹ اور فائل ورک فلو",
  "phaseNameEn": "Phase 6: Test Cuts & File Workflow",
  "titleUrdu": "کولیٹ اور ٹول معائنہ",
  "titleEn": "Inspect Collet and Tool",
  "shortSummaryUrdu": "کولیٹ، نٹ اور کٹر صاف کرکے دیکھیں؛ خراب ٹول استعمال نہ کریں اور شینک درست پکڑیں۔",
  "shortSummaryEn": "Clean and inspect the collet, nut and cutter; reject damaged tools and clamp the shank correctly.",
  "descriptionUrdu": "کولیٹ، نٹ اور کٹر صاف کرکے دیکھیں؛ خراب ٹول استعمال نہ کریں اور شینک درست پکڑیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Clean and inspect the collet, nut and cutter; reject damaged tools and clamp the shank correctly. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 53: Inspect Collet and Tool, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "dial_tramming"
},
{
  "id": 54,
  "phaseId": 6,
  "phaseNameUrdu": "فیز 6: ٹیسٹ کٹ اور فائل ورک فلو",
  "phaseNameEn": "Phase 6: Test Cuts & File Workflow",
  "titleUrdu": "ورک ہولڈنگ ٹیسٹ",
  "titleEn": "Verify Workholding",
  "shortSummaryUrdu": "ٹیسٹ لکڑی مضبوطی سے باندھیں اور تصدیق کریں کہ کلیمپ ٹول پاتھ یا گینٹری سے نہیں ٹکرائیں گے۔",
  "shortSummaryEn": "Secure a test blank and confirm clamps cannot enter the toolpath or collide with the gantry.",
  "descriptionUrdu": "ٹیسٹ لکڑی مضبوطی سے باندھیں اور تصدیق کریں کہ کلیمپ ٹول پاتھ یا گینٹری سے نہیں ٹکرائیں گے۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Secure a test blank and confirm clamps cannot enter the toolpath or collide with the gantry. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 54: Verify Workholding, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "lubrication"
},
{
  "id": 55,
  "phaseId": 6,
  "phaseNameUrdu": "فیز 6: ٹیسٹ کٹ اور فائل ورک فلو",
  "phaseNameEn": "Phase 6: Test Cuts & File Workflow",
  "titleUrdu": "اسپوئل بورڈ زیرو",
  "titleEn": "Set Spoilboard Reference",
  "shortSummaryUrdu": "اسپوئل بورڈ کی سطح درست کریں یا ناپیں اور ورک زیڈ کے لیے قابلِ تکرار حوالہ مقرر کریں۔",
  "shortSummaryEn": "Surface or measure the spoilboard and define a repeatable work Z reference.",
  "descriptionUrdu": "اسپوئل بورڈ کی سطح درست کریں یا ناپیں اور ورک زیڈ کے لیے قابلِ تکرار حوالہ مقرر کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Surface or measure the spoilboard and define a repeatable work Z reference. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 55: Set Spoilboard Reference, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "control_box"
},
{
  "id": 56,
  "phaseId": 6,
  "phaseNameUrdu": "فیز 6: ٹیسٹ کٹ اور فائل ورک فلو",
  "phaseNameEn": "Phase 6: Test Cuts & File Workflow",
  "titleUrdu": "کنٹرولر بیک اپ",
  "titleEn": "Back Up Controller Settings",
  "shortSummaryUrdu": "کنٹرولر کنفیگریشن ایکسپورٹ کرکے اسٹیپس، لمٹس، ہومنگ اور اسپنڈل سیٹنگز تاریخ کے ساتھ محفوظ کریں۔",
  "shortSummaryEn": "Export controller configuration and save steps, limits, homing and spindle settings with a date.",
  "descriptionUrdu": "کنٹرولر کنفیگریشن ایکسپورٹ کرکے اسٹیپس، لمٹس، ہومنگ اور اسپنڈل سیٹنگز تاریخ کے ساتھ محفوظ کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Export controller configuration and save steps, limits, homing and spindle settings with a date. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 56: Back Up Controller Settings, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "power_supplies"
},
{
  "id": 57,
  "phaseId": 6,
  "phaseNameUrdu": "فیز 6: ٹیسٹ کٹ اور فائل ورک فلو",
  "phaseNameEn": "Phase 6: Test Cuts & File Workflow",
  "titleUrdu": "جی کوڈ کی شناخت",
  "titleEn": "Identify the G-code File",
  "shortSummaryUrdu": "لوڈ کرنے سے پہلے فائل ایکسٹینشن، یونٹس، کوآرڈینیٹ موڈ، اوریجن اور کنٹرولر مطابقت چیک کریں۔",
  "shortSummaryEn": "Confirm file extension, units, coordinate mode, origin and controller compatibility before loading.",
  "descriptionUrdu": "لوڈ کرنے سے پہلے فائل ایکسٹینشن، یونٹس، کوآرڈینیٹ موڈ، اوریجن اور کنٹرولر مطابقت چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Confirm file extension, units, coordinate mode, origin and controller compatibility before loading. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 57: Identify the G-code File, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "stepper_drivers"
},
{
  "id": 58,
  "phaseId": 6,
  "phaseNameUrdu": "فیز 6: ٹیسٹ کٹ اور فائل ورک فلو",
  "phaseNameEn": "Phase 6: Test Cuts & File Workflow",
  "titleUrdu": "جی کوڈ پری ویو",
  "titleEn": "Preview G-code Toolpath",
  "shortSummaryUrdu": "پری ویو یا سیمولیٹر میں ٹریول لمٹس، گہرائی، ریپڈ مووز اور غیر متوقع کوآرڈینیٹس دیکھیں۔",
  "shortSummaryEn": "Inspect travel limits, depth, rapid moves and unexpected coordinates in the preview or simulator.",
  "descriptionUrdu": "پری ویو یا سیمولیٹر میں ٹریول لمٹس، گہرائی، ریپڈ مووز اور غیر متوقع کوآرڈینیٹس دیکھیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Inspect travel limits, depth, rapid moves and unexpected coordinates in the preview or simulator. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 58: Preview G-code Toolpath, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "vfd_inverter"
},
{
  "id": 59,
  "phaseId": 6,
  "phaseNameUrdu": "فیز 6: ٹیسٹ کٹ اور فائل ورک فلو",
  "phaseNameEn": "Phase 6: Test Cuts & File Workflow",
  "titleUrdu": "ڈرائی رن ٹیسٹ",
  "titleEn": "Perform a Dry Run",
  "shortSummaryUrdu": "اسپنڈل بند اور محفوظ کلیئرنس کے ساتھ ورک پیس کے اوپر ڈرائی رن کرکے حرکت اور لمٹس چیک کریں۔",
  "shortSummaryEn": "With spindle disabled and safe clearance, run above the workpiece to check motion and limits.",
  "descriptionUrdu": "اسپنڈل بند اور محفوظ کلیئرنس کے ساتھ ورک پیس کے اوپر ڈرائی رن کرکے حرکت اور لمٹس چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "With spindle disabled and safe clearance, run above the workpiece to check motion and limits. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 59: Perform a Dry Run, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "software_tuning"
},
{
  "id": 60,
  "phaseId": 6,
  "phaseNameUrdu": "فیز 6: ٹیسٹ کٹ اور فائل ورک فلو",
  "phaseNameEn": "Phase 6: Test Cuts & File Workflow",
  "titleUrdu": "زیرو پوائنٹ کی تصدیق",
  "titleEn": "Verify Work Zero",
  "shortSummaryUrdu": "منتخب طریقے سے X/Y/Z زیرو سیٹ کریں اور کٹنگ سے پہلے ٹول کلیئرنس دوبارہ دیکھیں۔",
  "shortSummaryEn": "Set X/Y/Z zero using the chosen method and recheck tool clearance before cutting.",
  "descriptionUrdu": "منتخب طریقے سے X/Y/Z زیرو سیٹ کریں اور کٹنگ سے پہلے ٹول کلیئرنس دوبارہ دیکھیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Set X/Y/Z zero using the chosen method and recheck tool clearance before cutting. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 60: Verify Work Zero, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "spoilboard_firstcut"
},
{
  "id": 61,
  "phaseId": 7,
  "phaseNameUrdu": "فیز 7: مینٹیننس اور خرابی کی تشخیص",
  "phaseNameEn": "Phase 7: Maintenance & Troubleshooting",
  "titleUrdu": "پہلا ٹیسٹ کٹ",
  "titleEn": "Run a Shallow Test Cut",
  "shortSummaryUrdu": "اسکریپ مٹیریل، کم گہرائی اور محتاط فیڈ سے ٹیسٹ کٹ کریں؛ وائبریشن ہو تو فوراً روکیں۔",
  "shortSummaryEn": "Use scrap material, shallow depth and conservative feed; stop immediately if vibration occurs.",
  "descriptionUrdu": "اسکریپ مٹیریل، کم گہرائی اور محتاط فیڈ سے ٹیسٹ کٹ کریں؛ وائبریشن ہو تو فوراً روکیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Use scrap material, shallow depth and conservative feed; stop immediately if vibration occurs. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 61: Run a Shallow Test Cut, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "base_frame"
},
{
  "id": 62,
  "phaseId": 7,
  "phaseNameUrdu": "فیز 7: مینٹیننس اور خرابی کی تشخیص",
  "phaseNameEn": "Phase 7: Maintenance & Troubleshooting",
  "titleUrdu": "کٹ کے سائز کی پیمائش",
  "titleEn": "Measure Test Part",
  "shortSummaryUrdu": "ٹیسٹ پارٹ کو کیلپر سے ناپ کر CAD ڈرائنگ کی پیمائش سے موازنہ کریں۔",
  "shortSummaryEn": "Measure the test part with calipers and compare dimensions with the CAD drawing.",
  "descriptionUrdu": "ٹیسٹ پارٹ کو کیلپر سے ناپ کر CAD ڈرائنگ کی پیمائش سے موازنہ کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Measure the test part with calipers and compare dimensions with the CAD drawing. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 62: Measure Test Part, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "cross_members"
},
{
  "id": 63,
  "phaseId": 7,
  "phaseNameUrdu": "فیز 7: مینٹیننس اور خرابی کی تشخیص",
  "phaseNameEn": "Phase 7: Maintenance & Troubleshooting",
  "titleUrdu": "سطح اور ٹول پاتھ معائنہ",
  "titleEn": "Inspect Surface and Toolpath",
  "shortSummaryUrdu": "چٹر، جلنے کے نشان، مسڈ اسٹیپس اور سطح کی لکیریں دیکھیں؛ ایک وقت میں ایک پیرامیٹر بدلیں۔",
  "shortSummaryEn": "Look for chatter, burn marks, missed steps and visible ridges; change one parameter at a time.",
  "descriptionUrdu": "چٹر، جلنے کے نشان، مسڈ اسٹیپس اور سطح کی لکیریں دیکھیں؛ ایک وقت میں ایک پیرامیٹر بدلیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Look for chatter, burn marks, missed steps and visible ridges; change one parameter at a time. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 63: Inspect Surface and Toolpath, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "leveling_feet"
},
{
  "id": 64,
  "phaseId": 7,
  "phaseNameUrdu": "فیز 7: مینٹیننس اور خرابی کی تشخیص",
  "phaseNameEn": "Phase 7: Maintenance & Troubleshooting",
  "titleUrdu": "روزمرہ صفائی",
  "titleEn": "Routine Cleaning",
  "shortSummaryUrdu": "چپس صاف کرنے سے پہلے بجلی منقطع کریں؛ ریل، اسکرو، پنکھے اور برقی باکس صاف رکھیں۔",
  "shortSummaryEn": "Isolate power before cleaning chips; keep rails, screws, fans and electrical enclosures clean.",
  "descriptionUrdu": "چپس صاف کرنے سے پہلے بجلی منقطع کریں؛ ریل، اسکرو، پنکھے اور برقی باکس صاف رکھیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Isolate power before cleaning chips; keep rails, screws, fans and electrical enclosures clean. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 64: Routine Cleaning, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "y_rails"
},
{
  "id": 65,
  "phaseId": 7,
  "phaseNameUrdu": "فیز 7: مینٹیننس اور خرابی کی تشخیص",
  "phaseNameEn": "Phase 7: Maintenance & Troubleshooting",
  "titleUrdu": "لبریکیشن شیڈول",
  "titleEn": "Set Lubrication Schedule",
  "shortSummaryUrdu": "ریل اور بال اسکرو بنانے والے کی چکنائی اور وقفے کی ہدایات اپنائیں؛ ضرورت سے زیادہ گریس نہ لگائیں۔",
  "shortSummaryEn": "Follow the rail and ball-screw maker’s lubricant type and interval; avoid over-greasing.",
  "descriptionUrdu": "ریل اور بال اسکرو بنانے والے کی چکنائی اور وقفے کی ہدایات اپنائیں؛ ضرورت سے زیادہ گریس نہ لگائیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Follow the rail and ball-screw maker’s lubricant type and interval; avoid over-greasing. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 65: Set Lubrication Schedule, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "sub_bed"
},
{
  "id": 66,
  "phaseId": 7,
  "phaseNameUrdu": "فیز 7: مینٹیننس اور خرابی کی تشخیص",
  "phaseNameEn": "Phase 7: Maintenance & Troubleshooting",
  "titleUrdu": "ڈھیلے فاسٹنرز کا معائنہ",
  "titleEn": "Inspect Fasteners Periodically",
  "shortSummaryUrdu": "اہم فاسٹنرز ڈھیلے ہونے کے لیے چیک کریں اور اندازے کے بجائے مقررہ ٹارک استعمال کریں۔",
  "shortSummaryEn": "Check critical fasteners for loosening and use the specified torque, not guessed values.",
  "descriptionUrdu": "اہم فاسٹنرز ڈھیلے ہونے کے لیے چیک کریں اور اندازے کے بجائے مقررہ ٹارک استعمال کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Check critical fasteners for loosening and use the specified torque, not guessed values. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 66: Inspect Fasteners Periodically, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "bearing_blocks"
},
{
  "id": 67,
  "phaseId": 7,
  "phaseNameUrdu": "فیز 7: مینٹیننس اور خرابی کی تشخیص",
  "phaseNameEn": "Phase 7: Maintenance & Troubleshooting",
  "titleUrdu": "موٹر درجہ حرارت کی نگرانی",
  "titleEn": "Monitor Motor Temperature",
  "shortSummaryUrdu": "مختصر ٹیسٹ رن میں موٹر اور ڈرائیور کا درجہ حرارت مینوفیکچرر کی حد سے ملائیں۔",
  "shortSummaryEn": "Check motor and driver temperatures during a short test run against manufacturer limits.",
  "descriptionUrdu": "مختصر ٹیسٹ رن میں موٹر اور ڈرائیور کا درجہ حرارت مینوفیکچرر کی حد سے ملائیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Check motor and driver temperatures during a short test run against manufacturer limits. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 67: Monitor Motor Temperature, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "ball_screws_y"
},
{
  "id": 68,
  "phaseId": 7,
  "phaseNameUrdu": "فیز 7: مینٹیننس اور خرابی کی تشخیص",
  "phaseNameEn": "Phase 7: Maintenance & Troubleshooting",
  "titleUrdu": "ڈسٹ کلیکشن کی جانچ",
  "titleEn": "Check Dust Collection",
  "shortSummaryUrdu": "ہوز کی بندش، ہوا کے بہاؤ اور فلٹر کی حالت چیک کریں؛ مٹیریل کے مطابق حفاظتی سامان استعمال کریں۔",
  "shortSummaryEn": "Inspect hose blockage, airflow and filter condition; use suitable protection for the material.",
  "descriptionUrdu": "ہوز کی بندش، ہوا کے بہاؤ اور فلٹر کی حالت چیک کریں؛ مٹیریل کے مطابق حفاظتی سامان استعمال کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Inspect hose blockage, airflow and filter condition; use suitable protection for the material. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 68: Check Dust Collection, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "floating_bearings"
},
{
  "id": 69,
  "phaseId": 7,
  "phaseNameUrdu": "فیز 7: مینٹیننس اور خرابی کی تشخیص",
  "phaseNameEn": "Phase 7: Maintenance & Troubleshooting",
  "titleUrdu": "مشین کی دستاویزات",
  "titleEn": "Document Machine Configuration",
  "shortSummaryUrdu": "مشین کی پیمائش، کنٹرولر، فرم ویئر، ٹول آف سیٹس اور کیلیبریشن ویلیوز درج کریں۔",
  "shortSummaryEn": "Record machine dimensions, controller, firmware, tool offsets and calibration values.",
  "descriptionUrdu": "مشین کی پیمائش، کنٹرولر، فرم ویئر، ٹول آف سیٹس اور کیلیبریشن ویلیوز درج کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Record machine dimensions, controller, firmware, tool offsets and calibration values. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 69: Document Machine Configuration, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "stepper_y"
},
{
  "id": 70,
  "phaseId": 7,
  "phaseNameUrdu": "فیز 7: مینٹیننس اور خرابی کی تشخیص",
  "phaseNameEn": "Phase 7: Maintenance & Troubleshooting",
  "titleUrdu": "فالٹ ریکوری طریقہ",
  "titleEn": "Prepare Fault Recovery Procedure",
  "shortSummaryUrdu": "محفوظ اسٹاپ، بجلی الگ کرنے، جاب دوبارہ شروع کرنے اور پوزیشن ضائع ہونے کی ریکوری درج کریں۔",
  "shortSummaryEn": "Document safe stop, power isolation, job restart checks and recovery from lost position.",
  "descriptionUrdu": "محفوظ اسٹاپ، بجلی الگ کرنے، جاب دوبارہ شروع کرنے اور پوزیشن ضائع ہونے کی ریکوری درج کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Document safe stop, power isolation, job restart checks and recovery from lost position. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 70: Prepare Fault Recovery Procedure, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "endstops_y"
},
{
  "id": 71,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "کام کی فائل محفوظ کرنا",
  "titleEn": "Archive Job Files",
  "shortSummaryUrdu": "اصل ڈیزائن، ایکسپورٹ جی کوڈ اور تاریخ والی ترمیمی کاپی الگ فولڈرز میں محفوظ کریں۔",
  "shortSummaryEn": "Keep the original design, exported G-code and a dated revision copy in separate folders.",
  "descriptionUrdu": "اصل ڈیزائن، ایکسپورٹ جی کوڈ اور تاریخ والی ترمیمی کاپی الگ فولڈرز میں محفوظ کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Keep the original design, exported G-code and a dated revision copy in separate folders. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 71: Archive Job Files, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "gantry_risers"
},
{
  "id": 72,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "فائل ورژن کا موازنہ",
  "titleEn": "Compare File Versions",
  "shortSummaryUrdu": "مشین چلانے سے پہلے منتخب ورژن کی تصدیق اور منظور شدہ ڈرائنگ سے پیمائشوں کا موازنہ کریں۔",
  "shortSummaryEn": "Before machining, verify the selected revision and compare dimensions against the approved drawing.",
  "descriptionUrdu": "مشین چلانے سے پہلے منتخب ورژن کی تصدیق اور منظور شدہ ڈرائنگ سے پیمائشوں کا موازنہ کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Before machining, verify the selected revision and compare dimensions against the approved drawing. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 72: Compare File Versions, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "gantry_beam"
},
{
  "id": 73,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "فائل اپ لوڈ کی جانچ",
  "titleEn": "Verify File Import",
  "shortSummaryUrdu": "اپ لوڈ کے بعد دکھایا گیا فائل نام، پارس شدہ جیومیٹری اور مجموعی پیمائش چیک کریں۔",
  "shortSummaryEn": "After upload, confirm the displayed filename, parsed geometry and expected overall dimensions.",
  "descriptionUrdu": "اپ لوڈ کے بعد دکھایا گیا فائل نام، پارس شدہ جیومیٹری اور مجموعی پیمائش چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "After upload, confirm the displayed filename, parsed geometry and expected overall dimensions. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 73: Verify File Import, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "x_rails"
},
{
  "id": 74,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "فائل ایکسپورٹ کی جانچ",
  "titleEn": "Verify Exported File",
  "shortSummaryUrdu": "ڈاؤن لوڈ کے بعد فائل ٹیکسٹ ایڈیٹر یا کنٹرولر پری ویو میں کھول کر ہیڈر اور یونٹس چیک کریں۔",
  "shortSummaryEn": "After download, reopen the exported file in a text editor or controller preview and check its header and units.",
  "descriptionUrdu": "ڈاؤن لوڈ کے بعد فائل ٹیکسٹ ایڈیٹر یا کنٹرولر پری ویو میں کھول کر ہیڈر اور یونٹس چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "After download, reopen the exported file in a text editor or controller preview and check its header and units. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 74: Verify Exported File, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "ball_screw_x"
},
{
  "id": 75,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "ٹول آف سیٹس کی تصدیق",
  "titleEn": "Verify Tool Offsets",
  "shortSummaryUrdu": "ٹول ڈایا میٹر، لمبائی آف سیٹ اور ورک کوآرڈینیٹ سسٹم موجودہ سیٹ اپ سے ملائیں۔",
  "shortSummaryEn": "Confirm tool diameter, length offset and work coordinate system match the active setup.",
  "descriptionUrdu": "ٹول ڈایا میٹر، لمبائی آف سیٹ اور ورک کوآرڈینیٹ سسٹم موجودہ سیٹ اپ سے ملائیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Confirm tool diameter, length offset and work coordinate system match the active setup. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 75: Verify Tool Offsets, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "stepper_x"
},
{
  "id": 76,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "محفوظ Z کلیئرنس",
  "titleEn": "Verify Safe Z Clearance",
  "shortSummaryUrdu": "ریپڈ موومنٹ میں محفوظ Z کلیمپ اور مٹیریل سے اوپر ہو؛ ڈرائی رن سے تصدیق کریں۔",
  "shortSummaryEn": "Check safe Z clears clamps and stock during rapid travel; confirm in a dry run.",
  "descriptionUrdu": "ریپڈ موومنٹ میں محفوظ Z کلیمپ اور مٹیریل سے اوپر ہو؛ ڈرائی رن سے تصدیق کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Check safe Z clears clamps and stock during rapid travel; confirm in a dry run. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 76: Verify Safe Z Clearance, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "z_backplate"
},
{
  "id": 77,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "محور کی حدیں",
  "titleEn": "Verify Axis Soft Limits",
  "shortSummaryUrdu": "سافٹ ویئر لمٹس کو مشین کے ناپے گئے قابلِ استعمال ٹریول کے اندر محتاط رکھیں۔",
  "shortSummaryEn": "Set software travel limits conservatively within the machine’s measured usable travel.",
  "descriptionUrdu": "سافٹ ویئر لمٹس کو مشین کے ناپے گئے قابلِ استعمال ٹریول کے اندر محتاط رکھیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Set software travel limits conservatively within the machine’s measured usable travel. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 77: Verify Axis Soft Limits, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "z_rails"
},
{
  "id": 78,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "ایئر فلو اور وینٹیلیشن",
  "titleEn": "Check Airflow and Ventilation",
  "shortSummaryUrdu": "کنٹرول باکس کی وینٹیلیشن کھلی رکھیں اور پنکھوں اور فلٹرز کی حالت چیک کریں۔",
  "shortSummaryEn": "Keep control cabinet ventilation clear and verify fans operate without obstructed filters.",
  "descriptionUrdu": "کنٹرول باکس کی وینٹیلیشن کھلی رکھیں اور پنکھوں اور فلٹرز کی حالت چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Keep control cabinet ventilation clear and verify fans operate without obstructed filters. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 78: Check Airflow and Ventilation, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "z_leadscrew"
},
{
  "id": 79,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "کنٹرول باکس لیبلنگ",
  "titleEn": "Label the Control Cabinet",
  "shortSummaryUrdu": "پاور، موٹر، سینسر اور اسپنڈل کنکشن پر لیبل لگائیں تاکہ مینٹیننس میں شناخت آسان ہو۔",
  "shortSummaryEn": "Label power, motor, sensor and spindle connections so maintenance can identify them safely.",
  "descriptionUrdu": "پاور، موٹر، سینسر اور اسپنڈل کنکشن پر لیبل لگائیں تاکہ مینٹیننس میں شناخت آسان ہو۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Label power, motor, sensor and spindle connections so maintenance can identify them safely. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 79: Label the Control Cabinet, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "spindle_mount"
},
{
  "id": 80,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "کنیکٹر ٹینشن ریلیف",
  "titleEn": "Secure Cable Strain Relief",
  "shortSummaryUrdu": "متحرک اور مستقل مقامات پر کیبل مضبوط کریں تاکہ کنیکٹر پر کھنچاؤ نہ پڑے۔",
  "shortSummaryEn": "Secure cables at moving and fixed points so connectors do not carry cable weight or motion load.",
  "descriptionUrdu": "متحرک اور مستقل مقامات پر کیبل مضبوط کریں تاکہ کنیکٹر پر کھنچاؤ نہ پڑے۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Secure cables at moving and fixed points so connectors do not carry cable weight or motion load. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 80: Secure Cable Strain Relief, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "spindle_motor"
},
{
  "id": 81,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "شور اور وائبریشن کی بنیاد",
  "titleEn": "Record Baseline Noise and Vibration",
  "shortSummaryUrdu": "آئیڈل اور ٹیسٹ کٹ کے دوران معمول کی آواز اور وائبریشن ریکارڈ کریں تاکہ بعد میں موازنہ ہو۔",
  "shortSummaryEn": "Record normal sound and vibration at idle and during a test cut for future comparison.",
  "descriptionUrdu": "آئیڈل اور ٹیسٹ کٹ کے دوران معمول کی آواز اور وائبریشن ریکارڈ کریں تاکہ بعد میں موازنہ ہو۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Record normal sound and vibration at idle and during a test cut for future comparison. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 81: Record Baseline Noise and Vibration, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "drag_chains"
},
{
  "id": 82,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "پروڈکشن سے پہلے چیک لسٹ",
  "titleEn": "Pre-Production Checklist",
  "shortSummaryUrdu": "پروڈکشن سے پہلے گارڈ، ڈسٹ کلیکشن، ورک ہولڈنگ، ٹول، ای اسٹاپ، لمٹس اور پروگرام ورژن چیک کریں۔",
  "shortSummaryEn": "Verify guards, extraction, workholding, tool condition, E-stop, limits and correct program revision.",
  "descriptionUrdu": "پروڈکشن سے پہلے گارڈ، ڈسٹ کلیکشن، ورک ہولڈنگ، ٹول، ای اسٹاپ، لمٹس اور پروگرام ورژن چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Verify guards, extraction, workholding, tool condition, E-stop, limits and correct program revision. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 82: Pre-Production Checklist, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "limit_switches"
},
{
  "id": 83,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "آپریٹر کی تربیت",
  "titleEn": "Operator Training",
  "shortSummaryUrdu": "آپریٹر کو محفوظ آغاز، پاز، ای اسٹاپ، ٹول تبدیلی اور بجلی منقطع کرنے کی تربیت دیں۔",
  "shortSummaryEn": "Train operators on safe start, pause, emergency stop, tool changes and power isolation.",
  "descriptionUrdu": "آپریٹر کو محفوظ آغاز، پاز، ای اسٹاپ، ٹول تبدیلی اور بجلی منقطع کرنے کی تربیت دیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Train operators on safe start, pause, emergency stop, tool changes and power isolation. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 83: Operator Training, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "dial_tramming"
},
{
  "id": 84,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "پی پی ای اور ورک ایریا",
  "titleEn": "PPE and Work Area Safety",
  "shortSummaryUrdu": "آنکھوں، سماعت اور مناسب ڈسٹ پروٹیکشن کا استعمال کریں اور ورک ایریا صاف رکھیں۔",
  "shortSummaryEn": "Use eye and hearing protection and suitable dust protection; keep the work area clear.",
  "descriptionUrdu": "آنکھوں، سماعت اور مناسب ڈسٹ پروٹیکشن کا استعمال کریں اور ورک ایریا صاف رکھیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Use eye and hearing protection and suitable dust protection; keep the work area clear. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 84: PPE and Work Area Safety, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "lubrication"
},
{
  "id": 85,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "آگ اور مواد کے خطرات",
  "titleEn": "Fire and Material Risk Review",
  "shortSummaryUrdu": "مٹیریل کی مطابقت اور ڈسٹ کلیکشن چیک کریں؛ چلتی CNC مشین کو کبھی بے نگرانی نہ چھوڑیں۔",
  "shortSummaryEn": "Check material compatibility and extraction; never leave a running CNC unattended.",
  "descriptionUrdu": "مٹیریل کی مطابقت اور ڈسٹ کلیکشن چیک کریں؛ چلتی CNC مشین کو کبھی بے نگرانی نہ چھوڑیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Check material compatibility and extraction; never leave a running CNC unattended. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 85: Fire and Material Risk Review, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "control_box"
},
{
  "id": 86,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "مینٹیننس لاگ",
  "titleEn": "Maintain a Service Log",
  "shortSummaryUrdu": "ہر سروس کے بعد تاریخ، علامات، پیمائش، تبدیل شدہ پرزے اور تصدیقی نتیجہ درج کریں۔",
  "shortSummaryEn": "Record date, symptoms, measurements, parts replaced and verification after each service.",
  "descriptionUrdu": "ہر سروس کے بعد تاریخ، علامات، پیمائش، تبدیل شدہ پرزے اور تصدیقی نتیجہ درج کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Record date, symptoms, measurements, parts replaced and verification after each service. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 86: Maintain a Service Log, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "power_supplies"
},
{
  "id": 87,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "اسپیئر پارٹس کی فہرست",
  "titleEn": "Create a Spare Parts List",
  "shortSummaryUrdu": "فیوز، سوئچ، کپلر اور عام گھسنے والے پرزوں کے پارٹ نمبر اور تفصیل درج کریں۔",
  "shortSummaryEn": "Record part numbers and specifications for fuses, switches, couplers and common wear items.",
  "descriptionUrdu": "فیوز، سوئچ، کپلر اور عام گھسنے والے پرزوں کے پارٹ نمبر اور تفصیل درج کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Record part numbers and specifications for fuses, switches, couplers and common wear items. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 87: Create a Spare Parts List, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "stepper_drivers"
},
{
  "id": 88,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "خرابی کی بنیادی تشخیص",
  "titleEn": "Basic Fault Diagnosis",
  "shortSummaryUrdu": "پرزے بدلنے سے پہلے الارم، کنکشن، مکینیکل رگڑ اور حالیہ تبدیلیاں چیک کریں۔",
  "shortSummaryEn": "Check alarms, connections, mechanical binding and recent changes before replacing components.",
  "descriptionUrdu": "پرزے بدلنے سے پہلے الارم، کنکشن، مکینیکل رگڑ اور حالیہ تبدیلیاں چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Check alarms, connections, mechanical binding and recent changes before replacing components. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 88: Basic Fault Diagnosis, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "vfd_inverter"
},
{
  "id": 89,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "پوزیشن ضائع ہونے کی جانچ",
  "titleEn": "Investigate Lost Position",
  "shortSummaryUrdu": "پوزیشن ضائع ہو تو رگڑ، ایکسلریشن، کپلر، ڈرائیور کرنٹ اور برقی شور مینوفیکچرر کی حدود میں چیک کریں۔",
  "shortSummaryEn": "Check binding, acceleration, couplers, driver current and electrical noise within maker limits.",
  "descriptionUrdu": "پوزیشن ضائع ہو تو رگڑ، ایکسلریشن، کپلر، ڈرائیور کرنٹ اور برقی شور مینوفیکچرر کی حدود میں چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Check binding, acceleration, couplers, driver current and electrical noise within maker limits. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 89: Investigate Lost Position, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "software_tuning"
},
{
  "id": 90,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "سطح پر جلنے کے نشان",
  "titleEn": "Diagnose Burn Marks",
  "shortSummaryUrdu": "جلنے کے نشان پر فیڈ، RPM، ٹول کی تیزی، چپس کے اخراج اور ٹول پاتھ کا جائزہ لیں۔",
  "shortSummaryEn": "Review feed, RPM, tool sharpness, chip evacuation and toolpath engagement before changing settings.",
  "descriptionUrdu": "جلنے کے نشان پر فیڈ، RPM، ٹول کی تیزی، چپس کے اخراج اور ٹول پاتھ کا جائزہ لیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Review feed, RPM, tool sharpness, chip evacuation and toolpath engagement before changing settings. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 90: Diagnose Burn Marks, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "spoilboard_firstcut"
},
{
  "id": 91,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "ابعاد میں فرق",
  "titleEn": "Diagnose Dimensional Error",
  "shortSummaryUrdu": "ابعادی فرق میں یونٹس، اسکیل، اسٹیپس فی ملی میٹر، بیک لیش اور ٹول ڈایا میٹر کمپنسیشن چیک کریں۔",
  "shortSummaryEn": "Check units, scale, steps per millimeter, backlash and tool diameter compensation.",
  "descriptionUrdu": "ابعادی فرق میں یونٹس، اسکیل، اسٹیپس فی ملی میٹر، بیک لیش اور ٹول ڈایا میٹر کمپنسیشن چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Check units, scale, steps per millimeter, backlash and tool diameter compensation. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 91: Diagnose Dimensional Error, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "base_frame"
},
{
  "id": 92,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "غیر متوقع حرکت",
  "titleEn": "Investigate Unexpected Motion",
  "shortSummaryUrdu": "غیر متوقع حرکت پر مشین روکیں اور کوآرڈینیٹ موڈ، آف سیٹس، یونٹس اور پروگرام مطابقت چیک کریں۔",
  "shortSummaryEn": "Stop the machine and verify coordinate mode, offsets, units and program compatibility.",
  "descriptionUrdu": "غیر متوقع حرکت پر مشین روکیں اور کوآرڈینیٹ موڈ، آف سیٹس، یونٹس اور پروگرام مطابقت چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Stop the machine and verify coordinate mode, offsets, units and program compatibility. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 92: Investigate Unexpected Motion, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "cross_members"
},
{
  "id": 93,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "محفوظ سافٹ ویئر اپ ڈیٹ",
  "titleEn": "Safely Update Control Software",
  "shortSummaryUrdu": "کنٹرولر سافٹ ویئر یا فرم ویئر اپ ڈیٹ سے پہلے سیٹنگز بیک اپ اور مطابقت چیک کریں۔",
  "shortSummaryEn": "Back up settings and verify compatibility before updating controller software or firmware.",
  "descriptionUrdu": "کنٹرولر سافٹ ویئر یا فرم ویئر اپ ڈیٹ سے پہلے سیٹنگز بیک اپ اور مطابقت چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Back up settings and verify compatibility before updating controller software or firmware. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 93: Safely Update Control Software, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "leveling_feet"
},
{
  "id": 94,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "حتمی میکینیکل آڈٹ",
  "titleEn": "Final Mechanical Audit",
  "shortSummaryUrdu": "تمام ایکسس، فاسٹنرز، موشن کلیئرنس، اسپنڈل ماؤنٹ اور لبریکیشن ریکارڈ دوبارہ چیک کریں۔",
  "shortSummaryEn": "Recheck all axes, fasteners, motion clearance, spindle mounting and lubrication records.",
  "descriptionUrdu": "تمام ایکسس، فاسٹنرز، موشن کلیئرنس، اسپنڈل ماؤنٹ اور لبریکیشن ریکارڈ دوبارہ چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Recheck all axes, fasteners, motion clearance, spindle mounting and lubrication records. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 94: Final Mechanical Audit, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "y_rails"
},
{
  "id": 95,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "حتمی برقی آڈٹ",
  "titleEn": "Final Electrical Audit",
  "shortSummaryUrdu": "مستند شخص سے وائرنگ، ارتھنگ، حفاظتی آلات اور انکلوژر کی بندش کی تصدیق کروائیں۔",
  "shortSummaryEn": "Have a qualified person verify wiring, grounding, protective devices and enclosure closure.",
  "descriptionUrdu": "مستند شخص سے وائرنگ، ارتھنگ، حفاظتی آلات اور انکلوژر کی بندش کی تصدیق کروائیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Have a qualified person verify wiring, grounding, protective devices and enclosure closure. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 95: Final Electrical Audit, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "sub_bed"
},
{
  "id": 96,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "حتمی کیلیبریشن ریکارڈ",
  "titleEn": "Final Calibration Record",
  "shortSummaryUrdu": "اسکوائرنس، ریپیٹ ایبلٹی، بیک لیش اور ٹیسٹ پارٹ کی پیمائشیں بنیادی ریکارڈ کے طور پر محفوظ کریں۔",
  "shortSummaryEn": "Save measured squareness, repeatability, backlash and test-part dimensions as the baseline.",
  "descriptionUrdu": "اسکوائرنس، ریپیٹ ایبلٹی، بیک لیش اور ٹیسٹ پارٹ کی پیمائشیں بنیادی ریکارڈ کے طور پر محفوظ کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Save measured squareness, repeatability, backlash and test-part dimensions as the baseline. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 96: Final Calibration Record, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "bearing_blocks"
},
{
  "id": 97,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "مشین حوالگی اور قبولیت",
  "titleEn": "Machine Handover and Acceptance",
  "shortSummaryUrdu": "استعمال سے پہلے سیفٹی چیک لسٹ، بیک اپ، کیلیبریشن ریکارڈ اور آپریٹر منظوری کا جائزہ لیں۔",
  "shortSummaryEn": "Review the safety checklist, backup files, calibration records and operator sign-off before use.",
  "descriptionUrdu": "استعمال سے پہلے سیفٹی چیک لسٹ، بیک اپ، کیلیبریشن ریکارڈ اور آپریٹر منظوری کا جائزہ لیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Review the safety checklist, backup files, calibration records and operator sign-off before use. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 97: Machine Handover and Acceptance, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "ball_screws_y"
},
{
  "id": 98,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "مشین کی سطح اور پاؤں",
  "titleEn": "Leveling Feet and Floor Stability",
  "shortSummaryUrdu": "لیولنگ فٹ مستحکم ہوں اور معمول کے آپریشن میں فریم ہلتا نہ ہو۔",
  "shortSummaryEn": "Verify leveling feet are stable and the frame does not rock under normal operating load.",
  "descriptionUrdu": "لیولنگ فٹ مستحکم ہوں اور معمول کے آپریشن میں فریم ہلتا نہ ہو۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Verify leveling feet are stable and the frame does not rock under normal operating load. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 98: Leveling Feet and Floor Stability, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "floating_bearings"
},
{
  "id": 99,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "ٹول چینج کے بعد دوبارہ چیک",
  "titleEn": "Post-Tool-Change Check",
  "shortSummaryUrdu": "ہر ٹول تبدیلی کے بعد کولیٹ، ٹول لمبائی، ورک زیرو اور محفوظ کلیئرنس دوبارہ چیک کریں۔",
  "shortSummaryEn": "After each tool change, verify collet seating, tool length, work zero and safe clearance.",
  "descriptionUrdu": "ہر ٹول تبدیلی کے بعد کولیٹ، ٹول لمبائی، ورک زیرو اور محفوظ کلیئرنس دوبارہ چیک کریں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "After each tool change, verify collet seating, tool length, work zero and safe clearance. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 99: Post-Tool-Change Check, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "stepper_y"
},
{
  "id": 100,
  "phaseId": 8,
  "phaseNameUrdu": "فیز 8: حفاظت اور حتمی منظوری",
  "phaseNameEn": "Phase 8: Safety & Final Acceptance",
  "titleUrdu": "پہلی جاب کی نگرانی",
  "titleEn": "Supervise the First Full Job",
  "shortSummaryUrdu": "پہلی مکمل جاب مسلسل نگرانی میں چلائیں اور پری ویو سے مختلف حرکت پر فوراً روکنے کے لیے تیار رہیں۔",
  "shortSummaryEn": "Run the first full job under continuous supervision, ready to pause or stop if behavior differs from preview.",
  "descriptionUrdu": "پہلی مکمل جاب مسلسل نگرانی میں چلائیں اور پری ویو سے مختلف حرکت پر فوراً روکنے کے لیے تیار رہیں۔ اس نتیجے کو نوٹ کریں؛ اگر پیمائش یا حرکت غیر معمولی ہو تو مشین روک کر مسئلہ درست کریں۔",
  "descriptionEn": "Run the first full job under continuous supervision, ready to pause or stop if behavior differs from preview. Record the result; if measurements or motion are abnormal, stop and correct the issue before continuing.",
  "cadPrompt": "Technical CNC router engineering illustration for step 100: Supervise the First Full Job, clear labeled components, realistic workshop CAD drawing, safety-conscious setup.",
  "tools": [
    "مناسب پیمائشی آلہ / Suitable measuring tool",
    "مشین کا مینول / Machine manual",
    "ذاتی حفاظتی سامان / Appropriate PPE"
  ],
  "components": [
    "متعلقہ CNC اسمبلی / Relevant CNC assembly",
    "مینوفیکچرر کے مطابق فاسٹنرز / Manufacturer-specified fasteners"
  ],
  "specs": {
    "criticalCheck": "Verify against the machine and component manufacturers’ specifications; do not assume universal torque or electrical values."
  },
  "proTipUrdu": "ہر تبدیلی کے بعد نتیجہ درج کریں اور اگلے مرحلے سے پہلے محفوظ حالت کی تصدیق کریں۔",
  "proTipEn": "Record the result after each change and verify the machine is in a safe state before proceeding.",
  "defaultImage": "/src/assets/images/cnc_completed_router_cad_1791448958543.jpg",
  "svgSchemaType": "endstops_y"
}
];
