export interface CNCOperationStep {
  id: 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G';
  stepLetter: string;
  titleUrdu: string;
  titleEn: string;
  subtitleUrdu: string;
  subtitleEn: string;
  category: 'Power' | 'Setup' | 'Zeroing' | 'Spindle' | 'Operation' | 'Recovery' | 'Shutdown';
  estimatedTime: string;
  safetyLevel: 'CRITICAL' | 'WARNING' | 'IMPORTANT' | 'STANDARD';
  urduInstructions: string[];
  englishInstructions: string[];
  mach3State: {
    screenName: string;
    droX: string;
    droY: string;
    droZ: string;
    feedRate: string;
    spindleRpm: string;
    statusTextUrdu: string;
    statusTextEn: string;
    activeMode: string;
    highlightButtons: string[];
  };
  dspState: {
    screenTitle: string;
    line1: string;
    line2: string;
    line3: string;
    line4: string;
    activeKeys: string[];
    modeLabel: string;
  };
  keyShortcuts: {
    key: string;
    actionUrdu: string;
    actionEn: string;
  }[];
  checklist: {
    id: string;
    labelUrdu: string;
    labelEn: string;
  }[];
  proTipUrdu: string;
  proTipEn: string;
  sampleGcode?: string;
}

export const CNC_OPERATION_STEPS: CNCOperationStep[] = [
  {
    id: 'A',
    stepLetter: 'Step A',
    titleUrdu: 'پاور آن اور ریفرنس زیرو (مشین ہومنگ)',
    titleEn: 'Power On & Zeroing (Machine Homing)',
    subtitleUrdu: 'مین سپلائی ایکٹیویشن، ایمرجنسی اسٹاپ ریلیز اور ریفرنس سینسر ہومنگ',
    subtitleEn: 'Main Power Activation, E-Stop Release & Ref All Home Sequence',
    category: 'Power',
    estimatedTime: '3 - 5 منٹ',
    safetyLevel: 'CRITICAL',
    urduInstructions: [
      '1. مین پاور ڈسٹری بیوشن باکس کا 220V/380V سرکٹ بریکر آن کریں اور یقینی بنائیں کہ وولٹیج اسٹیبلائزر نارمل آؤٹ پٹ دے رہا ہے۔',
      '2. سی این سی کنٹرول پینل پر ریڈ کلر کا ایمرجنسی اسٹاپ (E-Stop) بٹن گھما کر کلاک وائز ریلیز کریں تا کہ انٹرلاک اوپن ہو۔',
      '3. کنٹرول کمپیوٹر یا ڈی ایس پی ہینڈ ہیلڈ پینڈنٹ آن کریں، اور سافٹ ویئر میں گرین اسٹیٹس ایل ای ڈی کی تصدیق کریں۔',
      '4. مچ تھری (Mach3) میں "Reset" بٹن دبائیں تا کہ فلیشنگ رکے اور مشین ڈرائیوز پر ہولڈنگ ٹارک متحرک ہو جائے۔',
      '5. سب سے پہلے Z-Axis کو اوپر ہوم کریں تاکہ اینڈ مل پرزے سے محفوظ رہے، اس کے بعد X اور Y ایکسز کو ہوم پوزیشن پر لے جائیں (Ref All Home)۔',
      '6. مشین کوآرڈینیٹس (Machine Coords G53) پر X: 0.00, Y: 0.00, Z: 0.00 ظاہر ہونے کی تصدیق کریں۔',
    ],
    englishInstructions: [
      '1. Switch on the main workshop breaker and verify 220V/380V stabilized power to the control cabinet.',
      '2. Twist and release the red Emergency Stop mushroom push-button clockwise to disengage interlock.',
      '3. Boot up the Mach3 PC or plug in the DSP A11 Handheld controller; ensure USB communication LED turns green.',
      '4. Click the flashing red "RESET" button in Mach3 until solid green, engaging stepper driver holding current.',
      '5. Execute "Ref All Home" sequence. Crucial rule: Z-Axis homes FIRST to safe positive ceiling before X and Y home.',
      '6. Confirm Machine Coordinates (G53) register X:0.000, Y:0.000, Z:0.000 at inductive limit switches.',
    ],
    mach3State: {
      screenName: 'Program Run (Alt-1) / Homing Screen',
      droX: '+0000.000',
      droY: '+0000.000',
      droZ: '+0000.000',
      feedRate: '0.00 mm/min',
      spindleRpm: '0 RPM (STOP)',
      statusTextUrdu: 'تمام ایکسز ریفرنس ہوم ہو گئے ہیں - مشین تیار ہے',
      statusTextEn: 'ALL AXES REFERENCED (HOMED) - SYSTEM READY',
      activeMode: 'MCH COORD (G53)',
      highlightButtons: ['RESET', 'Ref All Home', 'Machine Coords'],
    },
    dspState: {
      screenTitle: 'DSP RichAuto A11 // Home System',
      line1: '1. Home Z Axis ... [OK]',
      line2: '2. Home X Axis ... [OK]',
      line3: '3. Home Y Axis ... [OK]',
      line4: 'MCH: X0.0 Y0.0 Z0.0',
      activeKeys: ['HOME', 'ORIGIN OK', 'MENU'],
      modeLabel: 'ALL HOME EXEC',
    },
    keyShortcuts: [
      { key: 'Spacebar', actionUrdu: 'فیڈ ہولڈ / فوری موشن توقف', actionEn: 'Feed Hold / Motion Pause' },
      { key: 'Esc', actionUrdu: 'ایمرجنسی اسٹاپ / ریسٹ بٹن', actionEn: 'E-Stop / Software Reset' },
      { key: 'Home key', actionUrdu: 'ریفرنس ہوم Z ایکسس پہلے', actionEn: 'Execute Safe Z-Homing' },
    ],
    checklist: [
      { id: 'ca1', labelUrdu: 'مین بریکر 220V آن اور مستحکم ہے', labelEn: 'Main 220V breaker on & steady' },
      { id: 'ca2', labelUrdu: 'E-Stop پش بٹن کلاک وائز ریلیز ہے', labelEn: 'E-Stop push button released' },
      { id: 'ca3', labelUrdu: 'Mach3 ری سیٹ بٹن سولڈ گرین ہے', labelEn: 'Mach3 RESET button solid green' },
      { id: 'ca4', labelUrdu: 'Z-Axis پہلے اوپر ہوم ہوا، پھر X/Y', labelEn: 'Z-Axis homed first, then X & Y' },
    ],
    proTipUrdu: 'کبھی بھی Z ایکسس کو نیچے چھوڑ کر X یا Y ہوم نہ کریں! ہمیشہ Z کو پہلے مثبت حد (Top Limit) پر ہوم کرنا لازمی ہے تاکہ کلیمپ یا وائس سے ٹکراؤ نہ ہو۔',
    proTipEn: 'Always home Z-Axis first before X/Y. If Z is low, moving X/Y across the bed can crash your cutting bit into stock clamps.',
    sampleGcode: `$H (Grbl Home All)
G28 G91 Z0 (Elevate Z to home limit switch)
G28 X0 Y0 (Home X and Y axes to reference inductive sensors)
G90 (Return to Absolute Mode)`,
  },
  {
    id: 'B',
    stepLetter: 'Step B',
    titleUrdu: 'ڈیزائن لوڈنگ اور مٹیریل سیٹ اپ',
    titleEn: 'Loading Design & Material Setup',
    subtitleUrdu: 'G-Code فائل امپورٹ، ٹول پاتھ پری ویو اور کلیمپنگ سختی کی جانچ',
    subtitleEn: 'G-Code File Import, Toolpath Visual Preview & Vacuum/Clamp Clamping Check',
    category: 'Setup',
    estimatedTime: '5 - 8 منٹ',
    safetyLevel: 'IMPORTANT',
    urduInstructions: [
      '1. یو ایس بی ڈرائیو یا نیٹ ورک شیئر سے تیار شدہ G-Code فائل (.nc, .tap, .gcode) لوڈ کریں۔',
      '2. سافٹ ویئر میں ٹول پاتھ پری ویو ونڈو چیک کریں؛ تصدیق کریں کہ ڈیزائن کی پیمائشیں مٹیریل سائز (Length x Width x Thickness) کے اندر ہیں۔',
      '3. ووڈ ورکنگ شیٹ (MDF، ٹھوس لکڑی یا ایکریلک) کو ٹی سلاٹ ایلومینیم بیڈ پر مضبوطی سے کلیمپ کریں یا ویکیوم پمپ فعال کریں۔',
      '4. کلیمپس کو کٹنگ راستے (Toolpath Boundary) سے کم از کم 25 ملی میٹر دور رکھیں تاکہ کٹر ان سے نہ ٹکرائے۔',
      '5. کٹنگ ایریا کے نیچے ویسٹ بورڈ (Spoiler Board) کی سطح ہموار ہونے کی جانچ کریں۔',
    ],
    englishInstructions: [
      '1. Load your CAM-generated G-Code file (.nc, .tap, .gcode, .txt) from USB stick or network folder.',
      '2. Inspect the 3D toolpath boundary box inside Mach3 / DSP. Verify job dimensions match raw stock size.',
      '3. Secure raw wood stock (MDF, hardwood, acrylic) using T-track hold-down clamps or vacuum hold-down pump.',
      '4. Keep hold-down clamps at least 25mm clear of the toolpath envelope to prevent high-speed collisions.',
      '5. Verify wasteboard (spoilboard) surface flatness under the cut zone for depth consistency.',
    ],
    mach3State: {
      screenName: 'Program Run (Alt-1) // File Loaded',
      droX: '+0000.000',
      droY: '+0000.000',
      droZ: '+0025.000',
      feedRate: 'F2400 mm/min',
      spindleRpm: 'S18000 (Standby)',
      statusTextUrdu: 'G-Code فائل کامیابی سے لوڈ ہو گئی - 12,450 لائنز',
      statusTextEn: 'FILE LOADED: Carving_Floral_Panel.tap (12,450 lines)',
      activeMode: 'TOOLPATH ACTIVE',
      highlightButtons: ['Load G-Code', 'Edit G-Code', 'Regen. Toolpath'],
    },
    dspState: {
      screenTitle: 'DSP RichAuto A11 // USB Read',
      line1: 'File: FLOWER_PANEL.TAP',
      line2: 'Size: 840KB | Lines: 12450',
      line3: 'Stock: 600x400x18mm',
      line4: 'Press [RUN] to select WCS',
      activeKeys: ['MENU', '1 (U-Disk)', 'ORIGIN OK'],
      modeLabel: 'USB FILE READY',
    },
    keyShortcuts: [
      { key: 'Alt + 1', actionUrdu: 'Mach3 مین پروگرام رن اسکرین پر جانا', actionEn: 'Switch to Program Run View' },
      { key: 'Ctrl + O', actionUrdu: 'نئی G-code فائل اوپن ڈائیلاگ', actionEn: 'Open G-Code File Browser' },
      { key: 'Tab key', actionUrdu: 'ورچوئل جوگ پینڈنٹ (MPG) فلائی آؤٹ', actionEn: 'Toggle MPG Flyout Screen' },
    ],
    checklist: [
      { id: 'cb1', labelUrdu: 'G-code فائل بغیر خرابی کے لوڈ ہوئی', labelEn: 'G-code file loaded with no errors' },
      { id: 'cb2', labelUrdu: 'ورک پیس سائز ٹول پاتھ سے بڑا ہے', labelEn: 'Raw stock exceeds toolpath box' },
      { id: 'cb3', labelUrdu: 'کلیمپس ٹول کے راستے سے 25mm باہر ہیں', labelEn: 'Clamps placed 25mm clear of bit' },
      { id: 'cb4', labelUrdu: 'مٹیریل ہاتھ سے ہلانے پر بالکل ساکت ہے', labelEn: 'Material rigidly fixed to bed' },
    ],
    proTipUrdu: 'ہمیشہ CAM سافٹ ویئر (ArtCAM / Aspire / Fusion) میں جاب سیٹ اپ کے وقت میٹریل کلیمپ کی اونچائی اور ریپڈ موشن Z (Rapid Clearance Z) کم از کم 15 سے 25 ملی میٹر رکھیں۔',
    proTipEn: 'In your CAM software (ArtCAM, Aspire, Vectric), set Rapid Z Clearance to at least 15-25mm so the bit glides comfortably over tall clamps.',
    sampleGcode: `(JOB: 3D WOOD CARVING PANEL)
(TOOL: 6MM 2-FLUTE BALLNOSE)
G21 G90 G40 G80 (Standard Safety Header)
G0 Z25.000 (Safe Clearance Plane)
G0 X0.000 Y0.000`,
  },
  {
    id: 'C',
    stepLetter: 'Step C',
    titleUrdu: 'ورک زیرو سیٹ کرنا (Setting Work Zero X, Y, Z)',
    titleEn: 'Setting Work Zero (X, Y, Z Axes - WCS G54)',
    subtitleUrdu: 'لکڑی کے کونے پر ورک ڈیٹم X0, Y0 اور آٹو ٹول پروب سے Z0 سیٹ کرنا',
    subtitleEn: 'Aligning Corner Datum X0, Y0 and Auto Z-Touch Plate Probe Calibration',
    category: 'Zeroing',
    estimatedTime: '4 - 6 منٹ',
    safetyLevel: 'CRITICAL',
    urduInstructions: [
      '1. جوگ کیز (Arrow Keys) کے ذریعے کٹر کو مٹیریل کے نچلے بائیں کونے (Bottom-Left Corner) کے عین اوپر لائیں۔',
      '2. باریک جاگنگ موڈ (Step Jog 0.1mm یا 0.01mm) آن کریں اور کٹر کی نوک کو لکڑی کے کنارے پر بالکل سیدھ میں کریں۔',
      '3. کنٹرولر پر "Zero X" اور "Zero Y" کے بٹن دبائیں تاکہ WCS (G54) میں دونوں کوآرڈینیٹس 0.000 ہو جائیں۔',
      '4. Z-Axis زیرو کرنے کے لیے یا تو سگریٹ کے باریک پیپر کا طریقہ استعمال کریں یا آٹو ٹچ پروب پلیٹ (Z-Probe Plate) لکڑی پر رکھیں۔',
      '5. ٹچ پروب کلپ کو کٹر شینک پر لگائیں اور "Auto Tool Zero" دبائیں۔ کٹر نیچے آ کر ٹچ کرے گا اور خود بخود پلیٹ کی موٹائی (مثلاً 10.0mm) ایڈجسٹ کرے گا۔',
      '6. Z ایکسس کو فورا 15mm اوپر اٹھائیں اور چیک کریں کہ لکڑی کی اوپری سطح ہی Z=0.000 ہے۔',
    ],
    englishInstructions: [
      '1. Use Arrow keys to jog the cutting bit over the stock datum corner (typically Bottom-Left XY origin).',
      '2. Switch to Step Jog Mode (0.1mm or 0.01mm) for precision alignment with stock edge or crosshair laser.',
      '3. Press "Zero X" and "Zero Y" on the screen to store the Work Coordinate System (G54) datum origin.',
      '4. For Z-Axis zeroing, place the conductive aluminum touch plate directly beneath the endmill on stock top.',
      '5. Attach ground alligator clip to spindle collet/shank, then press "Auto Tool Zero" probing macro.',
      '6. Spindle touches plate, registers plate thickness (e.g. 10.00mm offset), then retracts safely to Z+15mm.',
    ],
    mach3State: {
      screenName: 'Program Run // Coordinate Work Offset (G54)',
      droX: '0.000 (ZEROED)',
      droY: '0.000 (ZEROED)',
      droZ: '+0015.000 (CLEAR)',
      feedRate: 'F500 mm/min',
      spindleRpm: '0 RPM',
      statusTextUrdu: 'WCS G54 زیرو سیٹ ہو گیا - Z کلیرنس 15.00mm پر موجود',
      statusTextEn: 'WCS G54 DATUM ZEROED: X0.000 Y0.000 Z0.000 AT TOP OF MATERIAL',
      activeMode: 'WCS G54 ACTIVE',
      highlightButtons: ['Zero X', 'Zero Y', 'Zero Z', 'Auto Tool Zero'],
    },
    dspState: {
      screenTitle: 'DSP RichAuto A11 // Set Origin',
      line1: 'Current Pos: X0.0 Y0.0',
      line2: 'Origin: G54 Standard',
      line3: 'Press [ORIGIN OK] to set 0',
      line4: 'Z Probe: 10.00mm offset OK',
      activeKeys: ['ORIGIN OK', 'MENU + ORIGIN', 'Z UP'],
      modeLabel: 'WORK ORIGIN STORED',
    },
    keyShortcuts: [
      { key: 'Arrow Left / Right', actionUrdu: 'X-Axis دائیں بائیں جاگنگ', actionEn: 'Jog X-Axis Left / Right' },
      { key: 'Arrow Up / Down', actionUrdu: 'Y-Axis آگے پیچھے جاگنگ', actionEn: 'Jog Y-Axis Forward / Back' },
      { key: 'Page Up / Page Down', actionUrdu: 'Z-Axis اوپر اٹھانا / نیچے لانا', actionEn: 'Jog Z-Axis Up / Down' },
      { key: 'Shift + Arrow', actionUrdu: 'تیز رفتار ریپڈ جاگنگ (Rapid Jog)', actionEn: 'Rapid High-Speed Traverse' },
    ],
    checklist: [
      { id: 'cc1', labelUrdu: 'X0 اور Y0 مٹیریل کے مطلوبہ کونے پر سیٹ ہیں', labelEn: 'X0 & Y0 match CAM design origin' },
      { id: 'cc2', labelUrdu: 'ٹچ پروب کی زمینی کلپ اسپنڈل شینک پر لگی تھی', labelEn: 'Ground clip was attached to tool' },
      { id: 'cc3', labelUrdu: 'Z=0 لکڑی کی اوپری سطح پر بالکل درست ہے', labelEn: 'Z=0 calibrated to top of stock' },
      { id: 'cc4', labelUrdu: 'پروبنگ کے بعد کلپ کٹر سے ہٹا لی گئی ہے', labelEn: 'Alligator clip removed before run' },
    ],
    proTipUrdu: 'سب سے عام غلطی: پروبنگ کے بعد مگرمچھ کلپ (Alligator Clip) کٹر پر ہی لگی رہ جاتی ہے! اسپنڈل گھومتے ہی تار لپٹ کر ٹوٹ جاتی ہے۔ ہمیشہ کٹ سے پہلے کلپ اتارنا مت بھولیں۔',
    proTipEn: 'Most common workshop mistake: Leaving the alligator clip clamped to the tool! When spindle spins to 18,000 RPM, it rips the wire instantly. Always unclip before starting.',
    sampleGcode: `G90 G54 (Select Work Coordinate System 1)
G10 L20 P1 X0 Y0 (Set current position as G54 X0 Y0)
G0 Z15.000 (Safe verification height above work piece)
G0 X0 Y0 (Confirm physical return to zero point)`,
  },
  {
    id: 'D',
    stepLetter: 'Step D',
    titleUrdu: 'اسپنڈل اسپیڈ، وی ایف ڈی اور ٹول چیک',
    titleEn: 'Spindle Speed & Tool Check',
    subtitleUrdu: 'کولٹ ٹائٹنس، ٹول رن آؤٹ، واٹر کولنگ پمپ اور وی ایف ڈی ہرٹز فریکوئنسی',
    subtitleEn: 'Collet Nut Tightness, Tool Runout, Water Pump & VFD 400Hz Frequency Check',
    category: 'Spindle',
    estimatedTime: '2 - 4 منٹ',
    safetyLevel: 'WARNING',
    urduInstructions: [
      '1. اسپنڈل کولٹ نٹ (ER20 / ER25) کو ڈبل اسپینر کی مدد سے مطلوبہ ٹارک (50-60 Nm) پر ٹائٹ کریں۔ ضرورت سے زیادہ ٹائٹ نہ کریں۔',
      '2. تصدیق کریں کہ کٹر کی فلوٹ (Flute) کولٹ کے اندر نہیں دبی، بلکہ شینک کا کم از کم 80% حصہ کولٹ میں پورا گرپ ہے۔',
      '3. واٹر کولڈ اسپنڈل کے لیے واٹر پمپ یا چِلر (Chiller CW-3000/CW-5000) آن کریں اور نوزل سے پانی کی گردش دیکھیں (واٹر فلو سینسر گرین ہونا چاہیے)۔',
      '4. وی ایف ڈی (VFD) پر فریکوئنسی چیک کریں: لکڑی کی تراش کے لیے 300Hz سے 400Hz (یعنی 18,000 سے 24,000 RPM) تجویز کی جاتی ہے۔',
      '5. سافٹ ویئر میں "Spindle CW (F5)" بٹن دبا کر اسپنڈل کو 2 سیکنڈ ٹیسٹ رن کریں؛ آواز سنیں کہ بیرنگ میں کوئی رگڑ یا غیر معمولی شور تو نہیں۔',
    ],
    englishInstructions: [
      '1. Tighten the ER20/ER25 collet nut using dual wrenches to specified 50-60 Nm torque. Do not over-torque.',
      '2. Ensure tool flute does not sit inside the collet cone; shank must be inserted at least 80% collet depth.',
      '3. Power on water cooling chiller (CW-3000/5000); verify water return stream in reservoir with no kinks in tubes.',
      '4. Check Variable Frequency Drive (VFD) display; set for 300Hz-400Hz corresponding to 18,000-24,000 RPM.',
      '5. Press "Spindle CW" (F5) for a 2-second idle spin test; listen for smooth bearing acoustic signature.',
    ],
    mach3State: {
      screenName: 'Program Run // Spindle & Coolant Control',
      droX: '0.000',
      droY: '0.000',
      droZ: '+0015.000',
      feedRate: 'F0 mm/min',
      spindleRpm: '18,000 RPM (RUNNING)',
      statusTextUrdu: 'اسپنڈل 18,000 RPM پر کامیابی سے آن - واٹر کولنگ درست',
      statusTextEn: 'SPINDLE CW ACTIVE: 18,000 RPM (300Hz) - WATER CHILLER OK',
      activeMode: 'SPINDLE RUNNING',
      highlightButtons: ['Spindle CW (F5)', 'Coolant (F4)', 'Spindle Override'],
    },
    dspState: {
      screenTitle: 'DSP RichAuto A11 // Spindle Test',
      line1: 'Spindle: S=18000 RPM',
      line2: 'VFD Status: RUN (300Hz)',
      line3: 'Water Flow: NORMAL',
      line4: 'Press [SPINDLE] to toggle',
      activeKeys: ['SPINDLE ON/OFF', 'MENU + 8', 'SPEED +'],
      modeLabel: 'SPINDLE 18K ACTIVE',
    },
    keyShortcuts: [
      { key: 'F5 key', actionUrdu: 'اسپنڈل موٹر آن / آف ٹوگل (M3/M5)', actionEn: 'Toggle Spindle CW On / Off' },
      { key: 'F4 key', actionUrdu: 'کولنٹ پمپ / ایئر بلاسٹ ٹوگل (M8/M9)', actionEn: 'Toggle Coolant Pump On / Off' },
      { key: '+ / - keys', actionUrdu: 'اسپنڈل اسپیڈ اوور رائیڈ (+/- 10%)', actionEn: 'Spindle RPM Override 10%' },
    ],
    checklist: [
      { id: 'cd1', labelUrdu: 'ER کولٹ نٹ مناسب ٹارک سے ٹائٹ ہے', labelEn: 'Collet nut tightened to spec' },
      { id: 'cd2', labelUrdu: 'واٹر پائپ میں پانی کا بہاؤ جاری ہے', labelEn: 'Cooling water flowing steadily' },
      { id: 'cd3', labelUrdu: 'وی ایف ڈی 300-400 ہرٹز دکھا رہا ہے', labelEn: 'VFD registers 300-400Hz frequency' },
      { id: 'cd4', labelUrdu: 'اسپنڈل آواز میں کوئی غیر معمولی جھٹکا نہیں', labelEn: 'Smooth bearing acoustic check' },
    ],
    proTipUrdu: '2.2kW واٹر کولڈ اسپنڈل کو بغیر پانی کی گردش کے 3 منٹ بھی چلانا اندرونی وائنڈنگ اور بیرنگز کو ہمیشہ کے لیے جلا دیتا ہے! ہمیشہ واٹر پمپ کے فوارے کی تصدیق کریں۔',
    proTipEn: 'Running a 2.2kW water-cooled spindle for even 3 minutes with dry or kinked tubing will burn out its ceramic bearings and windings permanently. Always check flow first.',
    sampleGcode: `M3 S18000 (Start Spindle Clockwise at 18000 RPM)
G4 P3.0 (Dwell pause 3 seconds for spindle to reach target speed)
M8 (Flood coolant / Air mist blast ON)`,
  },
  {
    id: 'E',
    stepLetter: 'Step E',
    titleUrdu: 'جاب اسٹارٹ اور حفاظتی کنٹرولز',
    titleEn: 'Starting Job & Safety Controls',
    subtitleUrdu: 'حفاظتی عینک، ڈسٹ ایکسٹریکٹر آن، ڈرائی رن (Air Cut) اور لائیو فیڈ اوور رائیڈ',
    subtitleEn: 'Eye Protection, Dust Extraction, Air Cut Verification & Live Feedrate Override',
    category: 'Operation',
    estimatedTime: 'جاب دورانیہ کے مطابق',
    safetyLevel: 'CRITICAL',
    urduInstructions: [
      '1. ذاتی حفاظتی سامان (حفاظتی گوگلز، کانوں کے پلگ اور ڈسٹ ماسک) لازمی پہنیں۔ ڈھیلے کپڑے اور مفلر دور رکھیں۔',
      '2. ڈسٹ کلیکٹر (Dust Extractor) آن کریں اور ویکیوم شو (Dust Shoe) کو Z-Axis پر نچلی سطح پر ایڈجسٹ کریں۔',
      '3. پہلی بار نئی فائل چلاتے وقت "Dry Run / Air Cut" طریقہ استعمال کریں: Z0 کو لکڑی سے 30mm اوپر سیٹ کر کے ہوا میں پروگرام کا پہلا چکر چلا کر موومنٹ چیک کریں۔',
      '4. اگر سب ٹھیک ہے تو Z کو اصلی سرفیس پر لا کر "Cycle Start (Alt-R)" دبائیں۔ پہلا 1 منٹ کٹر اور کٹنگ چپ کے سائز پر نگاہ رکھیں۔',
      '5. فیڈ ریٹ اوور رائیڈ (Feedrate Override) سلائیڈر کو پہلے 50% پر رکھیں، پھر دھواں یا وائبریشن نہ ہونے پر 100% پر بڑھائیں۔',
      '6. ایمرجنسی صورت میں فوری اسپیس بار (Feed Hold) یا ریڈ ای-اسٹاپ بٹن دبائیں۔ مشین کے چلتے وقت کبھی بھی کٹنگ ٹیبل کے اوپر ہاتھ نہ لے جائیں۔',
    ],
    englishInstructions: [
      '1. Put on ANSI-certified safety glasses, ear defenders, and particulate dust respirator. Remove loose clothes.',
      '2. Turn on the shop dust extraction collector; fasten brush dust shoe around spindle nose.',
      '3. For untested G-code, run an "Air Cut": zero Z +30mm above stock and let it run dry for 60 seconds to verify bounds.',
      '4. Click "Cycle Start" (Alt-R). Keep one hand resting near the red E-Stop mushroom button for the initial pass.',
      '5. Start with Feedrate Override dialed back to 50%; gradually bring up to 100% as chip evacuation proves clean.',
      '6. In case of unexpected noise, screeching, or binding, hit Spacebar (Feed Hold) or slap the physical E-Stop.',
    ],
    mach3State: {
      screenName: 'Program Run // Job Active (Cutting)',
      droX: '+0184.250',
      droY: '+0235.800',
      droZ: '-0003.500',
      feedRate: 'F2400 mm/min (100%)',
      spindleRpm: '18,000 RPM',
      statusTextUrdu: 'جاب کامیابی سے چل رہی ہے - لائن 1,420 / 12,450 (11%)',
      statusTextEn: 'CYCLE RUNNING: Line 1,420 of 12,450 (11% Elapsed: 04m 12s)',
      activeMode: 'CYCLE RUNNING',
      highlightButtons: ['Cycle Start (Alt-R)', 'Feed Hold (Space)', 'Stop (Alt-S)'],
    },
    dspState: {
      screenTitle: 'DSP RichAuto A11 // Running',
      line1: 'Line: 01420 / 12450',
      line2: 'Speed: 100% (2400mm)',
      line3: 'Time: 00:04:12',
      line4: 'X184.2 Y235.8 Z-3.5',
      activeKeys: ['PAUSE', 'STOP', 'SPEED +/-'],
      modeLabel: 'JOB IN PROGRESS',
    },
    keyShortcuts: [
      { key: 'Alt + R', actionUrdu: 'سائیکل اسٹارٹ (جاب شروع کرنا)', actionEn: 'Cycle Start (Start Job)' },
      { key: 'Spacebar', actionUrdu: 'فیڈ ہولڈ (محفوظ وقتی توقف)', actionEn: 'Feed Hold (Smooth Pause)' },
      { key: 'Alt + S', actionUrdu: 'سائیکل اسٹاپ (فوری کٹنگ بند)', actionEn: 'Stop Cycle Immediately' },
    ],
    checklist: [
      { id: 'ce1', labelUrdu: 'حفاظتی عینک اور ماسک پہنا ہوا ہے', labelEn: 'Safety glasses and mask worn' },
      { id: 'ce2', labelUrdu: 'ڈسٹ شو اور ویکیوم کلیکٹر فعال ہے', labelEn: 'Dust shoe attached and suction on' },
      { id: 'ce3', labelUrdu: 'ہاتھ ایمرجنسی سوئچ کے قریب الرٹ ہے', labelEn: 'Hand ready near physical E-Stop' },
      { id: 'ce4', labelUrdu: 'کٹنگ چپ سفید آٹے کے بجائے کرکرا برادہ ہے', labelEn: 'Wood chips crisp, not smoky dust' },
    ],
    proTipUrdu: 'لکڑی کاٹنے کا سنہری اصول: اگر کٹر سے سفید باریک دھواں یا کالا راکھ نما آٹا نکل رہا ہے تو اس کا مطلب ہے فیڈ ریٹ بہت سست ہے اور کٹر جل رہا ہے! فیڈ ریٹ بڑھائیں تاکہ صحت مند برادہ بنے اور گرمی چپ کے ساتھ باہر نکل جائے۔',
    proTipEn: 'Golden woodworking rule: If you see fine flour dust or smoke, your feedrate is too slow and the tool is rubbing! Increase feedrate to throw crisp chips that carry heat away.',
    sampleGcode: `(CYCLE START SEQUENCE)
G0 X0 Y0 Z15.000 (Verify Origin)
M3 S18000
G4 P3.0
G0 X154.200 Y212.400 (Rapid to first cut)
G1 Z-3.500 F600 (Plunge into material)
G1 X156.800 Y215.300 F2400 (Production feed)`,
  },
  {
    id: 'F',
    stepLetter: 'Step F',
    titleUrdu: 'پاور لاس ریکوری (لائن نمبر سے دوبارہ بحالی)',
    titleEn: 'Power Loss Recovery (Resume from exact G-code line)',
    subtitleUrdu: 'بجلی بندش یا بریک ڈاؤن کے بعد خراب شدہ لائن سے بلا جھٹکا کٹنگ کا تسلسل',
    subtitleEn: 'Mid-Program Power Outage Recovery & Clean Continuation from Exact G-code Block',
    category: 'Recovery',
    estimatedTime: '5 - 10 منٹ',
    safetyLevel: 'CRITICAL',
    urduInstructions: [
      '1. بجلی جانے پر کنٹرولر کا سوئچ فورا آف کریں تاکہ بجلی واپسی پر اچانک جھٹکا نہ لگے۔ کٹر کو ہاتھ سے ہرگز نہ ہلائیں!',
      '2. بجلی بحال ہونے پر سب سے پہلے Z-Axis کو اوپر اٹھائیں؛ کبھی بھی کٹر کو میٹریل کے اندر دبا کر سائیڈ پر نہ گھسیٹیں کیونکہ اینڈ مل فورا ٹوٹ جائے گی۔',
      '3. مشین کو دوبارہ ریفرنس ہوم (Ref All Home) کریں تاکہ مشین کے ہارڈویئر سینسرز اپنی حقیقی پوزیشن سنبھال لیں۔',
      '4. سابقہ سیٹ شدہ ورک کوآرڈینیٹس (WCS G54) کی تصدیق کریں۔ چونکہ ڈیٹم فکس تھا اس لیے زیرو پوائنٹ محفوظ ہے۔',
      '5. مچ تھری میں G-code اسکرول کر کے بندش سے 10-20 لائنز پہلے جائیں (مثلاً لائن N45200)، "Set Next Line" دبائیں، پھر "Run From Here" پر کلک کریں۔',
      '6. تیار شدہ ہیڈر میکرو تصدیق کرے گا: Z اوپر اٹھے گا، اسپنڈل 18,000 RPM پر گھومے گا، پھر کٹر کٹنگ پوائنٹ کے اوپر آ کر نیچے اترے گا اور ہموار کٹنگ شروع ہو جائے گی۔',
    ],
    englishInstructions: [
      '1. When power dies, switch off the control cabinet instantly to prevent electrical surge. Do NOT push gantry by hand!',
      '2. Upon power restoration, jog Z upwards straight out of the cut. Never jog XY while bit is buried in stock.',
      '3. Re-home all axes (Ref All Home) to recalibrate machine hardware against inductive proximity sensors.',
      '4. Re-verify the Work Coordinate System (WCS G54). Since the physical stock did not move, the origin remains intact.',
      '5. Locate the interruption point in the G-code editor; rewind 10-20 lines earlier (e.g. N45200), click "Run From Here".',
      '6. Mach3 generates the resume trajectory: lifts Z to safe clearance, spins spindle up to full RPM, traverses to XY, and descends.',
    ],
    mach3State: {
      screenName: 'Program Run // Run From Here Wizard',
      droX: '+0156.800',
      droY: '+0215.350',
      droZ: '+0025.000 (SAFE RETRACT)',
      feedRate: 'F1800 mm/min',
      spindleRpm: '18,000 RPM (SPUN UP)',
      statusTextUrdu: 'لائن N45210 پر بحالی تیار ہے - سائیکل اسٹارٹ دبائیں',
      statusTextEn: 'RESUME READY AT LINE N45210: SAFE TRAVERSE TO XY THEN G1 PLUNGE',
      activeMode: 'RUN FROM HERE MACRO',
      highlightButtons: ['Run From Here', 'Set Next Line', 'Cycle Start'],
    },
    dspState: {
      screenTitle: 'DSP RichAuto A11 // Breakpoint',
      line1: 'Breakpoint Found: L45210',
      line2: 'Resume Cut? [OK / CANCEL]',
      line3: 'Safe Height: 25.0mm',
      line4: 'Spindle Spin-up: 5 sec',
      activeKeys: ['ORIGIN OK', 'RUN', 'STOP (Back)'],
      modeLabel: 'BREAKPOINT RESUME',
    },
    keyShortcuts: [
      { key: 'Ctrl + F', actionUrdu: 'G-Code فائل میں لائن نمبر تلاش کرنا', actionEn: 'Find Interrupted G-code Line' },
      { key: 'Page Up', actionUrdu: 'کٹر کو مٹیریل سے فوری اوپر اٹھانا', actionEn: 'Safe Vertical Tool Retraction' },
      { key: 'Alt + R', actionUrdu: 'پریپریشن ڈائیلاگ کے بعد کٹنگ بحال کرنا', actionEn: 'Resume Execution at Breakpoint' },
    ],
    checklist: [
      { id: 'cf1', labelUrdu: 'Z-Axis پہلے اوپر اٹھایا گیا، XY نہیں ہلایا', labelEn: 'Z retracted vertically first' },
      { id: 'cf2', labelUrdu: 'مشین کو دوبارہ Ref All Home کیا گیا', labelEn: 'Machine successfully re-homed' },
      { id: 'cf3', labelUrdu: 'بندش سے 10 سے 20 لائنز پیچھے سے شروع کیا', labelEn: 'Rewound 10-20 lines prior' },
      { id: 'cf4', labelUrdu: 'اسپنڈل کے پورے چکر (18K) پکڑنے کا انتظار کیا', labelEn: 'Spindle allowed 5 sec spin-up' },
    ],
    proTipUrdu: 'ریکوری کا اہم راز: کٹنگ بندش کی عین لائن سے شروع کرنے کے بجائے ہمیشہ 10 یا 15 لائنز پیچھے سے شروع کریں۔ اس طرح کٹر پرانے کٹے ہوئے راستے پر ہوا میں گھومتا ہوا آتا ہے اور مٹیریل پر کوئی بدنما نشان یا سٹیپ نہیں بنتا۔',
    proTipEn: 'Recovery master tip: Always rewind 10 to 15 lines before the crash point. This allows the tool to blend in seamlessly along the existing cut path without creating an ugly step or scar.',
    sampleGcode: `(POWER RECOVERY HEADER)
G21 G90 G54
G0 Z25.000 (Safe clearance lift)
M3 S18000
G4 P5.0 (Dwell 5 seconds for spindle)
G0 X156.800 Y215.350 (Traverse directly above interrupted point)
G1 Z-4.500 F300 (Gentle controlled plunge)
G1 X157.450 Y215.900 F1800 (Resume continuous production path)`,
  },
  {
    id: 'G',
    stepLetter: 'Step G',
    titleUrdu: 'جاب تکمیل اور شٹ ڈاؤن طریقہ کار',
    titleEn: 'Job Completion & Shutdown Sequence',
    subtitleUrdu: 'ٹول پارکنگ، مٹیریل ان کلیمپنگ، بال اسکرو ڈسٹ کلیننگ اور بریکر پاور آف',
    subtitleEn: 'G28 Parking, Stock Unclamping, Rails Dust Cleaning, Lubrication & Breaker Off',
    category: 'Shutdown',
    estimatedTime: '3 - 5 منٹ',
    safetyLevel: 'STANDARD',
    urduInstructions: [
      '1. جاب مکمل ہونے پر تصدیق کریں کہ اسپنڈل موٹر مکمل رک چکی ہے (M5/M30) اور کٹر پارکنگ پوزیشن پر جا چکا ہے۔',
      '2. لکڑی کے پرزے کو ہاتھ لگانے سے پہلے ویکیوم یا ڈسٹ کلیکٹر سے فالتو برادہ صاف کریں۔',
      '3. کلیمپس کھولیں، تیار شدہ ووڈ کرافٹ کا ٹکڑا نکالیں اور کیلیپرز یا پیمائش کے فیتے سے ڈیزائن کے سائز کی تصدیق کریں۔',
      '4. لکیری گائیڈ ریلز (Linear Rails) اور بال اسکرولز سے ایئر گن کے ذریعے باریک لکڑی کا پاؤڈر صاف کریں۔',
      '5. بیئرنگ بلاکس پر سلائیڈنگ لوبریکنٹ یا آئل (ISO VG 68) کا ہلکا چھڑکاؤ کریں تاکہ زنگ نہ لگے۔',
      '6. مشین سافٹ ویئر بند کریں، کنٹرول باکس کا مین سوئچ آف کریں اور ورکشاپ کا مین سرکٹ بریکر بند کریں۔',
    ],
    englishInstructions: [
      '1. Verify program end (M30); confirm spindle stopped completely and gantry parked at back table clearance.',
      '2. Vacuum away loose sawdust before touching stock or unclamping hold-downs.',
      '3. Release hold-down clamps, remove carved piece, and inspect dimensional accuracy using vernier calipers.',
      '4. Blow off fine wood flour from linear guideways, SFU1605 ballscrews, and stepper cooling fins using compressed air.',
      '5. Apply light film of ISO VG 68 slide-way lubricant oil to polished rail tracks to prevent oxidation/rust.',
      '6. Exit CNC controller software, shut down computer, toggle control cabinet switch OFF, and trip main wall breaker.',
    ],
    mach3State: {
      screenName: 'Program Run // Job Complete',
      droX: '0.000 (PARKED)',
      droY: '+0700.000 (BACK)',
      droZ: '+0050.000 (HIGH)',
      feedRate: '0.00 mm/min',
      spindleRpm: '0 RPM (STOPPED)',
      statusTextUrdu: 'جاب کامیابی سے مکمل ہو گئی! پرزہ ان لوڈ کریں اور ریلز صاف کریں',
      statusTextEn: 'PROGRAM COMPLETED (M30) - MACHINE PARKED AT SAFE UNLOAD POSITION',
      activeMode: 'PROGRAM FINISHED',
      highlightButtons: ['Rewind (Ctrl-W)', 'Close G-Code', 'Exit'],
    },
    dspState: {
      screenTitle: 'DSP RichAuto A11 // Finished',
      line1: 'JOB 100% COMPLETED',
      line2: 'Total Time: 00:42:15',
      line3: 'Spindle: STOPPED',
      line4: 'Press [ORIGIN] to park',
      activeKeys: ['ORIGIN OK', 'STOP', 'MENU'],
      modeLabel: 'FINISHED (M30)',
    },
    keyShortcuts: [
      { key: 'Ctrl + W', actionUrdu: 'G-Code ریوائنڈ کر کے شروع میں لانا', actionEn: 'Rewind G-Code Program to Top' },
      { key: 'G28 / Park', actionUrdu: 'گینٹری کو پچھلی ان لوڈ پوزیشن پر بھیجنا', actionEn: 'Send Gantry to Safe Park Coords' },
      { key: 'Alt + F4', actionUrdu: 'سافٹ ویئر کو محفوظ طریقے سے بند کرنا', actionEn: 'Safely Exit Control Application' },
    ],
    checklist: [
      { id: 'cg1', labelUrdu: 'اسپنڈل مکمل طور پر رک چکا ہے', labelEn: 'Spindle rotation completely halted' },
      { id: 'cg2', labelUrdu: 'تیار شدہ لکڑی کا ٹکڑا نکال لیا گیا ہے', labelEn: 'Carved stock safely unfastened' },
      { id: 'cg3', labelUrdu: 'بال اسکرو اور ریلز سے برادہ صاف کیا گیا', labelEn: 'Rails & ballscrews dusted clean' },
      { id: 'cg4', labelUrdu: 'مین باکس اور بریکر بند کر دیا گیا ہے', labelEn: 'Control cabinet and wall breaker off' },
    ],
    proTipUrdu: 'کام کے اختتام پر 2 منٹ کی صفائی آپ کی مشین کی عمر 5 سال بڑھا دیتی ہے! بال اسکرو پر لکڑی کا برادہ جمنے سے بال بیرنگ جام ہو جاتے ہیں اور سٹیپ لوزنگ کا عارضہ لاحق ہو جاتا ہے۔',
    proTipEn: 'A 2-minute clean down at end of shift extends machine lifespan by 5 years! Trapped wood dust inside ballscrew nut wipers causes ball binding and phantom step skipping.',
    sampleGcode: `(JOB FINISH & SAFE PARK SEQUENCE)
G0 Z50.000 (Safe Z Retract)
M5 (Spindle Stop)
M9 (Coolant / Air Off)
G0 X0 Y700.000 (Park Gantry at rear table for effortless unloading)
M30 (Program End & Rewind)`,
  },
];
