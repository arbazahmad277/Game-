import React, { useEffect, useState } from 'react';
import { Sparkles, Cpu, CheckCircle } from 'lucide-react';

interface SplashScreenProps {
  onFinish: () => void;
  brandName?: string;
  subtitle?: string;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onFinish,
  brandName = 'Arbaz Wood Craft',
  subtitle = 'CNC Router Smart Assistant',
}) => {
  const [progress, setProgress] = useState<number>(0);
  const [isFadingOut, setIsFadingOut] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('ورکشاپ سسٹم لوڈ ہو رہا ہے...');

  useEffect(() => {
    // 2-second progress animation with progressive milestone text
    const startTime = Date.now();
    const duration = 2000; // 2 seconds

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(pct);

      if (pct < 35) {
        setStatusMessage('مشین ڈیٹا اور 30 مراحل کی تصدیق...');
      } else if (pct < 75) {
        setStatusMessage('3D CAD بلو پرنٹس اور آف لائن اسٹوریج تیار...');
      } else if (pct < 100) {
        setStatusMessage('ورکشاپ اسمارٹ اسسٹنٹ ایکٹیویٹ ہو رہا ہے...');
      } else {
        setStatusMessage('سسٹم تیار ہے! خوش آمدید');
      }

      if (elapsed >= duration) {
        clearInterval(interval);
        setIsFadingOut(true);
        setTimeout(() => {
          onFinish();
        }, 450); // allow fadeout animation to complete
      }
    }, 30);

    return () => clearInterval(interval);
  }, [onFinish]);

  return (
    <div
      className={`fixed inset-0 z-[99999] bg-[#070d18] flex flex-col items-center justify-center p-6 select-none transition-opacity duration-500 ${
        isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Background ambient lighting */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-blue-600/10 rounded-full blur-2xl" />
        {/* Subtle grid pattern */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #38bdf8 1px, transparent 0)`,
            backgroundSize: '32px 32px',
          }}
        />
      </div>

      <div className="relative z-10 flex flex-col items-center max-w-sm w-full text-center">
        {/* Glowing Brand Logo */}
        <div className="relative mb-6 group">
          <div className="absolute -inset-2 bg-gradient-to-r from-cyan-400 to-blue-600 rounded-3xl blur-xl opacity-75 animate-pulse" />
          <div className="relative w-24 h-24 rounded-2xl bg-gradient-to-br from-[#0c1626] to-[#040810] border-2 border-cyan-400/80 flex items-center justify-center shadow-2xl shadow-cyan-500/30">
            <span className="text-5xl transform hover:scale-110 transition-transform">🪵</span>
            <div className="absolute -bottom-2 -right-2 w-8 h-8 rounded-lg bg-cyan-500 text-slate-950 flex items-center justify-center shadow-md">
              <Cpu className="w-4 h-4" />
            </div>
          </div>
        </div>

        {/* Brand Name & Subtitle */}
        <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mb-1 font-sans">
          {brandName}
        </h1>
        <p className="text-cyan-400 font-medium text-xs sm:text-sm tracking-widest uppercase mb-6 flex items-center gap-1.5 font-mono">
          <Sparkles className="w-3.5 h-3.5" />
          <span>{subtitle}</span>
        </p>

        {/* Loading Bar with percentage display */}
        <div className="w-full max-w-[260px] mb-3">
          <div className="flex justify-between items-center text-[11px] font-mono text-slate-400 mb-1.5">
            <span className="text-cyan-300 truncate">{statusMessage}</span>
            <span className="font-bold text-white ml-2">{progress}%</span>
          </div>
          <div className="h-2 w-full bg-slate-900 border border-cyan-900/60 rounded-full overflow-hidden p-0.5 shadow-inner">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 rounded-full transition-all duration-75 ease-out shadow-[0_0_12px_rgba(56,189,248,0.8)]"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Bilingual badge */}
        <div className="flex items-center gap-2 mt-4 text-[11px] text-slate-500 font-mono">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          <span>اردو ورکشاپ گائیڈ &bull; 100% آف لائن ڈیٹا محفوظ</span>
        </div>
      </div>
    </div>
  );
};
