import React, { useState, useRef, useEffect } from 'react';
import { CNCStep } from '../data/cncSteps';
import {
  Wrench,
  Maximize2,
  Activity,
  Layers,
  Compass,
  Zap,
  Info,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
  Gauge,
  Sliders,
  Target
} from 'lucide-react';

export type BlueprintSubsystem =
  | 'base_frame'
  | 'gantry'
  | 'z_axis_spindle'
  | 'electronics'
  | 'assembled'
  | 'inspection';

export interface HotspotInfo {
  id: string;
  nameEn: string;
  nameUr: string;
  status: 'normal' | 'warning' | 'critical' | 'calibrated';
  spec: string;
  tolerance: string;
  torque: string;
  remedyUr: string;
  remedyEn: string;
  x: number;
  y: number;
}

interface InteractiveSVGBlueprintProps {
  step?: CNCStep;
  stepNumber?: number;
  subsystem?: BlueprintSubsystem;
  title?: string;
  faultArea?: string;
  interactive?: boolean;
  onSelectHotspot?: (hotspot: HotspotInfo) => void;
  showCanvasSimulation?: boolean;
  className?: string;
  aspectRatio?: string;
  isDiagnosticMode?: boolean;
  customOverlayText?: string;
}

export const InteractiveSVGBlueprint: React.FC<InteractiveSVGBlueprintProps> = ({
  step,
  stepNumber,
  subsystem: propSubsystem,
  title: propTitle,
  faultArea,
  interactive = true,
  onSelectHotspot,
  showCanvasSimulation = false,
  className = '',
  isDiagnosticMode = false,
  customOverlayText,
}) => {
  const currentStepNum = step?.id || stepNumber || 1;

  // Determine subsystem based on step if not explicitly provided
  const subsystem: BlueprintSubsystem = propSubsystem || (() => {
    if (step) {
      if (step.phaseId === 1 || step.id <= 6) return 'base_frame';
      if (step.phaseId === 2 || (step.id >= 7 && step.id <= 15)) return 'gantry';
      if (step.phaseId === 3 || (step.id >= 16 && step.id <= 20)) return 'z_axis_spindle';
      if (step.phaseId === 4 || (step.id >= 21 && step.id <= 25)) return 'electronics';
      return 'assembled';
    }
    return 'gantry';
  })();

  const [activeLayer, setActiveLayer] = useState<'all' | 'dimensions' | 'fasteners' | 'hotspots'>('all');
  const [selectedHotspot, setSelectedHotspot] = useState<HotspotInfo | null>(null);
  const [enableLiveSim, setEnableLiveSim] = useState<boolean>(showCanvasSimulation);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [rotationAngle, setRotationAngle] = useState<number>(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Subsystem-specific hotspots
  const hotspotsMap: Record<BlueprintSubsystem, HotspotInfo[]> = {
    base_frame: [
      {
        id: 'rail_y_left',
        nameEn: 'MGN15H Left Linear Rail',
        nameUr: 'بائیں جانب کی MGN15 لکیری ریل',
        status: faultArea?.includes('rail') ? 'warning' : 'calibrated',
        spec: 'MGN15H C-Grade High Precision',
        tolerance: '< 0.015 mm coplanarity',
        torque: 'M4: 4.8 N·m (Medium Loctite 243)',
        remedyUr: 'ڈائل انڈیکیٹر سے متوازی پن (Parallelism) ناپیں اور ہر 100mm پر بولٹ کسیں۔',
        remedyEn: 'Sweep with dial test indicator across 1500mm span, torque bolts progressively.',
        x: 180,
        y: 260,
      },
      {
        id: 'corner_bracket',
        nameEn: '4080 Gusset Corner Bracket',
        nameUr: 'کونے کا 4080 اینگل بریکٹ',
        status: 'normal',
        spec: 'Cast Aluminum 6061 Gusset',
        tolerance: '90.00° ± 0.05° Squareness',
        torque: 'M6: 9.5 N·m',
        remedyUr: 'مشین اسکوائر (Precision Square) سے 90 ڈگری تصدیق کریں اور ریل لگانے سے پہلے کسیں۔',
        remedyEn: 'Check 90° squareness with precision machinist square before tightening.',
        x: 230,
        y: 330,
      },
      {
        id: 'leveling_foot',
        nameEn: 'M12 Heavy Duty Leveling Foot',
        nameUr: 'ایم 12 لیولنگ پاؤں',
        status: 'normal',
        spec: 'M12x100 Swivel Rubber Pad',
        tolerance: 'Level < 0.2mm per meter',
        torque: 'Lock nut: 25 N·m',
        remedyUr: 'پریسیژن سپرٹ لیول سے فریم کی سطح کو چاروں کونوں پر متوازن کریں۔',
        remedyEn: 'Level all 4 corners using machinist precision bubble level.',
        x: 580,
        y: 370,
      },
    ],
    gantry: [
      {
        id: 'ballscrew_y',
        nameEn: 'SFU1605 Precision Ball Screw',
        nameUr: 'ایس ایف یو 1605 پریسیژن بال اسکرو',
        status: faultArea?.includes('screw') || faultArea?.includes('backlash') ? 'critical' : 'calibrated',
        spec: 'SFU1605-C7 Rolled / Ground Pitch 5mm',
        tolerance: 'Axial Backlash < 0.012 mm',
        torque: 'Coupler M4 clamp: 3.5 N·m',
        remedyUr: 'اینٹی بیک لیش اسپرنگ نٹ یا کپلر کی سیٹ اسکرو چیک کریں، گرد صاف کر کے ہلکا آئل ڈالیں۔',
        remedyEn: 'Inspect pre-load spring on double-nut, check coupler setscrews for slippage.',
        x: 400,
        y: 220,
      },
      {
        id: 'stepper_nema23',
        nameEn: 'NEMA 23 High-Torque Stepper Motor',
        nameUr: 'نیما 23 ہائی ٹارک موٹر',
        status: faultArea?.includes('stepper') || faultArea?.includes('motor') ? 'warning' : 'normal',
        spec: '3.0 N·m Holding Torque / 4.2A Peak',
        tolerance: 'Step Angle 1.8° ± 5%',
        torque: 'Mounting M5: 6.2 N·m',
        remedyUr: 'موٹر کی وائرنگ شیلڈنگ اور ڈرائیور کے مائیکرو اسٹیپس (1600 P/R) چیک کریں۔',
        remedyEn: 'Verify motor phase coil resistance (0.8Ω) and microstep dip switch config.',
        x: 640,
        y: 190,
      },
      {
        id: 'gantry_plate',
        nameEn: '15mm 6061-T6 Gantry Riser Plate',
        nameUr: '15 ملی میٹر ایلومینیم گینٹری پلیٹ',
        status: 'normal',
        spec: 'CNC Milled Mic-6 Tooling Plate',
        tolerance: 'Flatness < 0.02 mm',
        torque: 'M6 Grade 10.9: 11.2 N·m',
        remedyUr: 'دونوں سائیڈ پلیٹوں کا فاصلہ مساوی رکھیں تاکہ گینٹری نہ پھنسے۔',
        remedyEn: 'Verify dual Y-axis gantry upright orthogonality and racking tolerance.',
        x: 210,
        y: 170,
      },
    ],
    z_axis_spindle: [
      {
        id: 'spindle_collet',
        nameEn: 'ER20 High Precision Collet Chuck',
        nameUr: 'ای آر 20 پریسیژن کولیٹ چک',
        status: faultArea?.includes('collet') || faultArea?.includes('spindle') ? 'critical' : 'calibrated',
        spec: 'ER20-A Clamping 1-13mm, 24000 RPM',
        tolerance: 'Runout (TIR) < 0.005 mm at tool tip',
        torque: 'Collet Nut: 28-32 N·m',
        remedyUr: 'کولیٹ کو کھول کر اندرونی کونیکل سرفیس صاف کریں، کبھی زیادہ ٹارک نہ لگائیں۔',
        remedyEn: 'Clean collet taper thoroughly with brass brush; inspect for chips or burrs.',
        x: 400,
        y: 330,
      },
      {
        id: 'spindle_clamp',
        nameEn: '80mm Cast Spindle Mount',
        nameUr: '80 ملی میٹر اسپنڈل بریکٹ',
        status: 'normal',
        spec: '80mm Bore / 4x M8 Pinch Bolt',
        tolerance: 'Perpendicularity to Bed < 0.01mm / 100mm',
        torque: 'Pinch Bolts M8: 18 N·m progressive',
        remedyUr: 'اسپنڈل کو ٹرامنگ گیج (Tramming Arm) کے ذریعے بیڈ کے ساتھ بالکل 90° سیٹ کریں۔',
        remedyEn: 'Tram spindle axis perpendicularity using dual dial test indicator tramming tool.',
        x: 400,
        y: 200,
      },
      {
        id: 'z_lead_nut',
        nameEn: 'Z-Axis Anti-Backlash Brass Nut',
        nameUr: 'زیڈ ایکسس اینٹی بیک لیش نٹ',
        status: faultArea?.includes('z') ? 'warning' : 'normal',
        spec: 'T8x8 4-Start Brass Nut with Preload Spring',
        tolerance: 'Backlash < 0.02 mm',
        torque: 'Mounting Screws M3: 1.8 N·m',
        remedyUr: 'اسپرنگ کی لچک چیک کریں اور لیڈ اسکرو پر خشک پی ٹی ایف ای لیوبریکنٹ لگائیں۔',
        remedyEn: 'Check spring tension and apply PTFE dry lubricant to lead screw threads.',
        x: 450,
        y: 250,
      },
    ],
    electronics: [
      {
        id: 'stepper_driver',
        nameEn: 'DM542 Digital Stepper Driver',
        nameUr: 'ڈی ایم 542 مائیکرو اسٹیپ ڈرائیور',
        status: 'calibrated',
        spec: '20-50V DC / Peak 4.2A / 1600 Steps/Rev',
        tolerance: 'Opto-isolation 500V',
        torque: 'Screw Terminals: 0.5 N·m',
        remedyUr: 'ڈی آئی پی سوئچ کی کرنٹ سیٹنگ موٹر کی ریٹڈ کرنٹ کے مطابق سیٹ کریں۔',
        remedyEn: 'Verify DIP switch current (SW1-SW3) and microstepping resolution (SW5-SW8).',
        x: 320,
        y: 230,
      },
      {
        id: 'power_supply',
        nameEn: '48V 10A 480W Switching PSU',
        nameUr: '48 وولٹ 10 ایمپیئر پاور سپلائی',
        status: 'normal',
        spec: '48V DC ±1% Ripple < 150mV',
        tolerance: 'Overload Protection 110-150%',
        torque: 'Terminal Screws: 0.8 N·m',
        remedyUr: 'ملٹی میٹر سے وولٹیج 48.2V پر ناپیں اور ارتھنگ کنکشن مضبوط رکھیں۔',
        remedyEn: 'Trim DC voltage pot to 48.0V and verify PE earth ground bond resistance < 0.1Ω.',
        x: 520,
        y: 230,
      },
      {
        id: 'shielded_cable',
        nameEn: 'Drag Chain High-Flex Shielded Cable',
        nameUr: 'شیلڈڈ کیبل اور ڈریگ چین',
        status: 'normal',
        spec: '4x 0.5mm² Tinned Copper Braid Shield',
        tolerance: 'Noise Rejection > 80dB',
        torque: 'Cable Gland: Hand tight + 1 turn',
        remedyUr: 'کیبل شیلڈ کو صرف کنٹرولر سائیڈ پر ایک نقطہ (Star Ground) پر ارتھ کریں۔',
        remedyEn: 'Ground the cable shield braid at star grounding bus bar on controller side only.',
        x: 420,
        y: 350,
      },
    ],
    assembled: [
      {
        id: 'bed_surface',
        nameEn: 'Cast Tooling Aluminum Bed Plate',
        nameUr: 'ایلومینیم کٹنگ بیڈ سرفیس',
        status: 'calibrated',
        spec: '600 x 900 x 20mm T-Slot Bed',
        tolerance: 'Planarity < 0.03 mm across full travel',
        torque: 'T-Nuts M6: 12 N·m',
        remedyUr: 'اسپوائل بورڈ کو فلیٹ فلائی کٹر سے سرفیسنگ (Surfacing) کر کے بالکل ہموار بنائیں۔',
        remedyEn: 'Perform spoilboard fly-cutter skim pass (0.3mm depth) to zero machine plane.',
        x: 400,
        y: 310,
      },
      {
        id: 'spindle_head',
        nameEn: '3-Axis Cutting Head Assembly',
        nameUr: 'تین محور کٹنگ ہیڈ',
        status: 'normal',
        spec: 'XYZ Work Envelope: 600x900x150 mm',
        tolerance: 'Repeatability ±0.008 mm',
        torque: 'All Axis Checked',
        remedyUr: 'تمام تینوں محوروں پر زیرو پوزیشن اور ریپیٹ ایبلٹی چیک کریں۔',
        remedyEn: 'Run XYZ dial test indicator repeatability check after 20 test cycles.',
        x: 420,
        y: 180,
      },
    ],
    inspection: [
      {
        id: 'probe_sensor',
        nameEn: 'Auto Tool Zero Touch Probe',
        nameUr: 'آٹو ٹول زیرو پروچ سینسر',
        status: 'calibrated',
        spec: 'Conductive Brass / Normally Open Circuit',
        tolerance: 'Trigger Repeatability ±0.002 mm',
        torque: 'Cable Strain Relief: Verified',
        remedyUr: 'ٹچ پلیٹ کی موٹائی مائیکرو میٹر سے درست کیلیبریٹ کریں اور کیبل ٹیسٹ کریں۔',
        remedyEn: 'Measure exact plate thickness with outside micrometer and enter in G-code macro.',
        x: 390,
        y: 280,
      },
    ],
  };

  const currentHotspots = hotspotsMap[subsystem] || hotspotsMap.base_frame;

  // Real-time HTML5 Canvas Animation Loop
  useEffect(() => {
    if (!enableLiveSim) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let t = 0;

    const render = () => {
      t += 0.04;
      const width = canvas.width;
      const height = canvas.height;

      ctx.clearRect(0, 0, width, height);

      // Draw real-time oscillating dial indicator or laser straightness line
      if (subsystem === 'z_axis_spindle' || subsystem === 'gantry') {
        // Dial indicator gauge in corner
        const gaugeX = width - 110;
        const gaugeY = 90;
        const radius = 40;

        ctx.save();
        // Dial housing
        ctx.fillStyle = '#0a192f';
        ctx.strokeStyle = '#0284c7';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(gaugeX, gaugeY, radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Tick marks
        for (let i = 0; i < 12; i++) {
          const angle = (i / 12) * Math.PI * 2;
          const x1 = gaugeX + Math.cos(angle) * (radius - 4);
          const y1 = gaugeY + Math.sin(angle) * (radius - 4);
          const x2 = gaugeX + Math.cos(angle) * (radius - (i % 3 === 0 ? 9 : 6));
          const y2 = gaugeY + Math.sin(angle) * (radius - (i % 3 === 0 ? 9 : 6));
          ctx.strokeStyle = i % 3 === 0 ? '#38bdf8' : '#0369a1';
          ctx.lineWidth = i % 3 === 0 ? 1.5 : 1;
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.stroke();
        }

        // Needle oscillation
        const needleAngle = Math.sin(t * 2) * 0.35 - Math.PI / 2;
        const needleX = gaugeX + Math.cos(needleAngle) * (radius - 12);
        const needleY = gaugeY + Math.sin(needleAngle) * (radius - 12);

        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(gaugeX, gaugeY);
        ctx.lineTo(needleX, needleY);
        ctx.stroke();

        ctx.fillStyle = '#f87171';
        ctx.beginPath();
        ctx.arc(gaugeX, gaugeY, 3, 0, Math.PI * 2);
        ctx.fill();

        // Label
        ctx.font = '9px monospace';
        ctx.fillStyle = '#38bdf8';
        ctx.textAlign = 'center';
        ctx.fillText('RUNOUT (TIR)', gaugeX, gaugeY + 22);
        const reading = (Math.abs(Math.sin(t * 2)) * 0.006).toFixed(4);
        ctx.fillStyle = '#4ade80';
        ctx.fillText(`${reading} mm`, gaugeX, gaugeY + 32);
        ctx.restore();

        // Rotating lead screw thread effect across center
        const screwY = 220;
        const screwXStart = 200;
        const screwXEnd = 600;

        ctx.save();
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1;
        ctx.globalAlpha = 0.4;
        const threadOffset = (t * 25) % 15;
        for (let x = screwXStart + threadOffset; x < screwXEnd; x += 15) {
          ctx.beginPath();
          ctx.moveTo(x, screwY - 8);
          ctx.lineTo(x + 7, screwY + 8);
          ctx.stroke();
        }
        ctx.restore();
      }

      // Laser straightness scan line
      const laserY = 250 + Math.sin(t * 0.8) * 40;
      ctx.save();
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.globalAlpha = 0.6;
      ctx.beginPath();
      ctx.moveTo(120, laserY);
      ctx.lineTo(680, laserY);
      ctx.stroke();

      // Measurement point dot
      const dotX = 120 + ((t * 80) % 560);
      ctx.fillStyle = '#ef4444';
      ctx.globalAlpha = 0.9;
      ctx.beginPath();
      ctx.arc(dotX, laserY, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [enableLiveSim, subsystem]);

  const handleHotspotClick = (h: HotspotInfo) => {
    setSelectedHotspot(h);
    if (onSelectHotspot) {
      onSelectHotspot(h);
    }
  };

  const displayTitle =
    propTitle ||
    step?.titleEn ||
    (subsystem === 'base_frame'
      ? 'CNC Base Frame & MGN15 Linear Rail Alignment'
      : subsystem === 'gantry'
      ? 'Dual Y-Axis Gantry & SFU1605 Ball Screw Assembly'
      : subsystem === 'z_axis_spindle'
      ? '2.2kW Spindle Head & ER20 Collet Concentricity'
      : subsystem === 'electronics'
      ? 'DM542 Stepper Drivers & High-Flex Shielded Cabling'
      : 'Assembled 3-Axis CNC Router Precision System');

  return (
    <div
      className={`relative w-full rounded-xl overflow-hidden bg-[#030c1b] border border-cyan-900/80 shadow-2xl flex flex-col ${className}`}
      style={{ minHeight: '340px' }}
    >
      {/* Top Engineering Header Bar */}
      <div className="flex flex-wrap items-center justify-between px-3 py-2 bg-slate-950/90 border-b border-cyan-900/60 text-xs font-mono select-none z-10 backdrop-blur">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-cyan-400">
            <Compass className="w-4 h-4 animate-spin-slow text-cyan-400" />
            <span className="font-bold tracking-wider text-[11px] text-cyan-300">
              VECTOR CAD DWG // REV 4.2
            </span>
          </div>
          <span className="text-slate-600">|</span>
          <span className="text-slate-300 font-semibold text-[11px] truncate max-w-[260px]">
            {displayTitle}
          </span>
          {isDiagnosticMode && (
            <span className="bg-amber-950 text-amber-300 border border-amber-600/50 px-2 py-0.5 rounded text-[10px] font-bold animate-pulse">
              DIAGNOSTIC MODE
            </span>
          )}
        </div>

        {/* Action and Layer Controls */}
        <div className="flex items-center gap-1.5 mt-1 sm:mt-0">
          <button
            onClick={() => setEnableLiveSim(!enableLiveSim)}
            className={`px-2 py-1 rounded text-[11px] font-mono flex items-center gap-1 transition ${
              enableLiveSim
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-600 shadow-sm shadow-emerald-900/40'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
            title="Toggle Live Canvas Physics & Dial Simulation"
          >
            <Zap className={`w-3 h-3 ${enableLiveSim ? 'text-emerald-400 animate-pulse' : ''}`} />
            <span>{enableLiveSim ? 'Live Sim: ON' : 'Live Sim'}</span>
          </button>

          <button
            onClick={() =>
              setActiveLayer(
                activeLayer === 'all'
                  ? 'dimensions'
                  : activeLayer === 'dimensions'
                  ? 'fasteners'
                  : activeLayer === 'fasteners'
                  ? 'hotspots'
                  : 'all'
              )
            }
            className="px-2 py-1 rounded text-[11px] font-mono bg-slate-900 text-cyan-300 border border-cyan-900/60 hover:border-cyan-500 transition flex items-center gap-1"
            title="Cycle Blueprint Layer (Dimensions / Fasteners / Hotspots / All)"
          >
            <Layers className="w-3 h-3 text-cyan-400" />
            <span className="capitalize">{activeLayer}</span>
          </button>

          <button
            onClick={() => setZoomLevel((prev) => (prev >= 1.4 ? 1 : prev + 0.2))}
            className="p-1 rounded bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800"
            title="Zoom CAD schematic"
          >
            <Sliders className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Main Blueprint Viewport */}
      <div className="relative flex-1 w-full h-full min-h-[300px] flex items-center justify-center overflow-hidden bg-[#030c1b]">
        {/* Subtle Engineering Grid */}
        <svg
          className="absolute inset-0 w-full h-full pointer-events-none opacity-20"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <pattern id="bpGridSub" width="12" height="12" patternUnits="userSpaceOnUse">
              <path d="M 12 0 L 0 0 0 12" fill="none" stroke="#0ea5e9" strokeWidth="0.4" />
            </pattern>
            <pattern id="bpGridMain" width="60" height="60" patternUnits="userSpaceOnUse">
              <rect width="60" height="60" fill="url(#bpGridSub)" />
              <path d="M 60 0 L 0 0 0 60" fill="none" stroke="#38bdf8" strokeWidth="0.8" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#bpGridMain)" />
        </svg>

        {/* Live Simulation HTML5 Canvas Layer */}
        {enableLiveSim && (
          <canvas
            ref={canvasRef}
            width={800}
            height={500}
            className="absolute inset-0 w-full h-full pointer-events-none z-10"
          />
        )}

        {/* Pure Inline Vector SVG Blueprint Drawing */}
        <svg
          viewBox="0 0 800 500"
          className="w-full h-full max-h-[500px] transition-transform duration-300 ease-out select-none"
          style={{
            transform: `scale(${zoomLevel}) rotate(${rotationAngle}deg)`,
          }}
        >
          <defs>
            {/* Gradients */}
            <linearGradient id="alumGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.35" />
              <stop offset="50%" stopColor="#0284c7" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#082f49" stopOpacity="0.8" />
            </linearGradient>

            <linearGradient id="steelGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#94a3b8" stopOpacity="0.8" />
              <stop offset="50%" stopColor="#475569" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#1e293b" stopOpacity="1" />
            </linearGradient>

            <radialGradient id="hotspotGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0" />
            </radialGradient>

            <radialGradient id="alertGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ef4444" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#ef4444" stopOpacity="0" />
            </radialGradient>

            {/* Marker arrows */}
            <marker id="cadDimArrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 2 L 10 5 L 0 8 z" fill="#38bdf8" />
            </marker>
          </defs>

          {/* Coordinate Indicator Top-Right */}
          <g transform="translate(730, 50)" className="font-mono">
            <circle cx="0" cy="0" r="26" fill="#051930" stroke="#0ea5e9" strokeWidth="1" />
            <line x1="0" y1="0" x2="18" y2="0" stroke="#ef4444" strokeWidth="2" />
            <text x="21" y="4" fill="#ef4444" fontSize="9" fontWeight="bold">X</text>
            <line x1="0" y1="0" x2="-12" y2="12" stroke="#22c55e" strokeWidth="2" />
            <text x="-21" y="20" fill="#22c55e" fontSize="9" fontWeight="bold">Y</text>
            <line x1="0" y1="0" x2="0" y2="-18" stroke="#38bdf8" strokeWidth="2" />
            <text x="-4" y="-21" fill="#38bdf8" fontSize="9" fontWeight="bold">Z</text>
          </g>

          {/* ISO 128 Engineering Title Block Bottom-Right */}
          <g transform="translate(540, 410)" className="font-mono">
            <rect x="0" y="0" width="240" height="75" fill="#041224" stroke="#0284c7" strokeWidth="1" rx="3" />
            <line x1="0" y1="24" x2="240" y2="24" stroke="#0284c7" strokeWidth="0.8" />
            <line x1="0" y1="48" x2="240" y2="48" stroke="#0284c7" strokeWidth="0.8" />
            <line x1="120" y1="24" x2="120" y2="75" stroke="#0284c7" strokeWidth="0.8" />

            <text x="8" y="16" fill="#38bdf8" fontSize="10" fontWeight="bold">
              AI CAD BLUEPRINT // ISO 128
            </text>
            <text x="8" y="38" fill="#94a3b8" fontSize="9">
              STEP: <tspan fill="#38bdf8" fontWeight="bold">{String(currentStepNum).padStart(2, '0')}/30</tspan>
            </text>
            <text x="128" y="38" fill="#94a3b8" fontSize="9">
              SCALE: <tspan fill="#cbd5e1">1:5 METRIC</tspan>
            </text>
            <text x="8" y="64" fill="#94a3b8" fontSize="9">
              TOL: <tspan fill="#4ade80">±0.012 mm</tspan>
            </text>
            <text x="128" y="64" fill="#94a3b8" fontSize="9">
              STATUS: <tspan fill="#38bdf8">CALIBRATED</tspan>
            </text>
          </g>

          {/* Subsystem Vector CAD Geometry */}
          {subsystem === 'base_frame' && (
            <g id="baseFrameSchematic">
              {/* Outer 4080 Extrusion Frame */}
              <polygon points="120,110 520,110 500,130 100,130" fill="#0c4a6e" stroke="#38bdf8" strokeWidth="1.5" />
              <polygon points="100,130 100,170 220,290 220,250" fill="url(#alumGrad)" stroke="#38bdf8" strokeWidth="1.8" />
              <polygon points="500,130 500,170 620,290 620,250" fill="url(#alumGrad)" stroke="#38bdf8" strokeWidth="1.8" />
              <polygon points="220,250 620,250 620,290 220,290" fill="#075985" stroke="#38bdf8" strokeWidth="2" />

              {/* T-Slots grooved lines */}
              <line x1="220" y1="270" x2="620" y2="270" stroke="#0284c7" strokeWidth="1.5" />
              <line x1="140" y1="180" x2="140" y2="220" stroke="#0284c7" strokeWidth="1.5" />
              <line x1="580" y1="180" x2="580" y2="220" stroke="#0284c7" strokeWidth="1.5" />

              {/* Intermediate Cross Rails */}
              <polygon points="270,190 490,190 480,205 260,205" fill="#0369a1" stroke="#38bdf8" strokeWidth="1" />
              <polygon points="330,220 530,220 520,235 320,235" fill="#0369a1" stroke="#38bdf8" strokeWidth="1" />

              {/* Dual MGN15 Linear Rails along side extrusions */}
              <g id="mgn15Rails">
                <path d="M 120,135 L 210,245 L 218,245 L 128,135 Z" fill="#94a3b8" stroke="#38bdf8" strokeWidth="1.2" />
                <path d="M 480,135 L 570,245 L 578,245 L 488,135 Z" fill="#94a3b8" stroke="#38bdf8" strokeWidth="1.2" />

                {/* Left Carriage Block */}
                <rect x="155" y="175" width="22" height="16" rx="2" fill="#0284c7" stroke="#38bdf8" strokeWidth="1.5" transform="rotate(35, 166, 183)" />
                {/* Right Carriage Block */}
                <rect x="525" y="175" width="22" height="16" rx="2" fill="#0284c7" stroke="#38bdf8" strokeWidth="1.5" transform="rotate(35, 536, 183)" />
              </g>

              {/* Leveling Feet with rubber pads */}
              <g transform="translate(220, 290)">
                <rect x="-6" y="0" width="12" height="18" fill="#475569" stroke="#94a3b8" strokeWidth="1" />
                <ellipse cx="0" cy="22" rx="14" ry="6" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" />
              </g>
              <g transform="translate(620, 290)">
                <rect x="-6" y="0" width="12" height="18" fill="#475569" stroke="#94a3b8" strokeWidth="1" />
                <ellipse cx="0" cy="22" rx="14" ry="6" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" />
              </g>
            </g>
          )}

          {subsystem === 'gantry' && (
            <g id="gantrySchematic">
              {/* Dual Y-Riser Plates */}
              <polygon points="180,120 220,120 250,290 190,290" fill="url(#alumGrad)" stroke="#38bdf8" strokeWidth="2" />
              <polygon points="580,120 620,120 610,290 550,290" fill="url(#alumGrad)" stroke="#38bdf8" strokeWidth="2" />

              {/* Main X-Axis Gantry Beam 80160 */}
              <rect x="210" y="120" width="380" height="60" rx="3" fill="#0c4a6e" stroke="#38bdf8" strokeWidth="2" />
              {/* Horizontal T-Slots */}
              <line x1="210" y1="135" x2="590" y2="135" stroke="#0284c7" strokeWidth="1.5" />
              <line x1="210" y1="150" x2="590" y2="150" stroke="#0284c7" strokeWidth="1.5" />
              <line x1="210" y1="165" x2="590" y2="165" stroke="#0284c7" strokeWidth="1.5" />

              {/* Dual Linear Guide Rails on Gantry Beam */}
              <rect x="220" y="126" width="360" height="6" fill="#94a3b8" stroke="#38bdf8" strokeWidth="1" />
              <rect x="220" y="168" width="360" height="6" fill="#94a3b8" stroke="#38bdf8" strokeWidth="1" />

              {/* SFU1605 Ball Screw Shaft */}
              <rect x="220" y="215" width="360" height="10" rx="2" fill="url(#steelGrad)" stroke="#38bdf8" strokeWidth="1.5" />
              {/* Ball Nut Housing in center */}
              <rect x="375" y="205" width="50" height="30" rx="4" fill="#0284c7" stroke="#38bdf8" strokeWidth="1.5" />
              <circle cx="400" cy="220" r="7" fill="#0c4a6e" stroke="#38bdf8" strokeWidth="1" />

              {/* NEMA 23 Motor on Right Riser */}
              <g transform="translate(620, 195)">
                <rect x="0" y="0" width="55" height="50" rx="4" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" />
                <rect x="5" y="10" width="45" height="30" fill="#1e293b" />
                <line x1="-12" y1="25" x2="0" y2="25" stroke="#94a3b8" strokeWidth="6" />
                {/* Flexible Plum Coupler */}
                <rect x="-24" y="17" width="16" height="16" rx="2" fill="#ef4444" stroke="#f87171" strokeWidth="1" />
              </g>
            </g>
          )}

          {subsystem === 'z_axis_spindle' && (
            <g id="spindleSchematic">
              {/* Z-Axis Backplate */}
              <rect x="310" y="100" width="180" height="240" rx="4" fill="#075985" stroke="#38bdf8" strokeWidth="2" />
              <rect x="325" y="115" width="150" height="210" fill="#0c4a6e" stroke="#0284c7" strokeWidth="1" />

              {/* Z-Axis Linear Rails */}
              <rect x="335" y="115" width="10" height="210" fill="#94a3b8" stroke="#38bdf8" strokeWidth="1" />
              <rect x="455" y="115" width="10" height="210" fill="#94a3b8" stroke="#38bdf8" strokeWidth="1" />

              {/* Z Carriage Plate */}
              <rect x="350" y="145" width="100" height="150" rx="3" fill="#0369a1" stroke="#38bdf8" strokeWidth="1.5" />

              {/* 80mm Spindle Cast Clamp */}
              <rect x="360" y="175" width="80" height="90" rx="5" fill="#1e293b" stroke="#38bdf8" strokeWidth="2" />
              {/* 4x Pinch Bolts */}
              <circle cx="368" cy="188" r="3.5" fill="#475569" stroke="#38bdf8" strokeWidth="1" />
              <circle cx="432" cy="188" r="3.5" fill="#475569" stroke="#38bdf8" strokeWidth="1" />
              <circle cx="368" cy="252" r="3.5" fill="#475569" stroke="#38bdf8" strokeWidth="1" />
              <circle cx="432" cy="252" r="3.5" fill="#475569" stroke="#38bdf8" strokeWidth="1" />

              {/* 2.2kW Cylindrical Spindle Body */}
              <rect x="375" y="130" width="50" height="190" rx="6" fill="url(#steelGrad)" stroke="#38bdf8" strokeWidth="2" />
              {/* Cooling fin grooves */}
              <line x1="375" y1="150" x2="425" y2="150" stroke="#0ea5e9" strokeWidth="1.2" />
              <line x1="375" y1="165" x2="425" y2="165" stroke="#0ea5e9" strokeWidth="1.2" />
              <line x1="375" y1="275" x2="425" y2="275" stroke="#0ea5e9" strokeWidth="1.2" />

              {/* ER20 Collet Nut & Tool */}
              <polygon points="380,320 420,320 415,340 385,340" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />
              {/* Carbide Endmill Tool Bit */}
              <rect x="397" y="340" width="6" height="35" fill="#cbd5e1" stroke="#38bdf8" strokeWidth="1" />

              {/* Water Cooling Barbs on top */}
              <rect x="382" y="118" width="8" height="12" fill="#0284c7" stroke="#38bdf8" strokeWidth="1" />
              <rect x="410" y="118" width="8" height="12" fill="#0284c7" stroke="#38bdf8" strokeWidth="1" />
            </g>
          )}

          {subsystem === 'electronics' && (
            <g id="electronicsSchematic">
              {/* Enclosure Box */}
              <rect x="180" y="100" width="440" height="280" rx="6" fill="#061426" stroke="#0284c7" strokeWidth="2" />
              <rect x="195" y="115" width="410" height="250" fill="#0b1e36" stroke="#0369a1" strokeWidth="1" strokeDasharray="3 3" />

              {/* DIN Rail */}
              <rect x="205" y="210" width="390" height="15" fill="#64748b" stroke="#94a3b8" strokeWidth="1" />

              {/* 3x DM542 Stepper Drivers */}
              {[220, 310, 400].map((dx, i) => (
                <g key={i} transform={`translate(${dx}, 170)`}>
                  <rect x="0" y="0" width="75" height="95" rx="3" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" />
                  <rect x="8" y="10" width="59" height="16" fill="#0284c7" rx="1" />
                  <text x="37" y="22" fill="#ffffff" fontSize="8" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                    DM542 {['X', 'Y', 'Z'][i]}
                  </text>
                  {/* DIP Switch Array */}
                  <rect x="12" y="35" width="51" height="12" fill="#1e293b" stroke="#475569" strokeWidth="0.8" />
                  <circle cx="20" cy="41" r="2" fill="#4ade80" />
                  <circle cx="28" cy="41" r="2" fill="#ef4444" />
                  <circle cx="36" cy="41" r="2" fill="#4ade80" />
                  <circle cx="44" cy="41" r="2" fill="#4ade80" />
                  {/* Status LEDs */}
                  <circle cx="20" cy="60" r="3" fill="#22c55e" stroke="#16a34a" strokeWidth="1" />
                  <circle cx="32" cy="60" r="3" fill="#1e293b" stroke="#475569" strokeWidth="1" />
                  {/* Terminal Block */}
                  <rect x="8" y="75" width="59" height="14" fill="#047857" stroke="#10b981" strokeWidth="1" />
                </g>
              ))}

              {/* 48V Power Supply on Right */}
              <g transform="translate(495, 170)">
                <rect x="0" y="0" width="95" height="95" rx="4" fill="#1e293b" stroke="#38bdf8" strokeWidth="1.5" />
                <rect x="10" y="10" width="75" height="40" fill="#0f172a" />
                <text x="47" y="34" fill="#38bdf8" fontSize="10" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  48V 10A PSU
                </text>
                {/* Perforated mesh lines */}
                <line x1="15" y1="58" x2="80" y2="58" stroke="#0284c7" strokeWidth="1" strokeDasharray="2 2" />
                <line x1="15" y1="64" x2="80" y2="64" stroke="#0284c7" strokeWidth="1" strokeDasharray="2 2" />
                {/* Terminal Block */}
                <rect x="10" y="75" width="75" height="14" fill="#0c4a6e" stroke="#38bdf8" strokeWidth="1" />
              </g>
            </g>
          )}

          {subsystem === 'assembled' && (
            <g id="assembledSchematic">
              {/* Full 3D Isometric View */}
              {/* Bed */}
              <polygon points="140,240 460,150 660,240 340,330" fill="#0c4a6e" stroke="#38bdf8" strokeWidth="2" />
              {/* Spoilboard T-slots */}
              <line x1="200" y1="255" x2="520" y2="165" stroke="#0284c7" strokeWidth="1.5" />
              <line x1="260" y1="270" x2="580" y2="180" stroke="#0284c7" strokeWidth="1.5" />

              {/* Gantry Arch */}
              <polygon points="260,140 290,140 300,280 270,280" fill="url(#alumGrad)" stroke="#38bdf8" strokeWidth="1.8" />
              <polygon points="510,140 540,140 530,280 500,280" fill="url(#alumGrad)" stroke="#38bdf8" strokeWidth="1.8" />
              <polygon points="280,135 520,135 520,175 280,175" fill="#075985" stroke="#38bdf8" strokeWidth="2" />

              {/* Spindle on Gantry */}
              <rect x="380" y="145" width="40" height="110" rx="4" fill="url(#steelGrad)" stroke="#38bdf8" strokeWidth="2" />
              <rect x="397" y="255" width="6" height="25" fill="#cbd5e1" stroke="#38bdf8" strokeWidth="1" />

              {/* Coordinate Work Zero Symbol on Bed */}
              <g transform="translate(240, 260)">
                <circle cx="0" cy="0" r="12" fill="none" stroke="#ef4444" strokeWidth="1.5" />
                <line x1="-16" y1="0" x2="16" y2="0" stroke="#ef4444" strokeWidth="1.5" />
                <line x1="0" y1="-16" x2="0" y2="16" stroke="#ef4444" strokeWidth="1.5" />
                <text x="6" y="-8" fill="#ef4444" fontSize="9" fontWeight="bold" fontFamily="monospace">G54 (WCS)</text>
              </g>
            </g>
          )}

          {/* Dimension Lines Layer */}
          {(activeLayer === 'all' || activeLayer === 'dimensions') && (
            <g id="dimensionLayer" className="font-mono text-cyan-300">
              {subsystem === 'base_frame' && (
                <>
                  <line x1="220" y1="310" x2="620" y2="310" stroke="#38bdf8" strokeWidth="1" markerStart="url(#cadDimArrow)" markerEnd="url(#cadDimArrow)" />
                  <text x="420" y="325" fill="#38bdf8" fontSize="10" textAnchor="middle">WIDTH: 650.00 mm ±0.1</text>
                  <line x1="80" y1="130" x2="200" y2="290" stroke="#38bdf8" strokeWidth="1" markerStart="url(#cadDimArrow)" markerEnd="url(#cadDimArrow)" />
                  <text x="110" y="225" fill="#38bdf8" fontSize="10" transform="rotate(53, 110, 225)">LENGTH: 1500.00 mm</text>
                </>
              )}
              {subsystem === 'gantry' && (
                <>
                  <line x1="210" y1="105" x2="590" y2="105" stroke="#38bdf8" strokeWidth="1" markerStart="url(#cadDimArrow)" markerEnd="url(#cadDimArrow)" />
                  <text x="400" y="100" fill="#38bdf8" fontSize="10" textAnchor="middle">SPAN: 780.00 mm</text>
                  <line x1="220" y1="245" x2="580" y2="245" stroke="#38bdf8" strokeWidth="1" markerStart="url(#cadDimArrow)" markerEnd="url(#cadDimArrow)" />
                  <text x="400" y="260" fill="#38bdf8" fontSize="10" textAnchor="middle">LEAD PITCH: 5.00 mm</text>
                </>
              )}
              {subsystem === 'z_axis_spindle' && (
                <>
                  <line x1="300" y1="130" x2="300" y2="320" stroke="#38bdf8" strokeWidth="1" markerStart="url(#cadDimArrow)" markerEnd="url(#cadDimArrow)" />
                  <text x="290" y="230" fill="#38bdf8" fontSize="10" textAnchor="middle" transform="rotate(-90, 290, 230)">STROKE: 150.00 mm</text>
                  <line x1="375" y1="310" x2="425" y2="310" stroke="#38bdf8" strokeWidth="1" markerStart="url(#cadDimArrow)" markerEnd="url(#cadDimArrow)" />
                  <text x="400" y="305" fill="#38bdf8" fontSize="9" textAnchor="middle">Ø 80 mm</text>
                </>
              )}
            </g>
          )}

          {/* Fastener / Torque Specifications Layer */}
          {(activeLayer === 'all' || activeLayer === 'fasteners') && (
            <g id="fastenersLayer" className="font-mono">
              {subsystem === 'base_frame' && (
                <g transform="translate(190, 235)">
                  <rect x="-4" y="-12" width="90" height="18" fill="#041b33" stroke="#0ea5e9" strokeWidth="0.8" rx="2" />
                  <text x="2" y="1" fill="#4ade80" fontSize="9" fontWeight="bold">M5: 6.8 N·m</text>
                </g>
              )}
              {subsystem === 'gantry' && (
                <g transform="translate(620, 155)">
                  <rect x="-4" y="-12" width="94" height="18" fill="#041b33" stroke="#0ea5e9" strokeWidth="0.8" rx="2" />
                  <text x="2" y="1" fill="#4ade80" fontSize="9" fontWeight="bold">M4: 3.5 N·m</text>
                </g>
              )}
              {subsystem === 'z_axis_spindle' && (
                <g transform="translate(435, 175)">
                  <rect x="-4" y="-12" width="100" height="18" fill="#041b33" stroke="#0ea5e9" strokeWidth="0.8" rx="2" />
                  <text x="2" y="1" fill="#4ade80" fontSize="9" fontWeight="bold">M8: 18.0 N·m</text>
                </g>
              )}
            </g>
          )}

          {/* Interactive Inspection Hotspots Layer */}
          {(activeLayer === 'all' || activeLayer === 'hotspots') && interactive && (
            <g id="interactiveHotspots">
              {currentHotspots.map((h) => {
                const isSelected = selectedHotspot?.id === h.id;
                const isAlert = h.status === 'critical' || h.status === 'warning';
                return (
                  <g
                    key={h.id}
                    transform={`translate(${h.x}, ${h.y})`}
                    onClick={() => handleHotspotClick(h)}
                    className="cursor-pointer group"
                  >
                    {/* Pulsing halo */}
                    <circle
                      cx="0"
                      cy="0"
                      r={isSelected ? 20 : 14}
                      fill={isAlert ? 'url(#alertGlow)' : 'url(#hotspotGlow)'}
                      className="animate-ping opacity-75"
                    />
                    {/* Ring */}
                    <circle
                      cx="0"
                      cy="0"
                      r="12"
                      fill="#021427"
                      stroke={isAlert ? '#ef4444' : '#06b6d4'}
                      strokeWidth={isSelected ? '2.5' : '1.8'}
                    />
                    {/* Center indicator */}
                    <circle
                      cx="0"
                      cy="0"
                      r="4"
                      fill={isAlert ? '#ef4444' : '#38bdf8'}
                    />
                    {/* Hotspot Label Tag */}
                    <g transform="translate(16, -8)">
                      <rect
                        x="0"
                        y="0"
                        width={Math.max(h.nameEn.length * 6 + 16, 90)}
                        height="20"
                        rx="3"
                        fill="#051930"
                        stroke={isSelected ? '#38bdf8' : isAlert ? '#ef4444' : '#0369a1'}
                        strokeWidth="1"
                      />
                      <text
                        x="6"
                        y="14"
                        fill={isAlert ? '#fca5a5' : '#7dd3fc'}
                        fontSize="9"
                        fontFamily="monospace"
                        fontWeight="bold"
                      >
                        {h.nameEn}
                      </text>
                    </g>
                  </g>
                );
              })}
            </g>
          )}

          {/* Watermark Blueprint Stamp */}
          <g transform="translate(30, 470)" className="font-mono text-[9px]">
            <text x="0" y="0" fill="#0369a1" letterSpacing="2">
              CNC-ROUTER-ENGINEERING-CAD-STUDIO // VERIFIED ACCORDING TO DIN ISO 2768-m
            </text>
          </g>
        </svg>

        {/* Custom Overlay Banner (if provided) */}
        {customOverlayText && (
          <div className="absolute top-12 left-4 bg-slate-900/90 border border-cyan-500/70 text-cyan-200 px-3 py-1.5 rounded-lg text-xs font-mono backdrop-blur shadow-lg flex items-center gap-2">
            <Target className="w-3.5 h-3.5 text-cyan-400" />
            <span>{customOverlayText}</span>
          </div>
        )}

        {/* Selected Hotspot Inspection Drawer / Tooltip */}
        {selectedHotspot && (
          <div className="absolute bottom-3 left-3 right-3 sm:right-auto sm:max-w-md bg-slate-950/95 border border-cyan-500/80 rounded-xl p-3 shadow-2xl backdrop-blur text-xs z-20 space-y-2 animate-in fade-in slide-in-from-bottom-2 duration-200">
            <div className="flex items-center justify-between border-b border-cyan-900/60 pb-1.5">
              <div className="flex items-center gap-1.5">
                {selectedHotspot.status === 'critical' ? (
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                ) : selectedHotspot.status === 'warning' ? (
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                )}
                <div>
                  <h4 className="font-bold text-cyan-300 font-mono text-xs">
                    {selectedHotspot.nameEn}
                  </h4>
                  <p className="text-[11px] text-slate-400 font-sans">
                    {selectedHotspot.nameUr}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setSelectedHotspot(null)}
                className="text-slate-400 hover:text-slate-200 p-1 text-sm font-mono"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono bg-slate-900/80 p-2 rounded-lg border border-slate-800">
              <div>
                <span className="text-slate-500 block">TOLERANCE:</span>
                <span className="text-emerald-300 font-semibold">{selectedHotspot.tolerance}</span>
              </div>
              <div>
                <span className="text-slate-500 block">TORQUE:</span>
                <span className="text-amber-300 font-semibold">{selectedHotspot.torque}</span>
              </div>
            </div>

            <div className="text-[11px] space-y-1">
              <p className="text-slate-300 font-sans leading-relaxed">
                <span className="text-cyan-400 font-bold font-mono">اصلاحی طریقہ: </span>
                {selectedHotspot.remedyUr}
              </p>
              <p className="text-slate-400 font-mono text-[10px]">
                {selectedHotspot.remedyEn}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Status Ticker Bar */}
      <div className="px-3 py-1.5 bg-slate-950/95 border-t border-cyan-950 text-[11px] font-mono flex flex-wrap items-center justify-between text-slate-400 select-none">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 text-emerald-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            PURE SVG VECTORS (NO 404 / 100% OFFLINE)
          </span>
          <span className="hidden sm:inline text-slate-600">•</span>
          <span className="hidden sm:inline text-slate-400">
            HOTSPOTS: {currentHotspots.length} INSPECTABLE
          </span>
        </div>

        <div className="flex items-center gap-2 text-slate-500">
          <span>ZOOM: {Math.round(zoomLevel * 100)}%</span>
          <span>•</span>
          <span className="text-cyan-400">PRECISION: DIN 2768-m</span>
        </div>
      </div>
    </div>
  );
};
