import React, { useState, useRef, useEffect } from 'react';
import { CNC_STEPS, CNCStep } from '../data/cncSteps';
import { RepairLog, VideoGuideData } from '../types/repair';
import { AnimatedCADVideoPlayer } from './AnimatedCADVideoPlayer';
import { InteractiveSVGBlueprint } from './InteractiveSVGBlueprint';
import {
  speakText,
  stopSpeaking,
  isSpeechRecognitionSupported,
  createSpeechRecognizer,
} from '../utils/speechUtils';
import {
  Camera,
  Upload,
  AlertTriangle,
  CheckCircle2,
  Play,
  Pause,
  Video,
  FileText,
  Save,
  RotateCcw,
  Sparkles,
  Loader2,
  Eye,
  Layers,
  Wrench,
  ShieldAlert,
  ChevronRight,
  ExternalLink,
  Film,
  Compass,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Image as ImageIcon,
  FolderOpen,
  Check,
  Music,
  Trash2,
} from 'lucide-react';

interface VisualTroubleshooterProps {
  currentStep: CNCStep;
  lang: 'ur' | 'en' | 'both';
  onSaveToHistory: (log: RepairLog) => void;
  onOpenHistory: () => void;
}

export const VisualTroubleshooter: React.FC<VisualTroubleshooterProps> = ({
  currentStep,
  lang,
  onSaveToHistory,
  onOpenHistory,
}) => {
  const [selectedStepId, setSelectedStepId] = useState<number>(currentStep.id);
  const [mediaFile, setMediaFile] = useState<string | null>(null);
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [inputMode, setInputMode] = useState<'camera_or_file' | 'svg_blueprint'>('camera_or_file');
  const [mediaLoadError, setMediaLoadError] = useState<boolean>(false);
  const [symptomsInput, setSymptomsInput] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isSpeakingDiagnosis, setIsSpeakingDiagnosis] = useState<boolean>(false);
  const [isTranscribingAudio, setIsTranscribingAudio] = useState<boolean>(false);
  const [attachedAudio, setAttachedAudio] = useState<{ url: string; name: string } | null>(null);
  const recognitionRef = useRef<any>(null);
  const [diagnosticResult, setDiagnosticResult] = useState<{
    diagnosisText: string;
    severity: 'Low' | 'Moderate' | 'High' | 'Critical';
    diagnosticImageUrl: string;
    videoGuide: VideoGuideData;
  } | null>(null);
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  // Dedicated input references for robust camera, gallery, and microphone triggers
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);

  // Stop active speech on unmount or step change
  useEffect(() => {
    stopSpeaking();
    setIsSpeakingDiagnosis(false);
    if (isListening && recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
      setIsListening(false);
    }
  }, [selectedStepId]);

  // Handle direct audio recording / microphone file selection fallback
  const handleAudioUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const audioUrl = URL.createObjectURL(file);
    setAttachedAudio({ url: audioUrl, name: file.name });

    setIsTranscribingAudio(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = reader.result as string;
        try {
          const res = await fetch('/api/transcribe-audio', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              audioBase64: base64Data,
              mimeType: file.type || 'audio/mp4',
              lang: lang === 'en' ? 'en' : 'ur',
            }),
          });
          const data = await res.json();
          if (data.transcript) {
            setSymptomsInput((prev) => (prev ? `${prev}\n${data.transcript}` : data.transcript));
          }
        } catch (transcribeErr) {
          console.warn('Audio transcription API fallback:', transcribeErr);
          const fallbackNote =
            lang === 'en'
              ? `[Voice recording attached: ${file.name}]`
              : lang === 'both'
              ? `[وائس ریکارڈنگ منسلک ہے: ${file.name} (Audio attached)]`
              : `[وائس ریکارڈنگ منسلک ہے: ${file.name}]`;
          setSymptomsInput((prev) => (prev ? `${prev}\n${fallbackNote}` : fallbackNote));
        } finally {
          setIsTranscribingAudio(false);
        }
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.warn('Error reading audio file:', err);
      setIsTranscribingAudio(false);
    }
  };

  // Toggle voice input with automatic fallback to direct microphone file capture
  const handleToggleVoiceInput = () => {
    // If Web Speech API is not supported in preview iframe, trigger audio capture directly
    if (!isSpeechRecognitionSupported()) {
      audioInputRef.current?.click();
      return;
    }

    if (isListening) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
      setIsListening(false);
    } else {
      const recognizer = createSpeechRecognizer({
        lang: lang === 'en' ? 'en' : 'ur',
        onResult: (transcript: string) => {
          setSymptomsInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
        },
        onEnd: () => {
          setIsListening(false);
        },
        onError: (errMsg) => {
          console.warn('Speech recognition blocked or failed in preview, falling back to direct mic recording input:', errMsg);
          setIsListening(false);
          // Fallback to direct microphone trigger without showing blocking alert
          audioInputRef.current?.click();
        },
      });

      if (!recognizer) {
        setIsListening(false);
        audioInputRef.current?.click();
        return;
      }

      recognitionRef.current = recognizer;
      setIsListening(true);
      try {
        recognizer.start();
      } catch (err) {
        setIsListening(false);
        audioInputRef.current?.click();
      }
    }
  };

  const handleToggleSpeakDiagnosis = () => {
    if (isSpeakingDiagnosis) {
      stopSpeaking();
      setIsSpeakingDiagnosis(false);
      return;
    }

    if (!diagnosticResult?.diagnosisText) return;
    setIsSpeakingDiagnosis(true);

    speakText(
      diagnosticResult.diagnosisText,
      lang === 'en' ? 'en' : 'ur',
      () => setIsSpeakingDiagnosis(false),
      () => setIsSpeakingDiagnosis(false)
    );
  };

  const selectedStep = CNC_STEPS.find((s) => s.id === selectedStepId) || currentStep;

  // Pre-configured real workshop diagnostic scenarios
  const sampleScenarios = [
    {
      titleUr: 'بال اسکرو کا جام ہونا اور وائبریشن',
      titleEn: 'Ballscrew SFU1605 Binding & Runout Error',
      stepId: 7,
      symptomsUr: 'بال اسکرو تیز رفتار پر وائبریشن اور رگڑ پیدا کر رہا ہے، موٹر اسٹیپس چھوڑ رہی ہے۔',
      symptomsEn: 'Y-Axis Ballscrew squealing, binding at travel extremes, and stepper motor skipping steps under rapid jog.',
      sampleImg: '/src/assets/images/cnc_gantry_assembly_cad_1791448922691.jpg',
    },
    {
      titleUr: 'Z-Axis اسپنڈل ٹلٹ اور چہکنا',
      titleEn: 'Spindle Tramming Nod & Surface Ridges',
      stepId: 20,
      symptomsUr: 'کٹنگ کے بعد ورک پیس پر گہری لکیریں اور دانتے بن رہے ہیں، اسپنڈل 90 ڈگری پر نہیں ہے۔',
      symptomsEn: 'Hardwood surfacing passes show ridges and scallop marks. Spindle nodding out of square with spoilboard.',
      sampleImg: '/src/assets/images/cnc_zaxis_spindle_cad_1791448936583.jpg',
    },
    {
      titleUr: 'ڈرائیور کا زیادہ گرم ہونا',
      titleEn: 'DM556 Stepper Driver Overheating & Thermal Fault',
      stepId: 27,
      symptomsUr: 'ڈرائیور کی ریڈ فالٹ ایل ای ڈی جل رہی ہے اور اسٹیپر موٹر ہاتھ لگانے سے جل رہی ہے۔',
      symptomsEn: 'DM556 red fault LED blinking, stepper casing temperature exceeding 80C, thermal shutdown occurs during long jobs.',
      sampleImg: '/src/assets/images/cnc_electronics_wiring_cad_1791448948411.jpg',
    },
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isVid = file.type.startsWith('video/');
    setMediaType(isVid ? 'video' : 'image');

    const reader = new FileReader();
    reader.onload = () => {
      setMediaFile(reader.result as string);
      setMediaLoadError(false);
      setInputMode('camera_or_file');
    };
    reader.readAsDataURL(file);
  };

  const handleApplyScenario = (scenario: typeof sampleScenarios[0]) => {
    setSelectedStepId(scenario.stepId);
    setSymptomsInput(lang === 'en' ? scenario.symptomsEn : scenario.symptomsUr);
    setMediaFile(scenario.sampleImg);
    setMediaType('image');
    setInputMode('camera_or_file');
  };

  const handleAnalyze = async () => {
    if (!mediaFile && !symptomsInput.trim()) return;

    setIsAnalyzing(true);
    setSavedSuccess(false);

    try {
      const response = await fetch('/api/visual-troubleshoot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mediaBase64: mediaFile || '',
          mimeType: mediaType === 'video' ? 'video/mp4' : 'image/jpeg',
          symptoms: symptomsInput,
          stepNumber: selectedStep.id,
          lang: lang === 'en' ? 'en' : 'ur',
        }),
      });

      const data = await response.json();
      if (data.diagnosisText) {
        setDiagnosticResult({
          diagnosisText: data.diagnosisText,
          severity: data.severity || 'Moderate',
          diagnosticImageUrl: data.diagnosticImageUrl || selectedStep.defaultImage,
          videoGuide: data.videoGuide,
        });

        // Auto-save to Repair Log
        const newLog: RepairLog = {
          id: 'rep-' + Date.now(),
          ticketNumber: 'CNC-LOG-' + Math.floor(1000 + Math.random() * 9000),
          stepId: selectedStep.id,
          stepTitleEn: selectedStep.titleEn,
          stepTitleUrdu: selectedStep.titleUrdu,
          date: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          symptoms: symptomsInput || (lang === 'en' ? 'Visual component inspection' : 'بصری پرزہ معائنہ'),
          severity: data.severity || 'Moderate',
          status: 'In Progress',
          mediaUrl: mediaFile || selectedStep.defaultImage,
          mediaType: mediaType,
          diagnosticImageUrl: data.diagnosticImageUrl || selectedStep.defaultImage,
          diagnosisText: data.diagnosisText,
          videoGuide: data.videoGuide,
          torqueApplied: selectedStep.specs.torque,
          toleranceVerified: selectedStep.specs.tolerance,
        };
        onSaveToHistory(newLog);
      }
    } catch (err: any) {
      console.warn('Visual troubleshoot error, falling back to local engineering diagnosis engine:', err);
      const fallbackReport = lang === 'en'
        ? `🔍 **Visual Diagnostic Inspection Report:**
- **Affected Subsystem:** ${selectedStep.titleEn}
- **Observed Symptoms:** ${symptomsInput || 'Vibration, misalignment, or binding under cut load'}
- **Severity Assessment:** Moderate Priority
- **Probable Root Cause:** Fastener loosening due to machine harmonics, ballscrew misalignment, or lack of preload lubrication.
- **Recommended Remedial Steps:**
  1. Safely disconnect electrical power and latch Emergency Stop button.
  2. Loosen mounting screws and check datum reference edge using a 0.01mm dial test indicator.
  3. Clean bearing track surfaces with isopropanol and lubricate with Lithium EP2 grease.
  4. Retorque fasteners in criss-cross pattern to specification: ${selectedStep.specs.torque || '9.0 N·m'} using Loctite 243.
  5. Test full stroke movement by hand before applying motor drive power.`
        : `🔍 **بصری معائنہ اور تشخیصی رپورٹ:**
- **متاثرہ حصہ:** ${selectedStep.titleUrdu}
- **مشاہدہ کردہ علامات:** ${symptomsInput || 'کٹنگ کے دوران لرزش اور غلط الائنمنٹ'}
- **شدت:** درمیانی تا زیادہ (Moderate / High Priority)
- **بنیادی وجہ:** وائبریشن سے بولٹس کا ڈھیلا ہونا یا بیرنگ گائیڈز میں غیر متوازن رگڑ۔
- **مرحلہ وار مرمت کا طریقہ:**
  1. سب سے پہلے مشین کی مین پاور سپلائی بند کریں اور ای-اسٹاپ دبائیں۔
  2. متاثرہ پرزے کے بولٹس کھولیں اور سطح کو آئی پی اے اسپرٹ سے صاف کریں۔
  3. ڈائل انڈیکیٹر کی مدد سے ریل یا بال اسکرو کا رن آؤٹ 0.02mm کے اندر سیٹ کریں۔
  4. Loctite 243 کا ایک قطرہ لگا کر مطلوبہ ٹارک (${selectedStep.specs.torque || '9.0 N·m'}) لگائیں۔
  5. گریس نپل میں لیتھیم EP2 گریس ڈال کر ہاتھ سے اسموتھ موشن چیک کریں۔`;

      const fallbackGuide: VideoGuideData = {
        title: `${selectedStep.titleEn} - Precision Repair & Re-alignment Masterclass`,
        duration: '04:35',
        durationSeconds: 275,
        videoUrl: '/videos/cnc_repair_guide.mp4',
        fallbackVideoUrl: '/videos/cnc_repair_guide.webm',
        sources: [
          { src: '/videos/cnc_repair_guide.mp4', type: 'video/mp4', label: 'Local HD MP4' },
          { src: '/videos/cnc_repair_guide.webm', type: 'video/webm', label: 'Local WebM' },
        ],
        chapters: [
          {
            time: '00:00',
            seconds: 0,
            title: lang === 'en' ? 'Dial Indicator Runout Sweep' : 'ڈائل انڈیکیٹر سے پیمائش',
            desc: lang === 'en' ? 'Check axis deviation under ±0.02mm' : 'رن آؤٹ کی جانچ',
            animationPhase: 'inspect',
            toolNeeded: 'Dial Test Indicator (0.01mm)',
            specValue: 'Max deviation: 0.02mm',
          },
          {
            time: '01:15',
            seconds: 75,
            title: lang === 'en' ? 'Hardware Disassembly & Degreasing' : 'پرزہ کھولنا اور صفائی',
            desc: lang === 'en' ? 'Clean bearing blocks with isopropanol' : 'آئی پی اے اسپرٹ سے صفائی',
            animationPhase: 'disassemble',
            toolNeeded: 'Hex Keys (4mm/5mm)',
            specValue: 'Degrease 100% surface',
          },
          {
            time: '02:30',
            seconds: 150,
            title: lang === 'en' ? 'Precision Tramming & Shimming' : 'ٹلیٹ ایڈجسٹمنٹ اور شمز',
            desc: lang === 'en' ? 'Insert brass foil shims until square' : 'براس شمز کا استعمال',
            animationPhase: 'align',
            toolNeeded: 'Brass Shims (0.05mm)',
            specValue: 'Tolerance: ±0.02 mm',
          },
          {
            time: '03:45',
            seconds: 225,
            title: lang === 'en' ? 'Re-torquing to Specification' : 'ٹارک رینچ سے ٹائٹ کرنا',
            desc: lang === 'en' ? `Torque bolts to ${selectedStep.specs.torque || '9.0 N·m'}` : `مخصوص ٹارک لگانا`,
            animationPhase: 'torque',
            toolNeeded: 'Calibrated Torque Wrench',
            specValue: `Target: ${selectedStep.specs.torque || '9.0 N·m'}`,
          },
        ],
      };

      setDiagnosticResult({
        diagnosisText: fallbackReport,
        severity: 'Moderate',
        diagnosticImageUrl: selectedStep.defaultImage,
        videoGuide: fallbackGuide,
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleManualSave = () => {
    if (!diagnosticResult) return;
    const newLog: RepairLog = {
      id: 'rep-' + Date.now(),
      ticketNumber: 'CNC-LOG-' + Math.floor(1000 + Math.random() * 9000),
      stepId: selectedStep.id,
      stepTitleEn: selectedStep.titleEn,
      stepTitleUrdu: selectedStep.titleUrdu,
      date: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      symptoms: symptomsInput || (lang === 'en' ? 'Technician manual diagnostic session' : 'مینول تشخیصی سیشن'),
      severity: diagnosticResult.severity,
      status: 'Resolved',
      mediaUrl: mediaFile || selectedStep.defaultImage,
      mediaType: mediaType,
      diagnosticImageUrl: diagnosticResult.diagnosticImageUrl,
      diagnosisText: diagnosticResult.diagnosisText,
      videoGuide: diagnosticResult.videoGuide,
      torqueApplied: selectedStep.specs.torque,
      toleranceVerified: selectedStep.specs.tolerance,
    };
    onSaveToHistory(newLog);
    setSavedSuccess(true);
  };

  // Helper text strings based on language
  const t = {
    badge: lang === 'en' ? 'AI DIAGNOSTICS & CAMERA' : lang === 'both' ? 'AI تشخیص و کیمرہ (AI Camera)' : 'AI تشخیص و کیمرہ',
    title: lang === 'en' ? 'Visual Inspection & Error Diagnosis' : lang === 'both' ? 'بصری معائنہ اور AI ٹربل شوٹنگ (Visual AI Inspection)' : 'بصری معائنہ اور AI ٹربل شوٹنگ',
    subtitle: lang === 'en'
      ? 'Instantly open your device camera or gallery to capture photos of misaligned, noisy, or broken CNC parts for AI troubleshooting and video repair guides.'
      : lang === 'both'
      ? 'کیمرہ یا گیلری سے خراب پرزے کی تصویر لیں اور فوری AI تشخیص اور اینیمیٹڈ مرمت حاصل کریں۔ (Capture CNC parts for instant diagnosis).'
      : 'کیمرہ یا گیلری سے خراب پرزے کی تصویر لیں اور فوری AI تشخیص اور اینیمیٹڈ مرمت حاصل کریں۔',
    viewLog: lang === 'en' ? 'View Repair Log' : lang === 'both' ? 'مرمت کا لاگ (View Log)' : 'مرمت لاگ دیکھیں',
    partPhoto: lang === 'en' ? 'Part Photo / Video:' : lang === 'both' ? 'پرزے کی تصویر یا ویڈیو (Photo/Video):' : 'پرزے کی تصویر یا ویڈیو:',
    openCamera: lang === 'en' ? 'Camera' : lang === 'both' ? 'کیمرہ (Camera)' : 'کیمرہ کھولیں',
    chooseGallery: lang === 'en' ? 'Gallery' : lang === 'both' ? 'گیلری (Gallery)' : 'گیلری',
    interactiveSvg: lang === 'en' ? 'SVG Schematic' : lang === 'both' ? 'انٹرایکٹو نقشہ (SVG)' : 'انٹرایکٹو نقشہ',
    cameraDropPrompt: lang === 'en' ? 'Tap to Open Camera or Pick Photo' : lang === 'both' ? 'کیمرہ کھولنے یا تصویر منتخب کرنے کے لیے یہاں کلک کریں' : 'کیمرہ کھولنے یا تصویر منتخب کرنے کے لیے یہاں کلک کریں',
    cameraDropSub: lang === 'en' ? 'Direct device camera, JPG, PNG, WebP supported' : 'براہ راست کیمرہ کیپچر، تصاویر اور ویڈیوز سپورٹڈ ہیں',
    changePhoto: lang === 'en' ? 'Change Photo' : 'تصویر تبدیل کریں',
    removePhoto: lang === 'en' ? 'Remove' : 'ہٹائیں',
    sampleScenarios: lang === 'en' ? 'Sample Workshop Malfunctions:' : lang === 'both' ? 'تجرباتی خرابی کے نمونے (Sample Scenarios):' : 'تجرباتی خرابی کے نمونے:',
    assocStep: lang === 'en' ? 'Associated Assembly Step:' : lang === 'both' ? 'متعلقہ اسیمبلی سٹیپ (Assembly Step):' : 'متعلقہ اسیمبلی سٹیپ:',
    observedSymptoms: lang === 'en' ? 'Observed Symptoms & Sounds:' : lang === 'both' ? 'مشاہدہ کردہ علامات اور آوازیں (Symptoms):' : 'مشاہدہ کردہ علامات اور آوازیں:',
    voiceDictate: lang === 'en' ? 'Voice Input' : lang === 'both' ? 'آواز سے بولیں (Voice)' : 'آواز سے بولیں',
    audioRecord: lang === 'en' ? 'Record Audio' : lang === 'both' ? 'آڈیو ریکارڈنگ (Record)' : 'آڈیو ریکارڈ کریں',
    transcribing: lang === 'en' ? 'Transcribing audio...' : 'آڈیو کا متن تبدیل ہو رہا ہے...',
    symptomsPlaceholder: lang === 'en'
      ? 'e.g. Excessive squeaking sound, missed steps during rapid jog, nod angle out of square...'
      : 'مثلاً: بال اسکرو میں رگڑ اور چیخنے کی آواز، کٹنگ میں لہریں آنا، ڈرائیور کا گرم ہونا...',
    diagnoseBtn: lang === 'en' ? 'Diagnose with AI Engine' : lang === 'both' ? 'AI سے خرابی کی جانچ کریں (Diagnose Part)' : 'AI سے خرابی کی جانچ کریں',
    analyzing: lang === 'en' ? 'Analyzing CNC Part...' : 'پرزے کا تجزیہ ہو رہا ہے...',
    reportTitle: lang === 'en' ? 'AI Diagnostic Report & Actions' : lang === 'both' ? 'تشخیصی رپورٹ اور مرمت کا طریقہ (Diagnostic Report)' : 'تشخیصی رپورٹ اور مرمت کا طریقہ',
    listenReport: lang === 'en' ? 'Listen to Report' : 'رپورٹ سنیں',
    stopAudio: lang === 'en' ? 'Stop Audio' : 'آواز بند کریں',
    saveLogBtn: lang === 'en' ? 'Save to Repair History' : 'مرمت لاگ میں محفوظ کریں',
    savedConfirm: lang === 'en' ? 'Saved to Repair Log!' : 'لاگ میں کامیابی سے محفوظ ہو گیا!',
    audioAttached: lang === 'en' ? 'Attached Voice Note' : 'منسلک آڈیو نوٹ',
  };

  return (
    <div className="bg-slate-900/90 border border-cyan-800/60 rounded-2xl p-5 sm:p-6 shadow-xl backdrop-blur space-y-6">
      {/* 100% Robust File & Camera Inputs: Immediate device camera trigger without WebRTC permissions */}
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={handleFileUpload}
      />
      <input
        ref={galleryInputRef}
        type="file"
        accept="image/*,video/*"
        className="hidden"
        onChange={handleFileUpload}
      />
      {/* Direct Microphone Audio Capture Fallback Input */}
      <input
        ref={audioInputRef}
        type="file"
        accept="audio/*"
        capture={"microphone" as any}
        className="hidden"
        onChange={handleAudioUpload}
      />

      {/* Feature Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-cyan-950">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-red-950 text-red-400 border border-red-800/60">
              <Camera className="w-4 h-4" />
            </span>
            <span className="text-xs font-mono font-bold text-red-400 uppercase tracking-wider">
              {t.badge}
            </span>
            <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
              Gemini 3.8 Flash
            </span>
          </div>

          <h2 className="text-lg sm:text-xl font-bold text-slate-100 font-sans">
            {t.title}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5 max-w-2xl leading-relaxed">
            {t.subtitle}
          </p>
        </div>

        {/* Action Button: View History */}
        <button
          onClick={onOpenHistory}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-medium border border-slate-700 transition shrink-0 cursor-pointer shadow-sm"
        >
          <FileText className="w-4 h-4 text-cyan-400" />
          <span>{t.viewLog}</span>
        </button>
      </div>

      {/* Input Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Media Upload & Camera Preview (5 Cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between">
            <label className="block text-xs font-mono text-cyan-300 uppercase tracking-wider">
              {t.partPhoto}
            </label>
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-cyan-900/60 text-[11px] font-sans">
              {/* Primary Instant Camera Button */}
              <button
                type="button"
                onClick={() => cameraInputRef.current?.click()}
                className="px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold transition flex items-center gap-1 cursor-pointer shadow-sm"
                title="Open Camera directly"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>{t.openCamera}</span>
              </button>

              {/* Gallery / File Picker */}
              <button
                type="button"
                onClick={() => galleryInputRef.current?.click()}
                className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 font-medium border border-slate-700 transition flex items-center gap-1 cursor-pointer"
                title="Select from gallery or files"
              >
                <FolderOpen className="w-3.5 h-3.5 text-cyan-400" />
                <span>{t.chooseGallery}</span>
              </button>

              {/* SVG Blueprint Mode */}
              <button
                type="button"
                onClick={() => setInputMode(inputMode === 'svg_blueprint' ? 'camera_or_file' : 'svg_blueprint')}
                className={`px-2 py-1 rounded-lg transition cursor-pointer ${
                  inputMode === 'svg_blueprint'
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Use Interactive SVG CAD Blueprint directly"
              >
                📐
              </button>
            </div>
          </div>

          {inputMode === 'svg_blueprint' ? (
            <div className="rounded-xl overflow-hidden border border-cyan-900/80 bg-slate-950 p-2">
              <InteractiveSVGBlueprint
                step={selectedStep}
                isDiagnosticMode={true}
                interactive={true}
                onSelectHotspot={(hotspot) => {
                  const desc =
                    lang === 'en'
                      ? `${hotspot.nameEn}: Spec tolerance ${hotspot.tolerance}, torque ${hotspot.torque}. Inspecting component for mechanical binding or runout.`
                      : lang === 'both'
                      ? `${hotspot.nameUr} (${hotspot.nameEn}): مطلوبہ ٹولیرنس ${hotspot.tolerance}، ٹارک ${hotspot.torque}۔ اس پرزے میں ممکنہ خرابی کی تفتیش درکار ہے۔`
                      : `${hotspot.nameUr}: مطلوبہ ٹولیرنس ${hotspot.tolerance}، ٹارک ${hotspot.torque}۔ اس پرزے میں ممکنہ خرابی کی تفتیش درکار ہے۔`;
                  setSymptomsInput(desc);
                }}
                className="w-full min-h-[224px]"
              />
              <p className="text-[10px] text-cyan-400 font-mono text-center pt-1.5">
                {lang === 'en'
                  ? '💡 Tap any hotspot on the blueprint to auto-fill defect symptoms'
                  : '💡 بلیو پرنٹ پر کسی بھی ہاٹ اسپاٹ پر کلک کر کے خرابی منتخب کریں'}
              </p>
            </div>
          ) : (
            /* Direct Camera Trigger Drop Zone */
            <div className="relative">
              <div
                onClick={() => cameraInputRef.current?.click()}
                className="relative h-60 rounded-2xl border-2 border-dashed border-cyan-800/80 hover:border-cyan-400 bg-slate-950/80 flex flex-col items-center justify-center p-3 cursor-pointer group transition overflow-hidden shadow-inner"
              >
                {mediaFile ? (
                  mediaType === 'video' ? (
                    <video src={mediaFile} controls className="max-h-full max-w-full rounded-xl object-contain" />
                  ) : mediaLoadError ? (
                    <InteractiveSVGBlueprint step={selectedStep} isDiagnosticMode={true} className="w-full h-full" />
                  ) : (
                    <img
                      src={mediaFile}
                      alt="Captured CNC Part"
                      onError={() => setMediaLoadError(true)}
                      className="max-h-full max-w-full rounded-xl object-contain"
                    />
                  )
                ) : (
                  <div className="text-center space-y-2.5 p-4 pointer-events-none">
                    <div className="w-14 h-14 rounded-2xl bg-cyan-950 border border-cyan-800 text-cyan-400 flex items-center justify-center mx-auto group-hover:scale-110 transition shadow-lg shadow-cyan-500/10">
                      <Camera className="w-7 h-7" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-white font-sans">
                        {t.cameraDropPrompt}
                      </p>
                      <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                        {t.cameraDropSub}
                      </p>
                    </div>
                    <span className="inline-block px-3 py-1 rounded-full bg-slate-900 border border-slate-700 text-cyan-300 text-[10px] font-mono">
                      📸 {lang === 'en' ? '1-Click Instant Device Camera' : '1-کلک فوری ڈیوائس کیمرہ'}
                    </span>
                  </div>
                )}
              </div>

              {/* Floating controls if media is selected */}
              {mediaFile && (
                <div className="absolute bottom-2 right-2 flex gap-1.5 z-10">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      cameraInputRef.current?.click();
                    }}
                    className="px-2.5 py-1 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-cyan-300 text-[11px] font-medium border border-slate-700 transition cursor-pointer"
                  >
                    {t.changePhoto}
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setMediaFile(null);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-red-950/90 hover:bg-red-900 text-red-300 text-[11px] font-medium border border-red-800 transition cursor-pointer"
                  >
                    {t.removePhoto}
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Quick Scenario Chips */}
          <div>
            <span className="text-[11px] font-mono text-slate-400 block mb-1.5">
              {t.sampleScenarios}
            </span>
            <div className="space-y-1.5">
              {sampleScenarios.map((sc, idx) => (
                <button
                  key={idx}
                  onClick={() => handleApplyScenario(sc)}
                  className="w-full text-left p-2 rounded-xl bg-slate-950/70 hover:bg-cyan-950/50 border border-slate-800 hover:border-cyan-700/60 text-xs text-slate-300 transition flex items-center justify-between cursor-pointer"
                >
                  <span className="truncate pr-2 font-medium">
                    ⚡ {lang === 'en' ? sc.titleEn : lang === 'both' ? `${sc.titleUr} (${sc.titleEn})` : sc.titleUr}
                  </span>
                  <span className="text-[10px] text-cyan-400 font-mono shrink-0">Step #{sc.stepId}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Assembly Step Selection & Symptoms Input (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Step Selector */}
          <div>
            <label className="block text-xs font-mono text-cyan-300 mb-1.5 uppercase tracking-wider">
              {t.assocStep}
            </label>
            <select
              value={selectedStepId}
              onChange={(e) => setSelectedStepId(Number(e.target.value))}
              className="w-full bg-slate-950 border border-cyan-900 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-cyan-500 font-sans"
            >
              {CNC_STEPS.map((s) => (
                <option key={s.id} value={s.id}>
                  Step {s.id}: {lang === 'en' ? s.titleEn : lang === 'both' ? `${s.titleUrdu} (${s.titleEn})` : s.titleUrdu}
                </option>
              ))}
            </select>
          </div>

          {/* Symptoms Description with Speech and Mic Fallback */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-mono text-cyan-300 uppercase tracking-wider">
                {t.observedSymptoms}
              </label>

              {/* Voice Dictation & Direct Audio Recording Buttons */}
              <div className="flex items-center gap-1.5">
                {/* 1. Speech Recognition Dictation */}
                <button
                  type="button"
                  onClick={handleToggleVoiceInput}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-sans border transition cursor-pointer ${
                    isListening
                      ? 'bg-red-500 text-white border-red-400 animate-pulse shadow-md shadow-red-500/40'
                      : 'bg-slate-900 text-cyan-400 border-cyan-800 hover:bg-slate-800'
                  }`}
                  title="Dictate symptoms via speech"
                >
                  {isListening ? (
                    <>
                      <MicOff className="w-3.5 h-3.5" />
                      <span>{lang === 'en' ? 'Listening...' : 'ریکارڈنگ جاری ہے...'}</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-3.5 h-3.5" />
                      <span>{t.voiceDictate}</span>
                    </>
                  )}
                </button>

                {/* 2. Direct Audio File Recording Fallback Button */}
                <button
                  type="button"
                  onClick={() => audioInputRef.current?.click()}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-sans bg-slate-900 text-emerald-400 border border-emerald-800 hover:bg-slate-800 transition cursor-pointer"
                  title="Record audio clip directly using device microphone"
                >
                  <Music className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{t.audioRecord}</span>
                </button>
              </div>
            </div>

            {/* Attached Audio Player Widget */}
            {attachedAudio && (
              <div className="mb-2 p-2 rounded-xl bg-slate-950 border border-emerald-800/80 flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="w-6 h-6 rounded-full bg-emerald-950 text-emerald-400 flex items-center justify-center shrink-0">
                    🎵
                  </span>
                  <div className="truncate">
                    <p className="font-mono text-emerald-300 font-bold truncate text-[11px]">
                      {attachedAudio.name}
                    </p>
                    <p className="text-[10px] text-slate-400">
                      {t.audioAttached}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <audio src={attachedAudio.url} controls className="h-7 w-40 sm:w-48" />
                  <button
                    type="button"
                    onClick={() => setAttachedAudio(null)}
                    className="p-1 rounded text-red-400 hover:bg-red-950 transition cursor-pointer"
                    title="Remove audio"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {isTranscribingAudio && (
              <div className="mb-2 p-2 rounded-xl bg-cyan-950/60 border border-cyan-800 text-cyan-300 text-xs flex items-center gap-2 font-mono">
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>{t.transcribing}</span>
              </div>
            )}

            <textarea
              rows={3}
              value={symptomsInput}
              onChange={(e) => setSymptomsInput(e.target.value)}
              placeholder={t.symptomsPlaceholder}
              className="w-full bg-slate-950 border border-cyan-900/80 rounded-xl p-3 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-cyan-500 font-sans"
            />
          </div>

          {/* Action Trigger Button */}
          <button
            type="button"
            onClick={handleAnalyze}
            disabled={isAnalyzing || (!mediaFile && !symptomsInput.trim())}
            className="w-full py-3.5 px-4 bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 hover:from-red-500 hover:to-amber-500 disabled:opacity-40 text-white font-bold rounded-xl text-sm transition shadow-lg shadow-red-600/25 flex items-center justify-center gap-2 cursor-pointer font-sans"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{t.analyzing}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>{t.diagnoseBtn}</span>
              </>
            )}
          </button>

          {/* Diagnostic Results Presentation */}
          {diagnosticResult && (
            <div className="mt-4 p-5 rounded-2xl bg-slate-950/90 border border-cyan-800 space-y-4 shadow-xl">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-white font-sans">{t.reportTitle}</h3>
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded-full uppercase font-bold border ${
                      diagnosticResult.severity === 'Critical'
                        ? 'bg-red-950 text-red-300 border-red-800'
                        : diagnosticResult.severity === 'High'
                        ? 'bg-orange-950 text-orange-300 border-orange-800'
                        : 'bg-amber-950 text-amber-300 border-amber-800'
                    }`}
                  >
                    Severity: {diagnosticResult.severity}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {/* Speech button */}
                  <button
                    type="button"
                    onClick={handleToggleSpeakDiagnosis}
                    className="p-1.5 rounded-lg bg-slate-900 border border-slate-700 text-cyan-400 hover:bg-slate-800 transition text-xs flex items-center gap-1 cursor-pointer"
                    title={isSpeakingDiagnosis ? t.stopAudio : t.listenReport}
                  >
                    {isSpeakingDiagnosis ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
                    <span className="text-[11px]">{isSpeakingDiagnosis ? t.stopAudio : t.listenReport}</span>
                  </button>

                  {/* Save to Log */}
                  <button
                    type="button"
                    onClick={handleManualSave}
                    className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                  >
                    {savedSuccess ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
                    <span>{savedSuccess ? t.savedConfirm : t.saveLogBtn}</span>
                  </button>
                </div>
              </div>

              {/* Diagnosis text display */}
              <div className="text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-wrap bg-slate-900/60 p-4 rounded-xl border border-slate-800">
                {diagnosticResult.diagnosisText}
              </div>

              {/* Video Player Guide */}
              {diagnosticResult.videoGuide && (
                <div className="pt-2">
                  <AnimatedCADVideoPlayer
                    videoGuide={diagnosticResult.videoGuide}
                    diagnosticImageUrl={diagnosticResult.diagnosticImageUrl}
                    stepId={selectedStep.id}
                    stepTitleEn={selectedStep.titleEn}
                    stepTitleUrdu={selectedStep.titleUrdu}
                    torqueSpec={selectedStep.specs.torque}
                    toleranceSpec={selectedStep.specs.tolerance}
                    lang={lang}
                  />
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
