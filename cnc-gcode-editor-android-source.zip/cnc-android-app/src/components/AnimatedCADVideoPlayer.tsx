import React, { useState, useEffect, useRef, useMemo } from 'react';
import { VideoGuideData, VideoChapter, VideoSource } from '../types/repair';
import { InteractiveSVGBlueprint } from './InteractiveSVGBlueprint';
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  Layers,
  Video,
  Cpu,
  Clock,
  Sparkles,
  Wrench,
  Gauge,
  CheckCircle2,
  AlertCircle,
  Sliders,
  Flame,
  Radio,
  Check,
  ChevronRight,
  RefreshCw,
  Zap,
} from 'lucide-react';

interface AnimatedCADVideoPlayerProps {
  videoGuide: VideoGuideData;
  diagnosticImageUrl: string;
  stepId: number;
  stepTitleEn: string;
  stepTitleUrdu: string;
  torqueSpec?: string;
  toleranceSpec?: string;
  lang: 'ur' | 'en' | 'both';
}

export const AnimatedCADVideoPlayer: React.FC<AnimatedCADVideoPlayerProps> = ({
  videoGuide,
  diagnosticImageUrl,
  stepId,
  stepTitleEn,
  stepTitleUrdu,
  torqueSpec = '9.0 N·m',
  toleranceSpec = '±0.02 mm',
  lang,
}) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [isMuted, setIsMuted] = useState<boolean>(true); // start muted so browser allows seamless unprompted playback
  const [volume, setVolume] = useState<number>(0.8);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'animated_cad' | 'html5_stream'>('animated_cad');
  const [videoError, setVideoError] = useState<boolean>(false);
  const [activeChapterIndex, setActiveChapterIndex] = useState<number>(0);
  const [activeSourceIndex, setActiveSourceIndex] = useState<number>(0);
  const [isBuffering, setIsBuffering] = useState<boolean>(false);
  const [fpsCounter, setFpsCounter] = useState<number>(60);
  const [baseImgError, setBaseImgError] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const videoElementRef = useRef<HTMLVideoElement>(null);
  const animFrameRef = useRef<number | null>(null);
  const lastTimestampRef = useRef<number | null>(null);

  const totalDuration = videoGuide.durationSeconds || 275;
  const chapters = videoGuide.chapters || [];

  // Reliable collection of video sources with local fallback優先 (first local MP4, then local WebM, then stream, then CDN)
  const availableSources: VideoSource[] = useMemo(() => {
    const list: VideoSource[] = [];

    // Local static MP4 (zero latency, offline)
    list.push({
      src: '/videos/cnc_repair_guide.mp4',
      type: 'video/mp4',
      label: 'Local HD MP4 (تیز رفتار & آف لائن)',
    });

    // Local static WebM
    list.push({
      src: '/videos/cnc_repair_guide.webm',
      type: 'video/webm',
      label: 'Local WebM (High Compression)',
    });

    // Byte-Range streaming endpoint
    list.push({
      src: '/api/video-stream?format=mp4',
      type: 'video/mp4',
      label: 'Server Range Stream (No Buffer)',
    });

    // Custom sources from props if available
    if (videoGuide.sources && videoGuide.sources.length > 0) {
      videoGuide.sources.forEach((s) => {
        if (!list.some((existing) => existing.src === s.src)) {
          list.push(s);
        }
      });
    }

    // External reliable CDN fallbacks
    if (videoGuide.videoUrl && !list.some((existing) => existing.src === videoGuide.videoUrl)) {
      list.push({
        src: videoGuide.videoUrl,
        type: 'video/mp4',
        label: 'Cloud CDN Stream',
      });
    }

    list.push({
      src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      type: 'video/mp4',
      label: 'GCS Public Mirror',
    });

    list.push({
      src: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm',
      type: 'video/webm',
      label: 'MDN WebM Mirror',
    });

    return list;
  }, [videoGuide]);

  const currentSource = availableSources[activeSourceIndex] || availableSources[0];

  // Determine active chapter based on currentTime
  useEffect(() => {
    let foundIndex = 0;
    for (let i = chapters.length - 1; i >= 0; i--) {
      if (currentTime >= (chapters[i].seconds || 0)) {
        foundIndex = i;
        break;
      }
    }
    setActiveChapterIndex(foundIndex);
  }, [currentTime, chapters]);

  // Smooth 60 FPS animation loop using requestAnimationFrame
  useEffect(() => {
    if (!isPlaying) {
      lastTimestampRef.current = null;
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
        animFrameRef.current = null;
      }
      return;
    }

    let frameCount = 0;
    let fpsTimeAccum = 0;

    const tick = (now: number) => {
      if (lastTimestampRef.current !== null) {
        const deltaMs = now - lastTimestampRef.current;
        const deltaSec = (deltaMs / 1000) * playbackSpeed;

        // Smoothly advance time
        setCurrentTime((prev) => {
          const next = prev + deltaSec;
          if (next >= totalDuration) {
            setIsPlaying(false);
            return totalDuration;
          }
          return next;
        });

        // FPS calculation
        frameCount++;
        fpsTimeAccum += deltaMs;
        if (fpsTimeAccum >= 1000) {
          setFpsCounter(Math.round((frameCount * 1000) / fpsTimeAccum));
          frameCount = 0;
          fpsTimeAccum = 0;
        }
      }

      lastTimestampRef.current = now;
      animFrameRef.current = requestAnimationFrame(tick);
    };

    animFrameRef.current = requestAnimationFrame(tick);

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
        animFrameRef.current = null;
      }
    };
  }, [isPlaying, playbackSpeed, totalDuration]);

  // Sync with HTML5 video element when in stream mode
  useEffect(() => {
    const video = videoElementRef.current;
    if (!video || viewMode !== 'html5_stream') return;

    video.playbackRate = playbackSpeed;
    video.muted = isMuted;
    video.volume = volume;

    if (isPlaying) {
      const playPromise = video.play();
      if (playPromise !== undefined) {
        playPromise.catch((err) => {
          console.warn('Video playback notice:', err.message);
          // Try muted if audio was blocked by browser
          if (!video.muted) {
            video.muted = true;
            setIsMuted(true);
            video.play().catch(() => {
              // Try next source or switch smoothly to CAD simulation
              handleVideoError();
            });
          } else {
            handleVideoError();
          }
        });
      }
    } else {
      video.pause();
    }
  }, [isPlaying, viewMode, currentSource, playbackSpeed, isMuted, volume]);

  const handleVideoError = () => {
    console.warn(`Video source ${currentSource.src} failed. Trying fallback source.`);
    if (activeSourceIndex < availableSources.length - 1) {
      setActiveSourceIndex((prev) => prev + 1);
      setVideoError(false);
    } else {
      // All video URLs exhausted, switch seamlessly to 60 FPS CAD diagram
      setVideoError(true);
      setViewMode('animated_cad');
    }
  };

  const handleTogglePlay = () => {
    if (currentTime >= totalDuration) {
      setCurrentTime(0);
      if (videoElementRef.current) {
        videoElementRef.current.currentTime = 0;
      }
    }
    setIsPlaying(!isPlaying);
  };

  const handleSeek = (newTime: number) => {
    const clamped = Math.max(0, Math.min(newTime, totalDuration));
    setCurrentTime(clamped);
    if (videoElementRef.current) {
      const vidDur = videoElementRef.current.duration;
      if (vidDur && !isNaN(vidDur) && vidDur > 0) {
        videoElementRef.current.currentTime = clamped % vidDur;
      }
    }
  };

  const handleChapterClick = (chapter: VideoChapter, index: number) => {
    setActiveChapterIndex(index);
    handleSeek(chapter.seconds || 0);
    setIsPlaying(true);
  };

  const handleRestart = () => {
    handleSeek(0);
    setIsPlaying(true);
  };

  const handleSwitchSource = (idx: number) => {
    setActiveSourceIndex(idx);
    setVideoError(false);
    setIsBuffering(true);
    setTimeout(() => setIsBuffering(false), 500);
  };

  const formatSeconds = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const activeChapter = chapters[activeChapterIndex] || chapters[0];
  const progressRatio = totalDuration > 0 ? (currentTime / totalDuration) * 100 : 0;

  // Toggle fullscreen
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  // Keyboard controls listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      if (e.code === 'Space') {
        e.preventDefault();
        handleTogglePlay();
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        handleSeek(currentTime + 5);
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        handleSeek(currentTime - 5);
      } else if (e.code === 'KeyM') {
        setIsMuted((prev) => !prev);
      } else if (e.code === 'KeyF') {
        toggleFullscreen();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, currentTime]);

  return (
    <div
      ref={containerRef}
      className={`relative w-full rounded-2xl bg-slate-950 border border-cyan-800/80 shadow-2xl overflow-hidden flex flex-col ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none h-screen' : ''
      }`}
    >
      {/* Top Header & Mode Switcher Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 bg-slate-900/95 border-b border-cyan-900/60 z-20">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
          <h4 className="text-xs font-bold text-slate-100 font-mono tracking-wide truncate max-w-[260px] sm:max-w-md">
            {videoGuide.title}
          </h4>
        </div>

        {/* View Mode & Source Controls */}
        <div className="flex items-center gap-2">
          {/* View Mode Toggle: Animated CAD vs HTML5 Stream */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-cyan-900/60 text-xs">
            <button
              onClick={() => setViewMode('animated_cad')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-semibold transition ${
                viewMode === 'animated_cad'
                  ? 'bg-cyan-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-cyan-300'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>متحرک 3D CAD ڈایاگرام (60 FPS)</span>
            </button>

            <button
              onClick={() => {
                setVideoError(false);
                setViewMode('html5_stream');
              }}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-semibold transition ${
                viewMode === 'html5_stream'
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-amber-300'
              }`}
            >
              <Video className="w-3.5 h-3.5" />
              <span>ورکشاپ ویڈیو فیڈ (HTML5)</span>
            </button>
          </div>

          {/* Telemetry pill */}
          <div className="hidden md:flex items-center gap-1 px-2.5 py-1 rounded-md bg-slate-950 border border-slate-800 text-[11px] font-mono text-emerald-400">
            <Zap className="w-3 h-3 text-emerald-400" />
            <span>{viewMode === 'animated_cad' ? `${fpsCounter} FPS Ultra-Smooth` : 'Zero Buffering'}</span>
          </div>
        </div>
      </div>

      {/* Source Selector Bar for HTML5 Stream Mode */}
      {viewMode === 'html5_stream' && (
        <div className="flex items-center justify-between gap-2 px-4 py-1.5 bg-slate-950 border-b border-cyan-950/80 text-[11px] font-mono overflow-x-auto">
          <div className="flex items-center gap-1.5 text-slate-400 shrink-0">
            <Radio className="w-3.5 h-3.5 text-amber-400" />
            <span>ویڈیو سورس (Video Feed Source):</span>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            {availableSources.map((source, idx) => (
              <button
                key={idx}
                onClick={() => handleSwitchSource(idx)}
                className={`px-2 py-0.5 rounded text-[10px] font-medium transition flex items-center gap-1 ${
                  activeSourceIndex === idx
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/60'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {activeSourceIndex === idx && <Check className="w-2.5 h-2.5 text-amber-400" />}
                <span>{source.label || `Source ${idx + 1}`}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Main Video Viewport Canvas */}
      <div className="relative w-full h-72 sm:h-84 md:h-96 bg-[#020617] flex items-center justify-center overflow-hidden select-none">
        {/* MODE 1: BUTTERY SMOOTH 60 FPS ANIMATED CAD BLUEPRINT ENGINE */}
        {viewMode === 'animated_cad' && (
          <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
            {/* Technical CAD Blueprint Grid Background */}
            <svg
              className="absolute inset-0 w-full h-full opacity-25 pointer-events-none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <pattern id="vidGrid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#0ea5e9" strokeWidth="0.6" />
                </pattern>
                <pattern id="vidGridSub" width="8" height="8" patternUnits="userSpaceOnUse">
                  <path d="M 8 0 L 0 0 0 8" fill="none" stroke="#0ea5e9" strokeWidth="0.15" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#vidGridSub)" />
              <rect width="100%" height="100%" fill="url(#vidGrid)" />
            </svg>

            {/* Base CAD Blueprint Artwork */}
            {baseImgError || !diagnosticImageUrl ? (
              <InteractiveSVGBlueprint
                subsystem="gantry"
                isDiagnosticMode={true}
                showCanvasSimulation={false}
                className="w-full h-full"
              />
            ) : (
              <img
                src={diagnosticImageUrl}
                alt="CAD Blueprint"
                onError={() => setBaseImgError(true)}
                className="w-full h-full object-contain filter brightness-90 contrast-125 transition-transform duration-700"
                style={{
                  transform: `scale(${isPlaying ? 1.02 : 1})`,
                }}
              />
            )}

            {/* Vignette gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-transparent to-slate-950/40 pointer-events-none" />

            {/* LIVE DYNAMIC 60 FPS ANIMATED CAD OVERLAYS ACCORDING TO CURRENT PHASE */}
            <svg
              viewBox="0 0 800 450"
              className="absolute inset-0 w-full h-full pointer-events-none z-10"
            >
              <defs>
                <linearGradient id="laserGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#22c55e" stopOpacity="0" />
                  <stop offset="50%" stopColor="#22c55e" stopOpacity="1" />
                  <stop offset="100%" stopColor="#22c55e" stopOpacity="0" />
                </linearGradient>
                <linearGradient id="torqueGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#38bdf8" />
                  <stop offset="70%" stopColor="#f59e0b" />
                  <stop offset="100%" stopColor="#22c55e" />
                </linearGradient>
                <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="3" result="blur" />
                  <feMerge>
                    <feMergeNode in="blur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
                <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                  <path d="M 0 0 L 10 5 L 0 10 z" fill="#38bdf8" />
                </marker>
              </defs>

              {/* TECHNICAL CROSSHAIRS & MEASUREMENT AXES */}
              <g opacity="0.4">
                <line x1="40" y1="225" x2="760" y2="225" stroke="#38bdf8" strokeWidth="0.5" strokeDasharray="5 5" />
                <line x1="400" y1="40" x2="400" y2="410" stroke="#38bdf8" strokeWidth="0.5" strokeDasharray="5 5" />
              </g>

              {/* DIGITAL READOUT (DRO) OVERLAY */}
              <g transform="translate(30, 45)">
                <rect x="0" y="0" width="160" height="42" fill="#020617" rx="6" stroke="#0ea5e9" strokeWidth="1" opacity="0.85" />
                <text x="10" y="16" fill="#38bdf8" fontSize="9" fontFamily="monospace" fontWeight="bold">REAL-TIME TELEMETRY</text>
                <text x="10" y="32" fill="#22c55e" fontSize="12" fontFamily="monospace" fontWeight="bold">
                  {`X:${(320 + Math.sin(currentTime * 1.5) * 80).toFixed(2)}  Z:${(14.0 - Math.cos(currentTime * 0.8) * 4).toFixed(2)}`}
                </text>
              </g>

              {/* PHASE 1: INSPECTION & LASER RUNOUT CHECK (00:00 - 01:15) */}
              {activeChapter?.animationPhase === 'inspect' && (
                <g id="animInspect">
                  {/* Smooth Sweeping Laser Line (Calculated with continuous sine wave for 60 FPS motion) */}
                  {(() => {
                    const sweepX = isPlaying ? 200 + ((Math.sin(currentTime * 1.2) + 1) / 2) * 400 : 380;
                    return (
                      <g>
                        <line
                          x1={sweepX}
                          y1="60"
                          x2={sweepX}
                          y2="380"
                          stroke="#22c55e"
                          strokeWidth="3.5"
                          strokeDasharray="8 4"
                          filter="url(#neonGlow)"
                        />
                        <circle cx={sweepX} cy={220} r="6" fill="#22c55e" filter="url(#neonGlow)" />
                        <text x={sweepX + 10} y="90" fill="#22c55e" fontSize="10" fontFamily="monospace" fontWeight="bold">
                          LASER SCAN: {sweepX.toFixed(1)}mm
                        </text>
                      </g>
                    );
                  })()}

                  {/* High-Precision Dial Test Indicator */}
                  <g transform="translate(480, 220)">
                    {/* Mounting stem */}
                    <rect x="-4" y="-80" width="8" height="60" fill="#334155" stroke="#64748b" strokeWidth="1" />
                    {/* Dial gauge bezel */}
                    <circle cx="0" cy="0" r="38" fill="#090d16" stroke="#22c55e" strokeWidth="3" filter="url(#neonGlow)" />
                    <circle cx="0" cy="0" r="32" fill="#020617" stroke="#0ea5e9" strokeWidth="1" />
                    {/* Dial graduation marks */}
                    {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg) => (
                      <line
                        key={deg}
                        x1={Math.sin((deg * Math.PI) / 180) * 26}
                        y1={-Math.cos((deg * Math.PI) / 180) * 26}
                        x2={Math.sin((deg * Math.PI) / 180) * 31}
                        y2={-Math.cos((deg * Math.PI) / 180) * 31}
                        stroke="#64748b"
                        strokeWidth="1.2"
                      />
                    ))}
                    {/* Smooth vibrating indicator needle (high frequency oscillation) */}
                    {(() => {
                      const needleAngle = isPlaying ? Math.sin(currentTime * 8) * 35 : 12;
                      const rad = (needleAngle * Math.PI) / 180;
                      return (
                        <g>
                          <line
                            x1="0"
                            y1="0"
                            x2={Math.sin(rad) * 26}
                            y2={-Math.cos(rad) * 26}
                            stroke="#ef4444"
                            strokeWidth="2.5"
                            strokeLinecap="round"
                          />
                          <circle cx="0" cy="0" r="3" fill="#ef4444" />
                        </g>
                      );
                    })()}
                    <text x="-26" y="52" fill="#22c55e" fontSize="10" fontFamily="monospace" fontWeight="bold">
                      TIR 0.012mm
                    </text>
                  </g>

                  {/* Pulsing Concentric Fault Locator Rings */}
                  <g transform="translate(480, 220)">
                    <circle cx="0" cy="0" r="50" fill="none" stroke="#22c55e" strokeWidth="1.5" strokeDasharray="6 4" opacity="0.6" />
                    <circle cx="0" cy="0" r="65" fill="none" stroke="#0ea5e9" strokeWidth="1" strokeDasharray="3 3" opacity="0.4" />
                  </g>
                </g>
              )}

              {/* PHASE 2: DISASSEMBLY & DEGREASING (01:15 - 02:30) */}
              {activeChapter?.animationPhase === 'disassemble' && (
                <g id="animDisassemble">
                  {/* Exploded Hex Screws with smooth continuous rotation */}
                  {[
                    { cx: 280, cy: 150, label: 'M5x16' },
                    { cx: 520, cy: 150, label: 'M5x16' },
                    { cx: 280, cy: 300, label: 'M5x16' },
                    { cx: 520, cy: 300, label: 'M5x16' },
                  ].map((pos, idx) => {
                    const rot = isPlaying ? (currentTime * 120 + idx * 45) % 360 : 0;
                    return (
                      <g key={idx} transform={`translate(${pos.cx}, ${pos.cy})`}>
                        <circle cx="0" cy="0" r="18" fill="#090d16" stroke="#f59e0b" strokeWidth="2.5" />
                        {/* Hex bolt socket */}
                        <g transform={`rotate(${rot})`}>
                          <polygon points="0,-9 8,-4 8,4 0,9 -8,4 -8,-4" fill="#f59e0b" />
                        </g>
                        {/* CCW unscrew indicator curve */}
                        <path
                          d="M -24 0 A 24 24 0 1 1 0 24"
                          fill="none"
                          stroke="#38bdf8"
                          strokeWidth="2.5"
                          strokeDasharray="5 3"
                        />
                        <polygon points="-24,-5 -19,2 -29,2" fill="#38bdf8" />
                        <text x="-16" y="34" fill="#f59e0b" fontSize="9" fontFamily="monospace" fontWeight="bold">
                          {pos.label} LOOSEN
                        </text>
                      </g>
                    );
                  })}

                  {/* Precision IPA Cleaning Wiper moving smoothly back and forth */}
                  {(() => {
                    const wiperX = isPlaying ? 350 + Math.sin(currentTime * 3) * 60 : 400;
                    return (
                      <g transform={`translate(${wiperX}, 225)`}>
                        <rect x="-70" y="-18" width="140" height="36" fill="#0369a1" rx="8" stroke="#38bdf8" strokeWidth="2" opacity="0.9" filter="url(#neonGlow)" />
                        <text x="-56" y="5" fill="#f0f9ff" fontSize="11" fontFamily="monospace" fontWeight="bold">
                          DEGREASING IPA 99%
                        </text>
                        {/* Gleam droplets */}
                        <circle cx="50" cy="-6" r="3" fill="#bae6fd" opacity="0.8" />
                        <circle cx="-50" cy="8" r="2.5" fill="#bae6fd" opacity="0.8" />
                      </g>
                    );
                  })()}
                </g>
              )}

              {/* PHASE 3: PRECISION TRAMMING & SHIMMING (02:30 - 03:45) */}
              {activeChapter?.animationPhase === 'align' && (
                <g id="animAlign">
                  {/* Sweeping Tramming Arm Arc */}
                  <path
                    d="M 260 230 A 140 140 0 0 1 540 230"
                    fill="none"
                    stroke="#38bdf8"
                    strokeWidth="3.5"
                    strokeDasharray="8 4"
                    filter="url(#neonGlow)"
                  />

                  {/* Dual Dial Indicators with active comparative readouts */}
                  <g transform="translate(260, 230)">
                    <circle cx="0" cy="0" r="22" fill="#090d16" stroke="#38bdf8" strokeWidth="2.5" />
                    <text x="-16" y="4" fill="#38bdf8" fontSize="10" fontFamily="monospace" fontWeight="bold">0.00</text>
                    <text x="-24" y="34" fill="#94a3b8" fontSize="9" fontFamily="monospace">LEFT DATUM</text>
                  </g>

                  <g transform="translate(540, 230)">
                    <circle cx="0" cy="0" r="22" fill="#090d16" stroke="#22c55e" strokeWidth="2.5" />
                    <text x="-18" y="4" fill="#22c55e" fontSize="10" fontFamily="monospace" fontWeight="bold">
                      {(0.01 + Math.sin(currentTime * 4) * 0.003).toFixed(2)}
                    </text>
                    <text x="-28" y="34" fill="#22c55e" fontSize="9" fontFamily="monospace">RIGHT TRAM</text>
                  </g>

                  {/* Brass Foil Shim Insertion Animation */}
                  {(() => {
                    const shimY = isPlaying ? 130 + ((Math.sin(currentTime * 2) + 1) / 2) * 20 : 140;
                    return (
                      <g transform={`translate(400, ${shimY})`}>
                        <rect x="-40" y="-10" width="80" height="20" fill="#d97706" rx="3" stroke="#fde68a" strokeWidth="1.5" />
                        <text x="-32" y="4" fill="#1e293b" fontSize="10" fontWeight="bold" fontFamily="monospace">
                          SHIM 0.02mm
                        </text>
                        <line x1="0" y1="14" x2="0" y2="40" stroke="#f59e0b" strokeWidth="2.5" markerEnd="url(#arrow)" />
                      </g>
                    );
                  })()}
                </g>
              )}

              {/* PHASE 4: RE-TORQUING & FINAL COMMISSIONING (03:45 - end) */}
              {activeChapter?.animationPhase === 'torque' && (
                <g id="animTorque">
                  {/* Calibrated Torque Wrench Handle Smooth Animation */}
                  {(() => {
                    const angle = isPlaying ? -30 + Math.sin(currentTime * 2.5) * 35 : 0;
                    return (
                      <g transform={`translate(400, 220) rotate(${angle})`}>
                        {/* Wrench handle bar */}
                        <rect x="-8" y="-140" width="16" height="130" fill="#334155" rx="4" stroke="#64748b" strokeWidth="2" />
                        {/* Ratchet head */}
                        <circle cx="0" cy="0" r="26" fill="#0f172a" stroke="#f59e0b" strokeWidth="3.5" />
                        {/* Micrometer torque scale */}
                        <rect x="-24" y="-100" width="48" height="28" fill="#1e293b" rx="5" stroke="#f59e0b" strokeWidth="2" />
                        <text x="-20" y="-82" fill="#f59e0b" fontSize="11" fontFamily="monospace" fontWeight="bold">
                          {torqueSpec}
                        </text>
                      </g>
                    );
                  })()}

                  {/* Real-time Torque Gauge Arc Indicator */}
                  <g transform="translate(400, 330)">
                    <circle cx="0" cy="0" r="24" fill="#064e3b" stroke="#34d399" strokeWidth="2.5" filter="url(#neonGlow)" />
                    <text x="-14" y="6" fill="#ecfdf5" fontSize="18" fontWeight="bold">✓</text>
                    <text x="-48" y="38" fill="#34d399" fontSize="11" fontFamily="monospace" fontWeight="bold">
                      TORQUE LOCKED (PASS)
                    </text>
                    <text x="-42" y="52" fill="#94a3b8" fontSize="9" fontFamily="monospace">
                      LOCTITE 243 CURED
                    </text>
                  </g>
                </g>
              )}
            </svg>
          </div>
        )}

        {/* MODE 2: HTML5 VIDEO STREAM (RELIABLE WITH REDUNDANT SOURCES) */}
        {viewMode === 'html5_stream' && (
          <div className="relative w-full h-full flex items-center justify-center bg-black">
            {!videoError ? (
              <>
                <video
                  ref={videoElementRef}
                  src={currentSource.src}
                  playsInline
                  loop
                  muted={isMuted}
                  onWaiting={() => setIsBuffering(true)}
                  onPlaying={() => setIsBuffering(false)}
                  onCanPlay={() => setIsBuffering(false)}
                  onTimeUpdate={(e) => {
                    const vid = e.currentTarget;
                    if (vid.duration && !isNaN(vid.duration) && vid.duration > 0) {
                      setCurrentTime(vid.currentTime);
                    }
                  }}
                  onError={() => {
                    console.warn(`Video element encountered error loading: ${currentSource.src}`);
                    handleVideoError();
                  }}
                  className="w-full h-full object-contain"
                >
                  {/* Redundant child sources fallback */}
                  {availableSources.map((s, idx) => (
                    <source key={idx} src={s.src} type={s.type} />
                  ))}
                  Your browser does not support HTML5 video.
                </video>

                {/* Buffering Indicator */}
                {isBuffering && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm z-20">
                    <RefreshCw className="w-8 h-8 text-amber-400 animate-spin mb-2" />
                    <span className="text-xs font-mono text-slate-200">Buffering Stream...</span>
                  </div>
                )}
              </>
            ) : (
              <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
                <InteractiveSVGBlueprint
                  subsystem="gantry"
                  isDiagnosticMode={true}
                  showCanvasSimulation={true}
                  customOverlayText="LIVE 60 FPS VECTOR CAD STREAM"
                  className="w-full h-full"
                />
              </div>
            )}
          </div>
        )}

        {/* Center Big Play Button (when paused) */}
        {!isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center bg-slate-950/40 backdrop-blur-[2px] z-30 transition">
            <button
              onClick={handleTogglePlay}
              className="w-16 h-16 rounded-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 flex items-center justify-center shadow-2xl shadow-cyan-500/50 transition transform hover:scale-110 active:scale-95"
            >
              <Play className="w-7 h-7 fill-current ml-1" />
            </button>
          </div>
        )}

        {/* Top-Right Telemetry & HUD Badge */}
        <div className="absolute top-3 right-3 z-30 flex items-center gap-2 bg-slate-900/90 backdrop-blur px-3 py-1.5 rounded-lg border border-cyan-800/80 font-mono text-xs shadow-lg">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-cyan-300 font-semibold truncate max-w-[150px]">{activeChapter?.title}</span>
          <span className="text-slate-600">|</span>
          <span className="text-amber-400">{activeChapter?.specValue || torqueSpec}</span>
        </div>

        {/* Bottom Chapter Info Bar Overlay */}
        <div className="absolute bottom-2 left-3 right-3 z-30 flex items-center justify-between text-xs font-mono text-slate-300 pointer-events-none">
          <div className="bg-slate-900/85 backdrop-blur px-2.5 py-1 rounded border border-cyan-900/60 flex items-center gap-2">
            <Wrench className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-slate-200">{activeChapter?.toolNeeded || 'Machinist Tools'}</span>
          </div>

          <div className="bg-slate-900/85 backdrop-blur px-2.5 py-1 rounded border border-cyan-900/60 text-cyan-300 font-bold">
            {formatSeconds(currentTime)} / {formatSeconds(totalDuration)}
          </div>
        </div>
      </div>

      {/* Interactive Video Scrubber Timeline */}
      <div className="px-4 pt-3 pb-1 bg-slate-900/95 border-t border-cyan-950">
        <div
          onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const clickPos = (e.clientX - rect.left) / rect.width;
            handleSeek(clickPos * totalDuration);
          }}
          className="relative w-full h-3 bg-slate-950 rounded-full cursor-pointer group flex items-center border border-cyan-950"
        >
          {/* Filled progress bar */}
          <div
            className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-emerald-400 rounded-full transition-all duration-75 relative"
            style={{ width: `${progressRatio}%` }}
          >
            <span className="absolute right-0 top-1/2 -translate-y-1/2 w-3.5 h-3.5 rounded-full bg-white shadow-md border-2 border-cyan-500 scale-0 group-hover:scale-100 transition" />
          </div>

          {/* Chapter Tick Markers */}
          {chapters.map((chap, idx) => {
            const leftPct = (chap.seconds / totalDuration) * 100;
            return (
              <div
                key={idx}
                style={{ left: `${leftPct}%` }}
                className="absolute top-0 bottom-0 w-0.5 bg-slate-700/80 group-hover:bg-amber-400 transition"
                title={`${chap.time} - ${chap.title}`}
              />
            );
          })}
        </div>
      </div>

      {/* Main Controls Row */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 bg-slate-900/95 text-xs font-mono">
        {/* Left: Playback & Restart */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleTogglePlay}
            className="p-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold shadow-md shadow-cyan-500/20 transition"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
          </button>

          <button
            onClick={handleRestart}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
            title="Restart Video"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <span className="text-slate-400 ml-1">
            {formatSeconds(currentTime)} <span className="text-slate-600">/</span> {formatSeconds(totalDuration)}
          </span>
        </div>

        {/* Center: Playback Speed Buttons */}
        <div className="hidden sm:flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
          {[0.5, 1, 1.25, 1.5, 2].map((spd) => (
            <button
              key={spd}
              onClick={() => setPlaybackSpeed(spd)}
              className={`px-2 py-0.5 rounded text-[11px] font-semibold transition ${
                playbackSpeed === spd
                  ? 'bg-cyan-500 text-slate-950'
                  : 'text-slate-400 hover:text-cyan-300'
              }`}
            >
              {spd}x
            </button>
          ))}
        </div>

        {/* Right: Audio, Fullscreen & Status */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsMuted(!isMuted)}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-amber-400" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Chapters Breakdown Grid */}
      <div className="p-3 bg-slate-950/90 border-t border-cyan-950">
        <div className="text-[11px] font-mono text-slate-400 mb-2 flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-cyan-300">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>ویڈیو چیپٹرز اور مرمتی مراحل (Jump to Chapter):</span>
          </span>
          <span className="text-amber-400">⚡ Smooth 60 FPS Engine (Zero Lag)</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
          {chapters.map((chap, idx) => (
            <button
              key={idx}
              onClick={() => handleChapterClick(chap, idx)}
              className={`p-2.5 rounded-xl border text-left text-xs transition flex flex-col justify-between ${
                activeChapterIndex === idx
                  ? 'border-amber-400 bg-amber-950/60 text-amber-200 shadow-md shadow-amber-900/20'
                  : 'border-slate-800/80 bg-slate-900/60 text-slate-400 hover:border-slate-700 hover:text-slate-200'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono text-[10px] text-amber-400 font-bold">{chap.time}</span>
                  <span className="text-[9px] font-mono text-cyan-400 bg-cyan-950 px-1.5 py-0.2 rounded border border-cyan-800">
                    Phase {idx + 1}
                  </span>
                </div>
                <h5 className="font-bold text-xs truncate">{chap.title}</h5>
                <p className="text-[11px] text-slate-400 line-clamp-2 mt-0.5 leading-snug">
                  {chap.desc}
                </p>
              </div>

              {chap.toolNeeded && (
                <div className="mt-2 pt-1 border-t border-white/5 text-[10px] font-mono text-slate-500 flex items-center gap-1">
                  <Wrench className="w-3 h-3 text-cyan-400 shrink-0" />
                  <span className="truncate">{chap.toolNeeded}</span>
                </div>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
