import React from 'react';
import { Hammer, Cpu, Camera, Ruler, UserCheck } from 'lucide-react';

export type ActiveAppTab = 'assembly' | 'operation' | 'troubleshoot' | 'design_editor' | 'profile';

interface BottomNavBarProps {
  activeTab: ActiveAppTab;
  onTabChange: (tab: ActiveAppTab) => void;
  completedStepsCount?: number;
  lang?: 'ur' | 'en' | 'both';
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeTab,
  onTabChange,
  completedStepsCount = 0,
  lang = 'both',
}) => {
  const tabs = [
    {
      id: 'assembly' as ActiveAppTab,
      urduLabel: 'مشین بنائیں',
      enLabel: 'Assembly',
      icon: Hammer,
      badge: `${completedStepsCount}/30`,
    },
    {
      id: 'operation' as ActiveAppTab,
      urduLabel: 'مشین چلائیں',
      enLabel: 'Operation',
      icon: Cpu,
      badge: 'G-Code',
    },
    {
      id: 'troubleshoot' as ActiveAppTab,
      urduLabel: 'اے آئی کیمرہ',
      enLabel: 'AI Diagnosis',
      icon: Camera,
      badge: 'AI',
    },
    {
      id: 'design_editor' as ActiveAppTab,
      urduLabel: 'سائز اور ڈیزائن',
      enLabel: 'Size & Design',
      icon: Ruler,
      badge: 'CAD/RLF',
    },
    {
      id: 'profile' as ActiveAppTab,
      urduLabel: 'پروفائل',
      enLabel: 'Profile',
      icon: UserCheck,
      badge: 'Gmail',
    },
  ];

  const getLabel = (tab: (typeof tabs)[0]) => {
    if (lang === 'en') return tab.enLabel;
    if (lang === 'ur') return tab.urduLabel;
    // On small screens, keep it compact to avoid wrapping clutter
    return `${tab.urduLabel} (${tab.enLabel})`;
  };

  return (
    <nav
      aria-label="Bottom Navigation"
      className="fixed bottom-0 left-0 right-0 z-50 bg-[#070e1b]/98 backdrop-blur-xl border-t border-cyan-900/60 shadow-[0_-8px_30px_rgba(0,0,0,0.8)] px-1 sm:px-2 py-1 transition-all max-w-[100vw] overflow-x-hidden"
    >
      <div className="max-w-4xl mx-auto grid grid-cols-5 items-center gap-0.5 sm:gap-1">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`group flex flex-col items-center justify-center py-1 px-0.5 sm:px-1 transition-all relative rounded-xl cursor-pointer ${
                isActive
                  ? 'text-cyan-300 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {/* Active indicator pill background */}
              <div
                className={`relative flex items-center justify-center px-2.5 sm:px-4 py-1 rounded-full transition-all duration-300 ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500/25 to-blue-500/25 border border-cyan-500/40 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                    : 'bg-transparent group-hover:bg-slate-800/40'
                }`}
              >
                <Icon
                  className={`w-4 h-4 sm:w-5 sm:h-5 transition-transform duration-200 ${
                    isActive ? 'scale-110 text-cyan-400 stroke-[2.4]' : 'stroke-[1.8]'
                  }`}
                />

                {/* Sub-badge indicator */}
                {tab.badge && (
                  <span
                    className={`hidden xs:inline-block absolute -top-1 -right-1.5 text-[8px] sm:text-[9px] font-mono px-1 py-0.1 rounded-full border leading-tight ${
                      isActive
                        ? 'bg-cyan-500 text-slate-950 border-cyan-300 font-bold'
                        : 'bg-slate-800 text-slate-400 border-slate-700'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </div>

              {/* Dynamic Bilingual / Language-Aware Label */}
              <span
                className={`text-[9.5px] xs:text-[10px] sm:text-[11px] tracking-tight mt-0.5 leading-tight text-center transition-colors font-sans truncate max-w-full block ${
                  isActive ? 'text-cyan-300 font-bold' : 'text-slate-400'
                }`}
                title={getLabel(tab)}
              >
                {getLabel(tab)}
              </span>

              {/* Active dot indicator */}
              {isActive && (
                <span className="w-1.5 h-0.5 sm:h-1 rounded-full bg-cyan-400 mt-0.5 shadow-[0_0_6px_#22d3ee]" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
