import React, { useState } from 'react';
import {
  MessageCircle,
  Phone,
  User,
  Hammer,
  Copy,
  Check,
  ShieldCheck,
  Award,
  Sparkles,
  ExternalLink,
} from 'lucide-react';

interface DeveloperSupportPanelProps {
  layout?: 'sidebar' | 'footer' | 'card';
  lang?: 'ur' | 'en' | 'both';
}

export const DeveloperSupportPanel: React.FC<DeveloperSupportPanelProps> = ({
  layout = 'sidebar',
  lang = 'both',
}) => {
  const [copied, setCopied] = useState(false);

  const developerName = 'Arbaz Ahmad';
  const developerNameUrdu = 'ارباز احمد';
  const businessName = 'Arbaz Wood Craft';
  const businessNameUrdu = 'ارباذ ووڈ کرافٹ';
  const rawPhoneNumber = '03480170151';
  const formattedPhone = '+92 348 0170151';
  const whatsappUrl = `https://wa.me/923480170151?text=${encodeURIComponent(
    'السلام علیکم ارباز بھائی! مجھے CNC روٹر مشین اور ووڈ کرافٹنگ کے حوالے سے رہنمائی / سپورٹ درکار ہے۔'
  )}`;

  const handleCopyPhone = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(rawPhoneNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  if (layout === 'footer') {
    return (
      <div className="w-full bg-slate-950/90 border border-emerald-900/40 rounded-2xl p-5 shadow-2xl backdrop-blur-md">
        <div className="flex flex-col md:flex-row items-center justify-between gap-5">
          {/* Developer & Brand Info */}
          <div className="flex items-center gap-4 text-left">
            <div className="relative">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500/20 via-slate-900 to-amber-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-lg">
                <Hammer className="w-7 h-7 text-emerald-400" />
              </div>
              <span className="absolute -bottom-1 -right-1 flex h-3.5 w-3.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 font-semibold">
                  DEVELOPER & CRAFTSMAN
                </span>
                <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-amber-400" /> Master Woodcraft & CNC Specialist
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2 mt-0.5">
                <span>{developerName}</span>
                <span className="text-emerald-400 font-urdu font-normal text-sm">({developerNameUrdu})</span>
                <span className="text-slate-600">|</span>
                <span className="text-amber-400 font-medium">{businessName}</span>
                <span className="text-slate-400 text-xs font-urdu font-normal">({businessNameUrdu})</span>
              </h3>
              <p className="text-xs text-slate-400 max-w-xl mt-1">
                سی این سی روٹر مشین ڈیزائن، اسمبلنگ، ووڈ ورکنگ اور لائیو ٹیکنیکل سپورٹ۔ کسی بھی سوال یا مشین رہنمائی کے لیے واٹس ایپ پر رابطہ فرمائیں۔
              </p>
            </div>
          </div>

          {/* Contact & WhatsApp Button */}
          <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
            {/* Phone Copy Badge */}
            <button
              onClick={handleCopyPhone}
              className="w-full sm:w-auto px-3.5 py-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-850 border border-slate-700 hover:border-slate-500 text-slate-200 text-xs font-mono flex items-center justify-center gap-2 transition active:scale-95 shadow"
              title="Copy Phone Number"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>{rawPhoneNumber}</span>
              {copied ? (
                <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-sans">
                  <Check className="w-3 h-3" /> کاپی ہو گیا!
                </span>
              ) : (
                <Copy className="w-3 h-3 text-slate-400 hover:text-slate-200" />
              )}
            </button>

            {/* Official WhatsApp Button */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#20ba59] active:bg-[#1da850] text-slate-950 font-bold text-xs flex items-center justify-center gap-2.5 shadow-lg shadow-[#25D366]/25 hover:shadow-[#25D366]/40 transition transform hover:-translate-y-0.5"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>رابطہ برائے واٹس ایپ (Direct WhatsApp Chat)</span>
              <ExternalLink className="w-3.5 h-3.5 opacity-80" />
            </a>
          </div>
        </div>
      </div>
    );
  }

  // Sidebar Layout (Default)
  return (
    <div className="p-4 rounded-xl bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950/40 border border-emerald-800/50 shadow-xl space-y-3 relative overflow-hidden group">
      {/* Decorative Glow */}
      <div className="absolute -top-12 -right-12 w-28 h-28 bg-emerald-500/10 rounded-full blur-2xl group-hover:bg-emerald-500/20 transition duration-500 pointer-events-none" />

      {/* Header Badge */}
      <div className="flex items-center justify-between pb-2 border-b border-emerald-950/80">
        <span className="flex items-center gap-1.5 text-xs font-mono font-bold text-emerald-400">
          <User className="w-4 h-4 text-emerald-400" />
          <span>
            {lang === 'en'
              ? 'Developer & Craftsman Support'
              : lang === 'both'
              ? 'ڈویلپر اور کاریگر سپورٹ (Developer Support)'
              : 'ڈویلپر اور کاریگر سپورٹ'}
          </span>
        </span>
        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-800/80 text-emerald-300 flex items-center gap-1">
          <ShieldCheck className="w-3 h-3" />
          <span>{lang === 'en' ? 'Verified Craftsman' : 'وریفائیڈ کاریگر'}</span>
        </span>
      </div>

      {/* Profile Details */}
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-xl bg-slate-900 border border-emerald-700/60 flex items-center justify-center text-emerald-400 shadow-md shrink-0">
          <Hammer className="w-6 h-6 text-emerald-400" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" /> Developer & Craftsman
          </div>
          <h4 className="text-sm font-bold text-slate-100 truncate flex items-center gap-1.5 font-sans">
            <span>{developerName}</span>
            {lang !== 'en' && (
              <span className="text-emerald-400 font-sans font-normal text-xs">({developerNameUrdu})</span>
            )}
          </h4>
          <div className="text-xs font-semibold text-amber-400 flex items-center gap-1 mt-0.5 font-sans">
            <span>{businessName}</span>
            {lang !== 'en' && (
              <span className="text-slate-400 text-[11px] font-sans font-normal">({businessNameUrdu})</span>
            )}
          </div>
        </div>
      </div>

      {/* Description */}
      <p className="text-xs text-slate-300 leading-relaxed font-sans">
        {lang === 'en'
          ? 'CNC router machine manufacturing, precision wood crafting, and engineering support. Reach out on WhatsApp for direct workshop consultation.'
          : 'سی این سی راؤٹر مشین مینوفیکچرنگ، ووڈ کرافٹنگ اور ٹیکنیکل سپورٹ۔ مشین کے متعلق کسی بھی سوال یا رہنمائی کے لیے براہ راست رابطہ کریں۔'}
      </p>

      {/* Phone Number Copy Row */}
      <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950/80 border border-slate-800/80 text-xs font-mono">
        <div className="flex items-center gap-2 text-slate-300">
          <Phone className="w-3.5 h-3.5 text-emerald-400" />
          <span className="tracking-wide">{rawPhoneNumber}</span>
        </div>
        <button
          onClick={handleCopyPhone}
          className="px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-emerald-300 text-[11px] flex items-center gap-1 transition cursor-pointer"
          title={lang === 'en' ? 'Copy number' : 'کاپی کریں'}
        >
          {copied ? (
            <span className="text-emerald-400 flex items-center gap-0.5 font-sans">
              <Check className="w-3 h-3" /> {lang === 'en' ? 'Copied' : 'کاپی ہو گیا'}
            </span>
          ) : (
            <span className="flex items-center gap-1 font-sans">
              <Copy className="w-3 h-3" /> {lang === 'en' ? 'Copy' : 'کاپی'}
            </span>
          )}
        </button>
      </div>

      {/* Direct WhatsApp Click-to-Chat Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="w-full py-2.5 px-3 rounded-xl bg-[#25D366] hover:bg-[#20ba59] active:bg-[#1da850] text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-[#25D366]/20 hover:shadow-[#25D366]/40 transition transform active:scale-95 cursor-pointer font-sans"
      >
        <MessageCircle className="w-4 h-4 fill-current" />
        <span>
          {lang === 'en'
            ? 'Chat on WhatsApp Direct'
            : lang === 'both'
            ? 'واٹس ایپ پر رابطہ کریں (WhatsApp Direct)'
            : 'واٹس ایپ پر رابطہ کریں'}
        </span>
        <ExternalLink className="w-3.5 h-3.5 opacity-80" />
      </a>
    </div>
  );
};
