import React from 'react';
import { CNCStep } from '../data/cncSteps';

interface CADVectorSchematicProps {
  step: CNCStep;
  showDimensions: boolean;
  showFasteners: boolean;
  showMotion: boolean;
  showExploded: boolean;
  zoom: number;
}

export const CADVectorSchematic: React.FC<CADVectorSchematicProps> = ({
  step,
  showDimensions,
  showFasteners,
  showMotion,
  showExploded,
  zoom,
}) => {
  const explodeOffset = showExploded ? 35 : 0;

  return (
    <div className="relative w-full h-full flex items-center justify-center overflow-hidden bg-[#0a1120] select-none">
      {/* CAD Grid Background */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none opacity-25"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <pattern id="smallGrid" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#0ea5e9" strokeWidth="0.5" strokeOpacity="0.4" />
          </pattern>
          <pattern id="mainGrid" width="100" height="100" patternUnits="userSpaceOnUse">
            <rect width="100" height="100" fill="url(#smallGrid)" />
            <path d="M 100 0 L 0 0 0 100" fill="none" stroke="#38bdf8" strokeWidth="1" strokeOpacity="0.7" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#mainGrid)" />
      </svg>

      {/* Main Isometric CAD Vector Drawing */}
      <svg
        viewBox="0 0 800 500"
        className="w-full h-full max-h-[550px] transition-transform duration-300 ease-out"
        style={{ transform: `scale(${zoom})` }}
      >
        <defs>
          <linearGradient id="cyanMetal" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#0284c7" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#0369a1" stopOpacity="0.5" />
          </linearGradient>
          <linearGradient id="alumBeam" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.25" />
            <stop offset="50%" stopColor="#0284c7" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#082f49" stopOpacity="0.8" />
          </linearGradient>
          <radialGradient id="spindleGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#0ea5e9" stopOpacity="0" />
          </radialGradient>
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* CAD Coordinate Crosshairs Top-Right */}
        <g transform="translate(730, 60)" className="text-xs font-mono">
          <circle cx="0" cy="0" r="28" fill="#031525" stroke="#0284c7" strokeWidth="1" />
          {/* X Axis */}
          <line x1="0" y1="0" x2="20" y2="0" stroke="#ef4444" strokeWidth="2" markerEnd="url(#arrowRed)" />
          <text x="23" y="4" fill="#ef4444" fontSize="10">X</text>
          {/* Y Axis */}
          <line x1="0" y1="0" x2="-14" y2="14" stroke="#22c55e" strokeWidth="2" />
          <text x="-24" y="22" fill="#22c55e" fontSize="10">Y</text>
          {/* Z Axis */}
          <line x1="0" y1="0" x2="0" y2="-20" stroke="#38bdf8" strokeWidth="2" />
          <text x="-4" y="-24" fill="#38bdf8" fontSize="10">Z</text>
        </g>

        {/* Title Header Inset */}
        <g transform="translate(40, 45)">
          <rect x="-10" y="-18" width="340" height="52" fill="#031525" rx="4" stroke="#0ea5e9" strokeWidth="1" strokeDasharray="3 3" />
          <text x="0" y="0" fill="#38bdf8" fontSize="13" fontWeight="bold" fontFamily="monospace" letterSpacing="1">
            CAD DWG // STEP {String(step.id).padStart(2, '0')}: {step.phaseNameEn.toUpperCase()}
          </text>
          <text x="0" y="20" fill="#94a3b8" fontSize="11" fontFamily="monospace">
            {step.titleEn.substring(0, 42)}...
          </text>
        </g>

        {/* Dynamic Schematic Geometry by Phase and Type */}
        <g transform="translate(100, 100)">
          {/* BASE FRAME RENDER */}
          {(step.phaseId === 1 || step.phaseId === 2 || step.phaseId === 3 || step.phaseId === 5 || step.phaseId === 7) && (
            <g id="baseFrameGroup">
              {/* Outer Extrusions (Isometric Frame) */}
              {/* Bottom Rear Rail */}
              <polygon points="120,80 480,80 460,95 100,95" fill="#0c4a6e" stroke="#38bdf8" strokeWidth="1.5" />
              {/* Left Side Rail 4080 */}
              <polygon
                points={`100,95 100,${135 + explodeOffset} 220,${255 + explodeOffset} 220,215`}
                fill="url(#alumBeam)"
                stroke="#38bdf8"
                strokeWidth="1.8"
              />
              {/* Right Side Rail 4080 */}
              <polygon
                points={`460,95 460,${135 + explodeOffset} 580,${255 + explodeOffset} 580,215`}
                fill="url(#alumBeam)"
                stroke="#38bdf8"
                strokeWidth="1.8"
              />
              {/* Front Cross Rail 4040 */}
              <polygon
                points={`220,${215 + explodeOffset} 580,${215 + explodeOffset} 580,${255 + explodeOffset} 220,${255 + explodeOffset}`}
                fill="#075985"
                stroke="#38bdf8"
                strokeWidth="2"
              />

              {/* T-Slots grooved lines on front rail */}
              <line x1="220" y1={235 + explodeOffset} x2="580" y2={235 + explodeOffset} stroke="#0284c7" strokeWidth="1.5" />

              {/* Intermediate Cross Members (Step 2 and onwards) */}
              {step.id >= 2 && (
                <g opacity="0.85">
                  <polygon points="270,165 490,165 480,180 260,180" fill="#0369a1" stroke="#38bdf8" strokeWidth="1" />
                  <polygon points="330,190 530,190 520,205 320,205" fill="#0369a1" stroke="#38bdf8" strokeWidth="1" />
                </g>
              )}

              {/* Leveling Feet (Step 3 and onwards) */}
              {step.id >= 3 && (
                <g id="levelingFeet">
                  {/* Front Left Foot */}
                  <g transform="translate(220, 260)">
                    <rect x="-6" y="0" width="12" height="18" fill="#475569" stroke="#94a3b8" strokeWidth="1" />
                    <ellipse cx="0" cy="22" rx="14" ry="6" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" />
                  </g>
                  {/* Front Right Foot */}
                  <g transform="translate(580, 260)">
                    <rect x="-6" y="0" width="12" height="18" fill="#475569" stroke="#94a3b8" strokeWidth="1" />
                    <ellipse cx="0" cy="22" rx="14" ry="6" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" />
                  </g>
                  {/* Rear Left Foot */}
                  <g transform="translate(100, 140)">
                    <rect x="-5" y="0" width="10" height="14" fill="#334155" stroke="#64748b" strokeWidth="1" />
                    <ellipse cx="0" cy="16" rx="10" ry="4" fill="#0f172a" stroke="#38bdf8" strokeWidth="1" />
                  </g>
                  {/* Rear Right Foot */}
                  <g transform="translate(460, 140)">
                    <rect x="-5" y="0" width="10" height="14" fill="#334155" stroke="#64748b" strokeWidth="1" />
                    <ellipse cx="0" cy="16" rx="10" ry="4" fill="#0f172a" stroke="#38bdf8" strokeWidth="1" />
                  </g>
                </g>
              )}

              {/* Y-Axis Linear Rails (Step 4 and onwards) */}
              {step.id >= 4 && (
                <g id="yRails">
                  {/* Left Rail (Silver precision track) */}
                  <polygon points="106,94 112,94 226,214 220,214" fill="#e2e8f0" stroke="#38bdf8" strokeWidth="1.5" />
                  {/* Right Rail */}
                  <polygon points="466,94 472,94 586,214 580,214" fill="#e2e8f0" stroke="#38bdf8" strokeWidth="1.5" />
                </g>
              )}

              {/* Sub-Bed T-Slot Slats (Step 5 and onwards) */}
              {step.id >= 5 && (
                <g id="bedSlats" opacity="0.65">
                  <polygon points="160,130 500,130 520,150 180,150" fill="#075985" stroke="#38bdf8" strokeWidth="1" />
                  <polygon points="190,160 530,160 550,180 210,180" fill="#075985" stroke="#38bdf8" strokeWidth="1" />
                </g>
              )}
            </g>
          )}

          {/* Y-AXIS MOTION & BALLSCREWS (Step 6 to 10) */}
          {step.id >= 6 && step.id <= 10 && (
            <g id="yMotionGroup">
              {/* Bearing Carriages HGH20 */}
              <g transform="translate(160, 150)">
                <rect x="-12" y="-8" width="28" height="20" fill="#dc2626" rx="2" stroke="#fca5a5" strokeWidth="1.5" />
                <rect x="-6" y="-5" width="16" height="14" fill="#1e293b" />
                <circle cx="2" cy="2" r="2" fill="#38bdf8" />
              </g>
              <g transform="translate(520, 150)">
                <rect x="-12" y="-8" width="28" height="20" fill="#dc2626" rx="2" stroke="#fca5a5" strokeWidth="1.5" />
                <rect x="-6" y="-5" width="16" height="14" fill="#1e293b" />
                <circle cx="2" cy="2" r="2" fill="#38bdf8" />
              </g>

              {/* Ballscrew SFU1605 (Step 7+) */}
              {step.id >= 7 && (
                <g>
                  {/* Left Ballscrew helical line */}
                  <line x1="120" y1="102" x2="235" y2="222" stroke="#cbd5e1" strokeWidth="4" strokeDasharray="4 2" />
                  <circle cx="120" cy="102" r="6" fill="#0284c7" stroke="#38bdf8" strokeWidth="1.5" />
                  {/* Right Ballscrew */}
                  <line x1="475" y1="102" x2="590" y2="222" stroke="#cbd5e1" strokeWidth="4" strokeDasharray="4 2" />
                  <circle cx="475" cy="102" r="6" fill="#0284c7" stroke="#38bdf8" strokeWidth="1.5" />
                </g>
              )}

              {/* Stepper Motors NEMA (Step 9+) */}
              {step.id >= 9 && (
                <g>
                  {/* Rear Left Stepper */}
                  <g transform="translate(100, 80)">
                    <rect x="-18" y="-18" width="36" height="36" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" rx="3" />
                    <rect x="-12" y="-12" width="24" height="24" fill="#1e293b" />
                    <circle cx="0" cy="0" r="5" fill="#e2e8f0" />
                  </g>
                  {/* Rear Right Stepper */}
                  <g transform="translate(455, 80)">
                    <rect x="-18" y="-18" width="36" height="36" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" rx="3" />
                    <rect x="-12" y="-12" width="24" height="24" fill="#1e293b" />
                    <circle cx="0" cy="0" r="5" fill="#e2e8f0" />
                  </g>
                </g>
              )}
            </g>
          )}

          {/* GANTRY ASSEMBLY & X-AXIS BEAM (Step 11 to 20, 23, 29, 30) */}
          {(step.id >= 11 && step.id <= 20) || step.id >= 23 ? (
            <g id="gantryAssembly">
              {/* Left Riser Plate (Step 11+) */}
              <polygon
                points={`150,${150 - explodeOffset} 150,${20 - explodeOffset} 185,${20 - explodeOffset} 195,${190 - explodeOffset} 165,${190 - explodeOffset}`}
                fill="#0369a1"
                stroke="#38bdf8"
                strokeWidth="2"
              />
              {/* Right Riser Plate */}
              <polygon
                points={`490,${150 - explodeOffset} 490,${20 - explodeOffset} 525,${20 - explodeOffset} 535,${190 - explodeOffset} 505,${190 - explodeOffset}`}
                fill="#0369a1"
                stroke="#38bdf8"
                strokeWidth="2"
              />

              {/* Main Gantry Beam 8080 (Step 12+) */}
              {step.id >= 12 && (
                <g>
                  {/* Heavy Cross Extrusion */}
                  <rect
                    x="170"
                    y={25 - explodeOffset}
                    width="335"
                    height="75"
                    fill="url(#alumBeam)"
                    stroke="#38bdf8"
                    strokeWidth="2.5"
                    filter="url(#glow)"
                  />
                  {/* T-slots on front of gantry */}
                  <line x1="170" y1={45 - explodeOffset} x2="505" y2={45 - explodeOffset} stroke="#0ea5e9" strokeWidth="1.5" />
                  <line x1="170" y1={65 - explodeOffset} x2="505" y2={65 - explodeOffset} stroke="#0ea5e9" strokeWidth="1.5" />
                  <line x1="170" y1={85 - explodeOffset} x2="505" y2={85 - explodeOffset} stroke="#0ea5e9" strokeWidth="1.5" />
                </g>
              )}

              {/* X-Axis Linear Rails (Step 13+) */}
              {step.id >= 13 && (
                <g>
                  {/* Upper Rail */}
                  <rect x="175" y={32 - explodeOffset} width="325" height="7" fill="#e2e8f0" stroke="#38bdf8" strokeWidth="1" />
                  {/* Lower Rail */}
                  <rect x="175" y={88 - explodeOffset} width="325" height="7" fill="#e2e8f0" stroke="#38bdf8" strokeWidth="1" />
                </g>
              )}

              {/* X-Axis Ballscrew (Step 14+) */}
              {step.id >= 14 && (
                <g>
                  <line
                    x1="180"
                    y1={60 - explodeOffset}
                    x2="495"
                    y2={60 - explodeOffset}
                    stroke="#cbd5e1"
                    strokeWidth="5"
                    strokeDasharray="5 2"
                  />
                </g>
              )}

              {/* X Stepper Motor (Step 15+) */}
              {step.id >= 15 && (
                <g transform={`translate(535, ${35 - explodeOffset})`}>
                  <rect x="0" y="0" width="34" height="42" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" rx="3" />
                  <circle cx="17" cy="21" r="9" fill="#0284c7" />
                </g>
              )}

              {/* Z-Axis Carriage & Backplate (Step 16+) */}
              {step.id >= 16 && (
                <g id="zCarriageGroup" transform={`translate(310, ${15 - (showExploded ? 60 : 0)})`}>
                  {/* Z Backplate */}
                  <rect x="0" y="0" width="80" height="110" fill="#075985" stroke="#38bdf8" strokeWidth="2" rx="4" />

                  {/* Vertical Rails (Step 17+) */}
                  {step.id >= 17 && (
                    <g>
                      <rect x="12" y="8" width="6" height="94" fill="#e2e8f0" stroke="#38bdf8" strokeWidth="1" />
                      <rect x="62" y="8" width="6" height="94" fill="#e2e8f0" stroke="#38bdf8" strokeWidth="1" />
                      {/* Sliding Front Plate */}
                      <rect x="8" y="25" width="64" height="75" fill="#0284c7" stroke="#38bdf8" strokeWidth="1.5" opacity="0.85" />
                    </g>
                  )}

                  {/* Z Lead/Ballscrew & Motor (Step 18+) */}
                  {step.id >= 18 && (
                    <g>
                      <line x1="40" y1="5" x2="40" y2="105" stroke="#cbd5e1" strokeWidth="4" strokeDasharray="3 2" />
                      {/* Top NEMA 23 Motor */}
                      <rect x="23" y="-36" width="34" height="34" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" rx="2" />
                      <circle cx="40" cy="-19" r="6" fill="#0284c7" />
                    </g>
                  )}

                  {/* Spindle Clamp Collar (Step 19+) */}
                  {step.id >= 19 && (
                    <g transform="translate(12, 45)">
                      <rect x="0" y="0" width="56" height="32" fill="#0c4a6e" stroke="#38bdf8" strokeWidth="2" rx="3" />
                      <circle cx="28" cy="16" r="14" fill="#082f49" stroke="#38bdf8" strokeWidth="1.5" />
                    </g>
                  )}

                  {/* 2.2kW Spindle Motor (Step 20+) */}
                  {step.id >= 20 && (
                    <g transform="translate(26, 25)">
                      {/* Spindle Body */}
                      <rect x="0" y="0" width="28" height="90" fill="#0284c7" stroke="#38bdf8" strokeWidth="2" rx="14" />
                      <circle cx="14" cy="45" r="12" fill="url(#spindleGlow)" opacity="0.7" />
                      {/* ER20 Collet Chuck */}
                      <polygon points="4,90 24,90 20,105 8,105" fill="#e2e8f0" stroke="#38bdf8" strokeWidth="1.5" />
                      {/* Milling Tool Bit */}
                      <rect x="12" y="105" width="4" height="22" fill="#f8fafc" stroke="#38bdf8" strokeWidth="1" />
                    </g>
                  )}
                </g>
              )}
            </g>
          ) : null}

          {/* ELECTRONICS & WIRING SCHEMATIC (Step 25 to 28) */}
          {step.phaseId === 6 && (
            <g id="electronicsChassis" transform="translate(130, 20)">
              {/* Control Enclosure Box */}
              <rect x="0" y="0" width="420" height="240" fill="#031525" stroke="#38bdf8" strokeWidth="2" rx="6" />
              <rect x="10" y="10" width="400" height="220" fill="#07192f" stroke="#0284c7" strokeWidth="1" strokeDasharray="4 2" />

              {/* DIN Rails */}
              <rect x="25" y="40" width="370" height="8" fill="#475569" stroke="#94a3b8" strokeWidth="1" />
              <rect x="25" y="140" width="370" height="8" fill="#475569" stroke="#94a3b8" strokeWidth="1" />

              {/* Power Supply (Step 26+) */}
              {step.id >= 26 && (
                <g transform="translate(35, 60)">
                  <rect x="0" y="0" width="100" height="65" fill="#1e293b" stroke="#38bdf8" strokeWidth="1.5" rx="3" />
                  <text x="12" y="24" fill="#38bdf8" fontSize="10" fontFamily="monospace">48V 10A PSU</text>
                  <circle cx="20" cy="45" r="3" fill="#22c55e" />
                  <text x="28" y="48" fill="#22c55e" fontSize="9" fontFamily="monospace">DC-OK</text>
                </g>
              )}

              {/* Stepper Drivers DM556 (Step 27+) */}
              {step.id >= 27 && (
                <g transform="translate(150, 60)">
                  {[0, 1, 2, 3].map((idx) => (
                    <g key={idx} transform={`translate(${idx * 40}, 0)`}>
                      <rect x="0" y="0" width="32" height="65" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" rx="2" />
                      <line x1="4" y1="18" x2="28" y2="18" stroke="#38bdf8" strokeWidth="1" />
                      <text x="4" y="14" fill="#38bdf8" fontSize="8" fontFamily="monospace">D{idx + 1}</text>
                      <rect x="6" y="24" width="20" height="15" fill="#dc2626" />
                      {/* Pulse LEDs */}
                      <circle cx="10" cy="48" r="2" fill="#22c55e" />
                      <circle cx="22" cy="48" r="2" fill="#ef4444" />
                    </g>
                  ))}
                </g>
              )}

              {/* 2.2kW VFD Inverter (Step 28) */}
              {step.id >= 28 && (
                <g transform="translate(320, 55)">
                  <rect x="0" y="0" width="75" height="150" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" rx="4" />
                  <rect x="10" y="15" width="55" height="22" fill="#1e293b" stroke="#0ea5e9" strokeWidth="1" />
                  <text x="16" y="31" fill="#22c55e" fontSize="11" fontFamily="monospace" fontWeight="bold">
                    400.0
                  </text>
                  <circle cx="37" cy="58" r="10" fill="#334155" stroke="#94a3b8" strokeWidth="1" />
                  {/* RUN / STOP Buttons */}
                  <circle cx="24" cy="85" r="6" fill="#16a34a" />
                  <circle cx="50" cy="85" r="6" fill="#dc2626" />
                </g>
              )}

              {/* Controller Breakout Board (Mach3 / GRBL) */}
              <g transform="translate(40, 160)">
                <rect x="0" y="0" width="130" height="50" fill="#065f46" stroke="#34d399" strokeWidth="1.5" rx="3" />
                <text x="10" y="20" fill="#a7f3d0" fontSize="10" fontFamily="monospace" fontWeight="bold">
                  32-BIT CONTROLLER
                </text>
                <line x1="10" y1="30" x2="120" y2="30" stroke="#34d399" strokeWidth="1" />
                <circle cx="20" cy="40" r="3" fill="#38bdf8" />
                <text x="28" y="43" fill="#a7f3d0" fontSize="9" fontFamily="monospace">USB / ETH</text>
              </g>

              {/* E-Stop Button */}
              {step.id >= 28 && (
                <g transform="translate(200, 160)">
                  <circle cx="24" cy="24" r="20" fill="#991b1b" stroke="#f87171" strokeWidth="2" />
                  <circle cx="24" cy="24" r="14" fill="#dc2626" />
                  <text x="14" y="28" fill="#ffffff" fontSize="11" fontWeight="bold" fontFamily="sans-serif">
                    STOP
                  </text>
                </g>
              )}
            </g>
          )}

          {/* FIRST CUT / SPOILBOARD FINALE (Step 30) */}
          {step.id === 30 && (
            <g id="firstCutEffects">
              {/* MDF Spoilboard */}
              <polygon points="170,125 490,125 515,190 195,190" fill="#b45309" stroke="#f59e0b" strokeWidth="1.5" opacity="0.8" />
              {/* Grid Facing toolpaths */}
              <line x1="200" y1="135" x2="480" y2="135" stroke="#fde047" strokeWidth="1" strokeDasharray="3 3" />
              <line x1="210" y1="150" x2="490" y2="150" stroke="#fde047" strokeWidth="1" strokeDasharray="3 3" />
              <line x1="220" y1="165" x2="500" y2="165" stroke="#fde047" strokeWidth="1" strokeDasharray="3 3" />
              {/* Completed CNC Badge */}
              <g transform="translate(280, 205)">
                <rect x="0" y="0" width="140" height="30" fill="#065f46" rx="4" stroke="#34d399" strokeWidth="1.5" />
                <text x="12" y="20" fill="#a7f3d0" fontSize="12" fontWeight="bold" fontFamily="monospace">
                  ✓ MACHINE VERIFIED
                </text>
              </g>
            </g>
          )}
        </g>

        {/* DIMENSION CALLOUTS OVERLAY */}
        {showDimensions && (
          <g id="dimensionLayer" className="font-mono text-xs">
            {/* Length Dimension Line (X axis) */}
            <g transform="translate(190, 390)">
              <line x1="0" y1="0" x2="380" y2="0" stroke="#38bdf8" strokeWidth="1.5" />
              <line x1="0" y1="-8" x2="0" y2="8" stroke="#38bdf8" strokeWidth="1.5" />
              <line x1="380" y1="-8" x2="380" y2="8" stroke="#38bdf8" strokeWidth="1.5" />
              <rect x="145" y="-12" width="90" height="18" fill="#031525" stroke="#38bdf8" strokeWidth="1" rx="2" />
              <text x="155" y="1" fill="#38bdf8" fontSize="11" fontWeight="bold">
                1000.00 mm
              </text>
            </g>
            {/* Height / Spec Dimension */}
            <g transform="translate(70, 160)">
              <line x1="0" y1="0" x2="0" y2="150" stroke="#38bdf8" strokeWidth="1.5" />
              <line x1="-6" y1="0" x2="6" y2="0" stroke="#38bdf8" strokeWidth="1.5" />
              <line x1="-6" y1="150" x2="6" y2="150" stroke="#38bdf8" strokeWidth="1.5" />
              <rect x="-45" y="65" width="90" height="18" fill="#031525" stroke="#38bdf8" strokeWidth="1" rx="2" />
              <text x="-38" y="78" fill="#38bdf8" fontSize="11" fontWeight="bold">
                TOL ±0.02
              </text>
            </g>
          </g>
        )}

        {/* FASTENERS & BOLTS CALLOUTS */}
        {showFasteners && (
          <g id="fastenersLayer">
            {/* Pulsing Bolt Indicators */}
            <circle cx="320" cy="335" r="5" fill="#f59e0b" stroke="#ffffff" strokeWidth="1.5" />
            <circle cx="680" cy="335" r="5" fill="#f59e0b" stroke="#ffffff" strokeWidth="1.5" />
            <circle cx="200" cy="215" r="5" fill="#f59e0b" stroke="#ffffff" strokeWidth="1.5" />
            <circle cx="560" cy="215" r="5" fill="#f59e0b" stroke="#ffffff" strokeWidth="1.5" />
            {/* Torque Spec Badge */}
            <g transform="translate(560, 410)">
              <rect x="0" y="0" width="150" height="26" fill="#78350f" rx="3" stroke="#f59e0b" strokeWidth="1.5" />
              <text x="12" y="17" fill="#fef3c7" fontSize="11" fontFamily="monospace" fontWeight="bold">
                ⚡ TORQUE: {step.specs.torque || '9.0 N·m'}
              </text>
            </g>
          </g>
        )}

        {/* MOTION VECTORS & ARROWS */}
        {showMotion && (
          <g id="motionVectorLayer">
            {/* Y Travel Arrows */}
            <g transform="translate(140, 260)">
              <line x1="0" y1="0" x2="50" y2="50" stroke="#22c55e" strokeWidth="2.5" strokeDasharray="5 3" />
              <polygon points="54,54 44,48 48,44" fill="#22c55e" />
              <text x="20" y="15" fill="#22c55e" fontSize="11" fontFamily="monospace" fontWeight="bold">±Y AXIS</text>
            </g>
            {/* X Travel Arrow */}
            <g transform="translate(360, 90)">
              <line x1="-50" y1="0" x2="50" y2="0" stroke="#ef4444" strokeWidth="2.5" strokeDasharray="5 3" />
              <polygon points="56,0 48,-4 48,4" fill="#ef4444" />
              <polygon points="-56,0 -48,-4 -48,4" fill="#ef4444" />
              <text x="-25" y="-8" fill="#ef4444" fontSize="11" fontFamily="monospace" fontWeight="bold">±X AXIS</text>
            </g>
            {/* Z Travel Arrow */}
            <g transform="translate(450, 130)">
              <line x1="0" y1="-30" x2="0" y2="30" stroke="#38bdf8" strokeWidth="2.5" strokeDasharray="5 3" />
              <polygon points="0,35 -4,28 4,28" fill="#38bdf8" />
              <polygon points="0,-35 -4,-28 4,-28" fill="#38bdf8" />
              <text x="10" y="4" fill="#38bdf8" fontSize="11" fontFamily="monospace" fontWeight="bold">±Z</text>
            </g>
          </g>
        )}
      </svg>

      {/* Viewport Floating Info Watermark */}
      <div className="absolute bottom-3 left-4 flex items-center gap-3 text-xs font-mono text-cyan-400/80 bg-slate-900/80 backdrop-blur px-3 py-1.5 rounded border border-cyan-800/50">
        <span className="inline-block w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
        <span>CAD ENGINE v3.8</span>
        <span className="text-slate-600">|</span>
        <span>ISOMETRIC 30° / 30°</span>
        <span className="text-slate-600">|</span>
        <span>ZOOM: {Math.round(zoom * 100)}%</span>
      </div>
    </div>
  );
};
