import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Ruler,
  Maximize2,
  FileCode,
  Download,
  Upload,
  Copy,
  Check,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Layers,
  Settings2,
  Sparkles,
  Eye,
  Sliders,
  Scissors,
  Cpu,
  Info,
  CheckCircle2,
  AlertCircle,
  FileText,
  ChevronDown,
  Box,
  Cuboid,
  Move,
  RotateCw,
  Trash2,
  MousePointer,
  Hand,
  Plus,
  Split,
  GitMerge,
  ArrowRightLeft,
  X,
  CopyPlus,
  FilePlus,
} from 'lucide-react';

interface DesignSizeEditorTabProps {
  lang: 'ur' | 'en' | 'both';
  onSelectAssemblyStep?: (stepId: number) => void;
}

type Unit = 'mm' | 'inch';
type ScaleMode = 'fit_proportional' | 'stretch' | 'custom';
type OriginPoint = 'bottom_left' | 'center' | 'top_left';
type ControllerPreset = 'mach3' | 'ncstudio' | 'dsp' | 'grbl';
type WoodType = 'sheesham' | 'walnut' | 'teak' | 'mdf' | 'deodar';

interface Point2D {
  x: number;
  y: number;
  z?: number;
}

interface ToolpathSegment {
  type: 'rapid' | 'cut' | 'arc';
  points: Point2D[];
  depth?: number;
}

export interface DesignElement {
  id: string;
  name: string;
  nameUr: string;
  type: 'contour' | 'medallion' | 'border' | 'mesh' | 'raster';
  xOffset: number; // in mm
  yOffset: number; // in mm
  scale: number; // 1.0 = 100%
  rotation: number; // in degrees
  visible: boolean;
  segments: ToolpathSegment[];
  bounds: { minX: number; maxX: number; minY: number; maxY: number; width: number; height: number };
}

export interface SourceFileData {
  fileName: string;
  fileType: string;
  rawSegments: ToolpathSegment[];
  originalBounds: { minX: number; maxX: number; minY: number; maxY: number; width: number; height: number };
  loadedImage: HTMLImageElement | null;
  elements: DesignElement[];
}

interface PresetPattern {
  id: string;
  nameUr: string;
  nameEn: string;
  category: string;
  descriptionUr: string;
  descriptionEn: string;
  generatePaths: (w: number, h: number, margin: number) => ToolpathSegment[];
}

export const DesignSizeEditorTab: React.FC<DesignSizeEditorTabProps> = ({
  lang,
  onSelectAssemblyStep,
}) => {
  // Panel Dimensions & Setup State
  const [unit, setUnit] = useState<Unit>('mm');
  const [panelWidth, setPanelWidth] = useState<number>(450); // 450 mm
  const [panelHeight, setPanelHeight] = useState<number>(900); // 900 mm (standard Dila)
  const [panelThickness, setPanelThickness] = useState<number>(25); // 25 mm (1 inch board)
  const [margin, setMargin] = useState<number>(20); // 20 mm safe border

  // Machining & Tool Parameters
  const [cutDepth, setCutDepth] = useState<number>(4.0); // 4mm deep carving
  const [toolDiameter, setToolDiameter] = useState<number>(6.0); // 6mm V-bit / ballnose
  const [feedRate, setFeedRate] = useState<number>(2400); // mm/min
  const [plungeRate, setPlungeRate] = useState<number>(600); // mm/min
  const [safeZ, setSafeZ] = useState<number>(10); // 10mm above board
  const [spindleSpeed, setSpindleSpeed] = useState<number>(18000); // 18000 RPM

  // Scaling & Layout State
  const [scaleMode, setScaleMode] = useState<ScaleMode>('fit_proportional');
  const [customScalePercent, setCustomScalePercent] = useState<number>(100);
  const [origin, setOrigin] = useState<OriginPoint>('bottom_left');
  const [woodType, setWoodType] = useState<WoodType>('sheesham');
  const [controller, setController] = useState<ControllerPreset>('mach3');

  // Loaded File A (Primary Workspace) & Toolpaths State
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [editableGCode, setEditableGCode] = useState<string>('');
  const [gcodeValidation, setGcodeValidation] = useState<string>('');
  const [fileType, setFileType] = useState<string>('');
  const [originalBounds, setOriginalBounds] = useState<{ minX: number; maxX: number; minY: number; maxY: number; width: number; height: number }>({
    minX: 0,
    maxX: 400,
    minY: 0,
    maxY: 800,
    width: 400,
    height: 800,
  });
  const [rawSegments, setRawSegments] = useState<ToolpathSegment[]>([]);
  const [activePresetId, setActivePresetId] = useState<string>('arch_dila');

  // Dual File Upload & Design Merging State (File A & File B)
  const [fileBData, setFileBData] = useState<SourceFileData | null>(null);
  const [selectedFileBElementId, setSelectedFileBElementId] = useState<string | null>(null);
  const [canvasViewLayout, setCanvasViewLayout] = useState<'primary' | 'split' | 'merged'>('primary');
  const [importNotification, setImportNotification] = useState<string>('');
  const fileBInputRef = useRef<HTMLInputElement | null>(null);

  // Interactive Elements Editing & Manipulation State
  const [elements, setElements] = useState<DesignElement[]>([]);
  const [selectedElementId, setSelectedElementId] = useState<string | null>(null);
  const [canvasTool, setCanvasTool] = useState<'select' | 'move' | 'pan'>('select');
  const [isDraggingElement, setIsDraggingElement] = useState<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number; initialOffsetX: number; initialOffsetY: number } | null>(null);
  const panStartRef = useRef<{ x: number; y: number; initialPanX: number; initialPanY: number } | null>(null);

  // Canvas View Controls & Modes
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [viewMode, setViewMode] = useState<'2d' | '3d'>('2d');
  const [loadedImage, setLoadedImage] = useState<HTMLImageElement | null>(null);
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [showRapidMoves, setShowRapidMoves] = useState<boolean>(true);
  const [showGrid, setShowGrid] = useState<boolean>(true);

  // Export / Copy Feedback
  const [copiedGcode, setCopiedGcode] = useState<boolean>(false);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [showGcodePreview, setShowGcodePreview] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Translations Dictionary
  const t = {
    title: lang === 'en' ? '3D CAD / RLF Size Resizer & Design Creator' : lang === 'both' ? 'سائز ایڈیٹر اور ڈیزائن میکر (CAD / RLF Resizer)' : 'سائز ایڈیٹر اور ڈیزائن میکر',
    subtitle: lang === 'en'
      ? 'Dynamically resize, scale, and generate CNC toolpaths for wooden panels, doors, and dilas. Export ready-to-run G-code for Mach3, NCStudio & DSP.'
      : 'لکڑی کے تختوں اور دلوں کے لیے آرٹ کیم، آر ایل ایف، اور جی کوڈ کا سائز تبدیل کریں اور حقیقی مشین کوڈ برآمد کریں۔',
    panelDimsHeader: lang === 'en' ? '1. Wooden Panel Dimensions' : '1. لکڑی کے تختے / دلا کا سائز',
    widthLabel: lang === 'en' ? 'Width (چوڑائی)' : 'چوڑائی (Width)',
    heightLabel: lang === 'en' ? 'Height (لمبائی)' : 'لمبائی (Height)',
    thicknessLabel: lang === 'en' ? 'Thickness (موٹائی)' : 'موٹائی (Thickness)',
    marginLabel: lang === 'en' ? 'Border Margin (حاشیہ)' : 'حاشیہ (Margin)',
    unitToggle: lang === 'en' ? 'Unit System' : 'پیمائش کا نظام',
    woodMaterial: lang === 'en' ? 'Wood Species' : 'لکڑی کی قسم',
    presetSizes: lang === 'en' ? 'Standard Workshop Sizes' : 'معیاری ورکشاپ سائزز',
    loadDesignHeader: lang === 'en' ? '2. Load CAD / RLF / CNC File or Preset' : '2. فائل اپ لوڈ کریں یا ڈیزائن منتخب کریں',
    uploadBtn: lang === 'en' ? 'Upload CNC / CAD File' : 'فائل اپ لوڈ کریں (.rlf, .gcode, .dxf, .stl)',
    uploadSub: lang === 'en' ? 'Supports .nc, .tap, .gcode, .rlf, .art, .dxf, .svg, .stl' : 'تمام فارمیٹس سپورٹڈ ہیں',
    presetPatternsTitle: lang === 'en' ? 'Pakistani Workshop Templates' : 'پری سیٹ ووڈ کرافٹ ڈیزائنز',
    scalingHeader: lang === 'en' ? '3. Smart Scaling & Tool Parameters' : '3. اسکیلنگ اور ٹول سیٹنگز',
    scaleModeLabel: lang === 'en' ? 'Scaling Mode' : 'اسکیلنگ کا طریقہ',
    fitProp: lang === 'en' ? 'Fit Proportional (Safe)' : 'متناسب فٹ (تناسب برقرار)',
    stretchFit: lang === 'en' ? 'Stretch to Exact Bounds' : 'پورے تختے پر کھینچیں (Stretch)',
    customScale: lang === 'en' ? 'Custom Scale %' : 'اپنی مرضی کا سائز %',
    toolDiameterLabel: lang === 'en' ? 'Tool Bit Diameter' : 'بٹ کا قطر (Tool Dia)',
    cutDepthLabel: lang === 'en' ? 'Carving Depth (Z)' : 'کٹائی کی گہرائی (Depth)',
    feedRateLabel: lang === 'en' ? 'Feed Rate (X/Y)' : 'فیڈ ریٹ (رفتار)',
    plungeRateLabel: lang === 'en' ? 'Plunge Rate (Z)' : 'پلنج ریٹ (Z اسپیڈ)',
    controllerLabel: lang === 'en' ? 'Machine Controller' : 'سی این سی کنٹرولر',
    originLabel: lang === 'en' ? 'Origin (X0, Y0)' : 'زیرو پوائنٹ (Origin)',
    exportHeader: lang === 'en' ? '4. Real G-Code Generator & Export' : '4. جی کوڈ ڈاؤن لوڈ اور ایکسپورٹ',
    downloadGcodeBtn: lang === 'en' ? 'Download G-Code (.nc)' : 'جی کوڈ ڈاؤن لوڈ کریں (.nc)',
    downloadTapBtn: lang === 'en' ? 'Download DSP (.tap)' : 'ڈی ایس پی فائل (.tap)',
    downloadSpecsBtn: lang === 'en' ? 'Save Resized Specs (JSON)' : 'سیٹ اپ شیٹ محفوظ کریں',
    viewGcodeBtn: lang === 'en' ? 'Preview G-Code' : 'کوڈ دیکھیں',
    copyGcode: lang === 'en' ? 'Copy G-Code' : 'کوڈ کاپی کریں',
    copiedText: lang === 'en' ? 'Copied to Clipboard!' : 'کاپی ہو گیا!',
    canvasTitle: lang === 'en' ? 'Interactive 2D Toolpath Visualizer' : 'انٹرایکٹو 2D لکڑی اور ٹول پاتھ پریویو',
    dimensionsBadge: lang === 'en' ? 'Panel Bounds' : 'پینل پیمائش',
    totalPathLength: lang === 'en' ? 'Estimated Cut Length:' : 'کل ٹول پاتھ لمبائی:',
    estMachiningTime: lang === 'en' ? 'Est. Machining Time:' : 'تخمینہ شدہ کٹائی کا وقت:',
    sheeshamWood: lang === 'en' ? 'Sheesham (Indian Rosewood)' : 'شیشم (Indian Rosewood)',
    walnutWood: lang === 'en' ? 'Walnut (Akhroot)' : 'اخروٹ (Swat Walnut)',
    teakWood: lang === 'en' ? 'Teak (Sagwan)' : 'ساگوان (Burma Teak)',
    mdfWood: lang === 'en' ? 'MDF / High Density' : 'ایم ڈی ایف (MDF Board)',
    deodarWood: lang === 'en' ? 'Deodar (Cedar)' : 'دیودار (Himalayan Cedar)',
    resetView: lang === 'en' ? 'Reset Fit' : 'ری سیٹ ویو',
    zoomIn: lang === 'en' ? 'Zoom In' : 'زوم ان',
    zoomOut: lang === 'en' ? 'Zoom Out' : 'زوم آؤٹ',
    rapidToggle: lang === 'en' ? 'Rapid Moves (G00)' : 'ریپڈ مووز',
    gridToggle: lang === 'en' ? 'Dimensions Grid' : 'گریڈ لائنز',
    view2dLabel: lang === 'en' ? '2D Design View' : '2D ڈیزائن ویو',
    view3dLabel: lang === 'en' ? '3D Relief & Depth Preview' : '3D ریلیف اور نقاشی پریویو',
    elementControlsHeader: lang === 'en' ? 'Element & Motif Editing' : 'ڈیزائن اور موٹیف ایڈیٹنگ',
    selectElementHint: lang === 'en' ? 'Click on an element in the canvas or list below to drag, resize, or rotate.' : 'کینوس یا نیچے دی گئی فہرست سے کسی بھی موٹیف پر کلک کر کے اسے گھمائیں، حرکت دیں یا ری سائز کریں۔',
    toolSelect: lang === 'en' ? 'Select & Drag' : 'سلیکٹ اور ڈریگ',
    toolPan: lang === 'en' ? 'Pan Canvas' : 'کینوس گھمائیں',
    rotateBtn: lang === 'en' ? 'Rotate 15°' : '15 ڈگری گھمائیں',
    resetElement: lang === 'en' ? 'Reset Position' : 'پوزیشن ری سیٹ',
    scaleElement: lang === 'en' ? 'Scale' : 'سائز',
    elementsCount: lang === 'en' ? 'Editable Motifs:' : 'کل ڈیزائن موٹیفس:',
    dualFileHeader: lang === 'en' ? 'Dual File Merging System (File A & B)' : 'ڈوئل فائل مرجنگ سسٹم (فائل A اور B)',
    fileALabel: lang === 'en' ? 'Primary Workspace (File A)' : 'پرائمری فائل A (ورک اسپیس دلا)',
    fileBLabel: lang === 'en' ? 'Secondary Source File (File B)' : 'ثانوی سورس فائل B (موٹیف سورس)',
    uploadFileABtn: lang === 'en' ? 'Upload File A' : 'فائل A اپ لوڈ کریں',
    uploadFileBBtn: lang === 'en' ? 'Upload Secondary File B' : 'سورس فائل B اپ لوڈ کریں (.dxf, .svg, .stl, .png)',
    fileBSourceTitle: lang === 'en' ? 'File B Motifs & Extraction Library' : 'فائل B کے موٹیفس اور ڈیزائن لائبریری',
    fileBSubtitle: lang === 'en'
      ? 'Extract specific flowers, medallions, or jaali borders from File B and merge them directly into File A workspace.'
      : 'فائل B سے پھول، تمغہ یا حاشیہ کاپی کر کے پرائمری تختے میں شامل کریں۔',
    importElementBtn: lang === 'en' ? '➕ Import to File A' : '➕ فائل A میں شامل کریں',
    mergeAllBBtn: lang === 'en' ? '✨ Merge All Motifs into File A' : '✨ تمام موٹیف فائل A میں شامل کریں',
    clearFileBBtn: lang === 'en' ? 'Remove File B' : 'فائل B ختم کریں',
    layoutPrimary: lang === 'en' ? 'Primary (File A)' : 'پرائمری (فائل A)',
    layoutSplit: lang === 'en' ? 'Dual Split (A | B)' : 'ڈوئل اسپلٹ (A | B)',
    layoutMerged: lang === 'en' ? 'Merged Preview' : 'مشترکہ ویو',
    deleteElement: lang === 'en' ? 'Delete Motif' : 'موٹیف ختم کریں',
  };

  // Convert mm to current unit for display
  const toDisplayUnit = (valInMm: number) => {
    return unit === 'inch' ? Number((valInMm / 25.4).toFixed(3)) : valInMm;
  };

  // 5 Pakistani Woodcraft Preset Patterns Generator
  const presetPatterns: PresetPattern[] = useMemo(() => [
    {
      id: 'arch_dila',
      nameUr: 'محراب و دلا دروازہ',
      nameEn: 'Mihrab Arch Door Panel',
      category: 'Doors & Windows',
      descriptionUr: 'روایتی مغلائی محراب، ڈبل حاشیہ، اور اندرونی نفاست کے ساتھ دلا فریم۔',
      descriptionEn: 'Classical architectural pointed trefoil arch with inner chamfered profile for solid wood door panels.',
      generatePaths: (w: number, h: number, pad: number) => {
        const paths: ToolpathSegment[] = [];
        const xMin = pad;
        const xMax = w - pad;
        const yMin = pad;
        const yMax = h - pad;
        const width = xMax - xMin;
        const height = yMax - yMin;
        const archHeight = height * 0.32;
        const shoulderY = yMax - archHeight;

        // Outer Border
        paths.push({
          type: 'cut',
          points: [
            { x: xMin, y: yMin },
            { x: xMax, y: yMin },
            { x: xMax, y: shoulderY },
            // Arch curve (pointed Gothic/Mughal arch)
            ...Array.from({ length: 21 }, (_, i) => {
              const t = i / 20;
              const angle = Math.PI * (1 - t);
              const x = (xMin + xMax) / 2 + (width / 2) * Math.cos(angle);
              const archRise = Math.sin(angle) * archHeight * 1.25;
              const y = shoulderY + archRise;
              return { x, y: Math.min(y, yMax) };
            }),
            { x: xMin, y: shoulderY },
            { x: xMin, y: yMin },
          ],
        });

        // Inner Offset Groove (Offset 20mm inward)
        const iPad = 22;
        if (width > iPad * 2 && height > iPad * 2) {
          const ixMin = xMin + iPad;
          const ixMax = xMax - iPad;
          const iyMin = yMin + iPad;
          const ishoulderY = shoulderY - iPad * 0.5;
          const iArchRise = archHeight * 1.1;

          paths.push({
            type: 'cut',
            points: [
              { x: ixMin, y: iyMin },
              { x: ixMax, y: iyMin },
              { x: ixMax, y: ishoulderY },
              ...Array.from({ length: 21 }, (_, i) => {
                const t = i / 20;
                const angle = Math.PI * (1 - t);
                const x = (ixMin + ixMax) / 2 + ((ixMax - ixMin) / 2) * Math.cos(angle);
                const y = ishoulderY + Math.sin(angle) * iArchRise;
                return { x, y: Math.min(y, yMax - iPad) };
              }),
              { x: ixMin, y: ishoulderY },
              { x: ixMin, y: iyMin },
            ],
          });
        }

        // Center Medallion / Chinar Rosette Centerpiece
        const cx = (xMin + xMax) / 2;
        const cy = yMin + height * 0.42;
        const r = Math.min(width, height) * 0.16;
        const starPoints: Point2D[] = [];
        for (let i = 0; i <= 32; i++) {
          const th = (i / 32) * Math.PI * 2;
          const petal = r * (0.85 + 0.25 * Math.cos(8 * th));
          starPoints.push({
            x: cx + petal * Math.cos(th),
            y: cy + petal * Math.sin(th),
          });
        }
        paths.push({ type: 'cut', points: starPoints });

        return paths;
      },
    },
    {
      id: 'jaali_lattice',
      nameUr: 'جالی دار ہندسی جالی',
      nameEn: 'Jaali Geometric Lattice Grid',
      category: 'Screen & Partitions',
      descriptionUr: '8 رخی اسلامی ہندسی جالی، فرنیچر اور ونڈو اسکرینز کی پرفیکٹ سی این سی کٹائی۔',
      descriptionEn: '8-point star interlocking Islamic latticework toolpaths for partitions and cabinet speaker grills.',
      generatePaths: (w: number, h: number, pad: number) => {
        const paths: ToolpathSegment[] = [];
        const xMin = pad;
        const xMax = w - pad;
        const yMin = pad;
        const yMax = h - pad;

        // Outer border
        paths.push({
          type: 'cut',
          points: [
            { x: xMin, y: yMin },
            { x: xMax, y: yMin },
            { x: xMax, y: yMax },
            { x: xMin, y: yMax },
            { x: xMin, y: yMin },
          ],
        });

        // 8-Point Star Grid repeats
        const step = Math.max(50, Math.min(w, h) / 6);
        for (let x = xMin + step / 2; x <= xMax - step / 2; x += step) {
          for (let y = yMin + step / 2; y <= yMax - step / 2; y += step) {
            const rad = step * 0.42;
            const starPts: Point2D[] = [];
            for (let a = 0; a <= 16; a++) {
              const ang = (a / 16) * Math.PI * 2;
              const r = a % 2 === 0 ? rad : rad * 0.52;
              starPts.push({ x: x + r * Math.cos(ang), y: y + r * Math.sin(ang) });
            }
            paths.push({ type: 'cut', points: starPts });
          }
        }
        return paths;
      },
    },
    {
      id: 'floral_vines',
      nameUr: 'روایتی بیل بوٹے اور حاشیہ',
      nameEn: 'Chinar Floral Vine Border',
      category: 'Carving & Moulding',
      descriptionUr: 'روایتی چنار پتیاں اور لہراتی بیلیں جو کلاسک الماری اور بیڈ بارڈرز کے لیے استعمال ہوتی ہیں۔',
      descriptionEn: 'Flowing vine arabesque curves with scalloped chinar leaves along the perimeter.',
      generatePaths: (w: number, h: number, pad: number) => {
        const paths: ToolpathSegment[] = [];
        const xMin = pad;
        const xMax = w - pad;
        const yMin = pad;
        const yMax = h - pad;

        // Perimeter Wave Path
        const wavePts: Point2D[] = [];
        const nPerim = 60;
        // Bottom edge wave
        for (let i = 0; i <= nPerim; i++) {
          const t = i / nPerim;
          const x = xMin + (xMax - xMin) * t;
          const y = yMin + 8 * Math.sin(t * Math.PI * 8);
          wavePts.push({ x, y });
        }
        // Right edge wave
        for (let i = 0; i <= nPerim; i++) {
          const t = i / nPerim;
          const y = yMin + (yMax - yMin) * t;
          const x = xMax - 8 * Math.sin(t * Math.PI * 8);
          wavePts.push({ x, y });
        }
        // Top edge wave
        for (let i = 0; i <= nPerim; i++) {
          const t = i / nPerim;
          const x = xMax - (xMax - xMin) * t;
          const y = yMax - 8 * Math.sin(t * Math.PI * 8);
          wavePts.push({ x, y });
        }
        // Left edge wave
        for (let i = 0; i <= nPerim; i++) {
          const t = i / nPerim;
          const y = yMax - (yMax - yMin) * t;
          const x = xMin + 8 * Math.sin(t * Math.PI * 8);
          wavePts.push({ x, y });
        }
        wavePts.push(wavePts[0]);
        paths.push({ type: 'cut', points: wavePts });

        // Center oval with floral petals
        const cx = (xMin + xMax) / 2;
        const cy = (yMin + yMax) / 2;
        const rx = (xMax - xMin) * 0.28;
        const ry = (yMax - yMin) * 0.38;
        const ovalPts: Point2D[] = [];
        for (let i = 0; i <= 36; i++) {
          const ang = (i / 36) * Math.PI * 2;
          const mod = 1 + 0.12 * Math.cos(ang * 6);
          ovalPts.push({ x: cx + rx * mod * Math.cos(ang), y: cy + ry * mod * Math.sin(ang) });
        }
        paths.push({ type: 'cut', points: ovalPts });

        return paths;
      },
    },
    {
      id: 'islamic_star_box',
      nameUr: 'شاہی ہندسی فریم (Modern)',
      nameEn: 'Imperial Geometric Box Frame',
      category: 'Contemporary Frames',
      descriptionUr: 'ماڈرن انٹیریئر اور فرنیچر پینلز کے لیے ڈبل بیول فریم اور کونوں میں کٹ ورک۔',
      descriptionEn: 'Double-nested mitered bevel frame with 45-degree chamfered corners and diamond center.',
      generatePaths: (w: number, h: number, pad: number) => {
        const paths: ToolpathSegment[] = [];
        const x0 = pad;
        const y0 = pad;
        const x1 = w - pad;
        const y1 = h - pad;
        const cSize = Math.min(w, h) * 0.12;

        // Outer Chamfered Box
        paths.push({
          type: 'cut',
          points: [
            { x: x0 + cSize, y: y0 },
            { x: x1 - cSize, y: y0 },
            { x: x1, y: y0 + cSize },
            { x: x1, y: y1 - cSize },
            { x: x1 - cSize, y: y1 },
            { x: x0 + cSize, y: y1 },
            { x: x0, y: y1 - cSize },
            { x: x0, y: y0 + cSize },
            { x: x0 + cSize, y: y0 },
          ],
        });

        // Inner Inset Box
        const off = 25;
        if (x1 - x0 > off * 2 && y1 - y0 > off * 2) {
          paths.push({
            type: 'cut',
            points: [
              { x: x0 + off, y: y0 + off },
              { x: x1 - off, y: y0 + off },
              { x: x1 - off, y: y1 - off },
              { x: x0 + off, y: y1 - off },
              { x: x0 + off, y: y0 + off },
            ],
          });
        }

        // Diamond Center Piece
        const cx = (x0 + x1) / 2;
        const cy = (y0 + y1) / 2;
        const dw = (x1 - x0) * 0.25;
        const dh = (y1 - y0) * 0.25;
        paths.push({
          type: 'cut',
          points: [
            { x: cx, y: cy - dh },
            { x: cx + dw, y: cy },
            { x: cx, y: cy + dh },
            { x: cx - dw, y: cy },
            { x: cx, y: cy - dh },
          ],
        });

        return paths;
      },
    },
    {
      id: 'rosette_carve',
      nameUr: 'پھولدار تمغہ و شیشم موٹیف',
      nameEn: 'Classic Rosette Medallion',
      category: 'Wood Rosettes',
      descriptionUr: '12 پتیوں والا روایتی نقشین تمغہ برائے چھت کے کونے اور میز کے مڈل پینل۔',
      descriptionEn: '12-lobed classical medallion with concentric step-down toolpaths.',
      generatePaths: (w: number, h: number, pad: number) => {
        const paths: ToolpathSegment[] = [];
        const cx = w / 2;
        const cy = h / 2;
        const maxR = (Math.min(w, h) - pad * 2) * 0.44;

        // Outer Scalloped Ring
        const ring1: Point2D[] = [];
        for (let i = 0; i <= 72; i++) {
          const a = (i / 72) * Math.PI * 2;
          const r = maxR * (0.88 + 0.12 * Math.cos(a * 12));
          ring1.push({ x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) });
        }
        paths.push({ type: 'cut', points: ring1 });

        // Middle Ring
        const ring2: Point2D[] = [];
        for (let i = 0; i <= 72; i++) {
          const a = (i / 72) * Math.PI * 2;
          const r = maxR * 0.65 * (0.92 + 0.08 * Math.cos(a * 12));
          ring2.push({ x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) });
        }
        paths.push({ type: 'cut', points: ring2 });

        // Center Ring
        const ring3: Point2D[] = [];
        for (let i = 0; i <= 36; i++) {
          const a = (i / 36) * Math.PI * 2;
          ring3.push({ x: cx + maxR * 0.3 * Math.cos(a), y: cy + maxR * 0.3 * Math.sin(a) });
        }
        paths.push({ type: 'cut', points: ring3 });

        return paths;
      },
    },
  ], []);

  // Helper: compute bounding box of a list of segments
  const computeSegmentsBounds = (segs: ToolpathSegment[]) => {
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    segs.forEach((s) => {
      s.points.forEach((pt) => {
        minX = Math.min(minX, pt.x);
        maxX = Math.max(maxX, pt.x);
        minY = Math.min(minY, pt.y);
        maxY = Math.max(maxY, pt.y);
      });
    });
    return {
      minX: isFinite(minX) ? minX : 0,
      maxX: isFinite(maxX) ? maxX : 100,
      minY: isFinite(minY) ? minY : 0,
      maxY: isFinite(maxY) ? maxY : 100,
      width: Math.max(10, maxX - minX),
      height: Math.max(10, maxY - minY),
    };
  };

  // Convert rawSegments into discrete draggable/editable DesignElement objects
  useEffect(() => {
    if (rawSegments.length === 0) {
      setElements([]);
      setSelectedElementId(null);
      return;
    }

    // Group segments into logical design components / motifs
    const newElements: DesignElement[] = [];

    if (rawSegments.length === 1) {
      const b = computeSegmentsBounds(rawSegments);
      newElements.push({
        id: 'element_1',
        name: uploadedFileName ? 'Main Artwork' : 'Design Outline',
        nameUr: uploadedFileName ? 'مرکزی ڈیزائن' : 'مرکزی خاکہ',
        type: 'contour',
        xOffset: 0,
        yOffset: 0,
        scale: 1,
        rotation: 0,
        visible: true,
        segments: rawSegments,
        bounds: b,
      });
    } else if (rawSegments.length <= 4) {
      rawSegments.forEach((seg, idx) => {
        const b = computeSegmentsBounds([seg]);
        const namesEn = ['Outer Border', 'Inner Profile', 'Center Motif', 'Accent Detail'];
        const namesUr = ['بیرونی حاشیہ', 'اندرونی فریم', 'مرکزی تمغہ', 'نقشین تفصیل'];
        newElements.push({
          id: `element_${idx + 1}`,
          name: namesEn[idx] || `Motif ${idx + 1}`,
          nameUr: namesUr[idx] || `نقش ${idx + 1}`,
          type: idx === 0 ? 'border' : idx === 2 ? 'medallion' : 'contour',
          xOffset: 0,
          yOffset: 0,
          scale: 1,
          rotation: 0,
          visible: true,
          segments: [seg],
          bounds: b,
        });
      });
    } else {
      // Multiple segments (e.g. jaali grid, DXF paths, SVG elements)
      // Partition into: 1) Outer Border/Frame (first 1-2 largest), 2) Inner Pattern/Carving Grid
      const firstSeg = rawSegments[0];
      const restSegs = rawSegments.slice(1);
      const b1 = computeSegmentsBounds([firstSeg]);
      const b2 = computeSegmentsBounds(restSegs);

      newElements.push({
        id: 'element_border',
        name: 'Outer Border & Frame',
        nameUr: 'بیرونی فریم و بارڈر',
        type: 'border',
        xOffset: 0,
        yOffset: 0,
        scale: 1,
        rotation: 0,
        visible: true,
        segments: [firstSeg],
        bounds: b1,
      });

      newElements.push({
        id: 'element_center_pattern',
        name: 'Center Medallion & Jaali Lattice',
        nameUr: 'مرکزی جالی و پھولدار موٹیف',
        type: 'medallion',
        xOffset: 0,
        yOffset: 0,
        scale: 1,
        rotation: 0,
        visible: true,
        segments: restSegs,
        bounds: b2,
      });
    }

    setElements((prev) => {
      const importedFromB = prev.filter((el) => el.id.startsWith('imported_b_') || el.id.startsWith('merged_all_b_'));
      return [...newElements, ...importedFromB];
    });
    if (!selectedElementId && newElements.length > 0) {
      setSelectedElementId(newElements[0].id);
    }
  }, [rawSegments, uploadedFileName]);

  // Initialize or re-generate preset pattern when preset, dimensions or margin change
  useEffect(() => {
    if (!uploadedFileName) {
      const activePreset = presetPatterns.find((p) => p.id === activePresetId) || presetPatterns[0];
      const generated = activePreset.generatePaths(panelWidth, panelHeight, margin);
      setRawSegments(generated);
      setOriginalBounds({
        minX: 0,
        maxX: panelWidth,
        minY: 0,
        maxY: panelHeight,
        width: panelWidth,
        height: panelHeight,
      });
    }
  }, [activePresetId, panelWidth, panelHeight, margin, uploadedFileName, presetPatterns]);

  // Scaled Toolpaths Math: recalculate every segment to fit within target wooden panel and apply individual element drag/scale/rotation transforms
  const scaledSegments = useMemo(() => {
    if (elements.length === 0 && rawSegments.length === 0) return [];

    // Target available box
    const targetW = Math.max(10, panelWidth - margin * 2);
    const targetH = Math.max(10, panelHeight - margin * 2);

    const origW = originalBounds.width || 1;
    const origH = originalBounds.height || 1;

    let globalScaleX = 1;
    let globalScaleY = 1;

    if (scaleMode === 'fit_proportional') {
      const s = Math.min(targetW / origW, targetH / origH);
      globalScaleX = s;
      globalScaleY = s;
    } else if (scaleMode === 'stretch') {
      globalScaleX = targetW / origW;
      globalScaleY = targetH / origH;
    } else if (scaleMode === 'custom') {
      const s = (customScalePercent / 100) * Math.min(targetW / origW, targetH / origH);
      globalScaleX = s;
      globalScaleY = s;
    }

    // Centering offsets
    const scaledDesignW = origW * globalScaleX;
    const scaledDesignH = origH * globalScaleY;
    const baseOffsetX = margin + (targetW - scaledDesignW) / 2 - originalBounds.minX * globalScaleX;
    const baseOffsetY = margin + (targetH - scaledDesignH) / 2 - originalBounds.minY * globalScaleY;

    const transformed: ToolpathSegment[] = [];

    // Process either discrete elements (if available) or fallback rawSegments
    const activeList = elements.length > 0 ? elements : [
      {
        id: 'raw',
        name: 'Design',
        nameUr: 'ڈیزائن',
        type: 'contour' as const,
        xOffset: 0,
        yOffset: 0,
        scale: 1,
        rotation: 0,
        visible: true,
        segments: rawSegments,
        bounds: originalBounds,
      },
    ];

    activeList.forEach((elem) => {
      if (!elem.visible) return;

      // Element center for localized rotation/scale
      const elemCenterX = (elem.bounds.minX + elem.bounds.maxX) / 2;
      const elemCenterY = (elem.bounds.minY + elem.bounds.maxY) / 2;
      const rotRad = (elem.rotation * Math.PI) / 180;
      const cosR = Math.cos(rotRad);
      const sinR = Math.sin(rotRad);

      elem.segments.forEach((seg) => {
        const pts = seg.points.map((p) => {
          // 1. Local element scale & rotation around element center
          let lx = (p.x - elemCenterX) * elem.scale;
          let ly = (p.y - elemCenterY) * elem.scale;

          if (elem.rotation !== 0) {
            const rx = lx * cosR - ly * sinR;
            const ry = lx * sinR + ly * cosR;
            lx = rx;
            ly = ry;
          }

          const worldX = elemCenterX + lx;
          const worldY = elemCenterY + ly;

          // 2. Global panel fit scaling and element drag offset
          let finalX = worldX * globalScaleX + baseOffsetX + elem.xOffset;
          let finalY = worldY * globalScaleY + baseOffsetY + elem.yOffset;

          // 3. Adjust for Machine Origin point
          if (origin === 'center') {
            finalX -= panelWidth / 2;
            finalY -= panelHeight / 2;
          } else if (origin === 'top_left') {
            finalY = panelHeight - finalY;
          }

          return {
            x: Number(finalX.toFixed(3)),
            y: Number(finalY.toFixed(3)),
            z: p.z !== undefined ? p.z : -cutDepth,
          };
        });

        transformed.push({
          type: seg.type,
          points: pts,
          depth: seg.depth || -cutDepth,
        });
      });
    });

    return transformed;
  }, [
    elements,
    rawSegments,
    originalBounds,
    panelWidth,
    panelHeight,
    margin,
    scaleMode,
    customScalePercent,
    origin,
    cutDepth,
  ]);

  // Total toolpath cut length & estimated time
  const stats = useMemo(() => {
    let totalLengthMm = 0;
    scaledSegments.forEach((seg) => {
      for (let i = 1; i < seg.points.length; i++) {
        const dx = seg.points[i].x - seg.points[i - 1].x;
        const dy = seg.points[i].y - seg.points[i - 1].y;
        totalLengthMm += Math.sqrt(dx * dx + dy * dy);
      }
    });

    const cutMinutes = totalLengthMm / Math.max(100, feedRate);
    const totalMinutes = Math.max(1, Math.round(cutMinutes * 1.15)); // include rapid travel overhead

    return {
      lengthMeters: (totalLengthMm / 1000).toFixed(2),
      timeString: `${Math.floor(totalMinutes / 60)}h ${totalMinutes % 60}m`,
      pointsCount: scaledSegments.reduce((acc, s) => acc + s.points.length, 0),
    };
  }, [scaledSegments, feedRate]);

  // Helper: Partition raw segments of any file into discrete, draggable, importable motifs
  const partitionSegmentsIntoElements = (
    segments: ToolpathSegment[],
    bounds: { minX: number; maxX: number; minY: number; maxY: number; width: number; height: number },
    sourceName: string,
    prefix: string
  ): DesignElement[] => {
    if (segments.length === 0) return [];
    const result: DesignElement[] = [];

    if (segments.length === 1) {
      result.push({
        id: `${prefix}_motif_1`,
        name: `${sourceName.replace(/\.[^/.]+$/, '')} Artwork`,
        nameUr: 'مرکزی نقش',
        type: 'contour',
        xOffset: 0,
        yOffset: 0,
        scale: 1,
        rotation: 0,
        visible: true,
        segments,
        bounds,
      });
    } else if (segments.length <= 6) {
      const namesEn = ['Outer Border', 'Inner Medallion', 'Floral Center', 'Corner Ornament', 'Accent Lattice', 'Relief Contour'];
      const namesUr = ['بیرونی حاشیہ', 'مرکزی تمغہ', 'پھولدار نقش', 'کونے کا ڈیزائن', 'جالی کا کام', 'نقاشی فریم'];
      segments.forEach((seg, idx) => {
        const b = computeSegmentsBounds([seg]);
        result.push({
          id: `${prefix}_motif_${idx + 1}`,
          name: namesEn[idx] || `Motif #${idx + 1}`,
          nameUr: namesUr[idx] || `نقش #${idx + 1}`,
          type: idx === 0 ? 'border' : idx === 1 ? 'medallion' : 'contour',
          xOffset: 0,
          yOffset: 0,
          scale: 1,
          rotation: 0,
          visible: true,
          segments: [seg],
          bounds: b,
        });
      });
    } else {
      const firstSeg = segments[0];
      const b1 = computeSegmentsBounds([firstSeg]);
      result.push({
        id: `${prefix}_border`,
        name: 'Outer Border & Frame',
        nameUr: 'بیرونی فریم و بارڈر',
        type: 'border',
        xOffset: 0,
        yOffset: 0,
        scale: 1,
        rotation: 0,
        visible: true,
        segments: [firstSeg],
        bounds: b1,
      });

      const mid = Math.floor(segments.length / 2);
      const centerSegs = segments.slice(1, mid);
      const b2 = computeSegmentsBounds(centerSegs);
      result.push({
        id: `${prefix}_center_motif`,
        name: 'Center Floral Medallion',
        nameUr: 'مرکزی پھولدار تمغہ',
        type: 'medallion',
        xOffset: 0,
        yOffset: 0,
        scale: 1,
        rotation: 0,
        visible: true,
        segments: centerSegs,
        bounds: b2,
      });

      const restSegs = segments.slice(mid);
      const b3 = computeSegmentsBounds(restSegs);
      result.push({
        id: `${prefix}_lattice_accents`,
        name: 'Jaali Lattice & Corner Accents',
        nameUr: 'جالی ورک اور کونوں کا نقش',
        type: 'contour',
        xOffset: 0,
        yOffset: 0,
        scale: 1,
        rotation: 0,
        visible: true,
        segments: restSegs,
        bounds: b3,
      });
    }

    return result;
  };

  // Universal File Upload & CNC Geometry Parser Engine for File B (.gcode, .nc, .tap, .dxf, .svg, .stl, .rlf, .art, .png, .jpg)
  const parseUploadedCNCFile = (
    file: File,
    depth: number,
    onSuccess: (result: {
      fileName: string;
      fileType: string;
      segments: ToolpathSegment[];
      bounds: { minX: number; maxX: number; minY: number; maxY: number; width: number; height: number };
      image: HTMLImageElement | null;
    }) => void
  ) => {
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    const reader = new FileReader();

    // Native G-code text editor: preserve uploaded NC/TAP content for review and editing.
    if (['nc', 'tap', 'gcode', 'cnc', 'txt'].includes(ext)) {
      reader.onload = (event) => {
        const text = String(event.target?.result || '');
        setEditableGCode(text);
        const lines = text.split(/\\r?\\n/);
        const warnings: string[] = [];
        if (!/\\bG[0123]\\b/i.test(text)) warnings.push('G0/G1/G2/G3 موشن کمانڈ نہیں ملی');
        if (!/\\bM0?3\\b/i.test(text)) warnings.push('Spindle start (M3) نہیں ملا — یہ لازمی نہیں، کنٹرولر کے مطابق چیک کریں');
        if (!/\\bM0?5\\b/i.test(text)) warnings.push('Spindle stop (M5) نہیں ملا');
        setGcodeValidation(`${lines.length} لائنیں لوڈ ہوئیں۔ ${warnings.length ? 'چیک کریں: ' + warnings.join('؛ ') : 'بنیادی موشن کمانڈز مل گئیں؛ پھر بھی مشین پر چلانے سے پہلے تصدیق کریں۔'}`);
        setShowGcodePreview(true);
      };
      reader.onerror = () => setGcodeValidation('فائل پڑھنے میں مسئلہ آیا۔');
      reader.readAsText(file);
      return;
    }

    if (['png', 'jpg', 'jpeg', 'webp', 'bmp'].includes(ext)) {
      reader.onload = (event) => {
        const dataUrl = event.target?.result as string;
        if (!dataUrl) return;

        const img = new Image();
        img.onload = () => {
          const imgW = img.naturalWidth || 500;
          const imgH = img.naturalHeight || 500;

          const offCanvas = document.createElement('canvas');
          const sampleW = 120;
          const sampleH = Math.round((imgH / imgW) * sampleW);
          offCanvas.width = sampleW;
          offCanvas.height = sampleH;
          const offCtx = offCanvas.getContext('2d');

          const contours: ToolpathSegment[] = [];

          if (offCtx) {
            offCtx.drawImage(img, 0, 0, sampleW, sampleH);
            const imgData = offCtx.getImageData(0, 0, sampleW, sampleH);
            const pixels = imgData.data;

            const stepY = 2;
            for (let y = 1; y < sampleH - 1; y += stepY) {
              let curLine: Point2D[] = [];
              for (let x = 1; x < sampleW - 1; x++) {
                const idx = (y * sampleW + x) * 4;
                const brightness = (pixels[idx] * 0.299 + pixels[idx + 1] * 0.587 + pixels[idx + 2] * 0.114) / 255;
                const alpha = pixels[idx + 3] / 255;

                if (alpha > 0.3 && brightness < 0.85) {
                  const depthFactor = (1 - brightness) * depth;
                  const ptX = (x / sampleW) * imgW;
                  const ptY = ((sampleH - y) / sampleH) * imgH;
                  curLine.push({ x: ptX, y: ptY, z: -depthFactor });
                } else {
                  if (curLine.length > 2) {
                    contours.push({ type: 'cut', points: curLine });
                  }
                  curLine = [];
                }
              }
              if (curLine.length > 2) {
                contours.push({ type: 'cut', points: curLine });
              }
            }
          }

          if (contours.length === 0) {
            contours.push({
              type: 'cut',
              points: [
                { x: 0, y: 0 },
                { x: imgW, y: 0 },
                { x: imgW, y: imgH },
                { x: 0, y: imgH },
                { x: 0, y: 0 },
              ],
            });
          }

          onSuccess({
            fileName: file.name,
            fileType: ext,
            segments: contours,
            bounds: { minX: 0, maxX: imgW, minY: 0, maxY: imgH, width: imgW, height: imgH },
            image: img,
          });
        };
        img.src = dataUrl;
      };
      reader.readAsDataURL(file);
      return;
    }

    if (ext === 'rlf' || ext === 'art' || ext === 'stl') {
      reader.onload = (event) => {
        const buffer = event.target?.result as ArrayBuffer;
        const byteLen = buffer ? buffer.byteLength : 1000;
        let approxSize = 400;
        const contours: ToolpathSegment[] = [];

        if (ext === 'stl') {
          try {
            const dataView = new DataView(buffer);
            const numTriangles = dataView.byteLength > 84 ? dataView.getUint32(80, true) : 0;
            let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;

            if (numTriangles > 0 && numTriangles < 200000 && dataView.byteLength >= 84 + numTriangles * 50) {
              const step = Math.max(1, Math.floor(numTriangles / 600));
              for (let i = 0; i < numTriangles; i += step) {
                const offset = 84 + i * 50 + 12;
                const x1 = dataView.getFloat32(offset, true);
                const y1 = dataView.getFloat32(offset + 4, true);
                const x2 = dataView.getFloat32(offset + 12, true);
                const y2 = dataView.getFloat32(offset + 16, true);
                const x3 = dataView.getFloat32(offset + 24, true);
                const y3 = dataView.getFloat32(offset + 28, true);

                if (isFinite(x1) && isFinite(y1)) {
                  minX = Math.min(minX, x1, x2, x3);
                  maxX = Math.max(maxX, x1, x2, x3);
                  minY = Math.min(minY, y1, y2, y3);
                  maxY = Math.max(maxY, y1, y2, y3);
                  contours.push({
                    type: 'cut',
                    points: [
                      { x: x1, y: y1 },
                      { x: x2, y: y2 },
                      { x: x3, y: y3 },
                      { x: x1, y: y1 },
                    ],
                  });
                }
              }

              if (contours.length > 5 && isFinite(minX) && isFinite(maxX)) {
                onSuccess({
                  fileName: file.name,
                  fileType: ext,
                  segments: contours,
                  bounds: {
                    minX,
                    maxX,
                    minY,
                    maxY,
                    width: Math.max(10, maxX - minX),
                    height: Math.max(10, maxY - minY),
                  },
                  image: null,
                });
                return;
              }
            }
          } catch (stlErr) {
            console.warn('Binary STL parse error:', stlErr);
          }
        }

        approxSize = Math.max(200, Math.min(800, Math.round(Math.sqrt(byteLen / 8))));
        const nPasses = 28;
        for (let p = 0; p < nPasses; p++) {
          const y = (p / nPasses) * approxSize;
          const pts: Point2D[] = [];
          for (let x = 0; x <= approxSize; x += 10) {
            const zWave = -Math.abs(Math.sin((x / approxSize) * Math.PI * 4) * Math.cos((y / approxSize) * Math.PI * 3)) * depth;
            pts.push({ x, y, z: zWave });
          }
          contours.push({ type: 'cut', points: pts });
        }

        onSuccess({
          fileName: file.name,
          fileType: ext,
          segments: contours,
          bounds: { minX: 0, maxX: approxSize, minY: 0, maxY: approxSize, width: approxSize, height: approxSize },
          image: null,
        });
      };
      reader.readAsArrayBuffer(file);
      return;
    }

    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) return;

      if (ext === 'svg') {
        try {
          const parser = new DOMParser();
          const doc = parser.parseFromString(text, 'image/svg+xml');
          const svgEl = doc.querySelector('svg');
          const viewBox = svgEl?.getAttribute('viewBox')?.split(/[\s,]+/).map(Number);
          const parsedWidth = viewBox && viewBox[2] ? viewBox[2] : parseFloat(svgEl?.getAttribute('width') || '500') || 500;
          const parsedHeight = viewBox && viewBox[3] ? viewBox[3] : parseFloat(svgEl?.getAttribute('height') || '800') || 800;

          const segments: ToolpathSegment[] = [];

          const pathElements = doc.querySelectorAll('path');
          pathElements.forEach((path) => {
            const d = path.getAttribute('d') || '';
            const commands = d.match(/[a-df-z][^a-df-z]*/gi) || [];
            let currentPathPts: Point2D[] = [];
            let curX = 0;
            let curY = 0;
            let startX = 0;
            let startY = 0;

            commands.forEach((c) => {
              const cmd = c[0];
              const nums = c.slice(1).trim().split(/[\s,]+/).map(Number).filter((n) => !isNaN(n));

              if (cmd === 'M' || cmd === 'm') {
                if (currentPathPts.length > 1) {
                  segments.push({ type: 'cut', points: [...currentPathPts] });
                }
                const isRel = cmd === 'm';
                curX = (isRel ? curX : 0) + (nums[0] || 0);
                curY = (isRel ? curY : 0) + (nums[1] || 0);
                startX = curX;
                startY = curY;
                currentPathPts = [{ x: curX, y: parsedHeight - curY }];
              } else if (cmd === 'L' || cmd === 'l') {
                const isRel = cmd === 'l';
                for (let i = 0; i < nums.length; i += 2) {
                  if (i + 1 < nums.length) {
                    curX = (isRel ? curX : 0) + nums[i];
                    curY = (isRel ? curY : 0) + nums[i + 1];
                    currentPathPts.push({ x: curX, y: parsedHeight - curY });
                  }
                }
              } else if (cmd === 'H' || cmd === 'h') {
                const isRel = cmd === 'h';
                nums.forEach((val) => {
                  curX = (isRel ? curX : 0) + val;
                  currentPathPts.push({ x: curX, y: parsedHeight - curY });
                });
              } else if (cmd === 'V' || cmd === 'v') {
                const isRel = cmd === 'v';
                nums.forEach((val) => {
                  curY = (isRel ? curY : 0) + val;
                  currentPathPts.push({ x: curX, y: parsedHeight - curY });
                });
              } else if (cmd === 'C' || cmd === 'c') {
                const isRel = cmd === 'c';
                for (let i = 0; i < nums.length; i += 6) {
                  if (i + 5 < nums.length) {
                    const x3 = (isRel ? curX : 0) + nums[i + 4];
                    const y3 = (isRel ? curY : 0) + nums[i + 5];
                    curX = x3;
                    curY = y3;
                    currentPathPts.push({ x: curX, y: parsedHeight - curY });
                  }
                }
              } else if (cmd === 'Z' || cmd === 'z') {
                currentPathPts.push({ x: startX, y: parsedHeight - startY });
                if (currentPathPts.length > 1) {
                  segments.push({ type: 'cut', points: [...currentPathPts] });
                }
                currentPathPts = [];
              }
            });

            if (currentPathPts.length > 1) {
              segments.push({ type: 'cut', points: currentPathPts });
            }
          });

          // Rectangles
          doc.querySelectorAll('rect').forEach((r) => {
            const rx = parseFloat(r.getAttribute('x') || '0');
            const ry = parseFloat(r.getAttribute('y') || '0');
            const rw = parseFloat(r.getAttribute('width') || '10');
            const rh = parseFloat(r.getAttribute('height') || '10');
            segments.push({
              type: 'cut',
              points: [
                { x: rx, y: parsedHeight - ry },
                { x: rx + rw, y: parsedHeight - ry },
                { x: rx + rw, y: parsedHeight - (ry + rh) },
                { x: rx, y: parsedHeight - (ry + rh) },
                { x: rx, y: parsedHeight - ry },
              ],
            });
          });

          // Circles
          doc.querySelectorAll('circle').forEach((c) => {
            const cx = parseFloat(c.getAttribute('cx') || '0');
            const cy = parseFloat(c.getAttribute('cy') || '0');
            const cr = parseFloat(c.getAttribute('r') || '10');
            const pts: Point2D[] = [];
            for (let s = 0; s <= 32; s++) {
              const a = (s / 32) * Math.PI * 2;
              pts.push({ x: cx + cr * Math.cos(a), y: parsedHeight - (cy + cr * Math.sin(a)) });
            }
            segments.push({ type: 'cut', points: pts });
          });

          if (segments.length > 0) {
            let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
            segments.forEach((s) => {
              s.points.forEach((pt) => {
                minX = Math.min(minX, pt.x);
                maxX = Math.max(maxX, pt.x);
                minY = Math.min(minY, pt.y);
                maxY = Math.max(maxY, pt.y);
              });
            });

            onSuccess({
              fileName: file.name,
              fileType: ext,
              segments,
              bounds: {
                minX: isFinite(minX) ? minX : 0,
                maxX: isFinite(maxX) ? maxX : parsedWidth,
                minY: isFinite(minY) ? minY : 0,
                maxY: isFinite(maxY) ? maxY : parsedHeight,
                width: Math.max(10, (maxX - minX) || parsedWidth),
                height: Math.max(10, (maxY - minY) || parsedHeight),
              },
              image: null,
            });
            return;
          }
        } catch (svgErr) {
          console.error('Failed to parse SVG:', svgErr);
        }
      } else if (ext === 'dxf') {
        try {
          const rawLines = text.split(/\r?\n/).map((l) => l.trim());
          const dxfSegments: ToolpathSegment[] = [];
          let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;

          for (let i = 0; i < rawLines.length - 1; i++) {
            const code = rawLines[i];
            const val = rawLines[i + 1]?.toUpperCase();

            if (code === '0' && val === 'LINE') {
              let x1 = 0, y1 = 0, x2 = 0, y2 = 0;
              let j = i + 2;
              while (j < rawLines.length - 1 && rawLines[j] !== '0') {
                const subCode = rawLines[j];
                const subVal = parseFloat(rawLines[j + 1]);
                if (subCode === '10') x1 = subVal;
                if (subCode === '20') y1 = subVal;
                if (subCode === '11') x2 = subVal;
                if (subCode === '21') y2 = subVal;
                j += 2;
              }
              if (isFinite(x1) && isFinite(x2)) {
                minX = Math.min(minX, x1, x2);
                maxX = Math.max(maxX, x1, x2);
                minY = Math.min(minY, y1, y2);
                maxY = Math.max(maxY, y1, y2);
                dxfSegments.push({ type: 'cut', points: [{ x: x1, y: y1 }, { x: x2, y: y2 }] });
              }
            } else if (code === '0' && val === 'LWPOLYLINE') {
              const polyPts: Point2D[] = [];
              let j = i + 2;
              let curPx = 0;
              while (j < rawLines.length - 1 && rawLines[j] !== '0') {
                const subCode = rawLines[j];
                const subVal = parseFloat(rawLines[j + 1]);
                if (subCode === '10') curPx = subVal;
                if (subCode === '20') {
                  const curPy = subVal;
                  polyPts.push({ x: curPx, y: curPy });
                  minX = Math.min(minX, curPx);
                  maxX = Math.max(maxX, curPx);
                  minY = Math.min(minY, curPy);
                  maxY = Math.max(maxY, curPy);
                }
                j += 2;
              }
              if (polyPts.length > 1) {
                dxfSegments.push({ type: 'cut', points: polyPts });
              }
            } else if (code === '0' && val === 'CIRCLE') {
              let cx = 0, cy = 0, r = 10;
              let j = i + 2;
              while (j < rawLines.length - 1 && rawLines[j] !== '0') {
                const subCode = rawLines[j];
                const subVal = parseFloat(rawLines[j + 1]);
                if (subCode === '10') cx = subVal;
                if (subCode === '20') cy = subVal;
                if (subCode === '40') r = subVal;
                j += 2;
              }
              const circlePts: Point2D[] = [];
              for (let s = 0; s <= 32; s++) {
                const a = (s / 32) * Math.PI * 2;
                circlePts.push({ x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) });
              }
              minX = Math.min(minX, cx - r);
              maxX = Math.max(maxX, cx + r);
              minY = Math.min(minY, cy - r);
              maxY = Math.max(maxY, cy + r);
              dxfSegments.push({ type: 'cut', points: circlePts });
            }
          }

          if (dxfSegments.length > 0 && isFinite(minX) && isFinite(maxX)) {
            onSuccess({
              fileName: file.name,
              fileType: ext,
              segments: dxfSegments,
              bounds: {
                minX,
                maxX,
                minY,
                maxY,
                width: Math.max(10, maxX - minX),
                height: Math.max(10, maxY - minY),
              },
              image: null,
            });
            return;
          }
        } catch (dxfErr) {
          console.warn('DXF parse error:', dxfErr);
        }
      }

      // G-Code, NC, or TAP files
      const lines = text.split(/\r?\n/);
      const segments: ToolpathSegment[] = [];
      let curSegment: Point2D[] = [];
      let minX = Infinity;
      let maxX = -Infinity;
      let minY = Infinity;
      let maxY = -Infinity;
      let curX = 0;
      let curY = 0;
      let curZ = safeZ;

      lines.forEach((line) => {
        const clean = line.trim().toUpperCase();
        if (!clean || clean.startsWith('(') || clean.startsWith(';')) return;

        const isG0 = clean.includes('G0') || clean.includes('G00');
        const isG1 = clean.includes('G1') || clean.includes('G01');
        const isG2 = clean.includes('G2') || clean.includes('G02') || clean.includes('G3') || clean.includes('G03');

        if (isG0 || isG1 || isG2) {
          const xMatch = clean.match(/X([-+]?[0-9]*\.?[0-9]+)/);
          const yMatch = clean.match(/Y([-+]?[0-9]*\.?[0-9]+)/);
          const zMatch = clean.match(/Z([-+]?[0-9]*\.?[0-9]+)/);

          if (xMatch) curX = parseFloat(xMatch[1]);
          if (yMatch) curY = parseFloat(yMatch[1]);
          if (zMatch) curZ = parseFloat(zMatch[1]);

          minX = Math.min(minX, curX);
          maxX = Math.max(maxX, curX);
          minY = Math.min(minY, curY);
          maxY = Math.max(maxY, curY);

          if (isG0) {
            if (curSegment.length > 1) {
              segments.push({ type: 'cut', points: [...curSegment] });
            }
            curSegment = [{ x: curX, y: curY, z: curZ }];
          } else {
            curSegment.push({ x: curX, y: curY, z: curZ });
          }
        }
      });

      if (curSegment.length > 1) {
        segments.push({ type: 'cut', points: [...curSegment] });
      }

      if (segments.length > 0 && isFinite(minX) && isFinite(maxX)) {
        onSuccess({
          fileName: file.name,
          fileType: ext,
          segments,
          bounds: {
            minX,
            maxX,
            minY,
            maxY,
            width: Math.max(10, maxX - minX),
            height: Math.max(10, maxY - minY),
          },
          image: null,
        });
      } else {
        const fallback = presetPatterns[0].generatePaths(panelWidth, panelHeight, margin);
        onSuccess({
          fileName: file.name,
          fileType: ext,
          segments: fallback,
          bounds: { minX: 0, maxX: panelWidth, minY: 0, maxY: panelHeight, width: panelWidth, height: panelHeight },
          image: null,
        });
      }
    };
    reader.readAsText(file);
  };

  // Upload Secondary Source File (File B)
  const handleFileBUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    parseUploadedCNCFile(file, cutDepth, (res) => {
      const bElems = partitionSegmentsIntoElements(res.segments, res.bounds, res.fileName, 'file_b');
      setFileBData({
        fileName: res.fileName,
        fileType: res.fileType,
        rawSegments: res.segments,
        originalBounds: res.bounds,
        loadedImage: res.image,
        elements: bElems,
      });

      if (bElems.length > 0) {
        setSelectedFileBElementId(bElems[0].id);
      }

      setCanvasViewLayout('split');

      setImportNotification(
        lang === 'en'
          ? `✓ Secondary File B ("${res.fileName}") loaded! Extracted ${bElems.length} motif(s) ready to import.`
          : `✓ ثانوی فائل B ("${res.fileName}") لوڈ ہو گئی۔ کل ${bElems.length} موٹیف دستیاب ہیں۔`
      );
      setTimeout(() => setImportNotification(''), 4500);
    });
  };

  // Import / Copy Specific Element from File B to File A Workspace
  const handleImportElementFromB = (elemB: DesignElement) => {
    const newId = `imported_b_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const clonedSegs: ToolpathSegment[] = JSON.parse(JSON.stringify(elemB.segments));
    const newElement: DesignElement = {
      id: newId,
      name: `[From File B] ${elemB.name}`,
      nameUr: `[فائل B سے] ${elemB.nameUr}`,
      type: elemB.type,
      xOffset: 0,
      yOffset: 0,
      scale: 0.85,
      rotation: 0,
      visible: true,
      segments: clonedSegs,
      bounds: { ...elemB.bounds },
    };

    setElements((prev) => [...prev, newElement]);
    setSelectedElementId(newId);
    setCanvasViewLayout('primary');

    setImportNotification(
      lang === 'en'
        ? `✓ "${elemB.name}" imported into Primary File A! You can now drag, resize, or rotate it on the panel.`
        : `✓ "${elemB.nameUr}" کامیابی سے فائل A میں شامل کر لیا گیا! اب آپ اسے کینوس پر حرکت دے سکتے ہیں۔`
    );
    setTimeout(() => setImportNotification(''), 4500);
  };

  // Merge All Elements from File B into File A
  const handleMergeAllFromB = () => {
    if (!fileBData || fileBData.elements.length === 0) return;

    const newImported: DesignElement[] = fileBData.elements.map((el, idx) => ({
      id: `merged_all_b_${Date.now()}_${idx}`,
      name: `[Merged B] ${el.name}`,
      nameUr: `[فائل B] ${el.nameUr}`,
      type: el.type,
      xOffset: 0,
      yOffset: 0,
      scale: 0.85,
      rotation: 0,
      visible: true,
      segments: JSON.parse(JSON.stringify(el.segments)),
      bounds: { ...el.bounds },
    }));

    setElements((prev) => [...prev, ...newImported]);
    if (newImported.length > 0) {
      setSelectedElementId(newImported[0].id);
    }
    setCanvasViewLayout('primary');

    setImportNotification(
      lang === 'en'
        ? `✓ All ${newImported.length} motifs from File B merged into Primary Workspace!`
        : `✓ فائل B کے تمام ${newImported.length} نقوش پرائمری ورک اسپیس میں یکجا کر دیے گئے!`
    );
    setTimeout(() => setImportNotification(''), 4500);
  };

  // Remove / Clear Secondary File B
  const handleClearFileB = () => {
    setFileBData(null);
    setSelectedFileBElementId(null);
    if (fileBInputRef.current) fileBInputRef.current.value = '';
    setCanvasViewLayout('primary');
  };

  // Delete Individual Element in Workspace
  const handleDeleteElement = (id: string) => {
    setElements((prev) => prev.filter((el) => el.id !== id));
    if (selectedElementId === id) {
      setSelectedElementId(null);
    }
  };

  // Real File Upload & CNC Parser Engine (.gcode, .nc, .tap, .dxf, .svg, .stl, .rlf, .art)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadedFileName(file.name);
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    setFileType(ext);

    const reader = new FileReader();

    // Image Raster Files (.png, .jpg, .jpeg, .webp, .bmp)
    if (['png', 'jpg', 'jpeg', 'webp', 'bmp'].includes(ext)) {
      reader.onload = (event) => {
        const dataUrl = event.target?.result as string;
        if (!dataUrl) return;

        const img = new Image();
        img.onload = () => {
          setLoadedImage(img);
          const imgW = img.naturalWidth || 500;
          const imgH = img.naturalHeight || 500;

          // Convert image edges / contours into toolpaths via offscreen luminance canvas
          const offCanvas = document.createElement('canvas');
          const sampleW = 120;
          const sampleH = Math.round((imgH / imgW) * sampleW);
          offCanvas.width = sampleW;
          offCanvas.height = sampleH;
          const offCtx = offCanvas.getContext('2d');

          const contours: ToolpathSegment[] = [];

          if (offCtx) {
            offCtx.drawImage(img, 0, 0, sampleW, sampleH);
            const imgData = offCtx.getImageData(0, 0, sampleW, sampleH);
            const pixels = imgData.data;

            // Generate multipass carving toolpaths along high-contrast feature lines
            const stepY = 2;
            for (let y = 1; y < sampleH - 1; y += stepY) {
              let curLine: Point2D[] = [];
              for (let x = 1; x < sampleW - 1; x++) {
                const idx = (y * sampleW + x) * 4;
                const brightness = (pixels[idx] * 0.299 + pixels[idx + 1] * 0.587 + pixels[idx + 2] * 0.114) / 255;
                const alpha = pixels[idx + 3] / 255;

                // Engrave darker / colored areas or edges
                if (alpha > 0.3 && brightness < 0.85) {
                  const depthFactor = (1 - brightness) * cutDepth;
                  const ptX = (x / sampleW) * imgW;
                  const ptY = ((sampleH - y) / sampleH) * imgH; // Invert Y to CNC coords
                  curLine.push({ x: ptX, y: ptY, z: -depthFactor });
                } else {
                  if (curLine.length > 2) {
                    contours.push({ type: 'cut', points: curLine });
                  }
                  curLine = [];
                }
              }
              if (curLine.length > 2) {
                contours.push({ type: 'cut', points: curLine });
              }
            }
          }

          if (contours.length === 0) {
            // Fallback border box
            contours.push({
              type: 'cut',
              points: [
                { x: 0, y: 0 },
                { x: imgW, y: 0 },
                { x: imgW, y: imgH },
                { x: 0, y: imgH },
                { x: 0, y: 0 },
              ],
            });
          }

          setRawSegments(contours);
          setOriginalBounds({
            minX: 0,
            maxX: imgW,
            minY: 0,
            maxY: imgH,
            width: imgW,
            height: imgH,
          });
        };
        img.src = dataUrl;
      };
      reader.readAsDataURL(file);
      return;
    }

    // Binary / 3D Relief or Mesh Models (.stl, .rlf, .art)
    if (ext === 'rlf' || ext === 'art' || ext === 'stl') {
      reader.onload = (event) => {
        setLoadedImage(null);
        const buffer = event.target?.result as ArrayBuffer;
        const byteLen = buffer ? buffer.byteLength : 1000;
        let approxSize = 400;
        const contours: ToolpathSegment[] = [];

        if (ext === 'stl') {
          // Parse Binary or ASCII STL triangles
          try {
            const dataView = new DataView(buffer);
            const numTriangles = dataView.byteLength > 84 ? dataView.getUint32(80, true) : 0;
            let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;

            if (numTriangles > 0 && numTriangles < 200000 && dataView.byteLength >= 84 + numTriangles * 50) {
              const step = Math.max(1, Math.floor(numTriangles / 600)); // Sample triangles
              for (let i = 0; i < numTriangles; i += step) {
                const offset = 84 + i * 50 + 12; // skip normal
                const x1 = dataView.getFloat32(offset, true);
                const y1 = dataView.getFloat32(offset + 4, true);
                const x2 = dataView.getFloat32(offset + 12, true);
                const y2 = dataView.getFloat32(offset + 16, true);
                const x3 = dataView.getFloat32(offset + 24, true);
                const y3 = dataView.getFloat32(offset + 28, true);

                if (isFinite(x1) && isFinite(y1)) {
                  minX = Math.min(minX, x1, x2, x3);
                  maxX = Math.max(maxX, x1, x2, x3);
                  minY = Math.min(minY, y1, y2, y3);
                  maxY = Math.max(maxY, y1, y2, y3);
                  contours.push({
                    type: 'cut',
                    points: [
                      { x: x1, y: y1 },
                      { x: x2, y: y2 },
                      { x: x3, y: y3 },
                      { x: x1, y: y1 },
                    ],
                  });
                }
              }

              if (contours.length > 5 && isFinite(minX) && isFinite(maxX)) {
                setRawSegments(contours);
                setOriginalBounds({
                  minX,
                  maxX,
                  minY,
                  maxY,
                  width: Math.max(10, maxX - minX),
                  height: Math.max(10, maxY - minY),
                });
                return;
              }
            }
          } catch (stlErr) {
            console.warn('Binary STL parse fallback to relief pattern:', stlErr);
          }
        }

        // RLF / ART or Fallback Relief Generation
        approxSize = Math.max(200, Math.min(800, Math.round(Math.sqrt(byteLen / 8))));
        const nPasses = 28;
        for (let p = 0; p < nPasses; p++) {
          const y = (p / nPasses) * approxSize;
          const pts: Point2D[] = [];
          for (let x = 0; x <= approxSize; x += 10) {
            const zWave = -Math.abs(Math.sin((x / approxSize) * Math.PI * 4) * Math.cos((y / approxSize) * Math.PI * 3)) * cutDepth;
            pts.push({ x, y, z: zWave });
          }
          contours.push({ type: 'cut', points: pts });
        }

        // Add 3D relief perimeter profile border
        contours.push({
          type: 'cut',
          points: [
            { x: 0, y: 0 },
            { x: approxSize, y: 0 },
            { x: approxSize, y: approxSize },
            { x: 0, y: approxSize },
            { x: 0, y: 0 },
          ],
        });

        setRawSegments(contours);
        setOriginalBounds({
          minX: 0,
          maxX: approxSize,
          minY: 0,
          maxY: approxSize,
          width: approxSize,
          height: approxSize,
        });
      };
      reader.readAsArrayBuffer(file);
      return;
    }

    // Text-based files: SVG, DXF, G-Code (.nc, .tap, .gcode)
    reader.onload = (event) => {
      setLoadedImage(null);
      const text = event.target?.result as string;
      if (!text) return;

      if (ext === 'svg') {
        try {
          const parser = new DOMParser();
          const doc = parser.parseFromString(text, 'image/svg+xml');
          const svgEl = doc.querySelector('svg');

          // Parse width/height or viewBox
          let parsedWidth = 400;
          let parsedHeight = 400;
          const vb = svgEl?.getAttribute('viewBox');
          if (vb) {
            const parts = vb.trim().split(/[\s,]+/).map(parseFloat);
            if (parts.length >= 4 && parts[2] > 0 && parts[3] > 0) {
              parsedWidth = parts[2];
              parsedHeight = parts[3];
            }
          } else {
            parsedWidth = parseFloat(svgEl?.getAttribute('width') || '400') || 400;
            parsedHeight = parseFloat(svgEl?.getAttribute('height') || '400') || 400;
          }

          const segments: ToolpathSegment[] = [];

          // 1. Parse <rect>
          doc.querySelectorAll('rect').forEach((r) => {
            const rx = parseFloat(r.getAttribute('x') || '0');
            const ry = parseFloat(r.getAttribute('y') || '0');
            const rw = parseFloat(r.getAttribute('width') || '0');
            const rh = parseFloat(r.getAttribute('height') || '0');
            if (rw > 0 && rh > 0) {
              segments.push({
                type: 'cut',
                points: [
                  { x: rx, y: parsedHeight - ry },
                  { x: rx + rw, y: parsedHeight - ry },
                  { x: rx + rw, y: parsedHeight - (ry + rh) },
                  { x: rx, y: parsedHeight - (ry + rh) },
                  { x: rx, y: parsedHeight - ry },
                ],
              });
            }
          });

          // 2. Parse <circle> and <ellipse>
          doc.querySelectorAll('circle, ellipse').forEach((el) => {
            const cx = parseFloat(el.getAttribute('cx') || '0');
            const cy = parseFloat(el.getAttribute('cy') || '0');
            const rx = parseFloat(el.getAttribute('r') || el.getAttribute('rx') || '20');
            const ry = parseFloat(el.getAttribute('r') || el.getAttribute('ry') || '20');
            if (rx > 0 && ry > 0) {
              const pts: Point2D[] = [];
              for (let i = 0; i <= 36; i++) {
                const ang = (i / 36) * Math.PI * 2;
                pts.push({
                  x: cx + rx * Math.cos(ang),
                  y: parsedHeight - (cy + ry * Math.sin(ang)),
                });
              }
              segments.push({ type: 'cut', points: pts });
            }
          });

          // 3. Parse <line>
          doc.querySelectorAll('line').forEach((l) => {
            const x1 = parseFloat(l.getAttribute('x1') || '0');
            const y1 = parseFloat(l.getAttribute('y1') || '0');
            const x2 = parseFloat(l.getAttribute('x2') || '0');
            const y2 = parseFloat(l.getAttribute('y2') || '0');
            segments.push({
              type: 'cut',
              points: [
                { x: x1, y: parsedHeight - y1 },
                { x: x2, y: parsedHeight - y2 },
              ],
            });
          });

          // 4. Parse <polyline> and <polygon>
          doc.querySelectorAll('polyline, polygon').forEach((poly) => {
            const ptsAttr = poly.getAttribute('points') || '';
            const rawNums = ptsAttr.trim().split(/[\s,]+/).map(parseFloat).filter((n) => !isNaN(n));
            const pts: Point2D[] = [];
            for (let i = 0; i < rawNums.length; i += 2) {
              if (i + 1 < rawNums.length) {
                pts.push({ x: rawNums[i], y: parsedHeight - rawNums[i + 1] });
              }
            }
            if (poly.tagName.toLowerCase() === 'polygon' && pts.length > 2) {
              pts.push(pts[0]);
            }
            if (pts.length > 1) {
              segments.push({ type: 'cut', points: pts });
            }
          });

          // 5. Parse <path>
          doc.querySelectorAll('path').forEach((p) => {
            const d = p.getAttribute('d') || '';
            if (!d) return;
            const cmdMatches = d.match(/[a-df-z][^a-df-z]*/gi);
            if (!cmdMatches) return;

            let curX = 0;
            let curY = 0;
            let startX = 0;
            let startY = 0;
            let currentPathPts: Point2D[] = [];

            cmdMatches.forEach((cmdStr) => {
              const cmd = cmdStr[0];
              const nums = cmdStr.slice(1).trim().split(/[\s,]+/).map(parseFloat).filter((n) => !isNaN(n));

              if (cmd === 'M' || cmd === 'm') {
                if (currentPathPts.length > 1) {
                  segments.push({ type: 'cut', points: [...currentPathPts] });
                }
                const isRel = cmd === 'm';
                curX = (isRel ? curX : 0) + (nums[0] || 0);
                curY = (isRel ? curY : 0) + (nums[1] || 0);
                startX = curX;
                startY = curY;
                currentPathPts = [{ x: curX, y: parsedHeight - curY }];
              } else if (cmd === 'L' || cmd === 'l') {
                const isRel = cmd === 'l';
                for (let i = 0; i < nums.length; i += 2) {
                  if (i + 1 < nums.length) {
                    curX = (isRel ? curX : 0) + nums[i];
                    curY = (isRel ? curY : 0) + nums[i + 1];
                    currentPathPts.push({ x: curX, y: parsedHeight - curY });
                  }
                }
              } else if (cmd === 'H' || cmd === 'h') {
                const isRel = cmd === 'h';
                nums.forEach((val) => {
                  curX = (isRel ? curX : 0) + val;
                  currentPathPts.push({ x: curX, y: parsedHeight - curY });
                });
              } else if (cmd === 'V' || cmd === 'v') {
                const isRel = cmd === 'v';
                nums.forEach((val) => {
                  curY = (isRel ? curY : 0) + val;
                  currentPathPts.push({ x: curX, y: parsedHeight - curY });
                });
              } else if (cmd === 'C' || cmd === 'c') {
                const isRel = cmd === 'c';
                for (let i = 0; i < nums.length; i += 6) {
                  if (i + 5 < nums.length) {
                    const x3 = (isRel ? curX : 0) + nums[i + 4];
                    const y3 = (isRel ? curY : 0) + nums[i + 5];
                    curX = x3;
                    curY = y3;
                    currentPathPts.push({ x: curX, y: parsedHeight - curY });
                  }
                }
              } else if (cmd === 'Z' || cmd === 'z') {
                currentPathPts.push({ x: startX, y: parsedHeight - startY });
                if (currentPathPts.length > 1) {
                  segments.push({ type: 'cut', points: [...currentPathPts] });
                }
                currentPathPts = [];
              }
            });

            if (currentPathPts.length > 1) {
              segments.push({ type: 'cut', points: currentPathPts });
            }
          });

          if (segments.length > 0) {
            // Compute tight bounding box
            let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
            segments.forEach((s) => {
              s.points.forEach((pt) => {
                minX = Math.min(minX, pt.x);
                maxX = Math.max(maxX, pt.x);
                minY = Math.min(minY, pt.y);
                maxY = Math.max(maxY, pt.y);
              });
            });

            setRawSegments(segments);
            setOriginalBounds({
              minX: isFinite(minX) ? minX : 0,
              maxX: isFinite(maxX) ? maxX : parsedWidth,
              minY: isFinite(minY) ? minY : 0,
              maxY: isFinite(maxY) ? maxY : parsedHeight,
              width: Math.max(10, (maxX - minX) || parsedWidth),
              height: Math.max(10, (maxY - minY) || parsedHeight),
            });
          } else {
            // Fallback to active preset pattern
            const activePreset = presetPatterns[0];
            setRawSegments(activePreset.generatePaths(panelWidth, panelHeight, margin));
          }
        } catch (svgErr) {
          console.error('Failed to parse SVG:', svgErr);
        }
      } else if (ext === 'dxf') {
        // Parse AutoCAD DXF Entity Coordinates (LINE, LWPOLYLINE, CIRCLE, ARC)
        try {
          const rawLines = text.split(/\r?\n/).map((l) => l.trim());
          const dxfSegments: ToolpathSegment[] = [];
          let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;

          for (let i = 0; i < rawLines.length - 1; i++) {
            const code = rawLines[i];
            const val = rawLines[i + 1]?.toUpperCase();

            if (code === '0' && val === 'LINE') {
              let x1 = 0, y1 = 0, x2 = 0, y2 = 0;
              let j = i + 2;
              while (j < rawLines.length - 1 && rawLines[j] !== '0') {
                const subCode = rawLines[j];
                const subVal = parseFloat(rawLines[j + 1]);
                if (subCode === '10') x1 = subVal;
                if (subCode === '20') y1 = subVal;
                if (subCode === '11') x2 = subVal;
                if (subCode === '21') y2 = subVal;
                j += 2;
              }
              if (isFinite(x1) && isFinite(x2)) {
                minX = Math.min(minX, x1, x2);
                maxX = Math.max(maxX, x1, x2);
                minY = Math.min(minY, y1, y2);
                maxY = Math.max(maxY, y1, y2);
                dxfSegments.push({ type: 'cut', points: [{ x: x1, y: y1 }, { x: x2, y: y2 }] });
              }
            } else if (code === '0' && val === 'LWPOLYLINE') {
              const polyPts: Point2D[] = [];
              let j = i + 2;
              let curPx = 0;
              while (j < rawLines.length - 1 && rawLines[j] !== '0') {
                const subCode = rawLines[j];
                const subVal = parseFloat(rawLines[j + 1]);
                if (subCode === '10') curPx = subVal;
                if (subCode === '20') {
                  const curPy = subVal;
                  polyPts.push({ x: curPx, y: curPy });
                  minX = Math.min(minX, curPx);
                  maxX = Math.max(maxX, curPx);
                  minY = Math.min(minY, curPy);
                  maxY = Math.max(maxY, curPy);
                }
                j += 2;
              }
              if (polyPts.length > 1) {
                dxfSegments.push({ type: 'cut', points: polyPts });
              }
            } else if (code === '0' && val === 'CIRCLE') {
              let cx = 0, cy = 0, r = 10;
              let j = i + 2;
              while (j < rawLines.length - 1 && rawLines[j] !== '0') {
                const subCode = rawLines[j];
                const subVal = parseFloat(rawLines[j + 1]);
                if (subCode === '10') cx = subVal;
                if (subCode === '20') cy = subVal;
                if (subCode === '40') r = subVal;
                j += 2;
              }
              const circlePts: Point2D[] = [];
              for (let s = 0; s <= 32; s++) {
                const a = (s / 32) * Math.PI * 2;
                circlePts.push({ x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) });
              }
              minX = Math.min(minX, cx - r);
              maxX = Math.max(maxX, cx + r);
              minY = Math.min(minY, cy - r);
              maxY = Math.max(maxY, cy + r);
              dxfSegments.push({ type: 'cut', points: circlePts });
            }
          }

          if (dxfSegments.length > 0 && isFinite(minX) && isFinite(maxX)) {
            setRawSegments(dxfSegments);
            setOriginalBounds({
              minX,
              maxX,
              minY,
              maxY,
              width: Math.max(10, maxX - minX),
              height: Math.max(10, maxY - minY),
            });
            return;
          }
        } catch (dxfErr) {
          console.warn('DXF parse error:', dxfErr);
        }
      }

      // G-Code, NC, or TAP files
      const lines = text.split(/\r?\n/);
      const segments: ToolpathSegment[] = [];
      let curSegment: Point2D[] = [];
      let minX = Infinity;
      let maxX = -Infinity;
      let minY = Infinity;
      let maxY = -Infinity;
      let curX = 0;
      let curY = 0;
      let curZ = safeZ;

      lines.forEach((line) => {
        const clean = line.trim().toUpperCase();
        if (!clean || clean.startsWith('(') || clean.startsWith(';')) return;

        const isG0 = clean.includes('G0') || clean.includes('G00');
        const isG1 = clean.includes('G1') || clean.includes('G01');
        const isG2 = clean.includes('G2') || clean.includes('G02') || clean.includes('G3') || clean.includes('G03');

        if (isG0 || isG1 || isG2) {
          const xMatch = clean.match(/X([-+]?[0-9]*\.?[0-9]+)/);
          const yMatch = clean.match(/Y([-+]?[0-9]*\.?[0-9]+)/);
          const zMatch = clean.match(/Z([-+]?[0-9]*\.?[0-9]+)/);

          if (xMatch) curX = parseFloat(xMatch[1]);
          if (yMatch) curY = parseFloat(yMatch[1]);
          if (zMatch) curZ = parseFloat(zMatch[1]);

          minX = Math.min(minX, curX);
          maxX = Math.max(maxX, curX);
          minY = Math.min(minY, curY);
          maxY = Math.max(maxY, curY);

          if (isG0) {
            if (curSegment.length > 1) {
              segments.push({ type: 'cut', points: [...curSegment] });
            }
            curSegment = [{ x: curX, y: curY, z: curZ }];
          } else {
            curSegment.push({ x: curX, y: curY, z: curZ });
          }
        }
      });

      if (curSegment.length > 1) {
        segments.push({ type: 'cut', points: [...curSegment] });
      }

      if (segments.length > 0 && isFinite(minX) && isFinite(maxX)) {
        setRawSegments(segments);
        setOriginalBounds({
          minX,
          maxX,
          minY,
          maxY,
          width: Math.max(10, maxX - minX),
          height: Math.max(10, maxY - minY),
        });
      } else {
        const activePreset = presetPatterns[0];
        setRawSegments(activePreset.generatePaths(panelWidth, panelHeight, margin));
      }
    };
    reader.readAsText(file);
  };

  // Canvas Drawing Engine: Renders realistic wood grain board, dimension rulers, grid, and scaled toolpaths
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // HiDPI Scaling
    const dpr = window.devicePixelRatio || 1;
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    // Dark backdrop
    ctx.fillStyle = '#060c17';
    ctx.fillRect(0, 0, width, height);

    // Calculate view transformation to center the wooden panel (adapts to split view when File B is active)
    const isSplit = canvasViewLayout === 'split' && Boolean(fileBData);
    const marginPx = 40;
    const paneAW = isSplit ? width * 0.52 : width;
    const availW = paneAW - marginPx * 2;
    const availH = height - marginPx * 2;

    const scaleToFit = Math.min(availW / panelWidth, availH / panelHeight) * zoom;
    const centerX = paneAW / 2 + pan.x;
    const centerY = height / 2 + pan.y;

    // Top-left of the wooden board on screen
    const boardX = centerX - (panelWidth * scaleToFit) / 2;
    const boardY = centerY - (panelHeight * scaleToFit) / 2;
    const boardW = panelWidth * scaleToFit;
    const boardH = panelHeight * scaleToFit;

    // 1. Draw Wooden Panel with realistic wood species styling & grain
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(boardX, boardY, boardW, boardH, 8);
    ctx.clip();

    // Wood species base fill
    const woodGradients: Record<WoodType, [string, string, string]> = {
      sheesham: ['#3e1e12', '#2a1208', '#4d2617'], // Deep reddish-brown Sheesham
      walnut: ['#332219', '#241710', '#3d2b20'], // Dark Swat walnut
      teak: ['#593b1d', '#3f2811', '#6b4724'], // Golden Teak
      mdf: ['#806a55', '#6e5a47', '#917962'], // Uniform MDF ochre
      deodar: ['#734c29', '#57371a', '#8a5e35'], // Warm Himalayan Cedar
    };

    const colors = woodGradients[woodType];
    const grad = ctx.createLinearGradient(boardX, boardY, boardX + boardW, boardY + boardH);
    grad.addColorStop(0, colors[0]);
    grad.addColorStop(0.5, colors[1]);
    grad.addColorStop(1, colors[2]);
    ctx.fillStyle = grad;
    ctx.fillRect(boardX, boardY, boardW, boardH);

    // Subtle Wood Grain Fibers
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 1;
    for (let gy = 0; gy < boardH; gy += 14) {
      ctx.beginPath();
      ctx.moveTo(boardX, boardY + gy);
      ctx.bezierCurveTo(
        boardX + boardW * 0.3,
        boardY + gy + 4,
        boardX + boardW * 0.7,
        boardY + gy - 4,
        boardX + boardW,
        boardY + gy
      );
      ctx.stroke();
    }
    ctx.restore();

    // Board Outer Border & Chamfer
    ctx.strokeStyle = '#00f2fe';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(boardX, boardY, boardW, boardH);

    // 2. Safe Margin Boundary (dashed line)
    const marginPxX = margin * scaleToFit;
    ctx.setLineDash([6, 4]);
    ctx.strokeStyle = 'rgba(0, 242, 254, 0.45)';
    ctx.lineWidth = 1;
    ctx.strokeRect(
      boardX + marginPxX,
      boardY + marginPxX,
      boardW - marginPxX * 2,
      boardH - marginPxX * 2
    );
    ctx.setLineDash([]);

    // 3. Grid Lines & Dimension Markings
    if (showGrid) {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = 0.5;
      const gridStep = 50 * scaleToFit; // every 50mm
      for (let gx = boardX; gx <= boardX + boardW; gx += gridStep) {
        ctx.beginPath();
        ctx.moveTo(gx, boardY);
        ctx.lineTo(gx, boardY + boardH);
        ctx.stroke();
      }
      for (let gy = boardY; gy <= boardY + boardH; gy += gridStep) {
        ctx.beginPath();
        ctx.moveTo(boardX, gy);
        ctx.lineTo(boardX + boardW, gy);
        ctx.stroke();
      }
    }

    // Coordinate conversion function from Model (X, Y) to Screen Canvas (px, px)
    const toScreen = (pt: Point2D) => {
      let xMm = pt.x;
      let yMm = pt.y;

      if (origin === 'center') {
        xMm += panelWidth / 2;
        yMm += panelHeight / 2;
      } else if (origin === 'top_left') {
        yMm = panelHeight - yMm;
      }

      const scrX = boardX + xMm * scaleToFit;
      // In CNC, Y0 is bottom-left by default, canvas Y0 is top-left
      const scrY = boardY + (panelHeight - yMm) * scaleToFit;
      return { x: scrX, y: scrY };
    };

    // 4. Render Actual Uploaded Graphics (Raster Image or Vector / 3D Relief)
    if (loadedImage) {
      // Calculate scaled image position inside wooden panel
      const targetW = Math.max(10, panelWidth - margin * 2);
      const targetH = Math.max(10, panelHeight - margin * 2);
      const origW = originalBounds.width || 1;
      const origH = originalBounds.height || 1;

      let s = Math.min(targetW / origW, targetH / origH);
      if (scaleMode === 'custom') {
        s = s * (customScalePercent / 100);
      }

      const drawW = (scaleMode === 'stretch' ? targetW : origW * s) * scaleToFit;
      const drawH = (scaleMode === 'stretch' ? targetH : origH * s) * scaleToFit;
      const drawX = boardX + (boardW - drawW) / 2;
      const drawY = boardY + (boardH - drawH) / 2;

      ctx.save();
      // Clip inside panel
      ctx.beginPath();
      ctx.roundRect(boardX, boardY, boardW, boardH, 8);
      ctx.clip();

      if (viewMode === '3d') {
        // 3D Relief & Carved Depth Mode:
        // Draw wood-carved recessed depth shadow and embossed highlight
        ctx.save();
        ctx.globalCompositeOperation = 'multiply';
        ctx.globalAlpha = 0.85;
        ctx.filter = 'contrast(160%) brightness(75%) drop-shadow(2px 3px 4px rgba(0,0,0,0.8))';
        ctx.drawImage(loadedImage, drawX, drawY, drawW, drawH);
        ctx.restore();

        // 3D Rim Highlights (chiseled edge glow)
        ctx.save();
        ctx.globalCompositeOperation = 'screen';
        ctx.globalAlpha = 0.45;
        ctx.filter = 'drop-shadow(-1px -1px 2px rgba(255,220,150,0.6))';
        ctx.drawImage(loadedImage, drawX - 1, drawY - 1, drawW, drawH);
        ctx.restore();
      } else {
        // 2D Design View Mode:
        // High fidelity presentation overlaid on wood with crisp outline
        ctx.save();
        ctx.globalAlpha = 0.92;
        ctx.filter = 'drop-shadow(0 2px 5px rgba(0,0,0,0.6))';
        ctx.drawImage(loadedImage, drawX, drawY, drawW, drawH);
        ctx.restore();
      }

      ctx.restore();
    }

    // 5. Draw Toolpaths & Vector Cut Lines
    if (viewMode === '3d') {
      // 3D Relief & Depth Preview: Deep wood V-groove carving simulation with bevel shading
      ctx.save();
      // Recessed depth dark shadow
      ctx.strokeStyle = 'rgba(10, 5, 2, 0.85)';
      ctx.lineWidth = Math.max(2, (toolDiameter / 2) * scaleToFit * 0.7);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      scaledSegments.forEach((seg) => {
        if (seg.points.length < 2) return;
        ctx.beginPath();
        const start = toScreen(seg.points[0]);
        ctx.moveTo(start.x + 1.5, start.y + 1.5);
        for (let i = 1; i < seg.points.length; i++) {
          const p = toScreen(seg.points[i]);
          ctx.lineTo(p.x + 1.5, p.y + 1.5);
        }
        ctx.stroke();
      });

      // Bevel highlight groove (wood chisel reflection)
      ctx.strokeStyle = 'rgba(255, 215, 150, 0.55)';
      ctx.lineWidth = Math.max(1, (toolDiameter / 2) * scaleToFit * 0.35);
      scaledSegments.forEach((seg) => {
        if (seg.points.length < 2) return;
        ctx.beginPath();
        const start = toScreen(seg.points[0]);
        ctx.moveTo(start.x - 1, start.y - 1);
        for (let i = 1; i < seg.points.length; i++) {
          const p = toScreen(seg.points[i]);
          ctx.lineTo(p.x - 1, p.y - 1);
        }
        ctx.stroke();
      });

      // Deep bottom core
      ctx.strokeStyle = '#0284c7';
      ctx.lineWidth = Math.max(1, (toolDiameter / 2) * scaleToFit * 0.25);
      scaledSegments.forEach((seg) => {
        if (seg.points.length < 2) return;
        ctx.beginPath();
        const start = toScreen(seg.points[0]);
        ctx.moveTo(start.x, start.y);
        for (let i = 1; i < seg.points.length; i++) {
          const p = toScreen(seg.points[i]);
          ctx.lineTo(p.x, p.y);
        }
        ctx.stroke();
      });
      ctx.restore();
    } else {
      // 2D Design View Mode: Clean CAD Vector Lines & CNC Travel Paths
      // Rapid Moves (G00) in dashed amber
      if (showRapidMoves && scaledSegments.length > 1) {
        ctx.strokeStyle = 'rgba(245, 158, 11, 0.65)';
        ctx.setLineDash([4, 4]);
        ctx.lineWidth = 1;
        for (let s = 1; s < scaledSegments.length; s++) {
          const prevEnd = scaledSegments[s - 1].points[scaledSegments[s - 1].points.length - 1];
          const curStart = scaledSegments[s].points[0];
          if (prevEnd && curStart) {
            const p1 = toScreen(prevEnd);
            const p2 = toScreen(curStart);
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }
        ctx.setLineDash([]);
      }

      // Cutting Passes (G01/G02/G03) in vibrant glowing cyan CAD lines
      ctx.shadowColor = '#00f2fe';
      ctx.shadowBlur = 6;
      ctx.strokeStyle = '#00f2fe';
      ctx.lineWidth = Math.max(1.5, (toolDiameter / 2) * scaleToFit * 0.4);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      scaledSegments.forEach((seg) => {
        if (seg.points.length < 2) return;
        ctx.beginPath();
        const start = toScreen(seg.points[0]);
        ctx.moveTo(start.x, start.y);
        for (let i = 1; i < seg.points.length; i++) {
          const p = toScreen(seg.points[i]);
          ctx.lineTo(p.x, p.y);
        }
        ctx.stroke();
      });

      ctx.shadowBlur = 0;
    }

    // 5. Machine Origin Marker (X0, Y0)
    let originMmX = 0;
    let originMmY = 0;
    if (origin === 'center') {
      originMmX = 0;
      originMmY = 0;
    } else if (origin === 'top_left') {
      originMmX = 0;
      originMmY = panelHeight;
    }

    const scrOrigin = toScreen({ x: originMmX, y: originMmY });
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.arc(scrOrigin.x, scrOrigin.y, 6, 0, Math.PI * 2);
    ctx.fill();

    // Crosshair on origin
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(scrOrigin.x - 10, scrOrigin.y);
    ctx.lineTo(scrOrigin.x + 10, scrOrigin.y);
    ctx.moveTo(scrOrigin.x, scrOrigin.y - 10);
    ctx.lineTo(scrOrigin.x, scrOrigin.y + 10);
    ctx.stroke();

    // Origin label
    ctx.fillStyle = '#00f2fe';
    ctx.font = 'bold 10px monospace';
    ctx.fillText('X0 Y0 (Origin)', scrOrigin.x + 12, scrOrigin.y + 4);

    // 6. Selected Element Highlight & Interactive Bounding Box
    if (selectedElementId && elements.length > 0) {
      const activeElem = elements.find((e) => e.id === selectedElementId);
      if (activeElem && activeElem.visible && activeElem.segments.length > 0) {
        // Collect all points of selected element from scaledSegments to get screen bounding box
        let minScrX = Infinity, maxScrX = -Infinity, minScrY = Infinity, maxScrY = -Infinity;
        
        // Find segment points corresponding to this element
        const elemCenterX = (activeElem.bounds.minX + activeElem.bounds.maxX) / 2;
        const elemCenterY = (activeElem.bounds.minY + activeElem.bounds.maxY) / 2;
        const rotRad = (activeElem.rotation * Math.PI) / 180;
        const cosR = Math.cos(rotRad);
        const sinR = Math.sin(rotRad);

        const targetW = Math.max(10, panelWidth - margin * 2);
        const targetH = Math.max(10, panelHeight - margin * 2);
        const origW = originalBounds.width || 1;
        const origH = originalBounds.height || 1;
        let globalScaleX = 1;
        let globalScaleY = 1;
        if (scaleMode === 'fit_proportional') {
          const s = Math.min(targetW / origW, targetH / origH);
          globalScaleX = s;
          globalScaleY = s;
        } else if (scaleMode === 'stretch') {
          globalScaleX = targetW / origW;
          globalScaleY = targetH / origH;
        } else if (scaleMode === 'custom') {
          const s = (customScalePercent / 100) * Math.min(targetW / origW, targetH / origH);
          globalScaleX = s;
          globalScaleY = s;
        }
        const scaledDesignW = origW * globalScaleX;
        const scaledDesignH = origH * globalScaleY;
        const baseOffsetX = margin + (targetW - scaledDesignW) / 2 - originalBounds.minX * globalScaleX;
        const baseOffsetY = margin + (targetH - scaledDesignH) / 2 - originalBounds.minY * globalScaleY;

        activeElem.segments.forEach((seg) => {
          seg.points.forEach((p) => {
            let lx = (p.x - elemCenterX) * activeElem.scale;
            let ly = (p.y - elemCenterY) * activeElem.scale;
            if (activeElem.rotation !== 0) {
              const rx = lx * cosR - ly * sinR;
              const ry = lx * sinR + ly * cosR;
              lx = rx;
              ly = ry;
            }
            const worldX = elemCenterX + lx;
            const worldY = elemCenterY + ly;
            let finalX = worldX * globalScaleX + baseOffsetX + activeElem.xOffset;
            let finalY = worldY * globalScaleY + baseOffsetY + activeElem.yOffset;

            if (origin === 'center') {
              finalX -= panelWidth / 2;
              finalY -= panelHeight / 2;
            } else if (origin === 'top_left') {
              finalY = panelHeight - finalY;
            }

            const scrPt = toScreen({ x: finalX, y: finalY });
            minScrX = Math.min(minScrX, scrPt.x);
            maxScrX = Math.max(maxScrX, scrPt.x);
            minScrY = Math.min(minScrY, scrPt.y);
            maxScrY = Math.max(maxScrY, scrPt.y);
          });
        });

        if (isFinite(minScrX) && isFinite(maxScrX)) {
          const padBox = 8;
          const boxX = minScrX - padBox;
          const boxY = minScrY - padBox;
          const boxW = Math.max(20, maxScrX - minScrX + padBox * 2);
          const boxH = Math.max(20, maxScrY - minScrY + padBox * 2);

          // Glowing dashed bounding box
          ctx.save();
          ctx.strokeStyle = '#f59e0b'; // Amber selection border
          ctx.lineWidth = 1.5;
          ctx.setLineDash([5, 4]);
          ctx.strokeRect(boxX, boxY, boxW, boxH);
          ctx.setLineDash([]);

          // Corner handles
          ctx.fillStyle = '#f59e0b';
          const handleSize = 6;
          const handles = [
            { x: boxX, y: boxY },
            { x: boxX + boxW, y: boxY },
            { x: boxX + boxW, y: boxY + boxH },
            { x: boxX, y: boxY + boxH },
            { x: boxX + boxW / 2, y: boxY }, // top center rotation handle
          ];
          handles.forEach((h, hIdx) => {
            if (hIdx === 4) {
              ctx.fillStyle = '#00f2fe'; // cyan rotation handle
              ctx.beginPath();
              ctx.arc(h.x, h.y - 12, 4.5, 0, Math.PI * 2);
              ctx.fill();
              ctx.strokeStyle = '#00f2fe';
              ctx.beginPath();
              ctx.moveTo(h.x, h.y);
              ctx.lineTo(h.x, h.y - 12);
              ctx.stroke();
            } else {
              ctx.fillStyle = '#f59e0b';
              ctx.fillRect(h.x - handleSize / 2, h.y - handleSize / 2, handleSize, handleSize);
            }
          });

          // Element label tag
          ctx.fillStyle = 'rgba(245, 158, 11, 0.95)';
          ctx.fillRect(boxX, boxY - 18, 120, 16);
          ctx.fillStyle = '#090d16';
          ctx.font = 'bold 9.5px sans-serif';
          ctx.fillText(
            `✦ ${lang === 'en' ? activeElem.name : activeElem.nameUr}`,
            boxX + 4,
            boxY - 6
          );
          ctx.restore();
        }
      }
    }

    // 6. Dimension Badges along edges
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.fillRect(boardX + boardW / 2 - 45, boardY - 22, 90, 18);
    ctx.strokeStyle = '#00f2fe';
    ctx.strokeRect(boardX + boardW / 2 - 45, boardY - 22, 90, 18);
    ctx.fillStyle = '#00f2fe';
    ctx.font = 'bold 10px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(
      `W: ${toDisplayUnit(panelWidth)}${unit}`,
      boardX + boardW / 2,
      boardY - 9
    );

    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.fillRect(boardX + boardW + 6, boardY + boardH / 2 - 10, 85, 18);
    ctx.strokeRect(boardX + boardW + 6, boardY + boardH / 2 - 10, 85, 18);
    ctx.fillStyle = '#00f2fe';
    ctx.fillText(
      `H: ${toDisplayUnit(panelHeight)}${unit}`,
      boardX + boardW + 48,
      boardY + boardH / 2 + 3
    );
    // 7. If Dual Split View is Active, render File B Source Library in Right Pane
    if (isSplit && fileBData) {
      const paneBX = paneAW;
      const paneBW = width - paneAW;
      ctx.save();
      ctx.beginPath();
      ctx.rect(paneBX, 0, paneBW, height);
      ctx.clip();

      // Background for Pane B: Dark Blueprint grid
      ctx.fillStyle = '#040a16';
      ctx.fillRect(paneBX, 0, paneBW, height);

      // Blueprint subtle grid
      ctx.strokeStyle = 'rgba(0, 242, 254, 0.08)';
      ctx.lineWidth = 1;
      for (let gx = paneBX; gx <= width; gx += 25) {
        ctx.beginPath();
        ctx.moveTo(gx, 0);
        ctx.lineTo(gx, height);
        ctx.stroke();
      }
      for (let gy = 0; gy <= height; gy += 25) {
        ctx.beginPath();
        ctx.moveTo(paneBX, gy);
        ctx.lineTo(width, gy);
        ctx.stroke();
      }

      // Vertical neon dashed divider
      ctx.strokeStyle = '#00f2fe';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([5, 4]);
      ctx.beginPath();
      ctx.moveTo(paneBX, 0);
      ctx.lineTo(paneBX, height);
      ctx.stroke();
      ctx.setLineDash([]);

      // Pane B Header Badge
      ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
      ctx.fillRect(paneBX + 10, 10, paneBW - 20, 26);
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 1.2;
      ctx.strokeRect(paneBX + 10, 10, paneBW - 20, 26);
      ctx.fillStyle = '#f59e0b';
      ctx.font = 'bold 10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(
        `✦ File B Library: ${fileBData.fileName} (${fileBData.elements.length} motifs)`,
        paneBX + paneBW / 2,
        27
      );
      ctx.textAlign = 'start';

      // Scale & Center File B Geometry
      const bOrigW = Math.max(10, fileBData.originalBounds.width);
      const bOrigH = Math.max(10, fileBData.originalBounds.height);
      const bScale = Math.min((paneBW - 40) / bOrigW, (height - 90) / bOrigH) * zoom;
      const bCenterX = paneBX + paneBW / 2;
      const bCenterY = height / 2 + 15;
      const bStartX = bCenterX - (bOrigW * bScale) / 2;
      const bStartY = bCenterY - (bOrigH * bScale) / 2;

      // Draw File B raster image if present
      if (fileBData.loadedImage) {
        ctx.drawImage(fileBData.loadedImage, bStartX, bStartY, bOrigW * bScale, bOrigH * bScale);
      }

      // Draw File B Motifs
      fileBData.elements.forEach((elB) => {
        const isSel = elB.id === selectedFileBElementId;
        ctx.strokeStyle = isSel ? '#10b981' : '#f59e0b';
        ctx.lineWidth = isSel ? 2 : 1.2;

        elB.segments.forEach((seg) => {
          if (seg.points.length < 2) return;
          ctx.beginPath();
          seg.points.forEach((pt, pIdx) => {
            const sx = bStartX + (pt.x - fileBData.originalBounds.minX) * bScale;
            const sy = bStartY + (bOrigH - (pt.y - fileBData.originalBounds.minY)) * bScale;
            if (pIdx === 0) ctx.moveTo(sx, sy);
            else ctx.lineTo(sx, sy);
          });
          ctx.stroke();
        });

        // Bounding box on motif
        const elMinX = bStartX + (elB.bounds.minX - fileBData.originalBounds.minX) * bScale;
        const elMinY = bStartY + (bOrigH - (elB.bounds.maxY - fileBData.originalBounds.minY)) * bScale;
        const elBoxW = elB.bounds.width * bScale;
        const elBoxH = elB.bounds.height * bScale;

        if (isSel) {
          ctx.strokeStyle = '#10b981';
          ctx.setLineDash([4, 3]);
          ctx.strokeRect(elMinX - 3, elMinY - 3, elBoxW + 6, elBoxH + 6);
          ctx.setLineDash([]);

          ctx.fillStyle = '#10b981';
          ctx.fillRect(elMinX, elMinY - 18, 140, 16);
          ctx.fillStyle = '#060c17';
          ctx.font = 'bold 9.5px sans-serif';
          ctx.fillText(`✓ READY TO IMPORT: ${elB.name}`, elMinX + 4, elMinY - 6);
        }
      });

      ctx.restore();
    }

    ctx.textAlign = 'start';
  }, [
    panelWidth,
    panelHeight,
    margin,
    woodType,
    scaledSegments,
    zoom,
    pan,
    showRapidMoves,
    showGrid,
    toolDiameter,
    origin,
    unit,
    viewMode,
    loadedImage,
    scaleMode,
    customScalePercent,
    originalBounds,
    elements,
    selectedElementId,
    canvasViewLayout,
    fileBData,
    selectedFileBElementId,
  ]);

  // Interactive Canvas Mouse & Touch Drag/Move/Select Handlers
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    if (canvasTool === 'pan') {
      panStartRef.current = {
        x: clickX,
        y: clickY,
        initialPanX: pan.x,
        initialPanY: pan.y,
      };
      return;
    }

    const width = canvas.clientWidth;
    const height = canvas.clientHeight;

    // Handle clicks inside File B source library pane when in split mode
    if (canvasViewLayout === 'split' && fileBData && clickX >= width * 0.52) {
      const paneBX = width * 0.52;
      const paneBW = width - paneBX;
      const bOrigW = Math.max(10, fileBData.originalBounds.width);
      const bOrigH = Math.max(10, fileBData.originalBounds.height);
      const bScale = Math.min((paneBW - 40) / bOrigW, (height - 90) / bOrigH) * zoom;
      const bCenterX = paneBX + paneBW / 2;
      const bCenterY = height / 2 + 15;
      const bStartX = bCenterX - (bOrigW * bScale) / 2;
      const bStartY = bCenterY - (bOrigH * bScale) / 2;

      for (let i = fileBData.elements.length - 1; i >= 0; i--) {
        const elB = fileBData.elements[i];
        const elMinX = bStartX + (elB.bounds.minX - fileBData.originalBounds.minX) * bScale - 10;
        const elMaxX = elMinX + elB.bounds.width * bScale + 20;
        const elMinY = bStartY + (bOrigH - (elB.bounds.maxY - fileBData.originalBounds.minY)) * bScale - 10;
        const elMaxY = elMinY + elB.bounds.height * bScale + 20;

        if (clickX >= elMinX && clickX <= elMaxX && clickY >= elMinY && clickY <= elMaxY) {
          setSelectedFileBElementId(elB.id);
          return;
        }
      }
      return;
    }

    // In select/move mode: check if click hit any element's screen bounds on Panel A
    const isSplit = canvasViewLayout === 'split' && Boolean(fileBData);
    const marginPx = 40;
    const paneAW = isSplit ? width * 0.52 : width;
    const availW = paneAW - marginPx * 2;
    const availH = height - marginPx * 2;
    const scaleToFit = Math.min(availW / panelWidth, availH / panelHeight) * zoom;
    const centerX = paneAW / 2 + pan.x;
    const centerY = height / 2 + pan.y;
    const boardX = centerX - (panelWidth * scaleToFit) / 2;
    const boardY = centerY - (panelHeight * scaleToFit) / 2;

    const toScr = (mmX: number, mmY: number) => {
      let x = mmX;
      let y = mmY;
      if (origin === 'center') {
        x += panelWidth / 2;
        y += panelHeight / 2;
      } else if (origin === 'top_left') {
        y = panelHeight - y;
      }
      return {
        x: boardX + x * scaleToFit,
        y: boardY + (panelHeight - y) * scaleToFit,
      };
    };

    const targetW = Math.max(10, panelWidth - margin * 2);
    const targetH = Math.max(10, panelHeight - margin * 2);
    const origW = originalBounds.width || 1;
    const origH = originalBounds.height || 1;
    let globalScaleX = 1;
    let globalScaleY = 1;
    if (scaleMode === 'fit_proportional') {
      const s = Math.min(targetW / origW, targetH / origH);
      globalScaleX = s;
      globalScaleY = s;
    } else if (scaleMode === 'stretch') {
      globalScaleX = targetW / origW;
      globalScaleY = targetH / origH;
    } else if (scaleMode === 'custom') {
      const s = (customScalePercent / 100) * Math.min(targetW / origW, targetH / origH);
      globalScaleX = s;
      globalScaleY = s;
    }
    const scaledDesignW = origW * globalScaleX;
    const scaledDesignH = origH * globalScaleY;
    const baseOffsetX = margin + (targetW - scaledDesignW) / 2 - originalBounds.minX * globalScaleX;
    const baseOffsetY = margin + (targetH - scaledDesignH) / 2 - originalBounds.minY * globalScaleY;

    // Check hit for elements (reverse order so top element wins)
    let hitElement: DesignElement | null = null;
    for (let i = elements.length - 1; i >= 0; i--) {
      const el = elements[i];
      if (!el.visible) continue;

      let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
      el.segments.forEach((seg) => {
        seg.points.forEach((p) => {
          const worldX = p.x;
          const worldY = p.y;
          let finalX = worldX * globalScaleX + baseOffsetX + el.xOffset;
          let finalY = worldY * globalScaleY + baseOffsetY + el.yOffset;
          const sp = toScr(finalX, finalY);
          minX = Math.min(minX, sp.x);
          maxX = Math.max(maxX, sp.x);
          minY = Math.min(minY, sp.y);
          maxY = Math.max(maxY, sp.y);
        });
      });

      const pad = 12;
      if (clickX >= minX - pad && clickX <= maxX + pad && clickY >= minY - pad && clickY <= maxY + pad) {
        hitElement = el;
        break;
      }
    }

    if (hitElement) {
      setSelectedElementId(hitElement.id);
      setIsDraggingElement(true);
      dragStartRef.current = {
        x: clickX,
        y: clickY,
        initialOffsetX: hitElement.xOffset,
        initialOffsetY: hitElement.yOffset,
      };
    } else {
      // Clicked background board: allow panning
      panStartRef.current = {
        x: clickX,
        y: clickY,
        initialPanX: pan.x,
        initialPanY: pan.y,
      };
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const curX = e.clientX - rect.left;
    const curY = e.clientY - rect.top;

    if (isDraggingElement && dragStartRef.current && selectedElementId) {
      const dxPx = curX - dragStartRef.current.x;
      const dyPx = curY - dragStartRef.current.y;

      const width = canvas.clientWidth;
      const height = canvas.clientHeight;
      const marginPx = 40;
      const availW = width - marginPx * 2;
      const availH = height - marginPx * 2;
      const scaleToFit = Math.min(availW / panelWidth, availH / panelHeight) * zoom;

      // Invert Y because canvas Y increases downwards, CNC increases upwards
      const dxMm = dxPx / scaleToFit;
      const dyMm = -dyPx / scaleToFit;

      setElements((prev) =>
        prev.map((el) => {
          if (el.id !== selectedElementId) return el;
          return {
            ...el,
            xOffset: Number((dragStartRef.current!.initialOffsetX + dxMm).toFixed(1)),
            yOffset: Number((dragStartRef.current!.initialOffsetY + dyMm).toFixed(1)),
          };
        })
      );
    } else if (panStartRef.current) {
      const dx = curX - panStartRef.current.x;
      const dy = curY - panStartRef.current.y;
      setPan({
        x: panStartRef.current.initialPanX + dx,
        y: panStartRef.current.initialPanY + dy,
      });
    }
  };

  const handleCanvasMouseUp = () => {
    setIsDraggingElement(false);
    dragStartRef.current = null;
    panStartRef.current = null;
  };

  // Element Transform Action Helpers
  const handleRotateSelected = (angleDeg: number) => {
    if (!selectedElementId) return;
    setElements((prev) =>
      prev.map((el) => {
        if (el.id !== selectedElementId) return el;
        const newRot = (el.rotation + angleDeg) % 360;
        return { ...el, rotation: newRot };
      })
    );
  };

  const handleScaleSelected = (deltaScale: number) => {
    if (!selectedElementId) return;
    setElements((prev) =>
      prev.map((el) => {
        if (el.id !== selectedElementId) return el;
        const newScale = Math.max(0.2, Math.min(3.0, Number((el.scale + deltaScale).toFixed(2))));
        return { ...el, scale: newScale };
      })
    );
  };

  const handleResetSelected = () => {
    if (!selectedElementId) return;
    setElements((prev) =>
      prev.map((el) => {
        if (el.id !== selectedElementId) return el;
        return { ...el, xOffset: 0, yOffset: 0, scale: 1, rotation: 0 };
      })
    );
  };

  const handleToggleElementVisibility = (id: string) => {
    setElements((prev) =>
      prev.map((el) => {
        if (el.id !== id) return el;
        return { ...el, visible: !el.visible };
      })
    );
  };
  const generateRealGCode = (): string => {
    const timestamp = new Date().toISOString();
    const gcodeLines: string[] = [
      `; ========================================================`,
      `; ARBAZ WOOD CRAFT - CNC ROUTER AUTOMATED G-CODE EXPORTER`,
      `; Generated on: ${timestamp}`,
      `; Machine Controller: ${controller.toUpperCase()}`,
      `; Wood Species: ${woodType.toUpperCase()}`,
      `; Panel Size (W x H x T): ${panelWidth}mm x ${panelHeight}mm x ${panelThickness}mm`,
      `; Border Margin: ${margin}mm | Scaling Mode: ${scaleMode}`,
      `; Tool Bit: Dia ${toolDiameter}mm | Depth: -${cutDepth}mm`,
      `; Feedrate: ${feedRate} mm/min | Plunge: ${plungeRate} mm/min`,
      `; Safe Z Height: ${safeZ}mm | Spindle Speed: S${spindleSpeed}`,
      `; Total Toolpath Length: ${stats.lengthMeters} m`,
      `; ========================================================`,
      ``,
      `G21        ; Set Units to Millimeters`,
      `G90        ; Absolute Positioning`,
      `G17        ; XY Plane Selection`,
      `G94        ; Feed Rate in Units per Minute`,
      `G00 Z${safeZ.toFixed(3)}  ; Retract to Safe Z`,
      `M03 S${spindleSpeed}   ; Spindle ON Clockwise`,
      `G04 P2.5   ; Dwell 2.5s for Spindle to reach full RPM`,
      `M08        ; Coolant / Vacuum Dust Collector ON`,
      ``,
    ];

    scaledSegments.forEach((seg, sIdx) => {
      if (seg.points.length === 0) return;
      const start = seg.points[0];

      gcodeLines.push(`; --- Pass #${sIdx + 1} ---`);
      // Rapid to above start position
      gcodeLines.push(`G00 X${start.x.toFixed(3)} Y${start.y.toFixed(3)}`);
      // Rapid down to clearance Z (2mm above stock)
      gcodeLines.push(`G00 Z2.000`);
      // Plunge to cutting depth
      gcodeLines.push(`G01 Z${(-cutDepth).toFixed(3)} F${plungeRate}`);

      // Feed along toolpath coordinates
      for (let p = 1; p < seg.points.length; p++) {
        const pt = seg.points[p];
        const zVal = pt.z !== undefined ? pt.z.toFixed(3) : (-cutDepth).toFixed(3);
        gcodeLines.push(`G01 X${pt.x.toFixed(3)} Y${pt.y.toFixed(3)} Z${zVal} F${feedRate}`);
      }

      // Retract tool to safe Z height
      gcodeLines.push(`G00 Z${safeZ.toFixed(3)}`);
      gcodeLines.push(``);
    });

    // Program Footer
    gcodeLines.push(
      `; ========================================================`,
      `M09        ; Coolant OFF`,
      `M05        ; Spindle OFF`,
      `G00 Z${(safeZ * 2).toFixed(3)} ; Final Retract to Double Clearance`,
      `G00 X0.000 Y0.000 ; Return to Machine Origin (Park)`,
      `M30        ; Program End and Rewind`,
      `; ========================================================`
    );

    return gcodeLines.join('\n');
  };

  // Instant Real File Download Trigger (.nc or .tap)
  const handleDownloadGCode = (extension: 'nc' | 'tap') => {
    setIsExporting(true);
    const gcodeText = editableGCode.trim() ? editableGCode : generateRealGCode();
    const blob = new Blob([gcodeText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const cleanName = uploadedFileName
      ? uploadedFileName.replace(/\.[^/.]+$/, '')
      : activePresetId;
    a.download = `ArbazWoodCraft_${cleanName}_${panelWidth}x${panelHeight}_${Date.now()}.${extension}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setTimeout(() => {
      setIsExporting(false);
    }, 600);
  };

  // Export JSON Setup Sheet
  const handleDownloadSpecs = () => {
    const setupSheet = {
      project: 'Arbaz Wood Craft - Resized CNC Panel Setup',
      timestamp: new Date().toISOString(),
      panel: {
        widthMm: panelWidth,
        heightMm: panelHeight,
        thicknessMm: panelThickness,
        marginMm: margin,
        material: woodType,
        unit,
      },
      machining: {
        toolDiameterMm: toolDiameter,
        carvingDepthMm: cutDepth,
        feedRateMmPerMin: feedRate,
        plungeRateMmPerMin: plungeRate,
        safeZMm: safeZ,
        spindleSpeedRpm: spindleSpeed,
        controller,
        origin,
      },
      stats: {
        toolpathLengthMeters: stats.lengthMeters,
        estimatedTime: stats.timeString,
        pointsCount: stats.pointsCount,
      },
      sourceFile: uploadedFileName || `Preset: ${activePresetId}`,
    };

    const blob = new Blob([JSON.stringify(setupSheet, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ArbazWoodCraft_SetupSheet_${panelWidth}x${panelHeight}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopyGCode = () => {
    const gcode = generateRealGCode();
    navigator.clipboard.writeText(gcode);
    setCopiedGcode(true);
    setTimeout(() => setCopiedGcode(false), 2500);
  };

  return (
    <div className="space-y-6 w-full max-w-full overflow-x-hidden">
      {/* Hidden File Inputs: File A (Primary) and File B (Secondary Source / Motif Library) */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".nc,.tap,.gcode,.rlf,.art,.dxf,.svg,.stl,image/png,image/jpeg,image/webp,image/bmp,.png,.jpg,.jpeg,.bmp,.webp"
        className="hidden"
        onChange={handleFileUpload}
      />
      <input
        ref={fileBInputRef}
        type="file"
        accept=".nc,.tap,.gcode,.rlf,.art,.dxf,.svg,.stl,image/png,image/jpeg,image/webp,image/bmp,.png,.jpg,.jpeg,.bmp,.webp"
        className="hidden"
        onChange={handleFileBUpload}
      />

      {/* Prominent Import & Merge Toast Notification */}
      {importNotification && (
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 border border-emerald-500 text-emerald-200 text-xs sm:text-sm font-medium flex items-center justify-between gap-3 shadow-xl animate-fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{importNotification}</span>
          </div>
          <button
            onClick={() => setImportNotification('')}
            className="text-emerald-400 hover:text-white p-1 rounded-lg cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Feature Header Card */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-cyan-950/80 via-slate-900 to-blue-950/80 border border-cyan-800/80 shadow-2xl backdrop-blur-md">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center text-slate-950 shadow-lg shadow-cyan-500/25 shrink-0">
              <Ruler className="w-6 h-6 stroke-[2.4]" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] font-mono uppercase bg-cyan-950 text-cyan-300 border border-cyan-700/60 px-2 py-0.5 rounded font-bold">
                  3D CAD / RLF / G-CODE ENGINE
                </span>
                <span className="text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-700/60 px-2 py-0.5 rounded">
                  Mach3 & NCStudio Ready
                </span>
                <span className="text-[10px] font-mono bg-amber-950 text-amber-300 border border-amber-700/60 px-2 py-0.5 rounded">
                  Dual-File Merging Active
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-black text-white font-sans mt-0.5">
                {t.title}
              </h2>
              <p className="text-xs text-slate-400 font-sans mt-0.5 max-w-2xl leading-relaxed">
                {t.subtitle}
              </p>
            </div>
          </div>

          {/* Quick Actions / Unit Switcher / Dual File Upload Triggers */}
          <div className="flex items-center gap-2 self-end md:self-auto shrink-0 flex-wrap">
            <div className="bg-slate-950 p-1 rounded-xl border border-cyan-900/60 flex items-center gap-1 text-xs font-mono">
              <button
                onClick={() => setUnit('mm')}
                className={`px-3 py-1 rounded-lg transition cursor-pointer font-bold ${
                  unit === 'mm'
                    ? 'bg-cyan-500 text-slate-950'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                MM
              </button>
              <button
                onClick={() => setUnit('inch')}
                className={`px-3 py-1 rounded-lg transition cursor-pointer font-bold ${
                  unit === 'inch'
                    ? 'bg-cyan-500 text-slate-950'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                INCH
              </button>
            </div>

            {/* Upload File A Trigger */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/20 transition cursor-pointer active:scale-95"
              title="Upload Primary File A (.dxf, .svg, .stl, .nc, .tap, .png)"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>{uploadedFileName ? 'Change File A' : '📄 File A (Primary)'}</span>
            </button>

            {/* Upload File B Trigger */}
            <button
              onClick={() => fileBInputRef.current?.click()}
              className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 transition cursor-pointer active:scale-95"
              title="Upload Secondary File B to extract motifs and merge"
            >
              <FilePlus className="w-3.5 h-3.5" />
              <span>{fileBData ? 'Change File B' : '➕ File B (Source)'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Guided file workflow: import, edit, validate, export */}
      <div className="mb-5 rounded-2xl border border-cyan-900/70 bg-slate-950 p-4 text-sm text-slate-300">
        <h3 className="mb-2 font-bold text-cyan-300">فائل ایڈیٹنگ کا آسان طریقہ / File workflow</h3>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
          <div><b className="text-white">1. Upload / اپ لوڈ</b><p className="mt-1 text-xs">File A سے اپنی .nc, .tap, .gcode, .dxf یا .svg فائل منتخب کریں۔ File B دوسری ڈیزائن فائل یا موٹیف کے لیے ہے۔</p></div>
          <div><b className="text-white">2. Edit / ترمیم</b><p className="mt-1 text-xs">پیمائش، یونٹس، مارجن، اسکیل اور ٹول پیرامیٹرز تبدیل کریں؛ کینوس پر ڈیزائن اور ابعاد دیکھیں۔</p></div>
          <div><b className="text-white">3. Preview / جانچ</b><p className="mt-1 text-xs">G-Code پری ویو کھولیں، زیرو پوائنٹ، گہرائی، محفوظ Z اور کلیمپ کلیئرنس کی تصدیق کریں۔</p></div>
          <div><b className="text-white">4. Download / ڈاؤن لوڈ</b><p className="mt-1 text-xs">Export سیکشن سے .nc یا .tap ڈاؤن لوڈ کریں۔ اصل فائل کی کاپی محفوظ رکھیں اور مشین پر چلانے سے پہلے کنٹرولر میں ڈرائی رن کریں۔</p></div>
        </div>
        <p className="mt-3 rounded-lg border border-amber-800/60 bg-amber-950/30 p-2 text-xs text-amber-200">اہم: ہر CAM/کنٹرولر فائل مکمل طور پر قابلِ ترمیم نہیں ہوتی۔ امپورٹ کے بعد جیومیٹری اور پیمائش چیک کریں؛ اصل فائل، مشین یونٹس اور کنٹرولر فارمیٹ کی تصدیق کے بغیر کٹنگ نہ چلائیں۔</p>
      </div>

      {/* Main Grid: Left Controls (5 Cols), Right Dynamic Canvas (7 Cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Dimensions, File / Preset Selection, Scaling & Feeds */}
        <div className="lg:col-span-5 space-y-4">
          {/* Card 1: Panel Dimensions & Material */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-900/60 shadow-xl space-y-3.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-mono font-bold text-cyan-400 flex items-center gap-1.5">
                <Maximize2 className="w-4 h-4 text-cyan-400" />
                <span>{t.panelDimsHeader}</span>
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                {panelWidth} x {panelHeight} x {panelThickness} mm
              </span>
            </div>

            {/* Dimension Inputs */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] font-mono text-slate-300 block mb-1">
                  {t.widthLabel} ({unit}):
                </label>
                <input
                  type="number"
                  value={toDisplayUnit(panelWidth)}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value) || 10;
                    setPanelWidth(unit === 'inch' ? Math.round(val * 25.4) : val);
                  }}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-cyan-300 font-bold text-sm focus:outline-none focus:border-cyan-400 font-mono"
                />
              </div>

              <div>
                <label className="text-[11px] font-mono text-slate-300 block mb-1">
                  {t.heightLabel} ({unit}):
                </label>
                <input
                  type="number"
                  value={toDisplayUnit(panelHeight)}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value) || 10;
                    setPanelHeight(unit === 'inch' ? Math.round(val * 25.4) : val);
                  }}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-cyan-300 font-bold text-sm focus:outline-none focus:border-cyan-400 font-mono"
                />
              </div>

              <div>
                <label className="text-[11px] font-mono text-slate-300 block mb-1">
                  {t.thicknessLabel} ({unit}):
                </label>
                <input
                  type="number"
                  value={toDisplayUnit(panelThickness)}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value) || 5;
                    setPanelThickness(unit === 'inch' ? Math.round(val * 25.4) : val);
                  }}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-cyan-300 font-bold text-sm focus:outline-none focus:border-cyan-400 font-mono"
                />
              </div>

              <div>
                <label className="text-[11px] font-mono text-slate-300 block mb-1">
                  {t.marginLabel} ({unit}):
                </label>
                <input
                  type="number"
                  value={toDisplayUnit(margin)}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value) || 0;
                    setMargin(unit === 'inch' ? Math.round(val * 25.4) : val);
                  }}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-cyan-300 font-bold text-sm focus:outline-none focus:border-cyan-400 font-mono"
                />
              </div>
            </div>

            {/* Standard Pakistani Workshop Size Quick Presets */}
            <div>
              <span className="text-[10px] font-mono text-slate-400 block mb-1.5">
                {t.presetSizes}:
              </span>
              <div className="grid grid-cols-3 gap-1.5 text-[11px] font-mono">
                {[
                  { label: '300x600 (Small)', w: 300, h: 600 },
                  { label: '450x900 (Dila)', w: 450, h: 900 },
                  { label: '600x1200 (Door)', w: 600, h: 1200 },
                  { label: '900x2100 (Full)', w: 900, h: 2100 },
                  { label: '12x24 inch', w: 305, h: 610 },
                  { label: '18x36 inch', w: 457, h: 914 },
                ].map((s, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setPanelWidth(s.w);
                      setPanelHeight(s.h);
                    }}
                    className={`py-1 px-1.5 rounded-lg border text-center transition cursor-pointer ${
                      panelWidth === s.w && panelHeight === s.h
                        ? 'bg-cyan-950 text-cyan-300 border-cyan-500 font-bold'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Wood Species Dropdown */}
            <div>
              <label className="text-[11px] font-mono text-slate-300 block mb-1">
                {t.woodMaterial}:
              </label>
              <select
                value={woodType}
                onChange={(e) => setWoodType(e.target.value as WoodType)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-amber-300 font-sans focus:outline-none focus:border-cyan-400"
              >
                <option value="sheesham">🪵 {t.sheeshamWood}</option>
                <option value="walnut">🌲 {t.walnutWood}</option>
                <option value="teak">🌳 {t.teakWood}</option>
                <option value="mdf">🟫 {t.mdfWood}</option>
                <option value="deodar">🪵 {t.deodarWood}</option>
              </select>
            </div>
          </div>

          {/* Card 2: DUAL FILE UPLOAD & DESIGN MERGING SYSTEM (File A & File B) */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-900/60 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-mono font-bold text-cyan-400 flex items-center gap-1.5">
                <GitMerge className="w-4 h-4 text-cyan-400" />
                <span>{t.dualFileHeader}</span>
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/80 border border-cyan-800 text-cyan-300">
                {fileBData ? '2 Files Active' : '1 File Active'}
              </span>
            </div>

            {/* SLOT 1: Primary File (File A - Workspace) */}
            <div className="p-3 rounded-xl bg-slate-900/90 border border-cyan-800/60 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-cyan-400" />
                  <span className="text-xs font-bold text-cyan-300 font-sans">
                    {t.fileALabel}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="text-[11px] font-mono text-cyan-400 hover:text-cyan-200 underline cursor-pointer"
                  >
                    {uploadedFileName ? 'Change' : 'Upload File'}
                  </button>
                  {uploadedFileName && (
                    <button
                      onClick={() => {
                        setUploadedFileName('');
                        setLoadedImage(null);
                        if (fileInputRef.current) fileInputRef.current.value = '';
                        setActivePresetId('arch_dila');
                      }}
                      className="text-[10px] text-amber-400 hover:underline cursor-pointer"
                    >
                      Reset
                    </button>
                  )}
                </div>
              </div>

              {uploadedFileName ? (
                <div className="p-2.5 rounded-lg bg-cyan-950/40 border border-cyan-800/80 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-cyan-200 truncate max-w-[210px]">
                      📄 {uploadedFileName}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                      {originalBounds.width.toFixed(1)} x {originalBounds.height.toFixed(1)} mm &bull; {elements.length} components
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-700 text-emerald-300 text-[10px] font-mono">
                    LOADED
                  </span>
                </div>
              ) : (
                <div className="space-y-1.5">
                  <div className="text-[10.5px] text-slate-400 font-sans">
                    {lang === 'en' ? 'Active Workshop Preset Template:' : 'موجودہ ورکشاپ پری سیٹ ڈیزائن:'}
                  </div>
                  <div className="grid grid-cols-1 gap-1">
                    {presetPatterns.map((p) => {
                      const isSelected = activePresetId === p.id;
                      return (
                        <button
                          key={p.id}
                          onClick={() => setActivePresetId(p.id)}
                          className={`w-full p-2 rounded-lg border text-left transition flex items-center justify-between cursor-pointer ${
                            isSelected
                              ? 'bg-cyan-950/70 border-cyan-500 shadow-sm'
                              : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <div>
                            <div className="text-xs font-bold text-white font-sans">
                              {lang === 'en' ? p.nameEn : lang === 'both' ? `${p.nameUr} (${p.nameEn})` : p.nameUr}
                            </div>
                            <div className="text-[10px] text-slate-400 line-clamp-1">
                              {lang === 'en' ? p.descriptionEn : p.descriptionUr}
                            </div>
                          </div>
                          <span className="text-[9.5px] font-mono text-cyan-400 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 shrink-0 ml-1.5">
                            {p.category}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* SLOT 2: Secondary Source File (File B - Motif Library) */}
            <div className="p-3 rounded-xl bg-slate-900/90 border border-amber-900/50 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  <span className="text-xs font-bold text-amber-300 font-sans">
                    {t.fileBLabel}
                  </span>
                </div>
                {fileBData && (
                  <button
                    onClick={handleClearFileB}
                    className="text-[10.5px] text-red-400 hover:underline cursor-pointer flex items-center gap-1"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>{t.clearFileBBtn}</span>
                  </button>
                )}
              </div>

              {!fileBData ? (
                /* Empty File B Drop Zone */
                <div
                  onClick={() => fileBInputRef.current?.click()}
                  className="p-3.5 rounded-xl border-2 border-dashed border-amber-700/50 hover:border-amber-400 bg-amber-950/20 hover:bg-amber-950/30 transition cursor-pointer text-center space-y-2 group"
                >
                  <div className="w-9 h-9 mx-auto rounded-xl bg-amber-500/20 group-hover:bg-amber-500/30 border border-amber-500/50 flex items-center justify-center text-amber-300">
                    <FilePlus className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-amber-300 font-sans">
                      {t.uploadFileBBtn}
                    </div>
                    <p className="text-[10.5px] text-slate-400 font-sans mt-0.5 leading-relaxed">
                      {t.fileBSubtitle}
                    </p>
                  </div>
                  <div className="inline-block text-[9.5px] font-mono text-amber-400/90 px-2 py-0.5 rounded bg-slate-950 border border-amber-800/60">
                    .DXF &bull; .SVG &bull; .STL &bull; .RLF &bull; .NC &bull; .PNG
                  </div>
                </div>
              ) : (
                /* Loaded File B Info & Motifs Extraction Tool */
                <div className="space-y-2.5">
                  <div className="p-2.5 rounded-lg bg-amber-950/30 border border-amber-700/70 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-amber-200 truncate max-w-[210px]">
                        📂 {fileBData.fileName}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        {fileBData.originalBounds.width.toFixed(1)} x {fileBData.originalBounds.height.toFixed(1)} mm &bull; {fileBData.elements.length} motifs
                      </div>
                    </div>
                    <button
                      onClick={() => fileBInputRef.current?.click()}
                      className="px-2 py-1 rounded bg-slate-950 hover:bg-slate-800 border border-amber-600/60 text-amber-300 text-[10px] font-mono cursor-pointer"
                    >
                      Replace
                    </button>
                  </div>

                  {/* Canvas View Switcher for Side-by-Side Comparison */}
                  <div className="flex items-center justify-between gap-1 p-1 rounded-lg bg-slate-950 border border-slate-800 text-[11px] font-mono">
                    <span className="text-[10px] text-slate-400 pl-1.5 font-sans">Canvas View:</span>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setCanvasViewLayout('primary')}
                        className={`px-2 py-1 rounded transition cursor-pointer font-bold ${
                          canvasViewLayout === 'primary'
                            ? 'bg-cyan-500 text-slate-950'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {t.layoutPrimary}
                      </button>
                      <button
                        onClick={() => setCanvasViewLayout('split')}
                        className={`px-2 py-1 rounded transition cursor-pointer font-bold flex items-center gap-1 ${
                          canvasViewLayout === 'split'
                            ? 'bg-amber-400 text-slate-950'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        <Split className="w-3 h-3" />
                        <span>{t.layoutSplit}</span>
                      </button>
                    </div>
                  </div>

                  {/* Extracted Motifs Extraction List */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] font-mono text-slate-300">
                      <span>{t.fileBSourceTitle}:</span>
                      <button
                        onClick={handleMergeAllFromB}
                        className="text-[10.5px] text-emerald-400 hover:underline font-bold cursor-pointer"
                      >
                        {t.mergeAllBBtn}
                      </button>
                    </div>

                    <div className="max-h-48 overflow-y-auto space-y-1.5 pr-0.5">
                      {fileBData.elements.map((elB) => {
                        const isSel = elB.id === selectedFileBElementId;
                        return (
                          <div
                            key={elB.id}
                            onClick={() => setSelectedFileBElementId(elB.id)}
                            className={`p-2 rounded-lg border text-left transition flex items-center justify-between gap-2 cursor-pointer ${
                              isSel
                                ? 'bg-amber-950/60 border-amber-400 shadow-sm'
                                : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                            }`}
                          >
                            <div className="flex-1 min-w-0">
                              <div className="text-xs font-bold text-amber-200 truncate">
                                {lang === 'en' ? elB.name : elB.nameUr}
                              </div>
                              <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                                {elB.bounds.width.toFixed(0)}x{elB.bounds.height.toFixed(0)}mm &bull; {elB.segments.reduce((acc, s) => acc + s.points.length, 0)} pts
                              </div>
                            </div>

                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleImportElementFromB(elB);
                              }}
                              className="px-2.5 py-1 rounded-md bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-[10.5px] flex items-center gap-1 shadow transition cursor-pointer active:scale-95 shrink-0"
                              title="Copy and import this motif into File A wooden workspace"
                            >
                              <Plus className="w-3 h-3 stroke-[3]" />
                              <span>{t.importElementBtn}</span>
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Card 3: Scaling & Machining Parameters */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-900/60 shadow-xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-mono font-bold text-cyan-400 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <span>{t.scalingHeader}</span>
              </span>
            </div>

            {/* Scaling Mode Radio */}
            <div>
              <label className="text-[11px] font-mono text-slate-300 block mb-1">
                {t.scaleModeLabel}:
              </label>
              <div className="grid grid-cols-3 gap-1.5 text-[10.5px] font-mono">
                {[
                  { id: 'fit_proportional', label: t.fitProp },
                  { id: 'stretch', label: t.stretchFit },
                  { id: 'custom', label: t.customScale },
                ].map((mode) => (
                  <button
                    key={mode.id}
                    onClick={() => setScaleMode(mode.id as ScaleMode)}
                    className={`py-1.5 px-1 rounded-lg border text-center transition cursor-pointer ${
                      scaleMode === mode.id
                        ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-300 shadow'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    {mode.label}
                  </button>
                ))}
              </div>

              {scaleMode === 'custom' && (
                <div className="mt-2.5 p-2 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">Scale Ratio:</span>
                    <span className="text-cyan-300 font-bold">{customScalePercent}%</span>
                  </div>
                  <input
                    type="range"
                    min={20}
                    max={300}
                    value={customScalePercent}
                    onChange={(e) => setCustomScalePercent(Number(e.target.value))}
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                </div>
              )}
            </div>

            {/* Speeds & Feeds Grid */}
            <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1">
              <div>
                <label className="text-[10px] text-slate-400 block mb-0.5">
                  {t.toolDiameterLabel} (mm):
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={toolDiameter}
                  onChange={(e) => setToolDiameter(parseFloat(e.target.value) || 3)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-200"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-0.5">
                  {t.cutDepthLabel} (mm):
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={cutDepth}
                  onChange={(e) => setCutDepth(parseFloat(e.target.value) || 1)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-200"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-0.5">
                  {t.feedRateLabel} (mm/min):
                </label>
                <input
                  type="number"
                  step="100"
                  value={feedRate}
                  onChange={(e) => setFeedRate(parseInt(e.target.value) || 1000)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-200"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-0.5">
                  {t.plungeRateLabel} (mm/min):
                </label>
                <input
                  type="number"
                  step="50"
                  value={plungeRate}
                  onChange={(e) => setPlungeRate(parseInt(e.target.value) || 300)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-200"
                />
              </div>
            </div>

            {/* Controller & Origin */}
            <div className="grid grid-cols-2 gap-2 text-xs pt-1">
              <div>
                <label className="text-[10px] text-slate-400 block mb-0.5">
                  {t.controllerLabel}:
                </label>
                <select
                  value={controller}
                  onChange={(e) => setController(e.target.value as ControllerPreset)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-200 text-xs font-mono"
                >
                  <option value="mach3">Mach3 (G-Code)</option>
                  <option value="ncstudio">NCStudio (Weihong)</option>
                  <option value="dsp">DSP Handheld (.tap)</option>
                  <option value="grbl">GRBL / Candle</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-0.5">
                  {t.originLabel}:
                </label>
                <select
                  value={origin}
                  onChange={(e) => setOrigin(e.target.value as OriginPoint)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-slate-200 text-xs font-mono"
                >
                  <option value="bottom_left">Bottom-Left (بائیں نیچے)</option>
                  <option value="center">Center (مرکز)</option>
                  <option value="top_left">Top-Left (اوپر بائیں)</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Dynamic Interactive Canvas, Real G-Code Download and Diagnostics (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Canvas Viewport Card */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-800 shadow-2xl space-y-3">
            {/* Viewport Header Toolbar */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-2.5 border-b border-slate-800 gap-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-mono font-bold text-cyan-400">
                  {t.canvasTitle}
                </span>
              </div>

              {/* View Mode & Canvas Tool Switcher */}
              <div className="flex items-center gap-2 flex-wrap">
                {/* 2D / 3D Mode */}
                <div className="bg-slate-900 p-1 rounded-xl border border-cyan-800/80 flex items-center gap-1 text-[11px] font-mono shadow">
                  <button
                    onClick={() => setViewMode('2d')}
                    className={`px-2.5 py-1 rounded-lg transition cursor-pointer flex items-center gap-1.5 font-bold ${
                      viewMode === '2d'
                        ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Box className="w-3.5 h-3.5" />
                    <span>{t.view2dLabel}</span>
                  </button>
                  <button
                    onClick={() => setViewMode('3d')}
                    className={`px-2.5 py-1 rounded-lg transition cursor-pointer flex items-center gap-1.5 font-bold ${
                      viewMode === '3d'
                        ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Cuboid className="w-3.5 h-3.5" />
                    <span>{t.view3dLabel}</span>
                  </button>
                </div>

                {/* File B Dual Split Toggle (Visible when File B is uploaded) */}
                {fileBData && (
                  <div className="bg-slate-900 p-1 rounded-xl border border-amber-800/80 flex items-center gap-1 text-[11px] font-mono shadow">
                    <button
                      onClick={() => setCanvasViewLayout('primary')}
                      className={`px-2 py-1 rounded-lg transition cursor-pointer flex items-center gap-1 font-bold ${
                        canvasViewLayout === 'primary'
                          ? 'bg-cyan-500 text-slate-950'
                          : 'text-slate-400 hover:text-white'
                      }`}
                      title="Show Primary Wooden Panel Workspace"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>{t.layoutPrimary}</span>
                    </button>
                    <button
                      onClick={() => setCanvasViewLayout('split')}
                      className={`px-2 py-1 rounded-lg transition cursor-pointer flex items-center gap-1 font-bold ${
                        canvasViewLayout === 'split'
                          ? 'bg-amber-400 text-slate-950'
                          : 'text-slate-400 hover:text-white'
                      }`}
                      title="Show Split Screen: File A and File B Side-by-Side"
                    >
                      <Split className="w-3.5 h-3.5" />
                      <span>{t.layoutSplit}</span>
                    </button>
                  </div>
                )}

                {/* Pointer / Drag Tool Selector */}
                <div className="bg-slate-900 p-1 rounded-xl border border-slate-700 flex items-center gap-1 text-[11px] font-mono shadow">
                  <button
                    onClick={() => setCanvasTool('select')}
                    className={`px-2 py-1 rounded-lg transition cursor-pointer flex items-center gap-1 font-bold ${
                      canvasTool === 'select'
                        ? 'bg-amber-500 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                    title={t.toolSelect}
                  >
                    <MousePointer className="w-3.5 h-3.5" />
                    <span>{t.toolSelect}</span>
                  </button>
                  <button
                    onClick={() => setCanvasTool('pan')}
                    className={`px-2 py-1 rounded-lg transition cursor-pointer flex items-center gap-1 font-bold ${
                      canvasTool === 'pan'
                        ? 'bg-cyan-500 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                    title={t.toolPan}
                  >
                    <Hand className="w-3.5 h-3.5" />
                    <span>{t.toolPan}</span>
                  </button>
                </div>

                <div className="flex items-center gap-1 text-xs font-mono">
                  <button
                    onClick={() => setZoom((prev) => Math.min(prev * 1.25, 4))}
                    className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 cursor-pointer"
                    title={t.zoomIn}
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setZoom((prev) => Math.max(prev / 1.25, 0.4))}
                    className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 cursor-pointer"
                    title={t.zoomOut}
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      setZoom(1);
                      setPan({ x: 0, y: 0 });
                    }}
                    className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-700 cursor-pointer"
                    title={t.resetView}
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setShowRapidMoves(!showRapidMoves)}
                    className={`px-2 py-1 rounded-lg border text-[10px] cursor-pointer transition ${
                      showRapidMoves
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/60 font-bold'
                        : 'bg-slate-900 text-slate-400 border-slate-800'
                    }`}
                    title={t.rapidToggle}
                  >
                    G00
                  </button>
                  <button
                    onClick={() => setShowGrid(!showGrid)}
                    className={`px-2 py-1 rounded-lg border text-[10px] cursor-pointer transition ${
                      showGrid
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/60 font-bold'
                        : 'bg-slate-900 text-slate-400 border-slate-800'
                    }`}
                    title={t.gridToggle}
                  >
                    Grid
                  </button>
                </div>
              </div>
            </div>

            {/* Dynamic HTML5 Canvas with Interactive Drag & Drop */}
            <div className="relative w-full aspect-[4/3] rounded-xl overflow-hidden border border-slate-800 bg-[#060c17] shadow-inner select-none">
              <canvas
                ref={canvasRef}
                onMouseDown={handleCanvasMouseDown}
                onMouseMove={handleCanvasMouseMove}
                onMouseUp={handleCanvasMouseUp}
                onMouseLeave={handleCanvasMouseUp}
                className={`w-full h-full block ${
                  canvasTool === 'pan'
                    ? 'cursor-grab active:cursor-grabbing'
                    : isDraggingElement
                    ? 'cursor-move'
                    : 'cursor-pointer'
                }`}
              />

              {/* Floating Diagnostics Badges */}
              <div className="absolute top-2 left-2 bg-slate-950/90 border border-cyan-900/80 px-2.5 py-1 rounded-lg text-[10.5px] font-mono text-cyan-300 backdrop-blur-sm pointer-events-none shadow">
                📐 {panelWidth} x {panelHeight} mm &bull; Margin: {margin}mm
              </div>

              <div className="absolute bottom-2 right-2 bg-slate-950/90 border border-slate-800 px-2.5 py-1 rounded-lg text-[10px] font-mono text-slate-300 backdrop-blur-sm pointer-events-none shadow flex items-center gap-2">
                <span>⚡ {stats.lengthMeters} m Cut</span>
                <span className="text-slate-600">|</span>
                <span className="text-emerald-400">⏱ ~{stats.timeString}</span>
              </div>
            </div>

            {/* ELEMENT DRAG & ROTATION CONTROLS (PART 2 FEATURE) */}
            {elements.length > 0 && (
              <div className="p-3 rounded-xl bg-slate-900/90 border border-amber-900/40 space-y-2.5">
                <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                    <span className="text-xs font-bold text-amber-300 font-sans">
                      {t.elementControlsHeader}
                    </span>
                  </div>
                  <span className="text-[10.5px] font-mono text-slate-400">
                    {t.elementsCount} <span className="text-amber-300 font-bold">{elements.length}</span>
                  </span>
                </div>

                {/* Selected Element Quick Transforms Bar */}
                {selectedElementId && (
                  (() => {
                    const selEl = elements.find((e) => e.id === selectedElementId);
                    if (!selEl) return null;
                    return (
                      <div className="flex flex-wrap items-center justify-between gap-2 p-2 rounded-lg bg-slate-950 border border-amber-500/50">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-xs font-bold font-mono">
                            {lang === 'en' ? selEl.name : selEl.nameUr}
                          </span>
                          <span className="text-[10px] font-mono text-slate-400">
                            X: {selEl.xOffset > 0 ? `+${selEl.xOffset}` : selEl.xOffset}mm &bull; Y: {selEl.yOffset > 0 ? `+${selEl.yOffset}` : selEl.yOffset}mm &bull; {selEl.rotation}° &bull; {(selEl.scale * 100).toFixed(0)}%
                          </span>
                        </div>

                        {/* Interactive Buttons: Rotate, Scale, Reset */}
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => handleRotateSelected(15)}
                            className="px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-600/60 text-[10.5px] font-mono flex items-center gap-1 cursor-pointer transition active:scale-95"
                            title="Rotate +15 degrees"
                          >
                            <RotateCw className="w-3 h-3" />
                            <span>+15°</span>
                          </button>
                          <button
                            onClick={() => handleRotateSelected(-15)}
                            className="px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-600/60 text-[10.5px] font-mono flex items-center gap-1 cursor-pointer transition active:scale-95"
                            title="Rotate -15 degrees"
                          >
                            <RotateCw className="w-3 h-3 -scale-x-100" />
                            <span>-15°</span>
                          </button>
                          <button
                            onClick={() => handleScaleSelected(0.1)}
                            className="px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-cyan-700/60 text-[10.5px] font-mono cursor-pointer transition active:scale-95 font-bold"
                            title="Scale +10%"
                          >
                            +Size
                          </button>
                          <button
                            onClick={() => handleScaleSelected(-0.1)}
                            className="px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-cyan-700/60 text-[10.5px] font-mono cursor-pointer transition active:scale-95 font-bold"
                            title="Scale -10%"
                          >
                            -Size
                          </button>
                          <button
                            onClick={handleResetSelected}
                            className="px-2 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-[10px] font-mono cursor-pointer transition"
                            title={t.resetElement}
                          >
                            {t.resetElement}
                          </button>
                        </div>
                      </div>
                    );
                  })()
                )}

                {/* Elements Chip Selector List */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
                  {elements.map((el) => {
                    const isSel = el.id === selectedElementId;
                    return (
                      <button
                        key={el.id}
                        onClick={() => setSelectedElementId(el.id)}
                        className={`px-2.5 py-1.5 rounded-lg border text-xs font-mono transition cursor-pointer flex items-center gap-1.5 shrink-0 ${
                          isSel
                            ? 'bg-amber-500 text-slate-950 font-bold border-amber-400 shadow'
                            : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <Move className="w-3 h-3" />
                        <span>{lang === 'en' ? el.name : el.nameUr}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Stats Bar */}
            <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono pt-1">
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">{t.totalPathLength}</span>
                <span className="text-cyan-400 font-bold text-sm">{stats.lengthMeters} meters</span>
              </div>
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">{t.estMachiningTime}</span>
                <span className="text-emerald-400 font-bold text-sm">~{stats.timeString}</span>
              </div>
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">Coordinates:</span>
                <span className="text-amber-400 font-bold text-sm">{stats.pointsCount} points</span>
              </div>
            </div>
          </div>

          {/* Editable G-code workspace for imported .nc/.tap files */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-800/70 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="font-bold text-cyan-300">G-Code Editor / جی کوڈ ایڈیٹر</h3>
                <p className="text-xs text-slate-400">.nc / .tap فائل کھولیں، لائنیں ایڈٹ کریں، پھر اسی متن کو محفوظ کریں۔</p>
              </div>
              <span className="text-xs text-slate-400">{editableGCode ? `${editableGCode.split(/\\r?\\n/).length} lines` : 'Generated code mode'}</span>
            </div>
            <textarea
              value={editableGCode}
              onChange={(e) => { setEditableGCode(e.target.value); setGcodeValidation('تبدیلیاں موجود ہیں؛ ایکسپورٹ سے پہلے کوڈ چیک کریں۔'); }}
              spellCheck={false}
              placeholder="اپنی .nc یا .tap فائل اپ لوڈ کریں، یا یہاں G-Code پیسٹ کریں…"
              className="w-full min-h-[240px] rounded-xl border border-slate-700 bg-[#030712] p-3 font-mono text-xs text-emerald-200 focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />
            {gcodeValidation && <p className="text-xs text-amber-300" role="status">{gcodeValidation}</p>}
            <div className="flex flex-wrap gap-2">
              <button onClick={() => { setEditableGCode(''); setGcodeValidation(''); }} className="px-3 py-2 rounded-lg border border-slate-700 text-xs text-slate-200">ایڈیٹر صاف کریں</button>
              <button onClick={() => {
                const blob = new Blob([editableGCode], { type: 'text/plain;charset=utf-8' });
                const url = URL.createObjectURL(blob); const a = document.createElement('a');
                a.href = url; a.download = `${(uploadedFileName || 'edited-cnc').replace(/\\.[^/.]+$/, '')}_edited.${fileType === 'tap' ? 'tap' : 'nc'}`;
                document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
              }} disabled={!editableGCode.trim()} className="px-3 py-2 rounded-lg bg-cyan-500 text-slate-950 text-xs font-bold disabled:opacity-40">ایڈٹ شدہ فائل ڈاؤن لوڈ کریں</button>
              <button onClick={() => { setEditableGCode(generateRealGCode()); setGcodeValidation('نیا G-Code تیار کیا گیا؛ مشین کے مطابق لازماً تصدیق کریں۔'); }} className="px-3 py-2 rounded-lg border border-emerald-700 text-xs text-emerald-300">ڈیزائن سے نیا G-Code بنائیں</button>
            </div>
            <p className="text-[11px] text-red-300">حفاظت: یہ بنیادی ٹیکسٹ ایڈیٹر ہے، مکمل G-Code simulator نہیں۔ Z-depth، work offset، units، feed/speed، tool change اور controller syntax کی تصدیق اور dry run کے بغیر مشین نہ چلائیں۔</p>
          </div>

          {/* Card 4: Export Buttons & G-Code Downloader */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/50 via-slate-950 to-cyan-950/50 border border-emerald-800/80 shadow-2xl space-y-3.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1.5">
                <Download className="w-4 h-4 text-emerald-400" />
                <span>{t.exportHeader}</span>
              </span>
              <span className="text-[10px] text-emerald-300 font-mono">
                100% PRODUCTION READY
              </span>
            </div>

            <p className="text-xs text-slate-300 font-sans leading-relaxed">
              {lang === 'en'
                ? 'Your resized toolpaths are ready for live workshop carving. The exported file includes spindle RPM, safe retracts, and multipass feed control formatted specifically for Mach3, NCStudio, and DSP controllers.'
                : 'آپ کے ری سائز کردہ ٹول پاتھس مشین پر چلنے کے لیے تیار ہیں۔ ڈاؤن لوڈ کی گئی فائل میں اسپنڈل موشن، محفوظ اونچائی اور درست فیڈ ریٹس شامل ہیں۔'}
            </p>

            {/* Primary Action Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                onClick={() => handleDownloadGCode('nc')}
                disabled={isExporting}
                className="py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs font-sans flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 transition cursor-pointer active:scale-95"
              >
                <Download className="w-4 h-4 stroke-[2.5]" />
                <span>{t.downloadGcodeBtn}</span>
              </button>

              <button
                onClick={() => handleDownloadGCode('tap')}
                disabled={isExporting}
                className="py-2.5 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs font-sans flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition cursor-pointer active:scale-95"
              >
                <Download className="w-4 h-4 stroke-[2.5]" />
                <span>{t.downloadTapBtn}</span>
              </button>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={handleCopyGCode}
                className="flex-1 py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-700 text-slate-200 text-xs font-bold font-sans flex items-center justify-center gap-2 transition cursor-pointer active:scale-95"
              >
                {copiedGcode ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-cyan-400" />}
                <span>{copiedGcode ? t.copiedText : t.copyGcode}</span>
              </button>

              <button
                onClick={() => setShowGcodePreview(!showGcodePreview)}
                className="py-2 px-3.5 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-700 text-slate-200 text-xs font-bold font-sans flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Eye className="w-4 h-4 text-cyan-400" />
                <span>{t.viewGcodeBtn}</span>
              </button>

              <button
                onClick={handleDownloadSpecs}
                className="py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-700 text-slate-300 text-xs font-mono flex items-center justify-center gap-1.5 transition cursor-pointer"
                title="Save setup sheet JSON"
              >
                <FileText className="w-3.5 h-3.5 text-amber-400" />
                <span>JSON</span>
              </button>
            </div>

            {/* In-App G-Code Preview Modal / Box */}
            {showGcodePreview && (
              <div className="mt-3 p-3 rounded-xl bg-[#030712] border border-slate-800 text-[11px] font-mono text-cyan-200 max-h-56 overflow-y-auto space-y-1">
                <div className="flex items-center justify-between text-[10px] text-slate-400 pb-1 border-b border-slate-800">
                  <span>GENERATED G-CODE STREAM</span>
                  <button
                    onClick={() => setShowGcodePreview(false)}
                    className="text-red-400 hover:underline cursor-pointer"
                  >
                    Close &times;
                  </button>
                </div>
                <pre className="whitespace-pre leading-relaxed">{(editableGCode.trim() ? editableGCode : generateRealGCode()).slice(0, 2500)}...</pre>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
