import React, { useState } from 'react';
import { CNCOperationStep } from '../data/cncOperationSteps';
import {
  Monitor,
  Gamepad2,
  Power,
  RotateCcw,
  Play,
  Square,
  Pause,
  RotateCw,
  Zap,
  Activity,
  CheckCircle,
  Circle,
  Maximize2,
  FileText,
  Sliders,
} from 'lucide-react';

interface ControllerScreenMockupProps {
  step: CNCOperationStep;
  currentX: number;
  currentY: number;
  currentZ: number;
  isSpindleOn: boolean;
  feedRate: number;
  spindleRpm: number;
  onJogAxis?: (axis: 'X' | 'Y' | 'Z', dir: number) => void;
  onToggleSpindle?: () => void;
  onZeroAxis?: (axis: 'X' | 'Y' | 'Z') => void;
}

export const ControllerScreenMockup: React.FC<ControllerScreenMockupProps> = ({
  step,
  currentX,
  currentY,
  currentZ,
  isSpindleOn,
  feedRate,
  spindleRpm,
  onJogAxis,
  onToggleSpindle,
  onZeroAxis,
}) => {
  const [controllerType, setControllerType] = useState<'mach3' | 'dsp'>('mach3');
  const [activeTab, setActiveTab] = useState<'program' | 'offsets' | 'settings'>('program');
  const [isResetPressed, setIsResetPressed] = useState<boolean>(true);

  return (
    <div className="bg-slate-950 border border-cyan-800/80 rounded-2xl overflow-hidden shadow-2xl flex flex-col font-mono text-xs">
      {/* Controller Toggle Header */}
      <div className="p-3 bg-gradient-to-r from-slate-900 via-slate-950 to-cyan-950/80 border-b border-cyan-900/60 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-bold text-cyan-400 flex items-center gap-1.5 uppercase tracking-wider">
            <Monitor className="w-4 h-4 text-cyan-400" />
            <span>انٹرایکٹو کنٹرولر اسکرین موک اپ (Controller Mockup)</span>
          </span>
          <span className="px-2 py-0.5 rounded text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-800">
            {step.stepLetter}
          </span>
        </div>

        {/* Switch between Mach3 and DSP Handheld */}
        <div className="flex items-center bg-slate-900 p-0.5 rounded-lg border border-slate-700">
          <button
            onClick={() => setControllerType('mach3')}
            className={`px-3 py-1 rounded text-[11px] font-bold flex items-center gap-1.5 transition ${
              controllerType === 'mach3'
                ? 'bg-cyan-600 text-slate-950 shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Mach3 CNC Screen</span>
          </button>
          <button
            onClick={() => setControllerType('dsp')}
            className={`px-3 py-1 rounded text-[11px] font-bold flex items-center gap-1.5 transition ${
              controllerType === 'dsp'
                ? 'bg-amber-500 text-slate-950 shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Gamepad2 className="w-3.5 h-3.5" />
            <span>DSP RichAuto A11 Pendant</span>
          </button>
        </div>
      </div>

      {/* ===================== MACH3 SCREEN VIEW ===================== */}
      {controllerType === 'mach3' && (
        <div className="p-4 bg-slate-900/90 text-slate-200 space-y-4">
          {/* Top Mach3 Menu Bar */}
          <div className="flex items-center justify-between text-[11px] bg-slate-950 p-2 rounded-lg border border-slate-800 text-slate-400">
            <div className="flex items-center gap-3">
              <span className="font-bold text-cyan-400">Mach3 CNC Controller</span>
              <span className="text-slate-600">|</span>
              <span className="text-emerald-400 font-semibold">{step.mach3State.activeMode}</span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-300">{step.mach3State.screenName}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-emerald-400 text-[10px]">COMM LINK OK</span>
            </div>
          </div>

          <div className="grid grid-cols-12 gap-4">
            {/* Left Column: Digital Readouts (DROs) - 7 cols */}
            <div className="col-span-12 md:col-span-7 space-y-3">
              <div className="p-3 bg-slate-950 rounded-xl border border-cyan-900/80 space-y-2.5">
                <div className="flex items-center justify-between text-[11px] text-cyan-400 border-b border-slate-800 pb-1">
                  <span>ورکنگ کوآرڈینیٹس (Work Coordinates G54)</span>
                  <span className="text-[10px] text-slate-400 font-sans">یونٹ: ملی میٹر (mm)</span>
                </div>

                {/* X Axis DRO */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/90 border border-slate-800">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onZeroAxis?.('X')}
                      className="px-2 py-1 rounded bg-cyan-950 hover:bg-cyan-800 text-cyan-300 border border-cyan-700 text-[11px] font-bold transition"
                      title="Set X to Zero"
                    >
                      Zero X
                    </button>
                    <span className="text-cyan-400 font-bold text-sm">X AXIS:</span>
                  </div>
                  <div className="text-right">
                    <span className="text-xl md:text-2xl font-mono font-bold tracking-widest text-emerald-400">
                      {currentX >= 0 ? `+${currentX.toFixed(3)}` : currentX.toFixed(3)}
                    </span>
                    <span className="text-[10px] text-slate-500 ml-1">mm</span>
                  </div>
                </div>

                {/* Y Axis DRO */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/90 border border-slate-800">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onZeroAxis?.('Y')}
                      className="px-2 py-1 rounded bg-cyan-950 hover:bg-cyan-800 text-cyan-300 border border-cyan-700 text-[11px] font-bold transition"
                      title="Set Y to Zero"
                    >
                      Zero Y
                    </button>
                    <span className="text-cyan-400 font-bold text-sm">Y AXIS:</span>
                  </div>
                  <div className="text-right">
                    <span className="text-xl md:text-2xl font-mono font-bold tracking-widest text-emerald-400">
                      {currentY >= 0 ? `+${currentY.toFixed(3)}` : currentY.toFixed(3)}
                    </span>
                    <span className="text-[10px] text-slate-500 ml-1">mm</span>
                  </div>
                </div>

                {/* Z Axis DRO */}
                <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/90 border border-slate-800">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onZeroAxis?.('Z')}
                      className="px-2 py-1 rounded bg-amber-950 hover:bg-amber-800 text-amber-300 border border-amber-700 text-[11px] font-bold transition"
                      title="Set Z to Zero"
                    >
                      Zero Z
                    </button>
                    <span className="text-amber-400 font-bold text-sm">Z AXIS:</span>
                  </div>
                  <div className="text-right">
                    <span className="text-xl md:text-2xl font-mono font-bold tracking-widest text-amber-400">
                      {currentZ >= 0 ? `+${currentZ.toFixed(3)}` : currentZ.toFixed(3)}
                    </span>
                    <span className="text-[10px] text-slate-500 ml-1">mm</span>
                  </div>
                </div>
              </div>

              {/* Feed Rate & Spindle Readout */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-[10px] text-slate-400">فیڈ ریٹ (Feed)</div>
                    <div className="text-sm font-bold text-cyan-300">{feedRate} mm/min</div>
                  </div>
                  <Activity className="w-5 h-5 text-cyan-500/60" />
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-[10px] text-slate-400">اسپنڈل (RPM)</div>
                    <div className={`text-sm font-bold ${isSpindleOn ? 'text-emerald-400 animate-pulse' : 'text-slate-400'}`}>
                      {isSpindleOn ? `${spindleRpm} RPM` : '0 (M5 STOP)'}
                    </div>
                  </div>
                  <RotateCw className={`w-5 h-5 ${isSpindleOn ? 'text-emerald-400 animate-spin' : 'text-slate-600'}`} />
                </div>
              </div>
            </div>

            {/* Right Column: Mach3 Primary Operator Action Buttons - 5 cols */}
            <div className="col-span-12 md:col-span-5 space-y-2.5">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <div className="text-[11px] text-slate-400 border-b border-slate-800 pb-1">
                  مشین ایکشن بٹنز (Operator Controls)
                </div>

                {/* Reset Button (Flashing or Solid Green) */}
                <button
                  onClick={() => setIsResetPressed(!isResetPressed)}
                  className={`w-full py-2.5 px-3 rounded-lg font-bold text-xs flex items-center justify-center gap-2 transition shadow-lg ${
                    isResetPressed
                      ? 'bg-emerald-600 text-slate-950 border border-emerald-400 hover:bg-emerald-500'
                      : 'bg-red-600 text-white animate-pulse border border-red-400 hover:bg-red-500'
                  }`}
                >
                  <Power className="w-4 h-4" />
                  <span>{isResetPressed ? 'RESET (ENGAGED - OK)' : 'RESET (E-STOP ACTIVE)'}</span>
                </button>

                {/* Ref All Home Button */}
                <button
                  className={`w-full py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition ${
                    step.mach3State.highlightButtons.includes('Ref All Home')
                      ? 'bg-cyan-600 text-slate-950 ring-2 ring-cyan-400 shadow'
                      : 'bg-slate-900 text-slate-200 border border-slate-700 hover:bg-slate-850'
                  }`}
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Ref All Home (ریفرنس ہومنگ)</span>
                </button>

                {/* Cycle Start / Feed Hold / Stop Row */}
                <div className="grid grid-cols-3 gap-1.5 pt-1">
                  <button
                    className={`py-2 px-1 rounded-lg text-[11px] font-bold flex flex-col items-center justify-center gap-1 transition ${
                      step.mach3State.highlightButtons.includes('Cycle Start (Alt-R)') ||
                      step.mach3State.highlightButtons.includes('Cycle Start')
                        ? 'bg-emerald-500 text-slate-950 ring-2 ring-emerald-300'
                        : 'bg-slate-900 text-emerald-400 border border-slate-700 hover:bg-slate-800'
                    }`}
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Cycle Start</span>
                  </button>
                  <button
                    className={`py-2 px-1 rounded-lg text-[11px] font-bold flex flex-col items-center justify-center gap-1 transition ${
                      step.mach3State.highlightButtons.includes('Feed Hold (Space)')
                        ? 'bg-amber-500 text-slate-950 ring-2 ring-amber-300'
                        : 'bg-slate-900 text-amber-400 border border-slate-700 hover:bg-slate-800'
                    }`}
                  >
                    <Pause className="w-3.5 h-3.5" />
                    <span>Feed Hold</span>
                  </button>
                  <button
                    className={`py-2 px-1 rounded-lg text-[11px] font-bold flex flex-col items-center justify-center gap-1 transition ${
                      step.mach3State.highlightButtons.includes('Stop (Alt-S)')
                        ? 'bg-red-500 text-slate-950 ring-2 ring-red-300'
                        : 'bg-slate-900 text-red-400 border border-slate-700 hover:bg-slate-800'
                    }`}
                  >
                    <Square className="w-3.5 h-3.5" />
                    <span>Stop</span>
                  </button>
                </div>

                {/* Spindle Toggle */}
                <button
                  onClick={onToggleSpindle}
                  className={`w-full py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition ${
                    isSpindleOn
                      ? 'bg-emerald-500 text-slate-950 shadow-md'
                      : 'bg-slate-900 text-slate-300 border border-slate-700 hover:border-emerald-600'
                  }`}
                >
                  <RotateCw className={`w-3.5 h-3.5 ${isSpindleOn ? 'animate-spin' : ''}`} />
                  <span>اسپنڈل کنٹرول (F5): {isSpindleOn ? 'ON (18K RPM)' : 'OFF (M5)'}</span>
                </button>
              </div>

              {/* Status Bar */}
              <div className="p-2.5 rounded-xl bg-slate-950 border border-cyan-900/60 space-y-1">
                <div className="text-[10px] text-slate-500 flex items-center justify-between">
                  <span>اسٹیٹس لائن (Status Bar):</span>
                  <span className="text-cyan-400 font-bold">{step.stepLetter} ACTIVE</span>
                </div>
                <div className="text-[11px] text-cyan-300 font-urdu">{step.mach3State.statusTextUrdu}</div>
                <div className="text-[10px] text-slate-400 font-mono truncate">{step.mach3State.statusTextEn}</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================== DSP HANDHELD PENDANT VIEW ===================== */}
      {controllerType === 'dsp' && (
        <div className="p-4 bg-slate-900 text-slate-200">
          <div className="max-w-md mx-auto bg-slate-950 p-5 rounded-3xl border-2 border-slate-700 shadow-2xl space-y-4">
            {/* Top Pendant Hook & Brand */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-[11px] text-slate-400">
              <span className="font-bold text-amber-400">RichAuto A11 DSP CNC Pendant</span>
              <span className="px-2 py-0.5 rounded bg-slate-900 text-[10px] text-emerald-400 border border-emerald-900">
                DSP 3-AXIS HANDHELD
              </span>
            </div>

            {/* Backlit LCD Screen (Classic CNC Green/Yellow Screen) */}
            <div className="bg-[#5c7a29] text-[#0d1f03] p-4 rounded-xl border-4 border-[#3d521b] font-mono shadow-inner space-y-1">
              <div className="flex items-center justify-between text-[11px] font-bold border-b border-[#445b1e] pb-1 uppercase">
                <span>{step.dspState.screenTitle}</span>
                <span>[{step.dspState.modeLabel}]</span>
              </div>
              <div className="text-xs font-bold">{step.dspState.line1}</div>
              <div className="text-xs font-bold">{step.dspState.line2}</div>
              <div className="text-xs font-bold">{step.dspState.line3}</div>
              <div className="text-xs font-bold flex items-center justify-between pt-1 border-t border-[#445b1e]/60">
                <span>{step.dspState.line4}</span>
                <span className="text-[10px] opacity-80">S:{isSpindleOn ? '18000' : '0'}</span>
              </div>
            </div>

            {/* Pendant 16-Key Tactile Keypad */}
            <div className="space-y-2">
              <div className="text-[10px] text-slate-400 text-center font-mono">
                کلیدی بٹنز (Tactile Operator Pad)
              </div>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { label: 'RUN', sub: 'سائیکل', color: 'bg-emerald-700 hover:bg-emerald-600 text-white' },
                  { label: 'PAUSE', sub: 'توقف', color: 'bg-amber-700 hover:bg-amber-600 text-white' },
                  { label: 'STOP', sub: 'بند', color: 'bg-red-700 hover:bg-red-600 text-white' },
                  { label: 'MENU', sub: 'مینو', color: 'bg-slate-800 hover:bg-slate-700 text-slate-200' },

                  { label: 'X+ (1)', sub: 'دائیں', action: () => onJogAxis?.('X', 1), color: 'bg-slate-800 hover:bg-cyan-700 text-cyan-300' },
                  { label: 'X- (2)', sub: 'بائیں', action: () => onJogAxis?.('X', -1), color: 'bg-slate-800 hover:bg-cyan-700 text-cyan-300' },
                  { label: 'Y+ (3)', sub: 'آگے', action: () => onJogAxis?.('Y', 1), color: 'bg-slate-800 hover:bg-cyan-700 text-cyan-300' },
                  { label: 'Y- (4)', sub: 'پیچھے', action: () => onJogAxis?.('Y', -1), color: 'bg-slate-800 hover:bg-cyan-700 text-cyan-300' },

                  { label: 'Z+ (5)', sub: 'اوپر', action: () => onJogAxis?.('Z', 1), color: 'bg-slate-800 hover:bg-amber-700 text-amber-300' },
                  { label: 'Z- (6)', sub: 'نیچے', action: () => onJogAxis?.('Z', -1), color: 'bg-slate-800 hover:bg-amber-700 text-amber-300' },
                  { label: 'ORIGIN', sub: 'زیرو', action: () => onZeroAxis?.('X'), color: 'bg-slate-800 hover:bg-slate-700 text-slate-200' },
                  { label: 'HOME', sub: 'ہوم', color: 'bg-slate-800 hover:bg-slate-700 text-slate-200' },

                  { label: 'SPEED+', sub: '+10%', color: 'bg-slate-800 hover:bg-slate-700 text-slate-300' },
                  { label: 'SPEED-', sub: '-10%', color: 'bg-slate-800 hover:bg-slate-700 text-slate-300' },
                  { label: 'SPINDLE', sub: 'موٹر', action: onToggleSpindle, color: isSpindleOn ? 'bg-emerald-600 text-slate-950' : 'bg-slate-800 text-slate-300' },
                  { label: 'OK', sub: 'تصدیق', color: 'bg-cyan-700 hover:bg-cyan-600 text-white' },
                ].map((btn, idx) => (
                  <button
                    key={idx}
                    onClick={btn.action}
                    className={`py-2 px-1 rounded-xl text-center flex flex-col items-center justify-center transition active:scale-95 border border-slate-700/60 shadow-sm ${btn.color}`}
                  >
                    <span className="font-bold text-[11px] leading-tight">{btn.label}</span>
                    <span className="text-[9px] opacity-75 font-urdu">{btn.sub}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Active Keys Guide */}
            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-[11px] flex items-center justify-between">
              <span className="text-slate-400">اس مرحلے کی کلیدی کیز:</span>
              <div className="flex items-center gap-1.5 flex-wrap">
                {step.dspState.activeKeys.map((keyName, kIdx) => (
                  <span
                    key={kIdx}
                    className="px-2 py-0.5 rounded bg-amber-950/80 border border-amber-700/80 text-amber-300 font-bold text-[10px]"
                  >
                    {keyName}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
