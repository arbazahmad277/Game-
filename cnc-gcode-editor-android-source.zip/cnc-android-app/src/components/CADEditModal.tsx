import React, { useState } from 'react';
import { CNCStep } from '../data/cncSteps';
import {
  X,
  Sparkles,
  Sliders,
  Wand2,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  Loader2,
  RefreshCw,
} from 'lucide-react';

interface CADEditModalProps {
  step: CNCStep;
  currentImage: string;
  isOpen: boolean;
  onClose: () => void;
  onApplyImage: (newImageUrl: string) => void;
  lang: 'ur' | 'en' | 'both';
}

export const CADEditModal: React.FC<CADEditModalProps> = ({
  step,
  currentImage,
  isOpen,
  onClose,
  onApplyImage,
  lang,
}) => {
  const [prompt, setPrompt] = useState<string>(step.cadPrompt);
  const [stylePreset, setStylePreset] = useState<string>('blueprint');
  const [imageSize, setImageSize] = useState<'1K' | '2K'>('1K');
  const [isEditingExisting, setIsEditingExisting] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const stylePresets = [
    { id: 'blueprint', label: 'Dark Cyan Blueprint', promptSuffix: 'dark cyan blueprint grid background, glowing white and blue technical CAD lines, engineering dimension markers' },
    { id: 'photorealistic_cad', label: 'Photorealistic 3D CAD', promptSuffix: 'high fidelity SolidWorks 3D CAD rendering, brushed aluminum metal textures, clean workshop studio lighting' },
    { id: 'exploded_view', label: 'Exploded Technical View', promptSuffix: 'exploded parts assembly diagram, floating screws and bearings with dotted assembly trajectory lines' },
    { id: 'wireframe', label: 'Neon Wireframe', promptSuffix: 'futuristic cyan wireframe CAD schematic, black background, high contrast mechanical outlines' },
  ];

  // Quick prompt injection
  const applyPreset = (presetId: string) => {
    setStylePreset(presetId);
    const chosen = stylePresets.find((p) => p.id === presetId);
    if (chosen) {
      setPrompt(`${step.titleEn} 3D CAD technical engineering model. ${chosen.promptSuffix}`);
    }
  };

  const handleGenerate = async () => {
    setIsLoading(true);
    setError(null);

    try {
      if (isEditingExisting && currentImage) {
        // Image-to-image edit mode
        const res = await fetch('/api/edit-cad-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            stepNumber: step.id,
            imageBase64: currentImage,
            prompt: prompt,
          }),
        });

        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          throw new Error(data.error || 'Failed to edit image');
        }

        const data = await res.json();
        if (data.imageUrl) {
          onApplyImage(data.imageUrl);
          onClose();
        }
      } else {
        // Text-to-image generate mode with gemini-nano-banana-2.1
        const res = await fetch('/api/generate-cad-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            stepNumber: step.id,
            prompt: prompt,
            style: stylePreset,
            imageSize: imageSize,
          }),
        });

        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          throw new Error(data.error || 'Failed to generate CAD image');
        }

        const data = await res.json();
        if (data.imageUrl) {
          onApplyImage(data.imageUrl);
          onClose();
        }
      }
    } catch (err: any) {
      console.error('Error during CAD image synthesis:', err);
      setError(err?.message || 'Synthesis failed. Please verify API key or network.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-cyan-800/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-cyan-900/60 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-cyan-950 border border-cyan-700/60 text-cyan-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2 font-sans">
                <span>{lang === 'en' ? '3D CAD Prompt Editor & Synthesizer' : lang === 'both' ? '3D CAD پرامپٹ ایڈیٹر (CAD Synthesizer)' : '3D CAD پرامپٹ ایڈیٹر اور تصویر ساز'}</span>
                <span className="text-xs font-mono font-normal text-cyan-400">
                  (Gemini Nano Banana 2.1)
                </span>
              </h3>
              <p className="text-xs text-slate-400 font-sans">
                {lang === 'en' ? `Step ${step.id}: ${step.titleEn}` : `سٹیپ ${step.id}: ${step.titleUrdu}`}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-sm">
          {/* Mode Selector */}
          <div className="flex rounded-lg bg-slate-950 p-1 border border-cyan-950">
            <button
              onClick={() => setIsEditingExisting(false)}
              className={`flex-1 py-2 text-xs font-medium rounded-md transition cursor-pointer ${
                !isEditingExisting
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-cyan-300'
              }`}
            >
              {lang === 'en' ? 'Generate New CAD Blueprint' : lang === 'both' ? 'نئی تصویر بنائیں (Generate New CAD)' : 'نئی CAD تصویر بنائیں'}
            </button>
            <button
              onClick={() => setIsEditingExisting(true)}
              className={`flex-1 py-2 text-xs font-medium rounded-md transition cursor-pointer ${
                isEditingExisting
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-cyan-300'
              }`}
            >
              {lang === 'en' ? 'Edit Existing CAD Blueprint' : lang === 'both' ? 'ترمیم کریں (Edit Existing CAD)' : 'موجودہ تصویر میں ترمیم کریں'}
            </button>
          </div>

          {/* Style Presets */}
          <div>
            <label className="block text-xs font-mono text-cyan-300 mb-2 uppercase tracking-wider">
              {lang === 'en' ? 'Style Preset:' : 'CAD اسٹائل منتخب کریں:'}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {stylePresets.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => applyPreset(preset.id)}
                  className={`p-2.5 rounded-lg border text-left text-xs transition cursor-pointer ${
                    stylePreset === preset.id
                      ? 'border-cyan-400 bg-cyan-950/80 text-cyan-200'
                      : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <span className="font-semibold block">{preset.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Prompt Textarea */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-mono text-cyan-300 uppercase tracking-wider">
                {lang === 'en' ? 'CAD Engineering Prompt:' : 'پرامپٹ کی تفصیل:'}
              </label>
              <button
                onClick={() => setPrompt(step.cadPrompt)}
                className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>{lang === 'en' ? 'Reset Prompt' : 'ڈیفالٹ پرامپٹ ری سیٹ'}</span>
              </button>
            </div>
            <textarea
              rows={4}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g. Add exploded screws and cyan wireframe annotations..."
              className="w-full bg-slate-950 border border-cyan-900/80 rounded-xl p-3 text-slate-200 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-cyan-500/50 resize-none"
            />
          </div>

          {/* Config: Resolution */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800">
            <div>
              <span className="text-xs font-semibold text-slate-200 block font-sans">
                {lang === 'en' ? 'Image Resolution' : 'ریزیولوشن (Image Resolution)'}
              </span>
              <span className="text-[11px] text-slate-500 font-mono">
                {lang === 'en' ? 'Gemini Nano Banana 2.1 Engine' : 'Gemini Nano Banana 2.1 سپورٹڈ فارمیٹ'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              {(['1K', '2K'] as const).map((size) => (
                <button
                  key={size}
                  onClick={() => setImageSize(size)}
                  className={`px-3 py-1 rounded text-xs font-mono font-semibold transition border cursor-pointer ${
                    imageSize === size
                      ? 'bg-cyan-500 text-slate-950 border-cyan-400'
                      : 'bg-slate-900 text-slate-400 border-slate-700 hover:text-white'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Error notice */}
          {error && (
            <div className="p-3 rounded-lg bg-red-950/60 border border-red-800 text-red-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-cyan-900/60 bg-slate-950/60">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white transition cursor-pointer font-sans"
          >
            {lang === 'en' ? 'Cancel' : 'کینسل'}
          </button>

          <button
            onClick={handleGenerate}
            disabled={isLoading || !prompt.trim()}
            className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-900/40 disabled:opacity-50 transition cursor-pointer font-sans"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{lang === 'en' ? 'Generating...' : 'جنریٹ ہو رہا ہے...'}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>
                  {isEditingExisting
                    ? (lang === 'en' ? 'Apply Edits' : 'تبدیلیاں لاگو کریں')
                    : (lang === 'en' ? 'Generate CAD Blueprint' : 'تصویر جنریٹ کریں')}
                </span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
