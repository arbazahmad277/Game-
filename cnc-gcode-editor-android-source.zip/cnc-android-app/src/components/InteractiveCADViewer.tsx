import React, { useState, useEffect } from 'react';
import { CNCStep } from '../data/cncSteps';
import { CADVectorSchematic } from './CADVectorSchematic';
import { InteractiveSVGBlueprint } from './InteractiveSVGBlueprint';
import {
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Layers,
  Sparkles,
  Maximize2,
  Minimize2,
  Download,
  Eye,
  Sliders,
  CheckCircle2,
  Loader2,
  Cpu,
  Compass,
} from 'lucide-react';

interface InteractiveCADViewerProps {
  step: CNCStep;
  generatedImageUrl?: string;
  isGenerating: boolean;
  onOpenEditModal: () => void;
  lang: 'ur' | 'en' | 'both';
}

export const InteractiveCADViewer: React.FC<InteractiveCADViewerProps> = ({
  step,
  generatedImageUrl,
  isGenerating,
  onOpenEditModal,
  lang,
}) => {
  const [viewMode, setViewMode] = useState<'ai_cad' | 'vector_cad' | 'interactive_blueprint' | 'split'>('ai_cad');
  const [zoom, setZoom] = useState<number>(1);
  const [showDimensions, setShowDimensions] = useState<boolean>(true);
  const [showFasteners, setShowFasteners] = useState<boolean>(true);
  const [showMotion, setShowMotion] = useState<boolean>(true);
  const [showExploded, setShowExploded] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [imageError, setImageError] = useState<boolean>(false);

  // Reset image error when step or generated image changes
  useEffect(() => {
    setImageError(false);
  }, [step.id, generatedImageUrl]);

  const activeImage = generatedImageUrl || step.defaultImage;

  const handleDownload = () => {
    if (!activeImage) return;
    const a = document.createElement('a');
    a.href = activeImage;
    a.download = `CNC_Router_Step_${String(step.id).padStart(2, '0')}_3D_CAD.jpg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleZoomIn = () => setZoom((prev) => Math.min(prev + 0.2, 2.2));
  const handleZoomOut = () => setZoom((prev) => Math.max(prev - 0.2, 0.6));
  const handleResetZoom = () => setZoom(1);

  return (
    <div
      className={`relative flex flex-col bg-slate-950 border border-cyan-900/60 rounded-xl overflow-hidden shadow-2xl transition-all duration-300 ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none' : 'h-[540px]'
      }`}
    >
      {/* Top CAD Viewport Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 bg-slate-900/95 border-b border-cyan-900/50 backdrop-blur z-20">
        {/* Left: View Mode Toggle */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-cyan-900/50 text-xs">
          <button
            onClick={() => setViewMode('ai_cad')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition cursor-pointer ${
              viewMode === 'ai_cad'
                ? 'bg-cyan-500 text-slate-950 shadow-sm font-semibold'
                : 'text-slate-400 hover:text-cyan-300'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{lang === 'en' ? '3D CAD Render' : '3D CAD رینڈر'}</span>
          </button>
          <button
            onClick={() => setViewMode('interactive_blueprint')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition cursor-pointer ${
              viewMode === 'interactive_blueprint'
                ? 'bg-cyan-500 text-slate-950 shadow-sm font-semibold'
                : 'text-slate-400 hover:text-cyan-300'
            }`}
            title="Interactive SVG Blueprint with Live Physics Simulation"
          >
            <Compass className="w-3.5 h-3.5" />
            <span>{lang === 'en' ? 'Interactive SVG' : 'انٹرایکٹو SVG'}</span>
          </button>
          <button
            onClick={() => setViewMode('vector_cad')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition cursor-pointer ${
              viewMode === 'vector_cad'
                ? 'bg-cyan-500 text-slate-950 shadow-sm font-semibold'
                : 'text-slate-400 hover:text-cyan-300'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>{lang === 'en' ? 'Vector Blueprint' : 'ویکٹر بلیو پرنٹ'}</span>
          </button>
          <button
            onClick={() => setViewMode('split')}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md font-medium transition cursor-pointer ${
              viewMode === 'split'
                ? 'bg-cyan-500 text-slate-950 shadow-sm font-semibold'
                : 'text-slate-400 hover:text-cyan-300'
            }`}
            title="Side-by-side view"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>{lang === 'en' ? 'Split View' : 'اسپلٹ ویو'}</span>
          </button>
        </div>

        {/* Center: Layers Toggles (for vector view) */}
        <div className="hidden md:flex items-center gap-1 text-xs text-slate-300">
          <button
            onClick={() => setShowDimensions(!showDimensions)}
            className={`px-2 py-1 rounded border text-[11px] transition ${
              showDimensions
                ? 'bg-cyan-950/80 border-cyan-500/80 text-cyan-300'
                : 'bg-slate-950 border-slate-800 text-slate-500'
            }`}
          >
            📏 Dims
          </button>
          <button
            onClick={() => setShowFasteners(!showFasteners)}
            className={`px-2 py-1 rounded border text-[11px] transition ${
              showFasteners
                ? 'bg-amber-950/80 border-amber-500/80 text-amber-300'
                : 'bg-slate-950 border-slate-800 text-slate-500'
            }`}
          >
            🔩 Bolts
          </button>
          <button
            onClick={() => setShowMotion(!showMotion)}
            className={`px-2 py-1 rounded border text-[11px] transition ${
              showMotion
                ? 'bg-emerald-950/80 border-emerald-500/80 text-emerald-300'
                : 'bg-slate-950 border-slate-800 text-slate-500'
            }`}
          >
            🎯 Motion
          </button>
          <button
            onClick={() => setShowExploded(!showExploded)}
            className={`px-2 py-1 rounded border text-[11px] transition ${
              showExploded
                ? 'bg-purple-950/80 border-purple-500/80 text-purple-300'
                : 'bg-slate-950 border-slate-800 text-slate-500'
            }`}
          >
            💥 Exploded
          </button>
        </div>

        {/* Right: Actions & Zoom */}
        <div className="flex items-center gap-1.5 text-slate-300">
          <button
            onClick={handleZoomIn}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 hover:text-cyan-300 text-slate-300 transition"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleZoomOut}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 hover:text-cyan-300 text-slate-300 transition"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleResetZoom}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 hover:text-cyan-300 text-slate-300 transition"
            title="Reset Zoom"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <span className="w-px h-4 bg-slate-700 mx-1" />

          {/* Prompt Edit Modal Trigger */}
          <button
            onClick={onOpenEditModal}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-medium text-xs shadow-md shadow-cyan-900/30 transition cursor-pointer"
            title="Edit prompt / Customize CAD visual"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">
              {lang === 'en' ? 'AI Prompt & Edit' : 'پرامپٹ ایڈٹ کریں'}
            </span>
          </button>

          {/* Download Image */}
          <button
            onClick={handleDownload}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-cyan-900/60 hover:text-cyan-300 text-slate-300 transition"
            title="Download CAD Blueprint"
          >
            <Download className="w-3.5 h-3.5" />
          </button>

          {/* Fullscreen */}
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-cyan-900/60 hover:text-cyan-300 text-slate-300 transition"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Viewport Content Area */}
      <div className="relative flex-1 w-full h-full overflow-hidden bg-slate-950">
        {/* Loading Overlay */}
        {isGenerating && (
          <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-slate-950/85 backdrop-blur-md">
            <div className="relative">
              <div className="w-20 h-20 rounded-full border-4 border-cyan-500/20 border-t-cyan-400 animate-spin" />
              <Cpu className="absolute inset-0 m-auto w-8 h-8 text-cyan-400 animate-pulse" />
            </div>
            <p className="mt-4 text-cyan-300 font-mono text-sm font-semibold tracking-wider animate-pulse">
              SYNTHESIZING 3D CAD BLUEPRINT (STEP {step.id})...
            </p>
            <p className="text-slate-400 text-xs mt-1 font-mono">
              Generating with Gemini Nano Banana 2.1 Engine
            </p>
          </div>
        )}

        {/* View mode: AI CAD Render */}
        {viewMode === 'ai_cad' && (
          <div className="relative w-full h-full flex items-center justify-center p-2 overflow-hidden bg-[#09111e]">
            {imageError || !activeImage ? (
              <InteractiveSVGBlueprint step={step} showCanvasSimulation={true} className="w-full h-full" />
            ) : (
              <div
                className="relative max-w-full max-h-full transition-transform duration-300 ease-out"
                style={{ transform: `scale(${zoom})` }}
              >
                <img
                  src={activeImage}
                  alt={`Step ${step.id} 3D CAD Blueprint`}
                  referrerPolicy="no-referrer"
                  onError={() => setImageError(true)}
                  className="rounded-lg max-h-[480px] w-auto object-contain border border-cyan-800/60 shadow-2xl shadow-cyan-950/50"
                />
                {/* Blueprint watermark tag */}
                <div className="absolute top-3 left-3 bg-slate-900/90 border border-cyan-500/60 backdrop-blur px-2.5 py-1 rounded text-[11px] font-mono text-cyan-300 flex items-center gap-1.5 shadow-lg">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
                  <span>CAD DWG: STEP {String(step.id).padStart(2, '0')}</span>
                  {generatedImageUrl && (
                    <span className="bg-emerald-950 text-emerald-300 px-1.5 py-0.5 rounded text-[10px] border border-emerald-600/50">
                      LIVE AI RENDER
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* View mode: Interactive SVG Blueprint */}
        {viewMode === 'interactive_blueprint' && (
          <div className="relative w-full h-full p-2 flex items-center justify-center bg-[#09111e]">
            <InteractiveSVGBlueprint step={step} showCanvasSimulation={true} className="w-full h-full" />
          </div>
        )}

        {/* View mode: Vector CAD Blueprint */}
        {viewMode === 'vector_cad' && (
          <CADVectorSchematic
            step={step}
            showDimensions={showDimensions}
            showFasteners={showFasteners}
            showMotion={showMotion}
            showExploded={showExploded}
            zoom={zoom}
          />
        )}

        {/* View mode: Split Screen */}
        {viewMode === 'split' && (
          <div className="grid grid-cols-1 md:grid-cols-2 w-full h-full divide-y md:divide-y-0 md:divide-x divide-cyan-900/60">
            {/* Left AI Render or SVG Fallback */}
            <div className="relative w-full h-full flex items-center justify-center p-3 overflow-hidden bg-[#09111e]">
              {imageError || !activeImage ? (
                <InteractiveSVGBlueprint step={step} showCanvasSimulation={false} className="w-full h-full" />
              ) : (
                <div className="relative max-w-full max-h-full" style={{ transform: `scale(${zoom})` }}>
                  <img
                    src={activeImage}
                    alt={`Step ${step.id} AI CAD`}
                    referrerPolicy="no-referrer"
                    onError={() => setImageError(true)}
                    className="rounded max-h-[440px] w-auto object-contain border border-cyan-800/60 shadow"
                  />
                  <span className="absolute bottom-2 left-2 bg-slate-900/90 px-2 py-0.5 rounded text-[10px] font-mono text-cyan-300 border border-cyan-800">
                    AI 3D CAD RENDER
                  </span>
                </div>
              )}
            </div>

            {/* Right Vector CAD */}
            <div className="relative w-full h-full overflow-hidden">
              <CADVectorSchematic
                step={step}
                showDimensions={showDimensions}
                showFasteners={showFasteners}
                showMotion={showMotion}
                showExploded={showExploded}
                zoom={zoom}
              />
              <span className="absolute bottom-2 right-2 bg-slate-900/90 px-2 py-0.5 rounded text-[10px] font-mono text-cyan-300 border border-cyan-800 z-10">
                VECTOR CAD BLUEPRINT
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Status Bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-900/95 border-t border-cyan-900/50 text-xs font-mono text-slate-400">
        <div className="flex items-center gap-3">
          <span className="text-cyan-400 font-semibold">
            {lang === 'en' ? `STEP ${step.id} / 30` : `سٹیپ ${step.id} / 30`}
          </span>
          <span className="text-slate-600">|</span>
          <span className="truncate max-w-[280px] sm:max-w-md text-slate-300">
            {lang === 'ur' ? step.titleUrdu : step.titleEn}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-slate-500 hidden sm:inline">TOLERANCE: {step.specs.tolerance || '±0.02mm'}</span>
          <span className="flex items-center gap-1 text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span className="text-[11px]">CAD READY</span>
          </span>
        </div>
      </div>
    </div>
  );
};
