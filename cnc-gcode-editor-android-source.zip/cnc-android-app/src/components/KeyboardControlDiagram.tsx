import React, { useState, useEffect } from 'react';
import {
  Keyboard,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ChevronUp,
  ChevronDown,
  Sparkles,
  Info,
  Zap,
} from 'lucide-react';

interface KeyboardControlDiagramProps {
  onJogAxis?: (axis: 'X' | 'Y' | 'Z', dir: number) => void;
  onToggleSpindle?: () => void;
  stepIncrement?: number;
}

export const KeyboardControlDiagram: React.FC<KeyboardControlDiagramProps> = ({
  onJogAxis,
  onToggleSpindle,
  stepIncrement = 1.0,
}) => {
  const [activePressedKey, setActivePressedKey] = useState<string | null>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }
      setActivePressedKey(e.key);
    };

    const handleKeyUp = () => {
      setActivePressedKey(null);
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  return (
    <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-800/80 shadow-2xl space-y-4 font-mono text-xs">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-cyan-900/60">
        <div className="flex items-center gap-2">
          <Keyboard className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-cyan-300 text-xs">
            کی بورڈ کنٹرول ڈایاگرام (CNC Keyboard Motion Map)
          </span>
        </div>
        <span className="text-[10px] text-emerald-400 flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>لائیو ہارڈویئر سنک فعال (Live Listener)</span>
        </span>
      </div>

      <p className="text-slate-400 text-xs font-sans leading-relaxed">
        سی این سی آپریٹنگ کے لیے کی بورڈ کیز کا معیار: نیچے دیے گئے کی بورڈ پر کلک کریں یا اپنے لیپ ٹاپ/کمپیوٹر کی کیز دبائیں۔
      </p>

      {/* Visual Keyboard Diagram Grid */}
      <div className="grid grid-cols-12 gap-3 items-start">
        {/* Left Side: X & Y Navigation Keys (7 Cols) */}
        <div className="col-span-12 lg:col-span-7 p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-[11px] text-slate-300 border-b border-slate-800 pb-1">
            <span className="text-cyan-400 font-bold">X اور Y ایکسز - ایرو کیز (Arrow Keys)</span>
            <span className="text-[10px] text-slate-500">یا W / A / S / D</span>
          </div>

          <div className="flex flex-col items-center gap-2 py-2">
            {/* Y+ Up Arrow */}
            <div className="text-center">
              <span className="text-[10px] text-slate-400 font-urdu block mb-0.5">Y+ (گینٹری پیچھے - Back)</span>
              <button
                onClick={() => onJogAxis?.('Y', 1)}
                className={`w-16 h-12 rounded-xl border flex flex-col items-center justify-center font-bold text-xs transition active:scale-90 shadow-md ${
                  activePressedKey === 'ArrowUp' || activePressedKey === 'w' || activePressedKey === 'W'
                    ? 'bg-cyan-500 text-slate-950 border-cyan-300 ring-2 ring-cyan-400 scale-95'
                    : 'bg-slate-950 text-cyan-300 border-cyan-800 hover:bg-cyan-900/60'
                }`}
                title="Y+ Jog (Up Arrow / W)"
              >
                <ArrowUp className="w-5 h-5" />
                <span className="text-[9px]">Y+ (↑)</span>
              </button>
            </div>

            {/* X- and X+ Arrow Keys */}
            <div className="flex items-center gap-4">
              <div className="text-center">
                <span className="text-[10px] text-slate-400 font-urdu block mb-0.5">X- (بائیں - Left)</span>
                <button
                  onClick={() => onJogAxis?.('X', -1)}
                  className={`w-16 h-12 rounded-xl border flex flex-col items-center justify-center font-bold text-xs transition active:scale-90 shadow-md ${
                    activePressedKey === 'ArrowLeft' || activePressedKey === 'a' || activePressedKey === 'A'
                      ? 'bg-cyan-500 text-slate-950 border-cyan-300 ring-2 ring-cyan-400 scale-95'
                      : 'bg-slate-950 text-cyan-300 border-cyan-800 hover:bg-cyan-900/60'
                  }`}
                  title="X- Jog (Left Arrow / A)"
                >
                  <ArrowLeft className="w-5 h-5" />
                  <span className="text-[9px]">X- (←)</span>
                </button>
              </div>

              <div className="w-12 h-12 rounded-xl bg-slate-950 border border-slate-700 flex flex-col items-center justify-center text-slate-400 font-bold text-[10px]">
                <span>XY</span>
                <span className="text-[8px] text-slate-500">PLANAR</span>
              </div>

              <div className="text-center">
                <span className="text-[10px] text-slate-400 font-urdu block mb-0.5">X+ (دائیں - Right)</span>
                <button
                  onClick={() => onJogAxis?.('X', 1)}
                  className={`w-16 h-12 rounded-xl border flex flex-col items-center justify-center font-bold text-xs transition active:scale-90 shadow-md ${
                    activePressedKey === 'ArrowRight' || activePressedKey === 'd' || activePressedKey === 'D'
                      ? 'bg-cyan-500 text-slate-950 border-cyan-300 ring-2 ring-cyan-400 scale-95'
                      : 'bg-slate-950 text-cyan-300 border-cyan-800 hover:bg-cyan-900/60'
                  }`}
                  title="X+ Jog (Right Arrow / D)"
                >
                  <ArrowRight className="w-5 h-5" />
                  <span className="text-[9px]">X+ (→)</span>
                </button>
              </div>
            </div>

            {/* Y- Down Arrow */}
            <div className="text-center">
              <button
                onClick={() => onJogAxis?.('Y', -1)}
                className={`w-16 h-12 rounded-xl border flex flex-col items-center justify-center font-bold text-xs transition active:scale-90 shadow-md ${
                  activePressedKey === 'ArrowDown' || activePressedKey === 's' || activePressedKey === 'S'
                    ? 'bg-cyan-500 text-slate-950 border-cyan-300 ring-2 ring-cyan-400 scale-95'
                    : 'bg-slate-950 text-cyan-300 border-cyan-800 hover:bg-cyan-900/60'
                }`}
                title="Y- Jog (Down Arrow / S)"
              >
                <ArrowDown className="w-5 h-5" />
                <span className="text-[9px]">Y- (↓)</span>
              </button>
              <span className="text-[10px] text-slate-400 font-urdu block mt-0.5">Y- (گینٹری آگے - Front)</span>
            </div>
          </div>
        </div>

        {/* Right Side: Z Axis (Page Up / Page Down) & Safety Action Keys (5 Cols) */}
        <div className="col-span-12 lg:col-span-5 p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-[11px] text-amber-400 border-b border-slate-800 pb-1 font-bold">
            <span>Z-Axis گہرائی و اونچائی (Vertical)</span>
            <span className="text-[10px] text-slate-400">PageUp / PageDn</span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {/* Page Up (Z+) */}
            <button
              onClick={() => onJogAxis?.('Z', 1)}
              className={`p-3 rounded-xl border flex flex-col items-center justify-center text-center transition active:scale-95 shadow-md ${
                activePressedKey === 'PageUp' || activePressedKey === 'e' || activePressedKey === 'E'
                  ? 'bg-amber-500 text-slate-950 border-amber-300 ring-2 ring-amber-400'
                  : 'bg-slate-950 text-amber-300 border-amber-800/80 hover:bg-amber-950/60'
              }`}
              title="Z+ Elevate (Page Up / E)"
            >
              <ChevronUp className="w-6 h-6" />
              <span className="font-bold text-xs mt-1">Page Up</span>
              <span className="text-[10px] text-amber-400/90 font-urdu">Z+ اوپر اٹھانا</span>
              <span className="text-[9px] text-slate-500 font-mono">(Safe Lift)</span>
            </button>

            {/* Page Down (Z-) */}
            <button
              onClick={() => onJogAxis?.('Z', -1)}
              className={`p-3 rounded-xl border flex flex-col items-center justify-center text-center transition active:scale-95 shadow-md ${
                activePressedKey === 'PageDown' || activePressedKey === 'q' || activePressedKey === 'Q'
                  ? 'bg-amber-500 text-slate-950 border-amber-300 ring-2 ring-amber-400'
                  : 'bg-slate-950 text-amber-300 border-amber-800/80 hover:bg-amber-950/60'
              }`}
              title="Z- Plunge (Page Down / Q)"
            >
              <ChevronDown className="w-6 h-6" />
              <span className="font-bold text-xs mt-1">Page Down</span>
              <span className="text-[10px] text-amber-400/90 font-urdu">Z- نیچے لانا</span>
              <span className="text-[9px] text-slate-500 font-mono">(Plunge Stock)</span>
            </button>
          </div>

          {/* Action Modifier Keys */}
          <div className="space-y-1.5 pt-1">
            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800">
              <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-bold text-[10px]">
                Shift + Arrow
              </span>
              <span className="text-[11px] text-slate-300 font-urdu">تیز رفتار ریپڈ موشن (Rapid G0)</span>
            </div>

            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800">
              <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 font-bold text-[10px]">
                Spacebar
              </span>
              <span className="text-[11px] text-amber-300 font-urdu">فیڈ ہولڈ (Pause Feed)</span>
            </div>

            <div className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800">
              <span className="px-2 py-0.5 rounded bg-red-950 text-red-300 font-bold text-[10px]">
                Esc / Alt+S
              </span>
              <span className="text-[11px] text-red-300 font-urdu">ایمرجنسی اسٹاپ (E-Stop)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
