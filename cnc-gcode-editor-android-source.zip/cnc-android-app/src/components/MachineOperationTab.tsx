import React, { useState, useRef, useEffect } from 'react';
import { CNCOperationRecovery } from './CNCOperationRecovery';
import { CNC_STEPS, CNCStep } from '../data/cncSteps';
import { InteractiveCADViewer } from './InteractiveCADViewer';
import {
  DEFAULT_GCODE_PROGRAMS,
  SavedGcodeProgram,
  getStoredGcodePrograms,
  saveGcodeProgram,
} from '../utils/storage';
import {
  Cpu,
  Calculator,
  FileCode,
  Layers,
  Sliders,
  Play,
  Copy,
  Download,
  Check,
  RotateCcw,
  Sparkles,
  Zap,
  ArrowRight,
  ShieldAlert,
  HelpCircle,
  Eye,
  CheckCircle2,
} from 'lucide-react';

interface MachineOperationTabProps {
  lang: 'ur' | 'en' | 'both';
  onSelectAssemblyStep?: (stepId: number) => void;
}

export const MachineOperationTab: React.FC<MachineOperationTabProps> = ({
  lang,
  onSelectAssemblyStep,
}) => {
  const [subTab, setSubTab] = useState<'control' | 'feeds' | 'gcode' | 'cad'>('control');

  // ==================== SPEEDS & FEEDS CALCULATOR STATE ====================
  const woodMaterials = [
    {
      id: 'mdf',
      nameUr: 'ایم ڈی ایف شیٹ (MDF Board)',
      nameEn: 'MDF (Medium Density Fiberboard)',
      hardnessUr: 'درمیانی (Medium)',
      hardnessEn: 'Medium Density',
      recommendedRpm: 18000,
      baseChipLoad: 0.12, // mm/tooth for 6mm
      maxDepthPerPassFactor: 1.0, // x tool diameter
      notesUr: 'کاربائیڈ 2-فلوٹ اسٹرائٹ یا اپ کٹ بٹ بہترین ہے۔ ڈسٹ ایکسٹریکٹر لازمی استعمال کریں۔',
      notesEn: 'Solid carbide 2-flute straight or upcut spiral bit recommended. Always engage dust extraction.',
    },
    {
      id: 'sheesham',
      nameUr: 'شیشم کی لکڑی (Sheesham / Rosewood)',
      nameEn: 'Sheesham (Indian Rosewood)',
      hardnessUr: 'سخت اور وزنی (Hard & Dense)',
      hardnessEn: 'Hard & Heavy Timber',
      recommendedRpm: 16000,
      baseChipLoad: 0.06,
      maxDepthPerPassFactor: 0.5,
      notesUr: 'شیشم سخت ریشوں والی لکڑی ہے، زیادہ گہرائی مت دیں۔ 6 ملی میٹر بٹ پر زیادہ سے زیادہ 3mm گہرائی فی پاس رکھیں۔',
      notesEn: 'Dense interlocking grain. Limit depth of cut to max 3mm per pass for 6mm tool to prevent spindle bogging.',
    },
    {
      id: 'walnut',
      nameUr: 'اخروٹ کی لکڑی (Walnut Hardwood)',
      nameEn: 'Walnut Hardwood',
      hardnessUr: 'درمیانی سخت (Medium-Hard)',
      hardnessEn: 'Medium-Hard Fine Grain',
      recommendedRpm: 17000,
      baseChipLoad: 0.08,
      maxDepthPerPassFactor: 0.7,
      notesUr: 'صاف کٹائی اور نفاست کے لیے ڈاون کٹ یا کمپریشن بٹ استعمال کریں تاکہ اوپر کی سطح نہ اکھڑے۔',
      notesEn: 'Use downcut or compression spirals to maintain crisp top edges without fiber tearout on decorative reliefs.',
    },
    {
      id: 'deodar',
      nameUr: 'دیودار / پرتھل (Deodar / Cedar Softwood)',
      nameEn: 'Deodar / Cedar Softwood',
      hardnessUr: 'نرم لکڑی (Softwood)',
      hardnessEn: 'Resinous Softwood',
      recommendedRpm: 19000,
      baseChipLoad: 0.14,
      maxDepthPerPassFactor: 1.2,
      notesUr: 'تیز کٹائی ممکن ہے لیکن گوند اور رال کی وجہ سے بٹ کو وقفے سے صاف کریں۔',
      notesEn: 'Fast feed rates possible. Clean resin buildup from flutes periodically using solvent to maintain keen edge.',
    },
    {
      id: 'plywood',
      nameUr: 'کمرشل پلائی ووڈ (Plywood Sheets)',
      nameEn: 'Commercial / Marine Plywood',
      hardnessUr: 'پرت دار (Multi-layer)',
      hardnessEn: 'Multi-ply Cross Laminated',
      recommendedRpm: 18000,
      baseChipLoad: 0.1,
      maxDepthPerPassFactor: 0.8,
      notesUr: 'گوند کی تہوں سے بٹ گرم ہو سکتی ہے، فیڈ ریٹ زیادہ رکھیں تاکہ بٹ جلنے سے بچے (Zero Burning)۔',
      notesEn: 'Abrasive glue lines generate heat. Maintain higher feed rates to prevent tool friction glazing and burn marks.',
    },
    {
      id: 'acrylic',
      nameUr: 'کاسٹ ایکریلک شیٹ (Cast Acrylic)',
      nameEn: 'Cast Acrylic (Plastic)',
      hardnessUr: 'پلاسٹک (Polymer)',
      hardnessEn: 'Cast Thermoplastic',
      recommendedRpm: 15000,
      baseChipLoad: 0.07,
      maxDepthPerPassFactor: 0.5,
      notesUr: 'سنگل فلوٹ (1-Flute) بٹ لازمی استعمال کریں ورنہ چپس پگھل کر بٹ کے ساتھ چپک جائیں گے۔',
      notesEn: 'Single "O-Flute" upcut spiral strictly required to eject curly chips without plastic weld-back.',
    },
  ];

  const [selectedMaterialId, setSelectedMaterialId] = useState<string>('sheesham');
  const [toolDiameter, setToolDiameter] = useState<number>(6.0); // mm
  const [flutes, setFlutes] = useState<number>(2);
  const [customRpm, setCustomRpm] = useState<number>(16000);
  const [customFeed, setCustomFeed] = useState<number>(2400); // mm/min
  const [customPlunge, setCustomPlunge] = useState<number>(800); // mm/min
  const [customDepthOfCut, setCustomDepthOfCut] = useState<number>(3.0); // mm

  const activeMaterial = woodMaterials.find((m) => m.id === selectedMaterialId) || woodMaterials[0];

  // Recalculate feeds when material or tool changes
  useEffect(() => {
    const rpm = activeMaterial.recommendedRpm;
    const chipLoad = activeMaterial.baseChipLoad * Math.sqrt(toolDiameter / 6);
    const calculatedFeed = Math.round(rpm * flutes * chipLoad);
    const calculatedPlunge = Math.round(calculatedFeed * 0.35);
    const calculatedDepth = Number((toolDiameter * activeMaterial.maxDepthPerPassFactor).toFixed(1));

    setCustomRpm(rpm);
    setCustomFeed(calculatedFeed);
    setCustomPlunge(calculatedPlunge);
    setCustomDepthOfCut(calculatedDepth);
  }, [selectedMaterialId, toolDiameter, flutes]);

  // ==================== G-CODE GENERATOR STATE ====================
  const [generatorType, setGeneratorType] = useState<'surfacing' | 'pocket' | 'circle' | 'engrave'>('surfacing');
  const [gcodeLength, setGcodeLength] = useState<number>(600); // mm
  const [gcodeWidth, setGcodeWidth] = useState<number>(400); // mm
  const [gcodeTotalDepth, setGcodeTotalDepth] = useState<number>(1.0); // mm
  const [gcodeSafeZ, setGcodeSafeZ] = useState<number>(20.0); // mm
  const [generatedGcode, setGeneratedGcode] = useState<string>('');
  const [copiedGcode, setCopiedGcode] = useState<boolean>(false);
  const [savedPrograms, setSavedPrograms] = useState<SavedGcodeProgram[]>(getStoredGcodePrograms);

  // Generate G-code dynamically based on user parameters
  useEffect(() => {
    let code = `(=======================================================)\n`;
    code += `( ARBAZ WOOD CRAFT - CNC ROUTER G-CODE PROGRAM )\n`;
    code += `( Material: ${activeMaterial.nameEn} )\n`;
    code += `( Tool Diameter: ${toolDiameter}mm | Spindle: ${customRpm} RPM )\n`;
    code += `( Feed: ${customFeed} mm/min | Plunge: ${customPlunge} mm/min )\n`;
    code += `( Date: ${new Date().toLocaleDateString()} )\n`;
    code += `(=======================================================)\n`;
    code += `G21 (Metric Units mm)\n`;
    code += `G90 (Absolute Coordinates)\n`;
    code += `G17 (XY Circular Plane Selection)\n`;
    code += `G0 Z${gcodeSafeZ.toFixed(3)} (Move to Clearance Height)\n`;
    code += `M3 S${customRpm} (Start Spindle Clockwise)\n`;
    code += `G4 P2.5 (Dwell 2.5s for Spindle Spool Up)\n\n`;

    if (generatorType === 'surfacing') {
      const stepover = Number((toolDiameter * 0.45).toFixed(2));
      code += `(--- OPERATION 1: SPOILBOARD / TIMBER SURFACING ---)\n`;
      code += `G0 X0.000 Y0.000\n`;
      code += `G1 Z-${gcodeTotalDepth.toFixed(3)} F${customPlunge}\n`;

      let curY = 0;
      let forward = true;
      while (curY <= gcodeWidth) {
        if (forward) {
          code += `G1 X${gcodeLength.toFixed(3)} F${customFeed}\n`;
        } else {
          code += `G1 X0.000 F${customFeed}\n`;
        }
        curY += stepover;
        if (curY <= gcodeWidth) {
          code += `G1 Y${curY.toFixed(3)} F${customFeed}\n`;
          forward = !forward;
        }
      }
    } else if (generatorType === 'pocket') {
      code += `(--- OPERATION 2: RECTANGULAR POCKET ROUGHING ---)\n`;
      const passDepth = Math.min(gcodeTotalDepth, customDepthOfCut);
      let currentZ = 0;
      while (currentZ < gcodeTotalDepth) {
        currentZ = Math.min(gcodeTotalDepth, currentZ + passDepth);
        code += `( Pass at Z -${currentZ.toFixed(2)} mm )\n`;
        code += `G0 X20.000 Y20.000\n`;
        code += `G1 Z-${currentZ.toFixed(3)} F${customPlunge}\n`;
        code += `G1 X${(gcodeLength - 20).toFixed(3)} F${customFeed}\n`;
        code += `G1 Y${(gcodeWidth - 20).toFixed(3)} F${customFeed}\n`;
        code += `G1 X20.000 F${customFeed}\n`;
        code += `G1 Y20.000 F${customFeed}\n`;
      }
    } else if (generatorType === 'circle') {
      const radius = Number((Math.min(gcodeLength, gcodeWidth) / 2 - 10).toFixed(2));
      const centerX = Number((gcodeLength / 2).toFixed(2));
      const centerY = Number((gcodeWidth / 2).toFixed(2));
      code += `(--- OPERATION 3: CIRCULAR ROSETTE MEDALLION ---)\n`;
      code += `G0 X${(centerX + radius).toFixed(3)} Y${centerY.toFixed(3)}\n`;
      code += `G1 Z-${gcodeTotalDepth.toFixed(3)} F${customPlunge}\n`;
      code += `G2 X${(centerX + radius).toFixed(3)} Y${centerY.toFixed(3)} I-${radius.toFixed(3)} J0.000 F${customFeed}\n`;
    } else {
      code += `(--- OPERATION 4: V-BIT CARVING & LETTERING ---)\n`;
      code += `G0 X50.000 Y50.000\n`;
      code += `G1 Z-${gcodeTotalDepth.toFixed(3)} F${customPlunge}\n`;
      code += `G1 X250.000 Y50.000 F${customFeed}\n`;
      code += `G1 X250.000 Y150.000 F${customFeed}\n`;
      code += `G1 X50.000 Y150.000 F${customFeed}\n`;
      code += `G1 X50.000 Y50.000 F${customFeed}\n`;
    }

    code += `\n(--- FINISH & SAFE PARK ---)\n`;
    code += `G0 Z${gcodeSafeZ.toFixed(3)} (Retract Spindle)\n`;
    code += `M5 (Spindle Stop)\n`;
    code += `G0 X0.000 Y0.000 (Return to Work Zero)\n`;
    code += `M30 (End Program and Rewind)\n`;

    setGeneratedGcode(code);
  }, [
    generatorType,
    gcodeLength,
    gcodeWidth,
    gcodeTotalDepth,
    gcodeSafeZ,
    customRpm,
    customFeed,
    customPlunge,
    activeMaterial,
    toolDiameter,
    customDepthOfCut,
  ]);

  const handleCopyGcode = () => {
    navigator.clipboard.writeText(generatedGcode);
    setCopiedGcode(true);
    setTimeout(() => setCopiedGcode(false), 2000);
  };

  const handleDownloadGcode = () => {
    const blob = new Blob([generatedGcode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ArbazWoodCraft_${generatorType}_${Date.now()}.nc`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleSaveToLibrary = () => {
    const prog: SavedGcodeProgram = {
      id: 'gcode-' + Date.now(),
      name: `Arbaz ${generatorType.toUpperCase()} (${toolDiameter}mm - ${activeMaterial.nameEn})`,
      description: `G-code for ${activeMaterial.nameEn}, ${gcodeLength}x${gcodeWidth}mm, cut depth ${gcodeTotalDepth}mm`,
      date: new Date().toLocaleDateString(),
      material: activeMaterial.nameEn,
      code: generatedGcode,
      estimatedTime: '5-12 min',
    };
    saveGcodeProgram(prog);
    setSavedPrograms(getStoredGcodePrograms());
    alert(lang === 'en' ? 'Program saved to workshop library!' : 'پروگرام کامیابی سے لائبریری میں محفوظ ہو گیا!');
  };

  // ==================== 3D CAD BLUEPRINTS STATE ====================
  const [selectedCadStepId, setSelectedCadStepId] = useState<number>(1);
  const selectedCadStep = CNC_STEPS.find((s) => s.id === selectedCadStepId) || CNC_STEPS[0];

  // Dynamic Translations object
  const t = {
    tabControls: lang === 'en' ? 'Machine Controls & Recovery' : lang === 'both' ? 'مشین کنٹرول و ریکوری (Controls)' : 'مشین کنٹرول اور ریکوری',
    tabFeeds: lang === 'en' ? 'Speeds & Feeds Calculator' : lang === 'both' ? 'اسپیڈز و فیڈز (Speeds & Feeds)' : 'اسپیڈز اور فیڈز کیلکولیٹر',
    tabGcode: lang === 'en' ? 'G-Code Generator & Library' : lang === 'both' ? 'G-Code جنریٹر (G-Code)' : 'G-Code جنریٹر اور لائبریری',
    tabCad: lang === 'en' ? '3D CAD Blueprints' : lang === 'both' ? '3D CAD بلو پرنٹس (CAD)' : '3D CAD بلو پرنٹس',
    woodHeader: lang === 'en' ? 'Wood & Material Selection' : lang === 'both' ? 'لکڑی اور میٹریل کا انتخاب (Wood Selection)' : 'لکڑی اور میٹریل کا انتخاب',
    woodSub: lang === 'en' ? 'Cutting parameters for Pakistani & local timbers' : 'پاکستانی اور لوکل لکڑیوں کے درست پیرامیٹرز',
    toolDiamLabel: lang === 'en' ? 'End Mill Diameter:' : lang === 'both' ? 'کٹنگ ٹول سائز (End Mill Diameter):' : 'کٹنگ ٹول کا سائز:',
    flutesLabel: lang === 'en' ? 'Number of Flutes:' : lang === 'both' ? 'فلوٹس کی تعداد (Flutes):' : 'فلوٹس کی تعداد:',
    calcTitle: lang === 'en' ? 'Calculated Speeds & Feeds Parameters' : lang === 'both' ? 'تجویز کردہ اسپیڈز اور فیڈز (Calculated Parameters)' : 'تجویز کردہ اسپیڈز اور فیڈز ریٹس',
    optimizedBadge: lang === 'en' ? 'Optimized for 2.2kW Spindle' : '2.2kW اسپنڈل کے لیے تصدیق شدہ',
    rpmLabel: lang === 'en' ? 'Spindle Speed' : 'اسپنڈل رفتار',
    feedLabel: lang === 'en' ? 'Feed Rate' : 'کٹنگ فیڈ',
    plungeLabel: lang === 'en' ? 'Plunge Rate' : 'پلنج رفتار',
    depthLabel: lang === 'en' ? 'Depth / Pass' : 'گہرائی فی پاس',
    masterTip: lang === 'en' ? 'Workshop Master Guidelines:' : lang === 'both' ? 'ورکشاپ ماسٹر ہدایات (Master Tips):' : 'ورکشاپ ماسٹر ہدایات:',
    useInGcodeBtn: lang === 'en' ? 'Use Parameters in G-Code Generator' : lang === 'both' ? 'یہ پیرامیٹرز G-Code جنریٹر میں استعمال کریں (Use in G-Code)' : 'یہ پیرامیٹرز G-Code جنریٹر میں استعمال کریں',
    gcodeOpTitle: lang === 'en' ? 'Select CNC Operation' : 'G-Code آپریشن منتخب کریں',
    gcodeOpSub: lang === 'en' ? 'Program automatically generated based on tool parameters' : 'تیار پروگرام خودکار طریقے سے تیار ہوگا',
    lenX: lang === 'en' ? 'Length X (mm):' : 'لمبائی X (mm):',
    widY: lang === 'en' ? 'Width Y (mm):' : 'چوڑائی Y (mm):',
    depthCut: lang === 'en' ? 'Cut Depth (mm):' : 'کل گہرائی (mm):',
    safeZ: lang === 'en' ? 'Safe Z (mm):' : 'سیفٹی ہائٹ (mm):',
    copyGcode: lang === 'en' ? 'Copy G-Code' : 'G-Code کاپی کریں',
    copied: lang === 'en' ? 'Copied!' : 'کاپی ہو گیا!',
    downloadNc: lang === 'en' ? 'Download (.NC)' : 'ڈاؤن لوڈ کریں (.NC)',
    saveLib: lang === 'en' ? '+ Save to Workshop Library' : '+ ورکشاپ لائبریری میں سیو کریں',
    savedProgsTitle: lang === 'en' ? 'Saved G-Code Files' : 'محفوظ شدہ G-Code فائلیں',
    loadCode: lang === 'en' ? 'Load' : 'لوڈ کریں',
    cadHeader: lang === 'en' ? '3D CAD Blueprint References (Steps 1 to 30)' : lang === 'both' ? '3D CAD بلو پرنٹ ریفرنسز (Steps 1-30)' : '3D CAD بلو پرنٹ ریفرنس ویور (مراحل 1 تا 30)',
    selectStepLabel: lang === 'en' ? 'Select Step:' : 'سٹیپ منتخب کریں:',
    goToStepBtn: lang === 'en' ? 'Go to Assembly Step &rarr;' : 'اسٹیپ پر جائیں &rarr;',
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-4 space-y-6 pb-24">
      {/* Sub-tab navigation buttons */}
      <div className="bg-slate-900/95 border border-cyan-900/60 rounded-2xl p-1.5 flex flex-wrap gap-1.5 shadow-lg backdrop-blur-md">
        <button
          onClick={() => setSubTab('control')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer ${
            subTab === 'control'
              ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-md shadow-cyan-500/25'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Cpu className="w-4 h-4" />
          <span>{t.tabControls}</span>
        </button>

        <button
          onClick={() => setSubTab('feeds')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer ${
            subTab === 'feeds'
              ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-md shadow-cyan-500/25'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Calculator className="w-4 h-4" />
          <span>{t.tabFeeds}</span>
        </button>

        <button
          onClick={() => setSubTab('gcode')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer ${
            subTab === 'gcode'
              ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-md shadow-cyan-500/25'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <FileCode className="w-4 h-4" />
          <span>{t.tabGcode}</span>
        </button>

        <button
          onClick={() => setSubTab('cad')}
          className={`flex-1 min-w-[140px] py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer ${
            subTab === 'cad'
              ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-md shadow-cyan-500/25'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>{t.tabCad}</span>
        </button>
      </div>

      {/* SUB-TAB 1: CNC MACHINE CONTROL & RECOVERY */}
      {subTab === 'control' && (
        <div className="space-y-6">
          <CNCOperationRecovery lang={lang} />
        </div>
      )}

      {/* SUB-TAB 2: SPEEDS & FEEDS CALCULATOR FOR WOOD CRAFT */}
      {subTab === 'feeds' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Material & Tool Selection */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-slate-900/90 border border-cyan-900/60 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                <span className="text-xl">🪵</span>
                <div>
                  <h3 className="text-sm font-bold text-white font-sans">{t.woodHeader}</h3>
                  <p className="text-[11px] text-slate-400">{t.woodSub}</p>
                </div>
              </div>

              {/* Material List */}
              <div className="space-y-2">
                {woodMaterials.map((mat) => (
                  <button
                    key={mat.id}
                    onClick={() => setSelectedMaterialId(mat.id)}
                    className={`w-full text-right p-3 rounded-xl border transition cursor-pointer ${
                      selectedMaterialId === mat.id
                        ? 'bg-cyan-950/80 border-cyan-400 text-white shadow-md shadow-cyan-500/10'
                        : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-bold text-xs font-sans">
                        {lang === 'en' ? mat.nameEn : lang === 'both' ? `${mat.nameUr}` : mat.nameUr}
                      </span>
                      <span className="text-[10px] font-mono text-cyan-400 px-2 py-0.5 rounded bg-slate-900 border border-cyan-900">
                        {lang === 'en' ? mat.hardnessEn : mat.hardnessUr}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 font-sans">
                      {lang === 'ur' ? mat.notesUr.slice(0, 48) + '...' : mat.nameEn}
                    </p>
                  </button>
                ))}
              </div>

              {/* Tool Parameters */}
              <div className="pt-2 border-t border-slate-800 space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1 font-sans">
                    {t.toolDiamLabel}
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[3.175, 4.0, 6.0, 12.0].map((d) => (
                      <button
                        key={d}
                        onClick={() => setToolDiameter(d)}
                        className={`py-2 rounded-lg text-xs font-mono font-bold border transition cursor-pointer ${
                          toolDiameter === d
                            ? 'bg-cyan-500 text-slate-950 border-cyan-400'
                            : 'bg-slate-950 border-slate-800 text-slate-300'
                        }`}
                      >
                        {d} mm {d === 3.175 ? '(1/8")' : d === 6 ? '(1/4")' : d === 12 ? '(1/2")' : ''}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1 font-sans">
                    {t.flutesLabel}
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[1, 2, 3].map((f) => (
                      <button
                        key={f}
                        onClick={() => setFlutes(f)}
                        className={`py-2 rounded-lg text-xs font-mono font-bold border transition cursor-pointer ${
                          flutes === f
                            ? 'bg-cyan-500 text-slate-950 border-cyan-400'
                            : 'bg-slate-950 border-slate-800 text-slate-300'
                        }`}
                      >
                        {f} Flute {f === 1 ? '(Single)' : f === 2 ? '(Double)' : '(Triple)'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Calculated Speeds & Feeds Result */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-slate-900/90 border border-cyan-900/60 rounded-2xl p-6 space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-cyan-400" />
                  <h3 className="text-base font-bold text-white font-sans">
                    {t.calcTitle}
                  </h3>
                </div>
                <span className="text-xs font-mono bg-emerald-950 text-emerald-400 border border-emerald-800 px-2.5 py-1 rounded-full">
                  {t.optimizedBadge}
                </span>
              </div>

              {/* 4 Big Spec Metric Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-950 p-3.5 rounded-xl border border-cyan-950">
                  <span className="text-[11px] text-slate-400 block font-mono">{t.rpmLabel} (RPM)</span>
                  <span className="text-xl font-bold font-mono text-cyan-400">{customRpm}</span>
                  <span className="text-[10px] text-slate-500 block">rev / min</span>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-cyan-950">
                  <span className="text-[11px] text-slate-400 block font-mono">{t.feedLabel} (Feed)</span>
                  <span className="text-xl font-bold font-mono text-emerald-400">{customFeed}</span>
                  <span className="text-[10px] text-slate-500 block">mm / min</span>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-cyan-950">
                  <span className="text-[11px] text-slate-400 block font-mono">{t.plungeLabel} (Plunge)</span>
                  <span className="text-xl font-bold font-mono text-amber-400">{customPlunge}</span>
                  <span className="text-[10px] text-slate-500 block">mm / min</span>
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl border border-cyan-950">
                  <span className="text-[11px] text-slate-400 block font-mono">{t.depthLabel}</span>
                  <span className="text-xl font-bold font-mono text-purple-400">{customDepthOfCut}</span>
                  <span className="text-[10px] text-slate-500 block">mm per pass</span>
                </div>
              </div>

              {/* Material Pro-Tip Note */}
              <div className="p-4 bg-cyan-950/40 border border-cyan-800/80 rounded-xl space-y-2 text-xs">
                <div className="flex items-center gap-1.5 text-cyan-300 font-bold font-sans">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  <span>{t.masterTip} ({lang === 'en' ? activeMaterial.nameEn : activeMaterial.nameUr})</span>
                </div>
                <p className="text-slate-300 leading-relaxed font-sans">
                  {lang === 'en' ? activeMaterial.notesEn : activeMaterial.notesUr}
                </p>
              </div>

              {/* Direct Link to G-Code generator */}
              <button
                onClick={() => setSubTab('gcode')}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-cyan-500/20 font-sans"
              >
                <span>{t.useInGcodeBtn}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: G-CODE GENERATOR & PROGRAM LIBRARY */}
      {subTab === 'gcode' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Generator Controls */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-slate-900/90 border border-cyan-900/60 rounded-2xl p-5 space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                <FileCode className="w-5 h-5 text-cyan-400" />
                <div>
                  <h3 className="text-sm font-bold text-white font-sans">{t.gcodeOpTitle}</h3>
                  <p className="text-[11px] text-slate-400">{t.gcodeOpSub}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {[
                  {
                    id: 'surfacing',
                    label: lang === 'en' ? 'Spoilboard Facing' : lang === 'both' ? 'اسپوائل بورڈ فیسنگ (Facing)' : 'اسپوائل بورڈ فیسنگ',
                  },
                  {
                    id: 'pocket',
                    label: lang === 'en' ? 'Rectangular Pocket' : lang === 'both' ? 'مستطیل پاکٹ (Pocket)' : 'مستطیل پاکٹ',
                  },
                  {
                    id: 'circle',
                    label: lang === 'en' ? 'Circular Rosette' : lang === 'both' ? 'دائرہ رو زیٹ (Rosette)' : 'دائرہ رو زیٹ',
                  },
                  {
                    id: 'engrave',
                    label: lang === 'en' ? 'V-Bit Engraving' : lang === 'both' ? 'وی-بٹ کندہ کاری (Engraving)' : 'وی-بٹ کندہ کاری',
                  },
                ].map((op) => (
                  <button
                    key={op.id}
                    onClick={() => setGeneratorType(op.id as any)}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition cursor-pointer text-right font-sans ${
                      generatorType === op.id
                        ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md shadow-cyan-500/20'
                        : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    {op.label}
                  </button>
                ))}
              </div>

              {/* Dimensional Inputs */}
              <div className="space-y-3 pt-2 border-t border-slate-800 text-xs">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1">{t.lenX}</label>
                    <input
                      type="number"
                      value={gcodeLength}
                      onChange={(e) => setGcodeLength(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">{t.widY}</label>
                    <input
                      type="number"
                      value={gcodeWidth}
                      onChange={(e) => setGcodeWidth(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1">{t.depthCut}</label>
                    <input
                      type="number"
                      step="0.5"
                      value={gcodeTotalDepth}
                      onChange={(e) => setGcodeTotalDepth(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">{t.safeZ}</label>
                    <input
                      type="number"
                      value={gcodeSafeZ}
                      onChange={(e) => setGcodeSafeZ(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex gap-2">
                <button
                  onClick={handleCopyGcode}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer border border-slate-700 font-sans"
                >
                  {copiedGcode ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-cyan-400" />}
                  <span>{copiedGcode ? t.copied : t.copyGcode}</span>
                </button>

                <button
                  onClick={handleDownloadGcode}
                  className="flex-1 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-cyan-500/20 font-sans"
                >
                  <Download className="w-4 h-4" />
                  <span>{t.downloadNc}</span>
                </button>
              </div>

              <button
                onClick={handleSaveToLibrary}
                className="w-full py-2.5 rounded-xl bg-slate-950 hover:bg-slate-900 border border-cyan-900 text-cyan-300 text-xs font-mono transition cursor-pointer font-sans"
              >
                {t.saveLib}
              </button>
            </div>

            {/* Saved Programs List */}
            <div className="bg-slate-900/90 border border-cyan-900/60 rounded-2xl p-5 space-y-3">
              <h4 className="text-xs font-bold text-cyan-300 uppercase tracking-wider font-mono">
                {t.savedProgsTitle} ({savedPrograms.length})
              </h4>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {savedPrograms.map((p) => (
                  <div
                    key={p.id}
                    className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between gap-2 text-xs"
                  >
                    <div className="truncate">
                      <p className="font-bold text-white truncate font-sans">{p.name}</p>
                      <span className="text-[10px] text-slate-500 font-mono">{p.material} &bull; {p.estimatedTime}</span>
                    </div>
                    <button
                      onClick={() => setGeneratedGcode(p.code)}
                      className="px-2.5 py-1 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-400 text-[11px] font-mono hover:bg-cyan-900 shrink-0 cursor-pointer"
                    >
                      {t.loadCode}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Code Editor */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-slate-950 border border-cyan-900/60 rounded-2xl p-4 font-mono text-xs flex flex-col h-[580px]">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-slate-400">
                <span className="text-cyan-400 font-bold flex items-center gap-1.5">
                  <FileCode className="w-4 h-4" />
                  <span>CNC PROGRAM PREVIEW: Arbaz_Router.nc</span>
                </span>
                <span className="text-[11px] bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                  {generatedGcode.split('\n').length} Lines
                </span>
              </div>

              <textarea
                readOnly
                value={generatedGcode}
                className="flex-1 w-full bg-transparent text-emerald-300 font-mono p-3 resize-none outline-none overflow-y-auto leading-relaxed selection:bg-cyan-500 selection:text-slate-950"
              />
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 4: 3D CAD/CAM BLUEPRINT REFERENCES (1-30) */}
      {subTab === 'cad' && (
        <div className="space-y-4">
          <div className="bg-slate-900/90 border border-cyan-900/60 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-cyan-400" />
              <h3 className="text-sm font-bold text-white font-sans">{t.cadHeader}</h3>
            </div>

            <div className="flex items-center gap-2">
              <label className="text-xs text-slate-400 font-mono">{t.selectStepLabel}</label>
              <select
                value={selectedCadStepId}
                onChange={(e) => setSelectedCadStepId(Number(e.target.value))}
                className="bg-slate-950 border border-cyan-800 text-white rounded-lg px-3 py-1.5 text-xs font-mono outline-none"
              >
                {CNC_STEPS.map((s) => (
                  <option key={s.id} value={s.id}>
                    Step {s.id}: {lang === 'en' ? s.titleEn : lang === 'both' ? `${s.titleUrdu} (${s.titleEn})` : s.titleUrdu}
                  </option>
                ))}
              </select>

              {onSelectAssemblyStep && (
                <button
                  onClick={() => onSelectAssemblyStep(selectedCadStepId)}
                  className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition cursor-pointer font-sans"
                >
                  {t.goToStepBtn}
                </button>
              )}
            </div>
          </div>

          <InteractiveCADViewer
            step={selectedCadStep}
            isGenerating={false}
            onOpenEditModal={() => {}}
            lang={lang}
          />
        </div>
      )}
    </div>
  );
};
