import React, { useState, useEffect, useRef, useMemo } from 'react';
import { CNC_OPERATION_STEPS, CNCOperationStep } from '../data/cncOperationSteps';
import { ControllerScreenMockup } from './ControllerScreenMockup';
import { KeyboardControlDiagram } from './KeyboardControlDiagram';
import { speakText, stopSpeaking, isSpeechSynthesisActive } from '../utils/speechUtils';
import {
  Compass,
  Zap,
  RotateCw,
  Play,
  Square,
  AlertTriangle,
  CheckCircle2,
  Volume2,
  VolumeX,
  FileCode,
  Copy,
  Download,
  Crosshair,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Check,
  ShieldCheck,
  Power,
  RotateCcw,
  Sparkles,
  Sliders,
  MessageCircle,
  ExternalLink,
  Keyboard,
  Monitor,
} from 'lucide-react';

interface CNCOperationRecoveryProps {
  lang: 'ur' | 'en' | 'both';
}

export const CNCOperationRecovery: React.FC<CNCOperationRecoveryProps> = ({ lang }) => {
  // Current Active Roadmap Step ('A' through 'G')
  const [currentStepId, setCurrentStepId] = useState<'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G'>('A');

  // Sub-view mode: 'step' (A-Z Roadmap) vs 'sandbox' (Full Interactive Jogging & Visualizer)
  const [viewMode, setViewMode] = useState<'step' | 'sandbox'>('step');

  // Completed Steps Tracker
  const [completedSteps, setCompletedSteps] = useState<Record<string, boolean>>({
    A: false,
    B: false,
    C: false,
    D: false,
    E: false,
    F: false,
    G: false,
  });

  // Step Checklist checked items
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});

  // Audio Guide State
  const [isSpeakingStep, setIsSpeakingStep] = useState<boolean>(false);

  // ==================== 3-AXIS JOGGING & MACHINE STATE ====================
  const [posX, setPosX] = useState<number>(150.0);
  const [posY, setPosY] = useState<number>(200.0);
  const [posZ, setPosZ] = useState<number>(-10.0);

  const [stepIncrement, setStepIncrement] = useState<number>(1.0); // mm
  const [feedRate, setFeedRate] = useState<number>(1800); // mm/min
  const [isSpindleOn, setIsSpindleOn] = useState<boolean>(false);
  const [spindleRpm, setSpindleRpm] = useState<number>(18000);
  const [isCoolantOn, setIsCoolantOn] = useState<boolean>(false);
  const [keyboardJogEnabled, setKeyboardJogEnabled] = useState<boolean>(true);

  // Recent jogging command log
  const [recentJogLog, setRecentJogLog] = useState<string[]>([
    'System initialized. G54 Coordinate System Active. Soft Limits: X[0-1000], Y[0-750], Z[-150-0] mm.',
  ]);

  // Canvas visualizer refs
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const trailRef = useRef<{ x: number; y: number }[]>([]);

  // ==================== STEP F: POWER LOSS RECOVERY STATE ====================
  const [interruptedLineNumber, setInterruptedLineNumber] = useState<number>(45210);
  const [safeZHeight, setSafeZHeight] = useState<number>(25.0);
  const [recoveryRpm, setRecoveryRpm] = useState<number>(18000);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  const currentStep = useMemo(() => {
    return CNC_OPERATION_STEPS.find((s) => s.id === currentStepId) || CNC_OPERATION_STEPS[0];
  }, [currentStepId]);

  // Stop active speech on step change or unmount
  useEffect(() => {
    stopSpeaking();
    setIsSpeakingStep(false);
    return () => {
      stopSpeaking();
    };
  }, [currentStepId]);

  // Toggle audio guide speech for the current step
  const handleToggleSpeakStep = () => {
    if (isSpeakingStep) {
      stopSpeaking();
      setIsSpeakingStep(false);
      return;
    }

    const textToSpeak = `${currentStep.titleUrdu}۔ ${currentStep.subtitleUrdu}۔ طریقہ کار: ${currentStep.urduInstructions.join(' ')} اہم انتباہ: ${currentStep.proTipUrdu}`;
    setIsSpeakingStep(true);

    speakText(
      textToSpeak,
      lang === 'en' ? 'en' : 'ur',
      () => setIsSpeakingStep(false),
      () => setIsSpeakingStep(false)
    );
  };

  // Toggle checklist item
  const handleToggleChecklist = (checkId: string) => {
    setCheckedItems((prev) => ({
      ...prev,
      [checkId]: !prev[checkId],
    }));
  };

  // Toggle step completion
  const handleToggleStepComplete = (stepId: string) => {
    setCompletedSteps((prev) => ({
      ...prev,
      [stepId]: !prev[stepId],
    }));
  };

  // Next / Prev Step Navigation
  const stepIds: ('A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G')[] = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
  const currentIndex = stepIds.indexOf(currentStepId);

  const handleNextStep = () => {
    if (currentIndex < stepIds.length - 1) {
      setCurrentStepId(stepIds[currentIndex + 1]);
    }
  };

  const handlePrevStep = () => {
    if (currentIndex > 0) {
      setCurrentStepId(stepIds[currentIndex - 1]);
    }
  };

  // Jog Axis Function
  const jogAxis = (axis: 'X' | 'Y' | 'Z', direction: number) => {
    const delta = direction * stepIncrement;
    let newX = posX;
    let newY = posY;
    let newZ = posZ;

    if (axis === 'X') {
      newX = Math.max(0, Math.min(1000, Number((posX + delta).toFixed(3))));
      setPosX(newX);
    } else if (axis === 'Y') {
      newY = Math.max(0, Math.min(750, Number((posY + delta).toFixed(3))));
      setPosY(newY);
    } else if (axis === 'Z') {
      newZ = Math.max(-150, Math.min(0, Number((posZ + delta).toFixed(3))));
      setPosZ(newZ);
    }

    // Add to toolpath trail
    trailRef.current.push({ x: newX, y: newY });
    if (trailRef.current.length > 60) trailRef.current.shift();

    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const logMsg = `[${timestamp}] JOG ${axis}${direction > 0 ? '+' : ''}${delta.toFixed(2)}mm -> Pos: X${newX.toFixed(2)} Y${newY.toFixed(2)} Z${newZ.toFixed(2)} (F${feedRate})`;
    setRecentJogLog((prev) => [logMsg, ...prev.slice(0, 6)]);
  };

  const handleZeroAxis = (axis: 'X' | 'Y' | 'Z') => {
    if (axis === 'X') setPosX(0);
    if (axis === 'Y') setPosY(0);
    if (axis === 'Z') setPosZ(0);
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setRecentJogLog((prev) => [`[${timestamp}] WCS G54 ZERO SET: Axis ${axis} = 0.000 mm`, ...prev.slice(0, 6)]);
  };

  // Global Keyboard Shortcuts Listener
  useEffect(() => {
    if (!keyboardJogEnabled) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      switch (e.key) {
        case 'ArrowLeft':
        case 'a':
        case 'A':
          e.preventDefault();
          jogAxis('X', -1);
          break;
        case 'ArrowRight':
        case 'd':
        case 'D':
          e.preventDefault();
          jogAxis('X', 1);
          break;
        case 'ArrowUp':
        case 'w':
        case 'W':
          e.preventDefault();
          jogAxis('Y', 1);
          break;
        case 'ArrowDown':
        case 's':
        case 'S':
          e.preventDefault();
          jogAxis('Y', -1);
          break;
        case 'PageUp':
        case 'e':
        case 'E':
          e.preventDefault();
          jogAxis('Z', 1); // Z Up
          break;
        case 'PageDown':
        case 'q':
        case 'Q':
          e.preventDefault();
          jogAxis('Z', -1); // Z Down
          break;
        case 'Escape':
          e.preventDefault();
          setIsSpindleOn(false);
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [keyboardJogEnabled, posX, posY, posZ, stepIncrement, feedRate]);

  // Canvas Motion Animation for 2D CNC Bed
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;

      // Dark CNC Grid Background
      ctx.fillStyle = '#060d19';
      ctx.fillRect(0, 0, width, height);

      // Grid Lines (100mm scale)
      ctx.strokeStyle = '#0e2238';
      ctx.lineWidth = 1;
      const step = 28;
      for (let x = 0; x < width; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Work Envelope Border (1000mm x 750mm scaled)
      const bedPad = 25;
      const bedW = width - bedPad * 2;
      const bedH = height - bedPad * 2;

      ctx.strokeStyle = '#0284c7';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(bedPad, bedPad, bedW, bedH);

      // Origin Marker (Bottom-Left 0,0)
      ctx.fillStyle = '#10b981';
      ctx.beginPath();
      ctx.arc(bedPad, bedPad + bedH, 4, 0, Math.PI * 2);
      ctx.fill();

      // Toolpath Trail
      if (trailRef.current.length > 1) {
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        trailRef.current.forEach((pt, i) => {
          const px = bedPad + (pt.x / 1000) * bedW;
          const py = bedPad + bedH - (pt.y / 750) * bedH;
          if (i === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        });
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Live Gantry X & Y Lines
      const curX = bedPad + (posX / 1000) * bedW;
      const curY = bedPad + bedH - (posY / 750) * bedH;

      // Gantry Y Axis Cross Beam
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.4)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(bedPad, curY);
      ctx.lineTo(bedPad + bedW, curY);
      ctx.stroke();

      // Spindle Head Crosshair
      ctx.strokeStyle = isSpindleOn ? '#22c55e' : '#f59e0b';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(curX, curY, isSpindleOn ? 10 : 7, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = isSpindleOn ? '#22c55e' : '#f59e0b';
      ctx.beginPath();
      ctx.arc(curX, curY, 3, 0, Math.PI * 2);
      ctx.fill();

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [posX, posY, posZ, isSpindleOn]);

  // Generated recovered G-code for Step F
  const generatedRecoveryGcode = useMemo(() => {
    return `(========================================================)
(CNC 3-AXIS RESUME AFTER SUDDEN POWER FAILURE MACRO)
(TARGET RESUME LINE: N${interruptedLineNumber} | SAFE RETRACT: Z+${safeZHeight.toFixed(1)}mm)
(GENERATED BY ARBAZ WOOD CRAFT CNC RECOVERY SYSTEM)
(========================================================)
G21 (All dimensions in Millimeters)
G90 (Absolute Distance Positioning Mode)
G54 (Select Work Coordinate System 1)

(STAGE 1: SAFE LIFT & CLEARANCE TRAVERSE)
G0 Z${safeZHeight.toFixed(2)} (Elevate Z to safe clearance plane above clamps)

(STAGE 2: SPINDLE ACTIVATION & THERMAL STABILIZATION)
M3 S${recoveryRpm} (Start Spindle Motor Clockwise at ${recoveryRpm} RPM)
G4 P5.0 (Dwell pause for 5 seconds until spindle reaches full operating torque)
${isCoolantOn ? 'M8 (Flood Coolant ON)' : '(M8 Coolant standby)'}

(STAGE 3: RAPID TRANSIT TO LAST VERIFIED XY DATUM)
G0 X156.800 Y215.350 (Rapid to exact XY above interruption line N${interruptedLineNumber})

(STAGE 4: CONTROLLED PLUNGE RE-ENTRY)
G1 Z-2.500 F500 (Initial gentle plunge to 2mm above cut surface)
G1 Z-4.500 F300 (Touch cut bottom at safe controlled entry feedrate)

(STAGE 5: RESUMED PRODUCTION TOOLPATH)
G1 X157.450 Y215.900 F1800 (Resume continuous carving profile)
G1 X158.100 Y216.420 F1800
G1 X158.850 Y217.000 F1800
(Continue rest of program...)`;
  }, [interruptedLineNumber, safeZHeight, recoveryRpm, isCoolantOn]);

  const handleCopyGcode = () => {
    navigator.clipboard.writeText(generatedRecoveryGcode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleDownloadGcode = () => {
    const blob = new Blob([generatedRecoveryGcode], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Recovery_Resume_Line_N${interruptedLineNumber}.nc`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Dynamic translations dictionary
  const t = {
    sopBadge: lang === 'en' ? 'Standard Operating Procedure (SOP)' : lang === 'both' ? 'معیاری آپریٹنگ طریقہ کار (SOP)' : 'معیاری آپریٹنگ طریقہ کار (SOP)',
    guideTitle: lang === 'en' ? 'CNC Router Operations Guide (A to Z Roadmap)' : lang === 'both' ? 'سی این سی مشین آپریشن گائیڈ (A to Z Roadmap)' : 'سی این سی مشین آپریشن گائیڈ (مرحلہ وار A تا Z روڈ میپ)',
    guideSub: lang === 'en'
      ? 'Complete workshop protocol from Power ON, homing, coordinate zeroing, job start, blackout recovery to safe shutdown.'
      : lang === 'both'
      ? 'پاور آن، ہومنگ، زیرو سیٹنگ، کٹنگ، پاور بریک ڈاون ریکوری اور شٹ ڈاؤن۔ (Complete SOP protocol)'
      : 'پاور آن سے لے کر زیرو سیٹنگ، کٹنگ اسٹارٹ، بجلی بندش کے بعد ریکوری اور محفوظ شٹ ڈاؤن کا مکمل نظام۔',
    tabRoadmap: lang === 'en' ? 'A to Z Roadmap' : lang === 'both' ? 'A تا Z روڈ میپ (Roadmap)' : 'A تا Z روڈ میپ',
    tabSandbox: lang === 'en' ? 'Full Jogging Sandbox' : lang === 'both' ? 'فل جاگنگ سینڈ باکس (Sandbox)' : 'فل جاگنگ سینڈ باکس',
    duration: lang === 'en' ? 'Duration:' : 'دورانیہ:',
    listenAudio: lang === 'en' ? 'Listen (Audio Guide)' : lang === 'both' ? 'سنیں (Audio Guide)' : 'سنیں (آڈیو گائیڈ)',
    stopAudio: lang === 'en' ? 'Stop Audio' : 'آڈیو روکیں',
    stepDone: lang === 'en' ? 'Step Completed ✓' : 'مرحلہ مکمل ✓',
    markDone: lang === 'en' ? 'Mark Complete' : 'مکمل مارک کریں',
    instructionsHeader: lang === 'en' ? 'Detailed Instructions & SOP' : lang === 'both' ? 'تفصیلی طریقہ کار اور ہدایات (Detailed Instructions)' : 'تفصیلی طریقہ کار اور ہدایات',
    proTipHeader: lang === 'en' ? 'Master Workshop Pro Tip' : lang === 'both' ? 'پیشہ ورانہ ورکشاپ ٹپ (Master Pro Tip)' : 'پیشہ ورانہ ورکشاپ ٹپ',
    checklistHeader: lang === 'en' ? 'Pre-Run Verification Checklist' : lang === 'both' ? 'چیک لسٹ برائے تصدیق (Pre-Run Verification)' : 'چیک لسٹ برائے تصدیق',
    prevStep: lang === 'en' ? 'Previous Step' : 'پچھلا مرحلہ',
    nextStep: lang === 'en' ? 'Next Step' : 'اگلا مرحلہ',
    stepOf: lang === 'en' ? 'Step' : 'مرحلہ',
    of: lang === 'en' ? 'of' : 'از',
    droHeader: lang === 'en' ? 'Digital Readout (DRO Coordinates)' : lang === 'both' ? 'ڈیجیٹل ریڈ آؤٹ (DRO Coordinates)' : 'ڈیجیٹل ریڈ آؤٹ',
    stepSize: lang === 'en' ? 'Step Increment:' : 'اسٹیپ سائز:',
    spindleOn: lang === 'en' ? 'Spindle: ON (18K)' : 'اسپنڈل: ON (18K)',
    spindleOff: lang === 'en' ? 'Spindle: OFF (M5)' : 'اسپنڈل: OFF (M5)',
    coolantOn: lang === 'en' ? 'Coolant: M8 ON' : 'کولنٹ: M8 ON',
    coolantOff: lang === 'en' ? 'Coolant: M9 OFF' : 'کولنٹ: M9 OFF',
    canvasHeader: lang === 'en' ? '2D CNC Bed Toolpath Simulation (1000 x 750 mm)' : lang === 'both' ? '2D بیڈ ٹول پاتھ سمولیشن (Toolpath Simulation)' : '2D سی این سی بیڈ ٹول پاتھ سمولیشن (1000 x 750 mm)',
    consoleLog: lang === 'en' ? 'Live Motion Command Log:' : 'کمانڈ کنسول لاگ:',
    supportTitle: lang === 'en' ? 'Chief Engineer & Developer Direct Support' : lang === 'both' ? 'ڈویلپر اور کاریگر براہ راست سپورٹ (Developer Support)' : 'ڈویلپر اور کاریگر براہ راست سپورٹ',
    supportSub: lang === 'en' ? 'WhatsApp for direct emergency guidance or troubleshooting.' : 'کسی بھی اسٹیپ (A تا G) میں دشواری یا ایمرجنسی مشین رہنمائی کے لیے واٹس ایپ کریں۔',
    whatsappBtn: lang === 'en' ? 'Contact +923480170151' : '03480170151 پر رابطہ کریں',
  };

  return (
    <div className="space-y-6">
      {/* ===================== TOP HEADER & NAVIGATION SYSTEM ===================== */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/70 border border-cyan-800/80 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold">
              CNC ROUTER OPERATION ROADMAP (A TO Z)
            </span>
            <span className="text-xs font-mono text-emerald-400 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> {t.sopBadge}
            </span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-100 flex items-center gap-2 font-sans">
            <span>{t.guideTitle}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1 font-sans max-w-2xl">
            {t.guideSub}
          </p>
        </div>

        {/* View Mode Toggle: Step Roadmap vs Jogging Sandbox */}
        <div className="flex items-center gap-2">
          <div className="bg-slate-900 p-1 rounded-xl border border-cyan-900 flex items-center text-xs font-mono">
            <button
              onClick={() => setViewMode('step')}
              className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition cursor-pointer ${
                viewMode === 'step'
                  ? 'bg-cyan-600 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-cyan-300'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>{t.tabRoadmap}</span>
            </button>
            <button
              onClick={() => setViewMode('sandbox')}
              className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition cursor-pointer ${
                viewMode === 'sandbox'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-amber-300'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>{t.tabSandbox}</span>
            </button>
          </div>
        </div>
      </div>

      {/* ===================== STEP-BY-STEP A TO Z SELECTOR BAR ===================== */}
      <div className="bg-slate-900/90 border border-cyan-900/80 rounded-2xl p-2 overflow-x-auto shadow-lg backdrop-blur">
        <div className="flex items-center gap-2 min-w-max">
          {CNC_OPERATION_STEPS.map((step) => {
            const isActive = step.id === currentStepId;
            const isDone = completedSteps[step.id];

            return (
              <button
                key={step.id}
                onClick={() => {
                  setCurrentStepId(step.id);
                  setViewMode('step');
                }}
                className={`px-3.5 py-2.5 rounded-xl text-xs font-mono flex items-center gap-2.5 transition shrink-0 ${
                  isActive
                    ? 'bg-cyan-600 text-slate-950 font-bold shadow-lg shadow-cyan-600/30 ring-2 ring-cyan-400 scale-[1.02]'
                    : isDone
                    ? 'bg-slate-950 text-emerald-400 border border-emerald-800/80 hover:bg-slate-850'
                    : 'bg-slate-950 text-slate-300 border border-slate-800 hover:border-cyan-800 hover:bg-slate-850'
                }`}
              >
                <span
                  className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs ${
                    isActive
                      ? 'bg-slate-950 text-cyan-300'
                      : isDone
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                      : 'bg-slate-900 text-slate-400'
                  }`}
                >
                  {isDone ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : step.id}
                </span>

                <div className="text-left font-sans">
                  <div className="font-bold leading-tight text-[11px]">
                    {lang === 'en' ? step.titleEn : lang === 'both' ? `${step.titleUrdu} (${step.titleEn})` : step.titleUrdu}
                  </div>
                  <div className="text-[10px] font-mono opacity-80">{step.stepLetter}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* ===================== VIEW MODE 1: STEP-BY-STEP (A TO Z) ===================== */}
      {viewMode === 'step' && (
        <div className="space-y-6">
          {/* Active Step Hero Card */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-950 via-slate-900 to-cyan-950/60 border border-cyan-800 shadow-2xl relative overflow-hidden">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-cyan-950">
              <div>
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <span className="px-3 py-1 rounded-md bg-cyan-950 border border-cyan-700 text-cyan-300 font-mono font-bold text-xs">
                    {currentStep.stepLetter}
                  </span>
                  <span className="px-2.5 py-0.5 rounded text-[11px] font-mono bg-slate-900 text-slate-300 border border-slate-800">
                    ⏱️ {t.duration} {currentStep.estimatedTime}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      currentStep.safetyLevel === 'CRITICAL'
                        ? 'bg-red-950/80 text-red-400 border border-red-800'
                        : currentStep.safetyLevel === 'WARNING'
                        ? 'bg-amber-950/80 text-amber-400 border border-amber-800'
                        : 'bg-emerald-950/80 text-emerald-400 border border-emerald-800'
                    }`}
                  >
                    {currentStep.safetyLevel} SAFETY
                  </span>
                </div>

                <h3 className="text-xl md:text-2xl font-bold text-slate-100 mt-1 font-sans">
                  {lang === 'en' ? currentStep.titleEn : lang === 'both' ? `${currentStep.titleUrdu} (${currentStep.titleEn})` : currentStep.titleUrdu}
                </h3>
                <div className="text-xs font-mono text-cyan-400 mt-0.5">
                  {lang === 'en' ? currentStep.subtitleEn : lang === 'both' ? `${currentStep.subtitleUrdu} // ${currentStep.subtitleEn}` : currentStep.subtitleUrdu}
                </div>
              </div>

              {/* Action Buttons: Audio Guide & Step Completion */}
              <div className="flex items-center gap-3">
                <button
                  onClick={handleToggleSpeakStep}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold font-sans flex items-center gap-2 transition shadow-md cursor-pointer ${
                    isSpeakingStep
                      ? 'bg-red-500 text-white animate-pulse shadow-red-500/30'
                      : 'bg-cyan-600 hover:bg-cyan-500 text-slate-950 shadow-cyan-600/30'
                  }`}
                  title="Listen to Voice Instructions"
                >
                  {isSpeakingStep ? (
                    <>
                      <VolumeX className="w-4 h-4" />
                      <span>{t.stopAudio}</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-4 h-4" />
                      <span>{t.listenAudio}</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => handleToggleStepComplete(currentStep.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold font-mono flex items-center gap-2 transition border cursor-pointer ${
                    completedSteps[currentStep.id]
                      ? 'bg-emerald-950/80 border-emerald-600 text-emerald-300'
                      : 'bg-slate-900 border-slate-700 hover:border-slate-500 text-slate-300'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{completedSteps[currentStep.id] ? t.stepDone : t.markDone}</span>
                </button>
              </div>
            </div>

            {/* Step Instructions Grid */}
            <div className="grid grid-cols-12 gap-6 mt-6">
              {/* Left Column: Instructions & Pro Tip (7 Cols) */}
              <div className="col-span-12 lg:col-span-7 space-y-4">
                <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between text-xs font-mono text-cyan-400 pb-2 border-b border-slate-800">
                    <span className="font-bold">{t.instructionsHeader}</span>
                    <span className="text-[10px] text-slate-500">
                      {lang === 'en' ? 'Standard Procedure' : lang === 'both' ? 'اردو اور انگلش' : 'معیاری طریقہ کار'}
                    </span>
                  </div>

                  <div className="space-y-2.5 text-xs text-slate-200 leading-relaxed font-sans">
                    {currentStep.urduInstructions.map((inst, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800/80 flex items-start gap-2.5 hover:border-cyan-900 transition"
                      >
                        <span className="w-5 h-5 rounded-full bg-cyan-950 text-cyan-300 text-[11px] font-mono font-bold flex items-center justify-center shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <div className="flex-1">
                          {(lang === 'ur' || lang === 'both') && (
                            <p className="text-slate-200 font-sans">{inst}</p>
                          )}
                          {(lang === 'en' || lang === 'both') && (
                            <p className={`text-[11px] font-mono text-slate-300 ${lang === 'both' ? 'mt-1 text-slate-400' : ''}`}>
                              {currentStep.englishInstructions[idx]}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Pro Workshop Tip Card */}
                <div className="p-4 rounded-xl bg-gradient-to-r from-amber-950/40 via-slate-950 to-amber-950/20 border border-amber-800/80 text-xs space-y-2">
                  <div className="flex items-center gap-2 text-amber-300 font-bold font-mono">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>{t.proTipHeader}</span>
                  </div>
                  {(lang === 'ur' || lang === 'both') && (
                    <p className="text-slate-200 leading-relaxed font-sans">
                      {currentStep.proTipUrdu}
                    </p>
                  )}
                  {(lang === 'en' || lang === 'both') && (
                    <p className={`text-[11px] font-mono text-slate-300 ${lang === 'both' ? 'text-slate-400' : ''}`}>
                      {currentStep.proTipEn}
                    </p>
                  )}
                </div>

                {/* Step Verification Checklist */}
                <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2.5">
                  <div className="text-xs font-mono text-emerald-400 font-bold border-b border-slate-800 pb-1 flex items-center justify-between">
                    <span>{t.checklistHeader}</span>
                    <span className="text-[10px] text-slate-500">{currentStep.checklist.length} {lang === 'en' ? 'Checks' : 'نکات'}</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {currentStep.checklist.map((item) => (
                      <label
                        key={item.id}
                        onClick={() => handleToggleChecklist(item.id)}
                        className={`p-2.5 rounded-lg border flex items-center gap-2.5 cursor-pointer transition select-none ${
                          checkedItems[item.id]
                            ? 'bg-emerald-950/60 border-emerald-600 text-emerald-200'
                            : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={Boolean(checkedItems[item.id])}
                          readOnly
                          className="rounded bg-slate-950 border-slate-700 text-emerald-500"
                        />
                        <div className="text-[11px] leading-tight">
                          <div className="font-sans">
                            {lang === 'en' ? item.labelEn : lang === 'both' ? `${item.labelUrdu} (${item.labelEn})` : item.labelUrdu}
                          </div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Column: Controller Screen Mockup & Keyboard Diagram (5 Cols) */}
              <div className="col-span-12 lg:col-span-5 space-y-4">
                {/* Controller Screen Mockup Component */}
                <ControllerScreenMockup
                  step={currentStep}
                  currentX={posX}
                  currentY={posY}
                  currentZ={posZ}
                  isSpindleOn={isSpindleOn}
                  feedRate={feedRate}
                  spindleRpm={spindleRpm}
                  onJogAxis={jogAxis}
                  onToggleSpindle={() => setIsSpindleOn(!isSpindleOn)}
                  onZeroAxis={handleZeroAxis}
                />

                {/* Keyboard Control Diagram Component */}
                <KeyboardControlDiagram
                  onJogAxis={jogAxis}
                  onToggleSpindle={() => setIsSpindleOn(!isSpindleOn)}
                  stepIncrement={stepIncrement}
                />

                {/* Step F Special: Interactive G-Code Recovery Box */}
                {currentStep.id === 'F' && (
                  <div className="p-4 rounded-xl bg-gradient-to-br from-amber-950/60 via-slate-950 to-slate-900 border-2 border-amber-600 shadow-xl space-y-3 font-mono text-xs">
                    <div className="flex items-center justify-between pb-2 border-b border-amber-900">
                      <span className="font-bold text-amber-300 flex items-center gap-1.5">
                        <Zap className="w-4 h-4 text-amber-400" />
                        <span>{lang === 'en' ? 'Live G-Code Crash Recovery Generator' : 'لائیو G-Code ریکوری جنریٹر'}</span>
                      </span>
                      <span className="text-[10px] text-amber-400/90 font-sans">
                        {lang === 'en' ? 'Instant Recovery' : 'فوری بحالی'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-1">
                          {lang === 'en' ? 'Interruption Line #:' : 'انقطاع لائن نمبر (Line #):'}
                        </label>
                        <input
                          type="number"
                          value={interruptedLineNumber}
                          onChange={(e) => setInterruptedLineNumber(Number(e.target.value) || 0)}
                          className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-amber-300 font-bold focus:outline-none focus:border-amber-500 text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-1">
                          {lang === 'en' ? 'Safe Retract Z (mm):' : 'محفوظ ریٹریکٹ Z اونچائی (mm):'}
                        </label>
                        <input
                          type="number"
                          value={safeZHeight}
                          onChange={(e) => setSafeZHeight(Number(e.target.value) || 20)}
                          className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-amber-300 font-bold focus:outline-none focus:border-amber-500 text-xs"
                        />
                      </div>
                    </div>

                    {/* Code Output Window */}
                    <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-[10px] text-slate-300 font-mono max-h-36 overflow-y-auto leading-relaxed">
                      <pre>{generatedRecoveryGcode}</pre>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleCopyGcode}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-700/80 text-[11px] font-bold flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer"
                      >
                        {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copiedCode ? (lang === 'en' ? 'Copied!' : 'کاپی ہو گیا!') : (lang === 'en' ? 'Copy G-Code' : 'G-Code کاپی کریں')}</span>
                      </button>
                      <button
                        onClick={handleDownloadGcode}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-slate-950 text-[11px] font-bold flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>{lang === 'en' ? 'Download Macro (.nc)' : 'ڈاؤن لوڈ میکرو (.nc)'}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Step Navigation Footer (Prev / Next Buttons) */}
            <div className="flex items-center justify-between pt-6 mt-6 border-t border-cyan-950">
              <button
                onClick={handlePrevStep}
                disabled={currentIndex === 0}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 disabled:opacity-40 text-xs font-mono flex items-center gap-2 transition cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>{t.prevStep} ({currentIndex > 0 ? stepIds[currentIndex - 1] : 'Start'})</span>
              </button>

              <div className="text-center font-mono text-xs text-slate-400 hidden sm:block">
                {t.stepOf} {currentIndex + 1} {t.of} {stepIds.length} ({currentStep.stepLetter})
              </div>

              <button
                onClick={handleNextStep}
                disabled={currentIndex === stepIds.length - 1}
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-slate-950 font-bold text-xs font-mono flex items-center gap-2 transition shadow-md cursor-pointer"
              >
                <span>{t.nextStep} ({currentIndex < stepIds.length - 1 ? stepIds[currentIndex + 1] : 'End'})</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================== VIEW MODE 2: FULL JOGGING & VISUALIZER SANDBOX ===================== */}
      {viewMode === 'sandbox' && (
        <div className="grid grid-cols-12 gap-6">
          {/* Left Column: DROs & Jog Controls (5 Cols) */}
          <div className="col-span-12 lg:col-span-5 space-y-4">
            {/* DRO Card */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-800 shadow-xl space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between text-cyan-400 border-b border-slate-800 pb-2">
                <span className="font-bold flex items-center gap-1.5">
                  <Crosshair className="w-4 h-4 text-cyan-400" />
                  <span>{t.droHeader}</span>
                </span>
                <span className="text-[10px] text-slate-500">WCS: G54 ACTIVE</span>
              </div>

              <div className="space-y-2">
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-cyan-400 font-bold text-sm">X-AXIS:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-bold tracking-widest text-emerald-400">
                      {posX.toFixed(3)}
                    </span>
                    <button
                      onClick={() => handleZeroAxis('X')}
                      className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300 hover:bg-cyan-700 cursor-pointer"
                    >
                      Zero X
                    </button>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-cyan-400 font-bold text-sm">Y-AXIS:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-bold tracking-widest text-emerald-400">
                      {posY.toFixed(3)}
                    </span>
                    <button
                      onClick={() => handleZeroAxis('Y')}
                      className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300 hover:bg-cyan-700 cursor-pointer"
                    >
                      Zero Y
                    </button>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-amber-400 font-bold text-sm">Z-AXIS:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-bold tracking-widest text-amber-400">
                      {posZ.toFixed(3)}
                    </span>
                    <button
                      onClick={() => handleZeroAxis('Z')}
                      className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300 hover:bg-amber-700 cursor-pointer"
                    >
                      Zero Z
                    </button>
                  </div>
                </div>
              </div>

              {/* Increment Selectors */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                <span className="text-slate-400 text-[11px]">{t.stepSize}</span>
                <div className="flex items-center gap-1">
                  {[0.01, 0.1, 1.0, 10.0].map((inc) => (
                    <button
                      key={inc}
                      onClick={() => setStepIncrement(inc)}
                      className={`px-2 py-1 rounded text-[10px] font-bold transition cursor-pointer ${
                        stepIncrement === inc
                          ? 'bg-cyan-500 text-slate-950'
                          : 'bg-slate-900 text-slate-400 hover:bg-slate-800'
                      }`}
                    >
                      {inc}mm
                    </button>
                  ))}
                </div>
              </div>

              {/* Spindle & Coolant */}
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
                <button
                  onClick={() => setIsSpindleOn(!isSpindleOn)}
                  className={`py-2 px-3 rounded-xl font-mono text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer ${
                    isSpindleOn
                      ? 'bg-emerald-500 text-slate-950 shadow-md animate-pulse'
                      : 'bg-slate-900 text-slate-300 border border-slate-700'
                  }`}
                >
                  <RotateCw className={`w-4 h-4 ${isSpindleOn ? 'animate-spin' : ''}`} />
                  <span>{isSpindleOn ? t.spindleOn : t.spindleOff}</span>
                </button>

                <button
                  onClick={() => setIsCoolantOn(!isCoolantOn)}
                  className={`py-2 px-3 rounded-xl font-mono text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer ${
                    isCoolantOn
                      ? 'bg-cyan-500 text-slate-950'
                      : 'bg-slate-900 text-slate-300 border border-slate-700'
                  }`}
                >
                  <Zap className="w-4 h-4" />
                  <span>{isCoolantOn ? t.coolantOn : t.coolantOff}</span>
                </button>
              </div>
            </div>

            {/* Keyboard Control Diagram Component */}
            <KeyboardControlDiagram
              onJogAxis={jogAxis}
              onToggleSpindle={() => setIsSpindleOn(!isSpindleOn)}
              stepIncrement={stepIncrement}
            />
          </div>

          {/* Right Column: 2D CNC Bed Canvas Visualizer & Command Logs (7 Cols) */}
          <div className="col-span-12 lg:col-span-7 space-y-4">
            <div className="p-4 rounded-2xl bg-slate-950 border border-cyan-800 shadow-xl space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between text-cyan-400 border-b border-slate-800 pb-2">
                <span className="font-bold flex items-center gap-1.5">
                  <Compass className="w-4 h-4 text-cyan-400" />
                  <span>{t.canvasHeader}</span>
                </span>
                <span className="text-emerald-400 text-[10px]">● 60 FPS MOTION</span>
              </div>

              {/* Canvas element */}
              <div className="relative w-full aspect-[4/3] rounded-xl overflow-hidden border border-slate-800 bg-[#060d19]">
                <canvas
                  ref={canvasRef}
                  width={640}
                  height={480}
                  className="w-full h-full block"
                />
              </div>

              {/* Console log */}
              <div className="space-y-1">
                <div className="text-[10px] text-slate-500">{t.consoleLog}</div>
                <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 font-mono text-[10px] text-slate-300 space-y-0.5 max-h-24 overflow-y-auto">
                  {recentJogLog.map((log, lIdx) => (
                    <div key={lIdx} className="truncate">{log}</div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================== DIRECT WHATSAPP SUPPORT SECTION BANNER ===================== */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-950 to-slate-900 border border-emerald-800/80 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 text-left">
          <div className="w-12 h-12 rounded-xl bg-emerald-950 border border-emerald-700/80 flex items-center justify-center text-emerald-400 shrink-0">
            <MessageCircle className="w-6 h-6 fill-current" />
          </div>
          <div>
            <div className="text-xs font-mono text-emerald-400 font-bold">
              {t.supportTitle}
            </div>
            <div className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>Arbaz Ahmad (ارباز احمد)</span>
              <span className="text-slate-500">|</span>
              <span className="text-amber-400">Arbaz Wood Craft</span>
            </div>
            <div className="text-xs text-slate-400 font-sans mt-0.5">
              {t.supportSub}
            </div>
          </div>
        </div>

        <a
          href="https://wa.me/923480170151?text=%D8%A7%D9%84%D8%B3%D9%84%D8%A7%D9%85%20%D8%B9%D9%84%D9%8A%DA%A9%D9%85%20%D8%A7%D8%B1%D8%A8%D8%A7%D8%B2%20%D8%A8%DA%BE%D8%A7%D8%A6%DB%8C!%20%D9%85%D8%AC%DA%BE%DB%92%20CNC%20%D8%B1%D9%88%D9%85%DB%8C%D9%BE%20%D8%A2%D9%BE%D8%B1%DB%8C%D8%B4%D9%86%20%DA%A9%DB%92%20%D8%AD%D9%88%D8%A7%D9%84%DB%92%20%D8%B3%DB%92%20%D8%B1%DB%81%D9%86%D9%85%D8%A7%D8%A6%DB%8C%20%DA%86%D8%A7%DB%81%DB%8C%DB%92%DB%94"
          target="_blank"
          rel="noopener noreferrer"
          className="px-5 py-2.5 rounded-xl bg-[#25D366] hover:bg-[#20ba59] active:bg-[#1da850] text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-[#25D366]/20 transition shrink-0 cursor-pointer"
        >
          <MessageCircle className="w-4 h-4 fill-current" />
          <span>{t.whatsappBtn}</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  );
};
