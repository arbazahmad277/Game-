import React, { useState } from 'react';
import { CNC_STEPS, CNCStep } from '../data/cncSteps';
import {
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Search,
  Layers,
  Sparkles,
  Cpu,
} from 'lucide-react';

interface StepNavigatorProps {
  currentStepId: number;
  onSelectStep: (stepId: number) => void;
  generatedImages: Record<number, string>;
  lang: 'ur' | 'en' | 'both';
  completedSteps?: Record<number, boolean>;
  onToggleComplete?: (stepId: number) => void;
}

export const StepNavigator: React.FC<StepNavigatorProps> = ({
  currentStepId,
  onSelectStep,
  generatedImages,
  lang,
  completedSteps = {},
  onToggleComplete,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [collapsedPhases, setCollapsedPhases] = useState<Record<number, boolean>>({});

  // Group steps by Phase
  const phases = [
    { id: 1, nameUrdu: 'فیز 1: بنیادی فریم اور بیڈ اسٹرکچر', nameEn: 'Phase 1: Base Frame & Bed Structure', range: '1 - 5' },
    { id: 2, nameUrdu: 'فیز 2: وائی ایکسس موشن سسٹم', nameEn: 'Phase 2: Y-Axis Motion System & Drive', range: '6 - 10' },
    { id: 3, nameUrdu: 'فیز 3: گینٹری اور ایکس ایکسس بیم', nameEn: 'Phase 3: Gantry Assembly & X-Axis Beam', range: '11 - 15' },
    { id: 4, nameUrdu: 'فیز 4: زیڈ ایکسس اور اسپنڈل ماؤنٹ', nameEn: 'Phase 4: Z-Axis Carriage & Spindle', range: '16 - 20' },
    { id: 5, nameUrdu: 'فیز 5: ڈریگ چین اور کیلیبریشن', nameEn: 'Phase 5: Cable Management & Alignment', range: '21 - 24' },
    { id: 6, nameUrdu: 'فیز 6: الیکٹرانکس، وی ایف ڈی اور وائرنگ', nameEn: 'Phase 6: Electronics, Power & Inverter', range: '25 - 28' },
    { id: 7, nameUrdu: 'فیز 7: سافٹ ویئر اور پہلی ٹیسٹ کٹنگ', nameEn: 'Phase 7: Commissioning & First Cut', range: '29 - 30' },
  ];

  const togglePhase = (phaseId: number) => {
    setCollapsedPhases((prev) => ({ ...prev, [phaseId]: !prev[phaseId] }));
  };

  const filteredSteps = CNC_STEPS.filter((s) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      s.titleEn.toLowerCase().includes(q) ||
      s.titleUrdu.toLowerCase().includes(q) ||
      String(s.id).includes(q)
    );
  });

  return (
    <div className="bg-slate-900/95 border border-cyan-800/60 rounded-xl overflow-hidden shadow-xl flex flex-col h-[700px] backdrop-blur">
      {/* Header */}
      <div className="p-4 border-b border-cyan-950 bg-slate-950/60">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-mono font-bold text-cyan-400 flex items-center gap-1.5 uppercase">
            <Layers className="w-4 h-4 text-cyan-400" />
            <span>
              {lang === 'en'
                ? 'Assembly Roadmap (1 - 30)'
                : lang === 'both'
                ? 'اسیمبلی روڈ میپ (Roadmap 1-30)'
                : 'اسیمبلی روڈ میپ (1 - 30)'}
            </span>
          </span>
          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800/60">
            {Object.keys(generatedImages).length} / 30 {lang === 'en' ? 'Ready' : 'تیار'}
          </span>
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              lang === 'en'
                ? 'Search step, component, or spec...'
                : lang === 'both'
                ? 'تلاش کریں (Search step or component)...'
                : 'تلاش کریں (مرحلہ یا پرزہ)...'
            }
            className="w-full bg-slate-950 border border-cyan-950 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500 font-sans"
          />
        </div>
      </div>

      {/* Step Tree List */}
      <div className="flex-1 overflow-y-auto p-2 space-y-3">
        {phases.map((phase) => {
          const phaseSteps = filteredSteps.filter((s) => s.phaseId === phase.id);
          if (phaseSteps.length === 0) return null;

          const isCollapsed = collapsedPhases[phase.id];

          return (
            <div key={phase.id} className="rounded-lg bg-slate-950/50 border border-slate-800/80 overflow-hidden">
              {/* Phase Collapsible Header */}
              <button
                onClick={() => togglePhase(phase.id)}
                className="w-full flex items-center justify-between p-2.5 text-left text-xs hover:bg-slate-900/60 transition cursor-pointer"
              >
                <div>
                  <span className="font-bold text-cyan-300 block font-sans">
                    {lang === 'en'
                      ? phase.nameEn
                      : lang === 'both'
                      ? `${phase.nameUrdu} (${phase.nameEn})`
                      : phase.nameUrdu}
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {lang === 'en' ? `Steps: ${phase.range}` : `مراحل: ${phase.range}`}
                  </span>
                </div>
                {isCollapsed ? (
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                ) : (
                  <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
                )}
              </button>

              {/* Step Items */}
              {!isCollapsed && (
                <div className="p-1 space-y-1 border-t border-slate-900">
                  {phaseSteps.map((step) => {
                    const isSelected = currentStepId === step.id;
                    const hasImage = Boolean(generatedImages[step.id]);
                    const isCompleted = Boolean(completedSteps[step.id]);

                    return (
                      <div
                        key={step.id}
                        className={`w-full flex items-center gap-2 p-1.5 rounded-lg transition ${
                          isSelected
                            ? 'bg-cyan-950/90 text-cyan-200 border border-cyan-500/70 shadow-sm'
                            : 'hover:bg-slate-900/80 text-slate-300'
                        }`}
                      >
                        {/* Toggle Checkbox */}
                        {onToggleComplete && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onToggleComplete(step.id);
                            }}
                            title={isCompleted ? 'مکمل ہو چکا (Completed)' : 'نامکمل (Incomplete)'}
                            className={`w-5 h-5 rounded-md flex items-center justify-center border transition shrink-0 cursor-pointer ${
                              isCompleted
                                ? 'bg-emerald-500 border-emerald-400 text-slate-950'
                                : 'border-slate-700 hover:border-slate-500 bg-slate-900/80'
                            }`}
                          >
                            {isCompleted && <CheckCircle2 className="w-3.5 h-3.5" />}
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => onSelectStep(step.id)}
                          className="flex-1 flex items-center gap-2 text-left min-w-0 cursor-pointer"
                        >
                          {/* Step Number Badge */}
                          <span
                            className={`w-5 h-5 rounded flex items-center justify-center text-[10px] font-mono font-bold shrink-0 ${
                              isSelected
                                ? 'bg-cyan-500 text-slate-950'
                                : isCompleted
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-700/60'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {step.id}
                          </span>

                          {/* Title */}
                          <div className="flex-1 min-w-0">
                            <p className={`text-xs font-medium truncate ${isCompleted ? 'text-slate-300' : ''}`}>
                              {lang === 'en' ? step.titleEn : step.titleUrdu}
                            </p>
                            <p className="text-[10px] text-slate-500 truncate font-mono">
                              {step.specs.fastener || step.specs.torque}
                            </p>
                          </div>
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
