import React, { useState, useRef } from 'react';
import { UserSession } from '../types/auth';
import {
  clearUserSession,
  saveUserSession,
  cacheAllStepsOffline,
  isOfflineDataReady,
} from '../utils/storage';
import { CNC_STEPS } from '../data/cncSteps';
import {
  UserCheck,
  Mail,
  ShieldCheck,
  HardDrive,
  Download,
  CheckCircle2,
  Settings,
  Languages,
  LogOut,
  RefreshCw,
  Cpu,
  Wrench,
  Database,
  FileDown,
  Sparkles,
  Layers,
  ChevronRight,
  Sliders,
  Check,
  Eye,
  Camera,
  Trash2,
  RotateCcw,
  Edit2,
  Save,
  X,
} from 'lucide-react';

interface ProfileTabProps {
  session: UserSession;
  completedStepsCount: number;
  totalStepsCount: number;
  lang: 'ur' | 'en' | 'both';
  onLanguageChange: (lang: 'ur' | 'en' | 'both') => void;
  onLogout: () => void;
  onDownloadAllData: () => void;
  onUpdateSession?: (session: UserSession) => void;
}

export const ProfileTab: React.FC<ProfileTabProps> = ({
  session,
  completedStepsCount,
  totalStepsCount,
  lang,
  onLanguageChange,
  onLogout,
  onDownloadAllData,
  onUpdateSession,
}) => {
  const [isSyncingOffline, setIsSyncingOffline] = useState<boolean>(false);
  const [offlineSyncMessage, setOfflineSyncMessage] = useState<string>('');
  const [showLogoutConfirm, setShowLogoutConfirm] = useState<boolean>(false);
  const [successNotification, setSuccessNotification] = useState<string>('');

  // Local Editable Profile Data
  const [displayName, setDisplayName] = useState<string>(session.displayName || 'Arbaz Ahmad');
  const [workshopName, setWorkshopName] = useState<string>(session.workshopName || 'Arbaz Wood Craft');
  const [workshopRole, setWorkshopRole] = useState<string>(session.workshopRole || 'Chief CNC Workshop Engineer');
  const [phone, setPhone] = useState<string>(session.phone || '+92 300 1234567');
  const [avatarUrl, setAvatarUrl] = useState<string>(session.avatarUrl || '');
  const [isEditingProfile, setIsEditingProfile] = useState<boolean>(false);

  const avatarInputRef = useRef<HTMLInputElement | null>(null);

  // Avatar Upload Handler
  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setAvatarUrl(dataUrl);
        const updatedSession: UserSession = {
          ...session,
          avatarUrl: dataUrl,
          displayName,
          workshopName,
          workshopRole,
          phone,
        };
        saveUserSession(updatedSession);
        onUpdateSession?.(updatedSession);

        setSuccessNotification(
          lang === 'en'
            ? 'Profile photo / workshop logo uploaded successfully!'
            : 'ورکشاپ کا لوگو / تصویر کامیابی سے اپ لوڈ ہو گئی!'
        );
        setTimeout(() => setSuccessNotification(''), 4000);
      }
    };
    reader.readAsDataURL(file);
  };

  // Remove / Cancel Profile Data (Resets to Default)
  const handleRemoveProfileData = () => {
    // 1. Reset all state values to pristine default
    setAvatarUrl('');
    setDisplayName('Arbaz Ahmad');
    setWorkshopName('Arbaz Wood Craft');
    setWorkshopRole('Chief CNC Workshop Engineer');
    setPhone('');
    setIsEditingProfile(false);

    if (avatarInputRef.current) {
      avatarInputRef.current.value = '';
    }

    // 2. Build default session
    const resetSession: UserSession = {
      email: session.email,
      displayName: 'Arbaz Ahmad',
      verifiedAt: session.verifiedAt || new Date().toISOString(),
      workshopRole: 'Chief CNC Workshop Engineer',
      workshopName: 'Arbaz Wood Craft',
      avatarUrl: undefined,
      phone: undefined,
    };

    // 3. Save to storage & notify parent
    saveUserSession(resetSession);
    onUpdateSession?.(resetSession);

    // 4. Show success toast notification
    setSuccessNotification(
      lang === 'en'
        ? '✓ Profile photo & custom data removed! Default workshop profile restored successfully.'
        : '✓ پروفائل ڈیٹا اور تصویر کامیابی سے ختم کر دی گئی! ڈیفالٹ سیٹنگ بحال ہو گئی۔'
    );
    setTimeout(() => setSuccessNotification(''), 4500);
  };

  // Save Custom Profile Details
  const handleSaveProfileDetails = () => {
    const updatedSession: UserSession = {
      ...session,
      displayName,
      workshopName,
      workshopRole,
      phone,
      avatarUrl: avatarUrl || undefined,
    };
    saveUserSession(updatedSession);
    onUpdateSession?.(updatedSession);
    setIsEditingProfile(false);

    setSuccessNotification(
      lang === 'en'
        ? 'Workshop profile details saved successfully!'
        : 'ورکشاپ پروفائل تفصیلات کامیابی سے محفوظ ہو گئیں!'
    );
    setTimeout(() => setSuccessNotification(''), 4000);
  };

  const handleSyncOfflineData = () => {
    setIsSyncingOffline(true);
    setTimeout(() => {
      const res = cacheAllStepsOffline();
      setIsSyncingOffline(false);
      setOfflineSyncMessage(
        lang === 'en'
          ? `All ${res.count} steps successfully synced to offline local cache!`
          : `تمام ${res.count} مراحل کامیابی سے آف لائن محفوظ کر لیے گئے!`
      );
      setTimeout(() => setOfflineSyncMessage(''), 4000);
    }, 600);
  };

  const progressPercent = Math.round((completedStepsCount / totalStepsCount) * 100);

  // Dynamic Translations object
  const t = {
    verifiedBadge: lang === 'en' ? 'Verified Account' : lang === 'both' ? 'تصدیق شدہ اکاؤنٹ (Verified)' : 'تصدیق شدہ اکاؤنٹ',
    workshopRole: lang === 'en' ? 'Chief CNC Workshop Engineer' : lang === 'both' ? 'چیف ورکشاپ انجینئر (Chief CNC Engineer)' : 'چیف ورکشاپ انجینئر',
    switchLogout: lang === 'en' ? 'Switch Account' : lang === 'both' ? 'لاگ آؤٹ (Switch)' : 'اکاؤنٹ تبدیل کریں',
    progressTitle: lang === 'en' ? 'Machine Assembly Progress' : lang === 'both' ? 'مشین اسیمبلی تکمیل (Assembly Progress)' : 'مشین اسیمبلی تکمیل',
    stepsWord: lang === 'en' ? 'Steps' : 'مراحل',
    offlineTitle: lang === 'en' ? 'Offline Data & Local Storage' : lang === 'both' ? 'آف لائن ڈیٹا اور اسٹوریج (Offline Storage)' : 'آف لائن ڈیٹا اور اسٹوریج',
    offlineSub: lang === 'en'
      ? 'All 30 steps, CAD blueprints, and checklist records are permanently saved on this device.'
      : 'تمام 30 مراحل اور ڈایاگرامز آپ کے فون میں مستقل محفوظ ہیں اور انٹرنیٹ کے بغیر بھی دستیاب ہیں۔',
    offlineReadyBadge: lang === 'en' ? '100% Offline Ready' : '100% آف لائن تیار',
    statStepsTitle: lang === 'en' ? 'Total Assembly Steps' : 'کل اسیمبلی مراحل',
    statStepsSub: lang === 'en' ? 'Cached & Verified' : 'کیچڈ اور تصدیق شدہ',
    statNotesTitle: lang === 'en' ? 'Checklists & Custom Notes' : 'چیک لسٹ اور نوٹ سیو',
    statNotesSub: lang === 'en' ? 'Persistent localStorage' : 'ایپ بند ہونے پر ضائع نہیں ہوتا',
    statSessionTitle: lang === 'en' ? 'Authentication State' : 'موجودہ سیشن',
    statSessionSub: lang === 'en' ? 'Never resets on reload' : 'دوبارہ لاگ ان نہیں مانگے گا',
    syncOfflineBtn: lang === 'en' ? 'Force Refresh Offline Cache' : 'تمام مراحل آف لائن ڈاؤن لوڈ / اپ ڈیٹ کریں',
    exportBackupBtn: lang === 'en' ? 'Export Workshop Backup (JSON)' : 'ورکشاپ بیک اپ محفوظ کریں (JSON)',
    machineSpecsTitle: lang === 'en' ? 'Machine Profile & Specifications' : lang === 'both' ? 'مشین اسپیسیفیکیشنز (Machine Profile)' : 'مشین اسپیسیفیکیشنز',
    machineSpecsSub: lang === 'en' ? 'Arbaz Wood Craft Workshop 3-Axis CNC Setup' : 'Arbaz Wood Craft Workshop 3-Axis CNC Router Setup',
    workEnvelope: lang === 'en' ? 'Working Envelope:' : 'ورکنگ ایریا:',
    spindleMotor: lang === 'en' ? 'Spindle Motor:' : 'اسپنڈل موٹر:',
    driveMotion: lang === 'en' ? 'Transmission Drive:' : 'موشن اور بال اسکرو:',
    cncController: lang === 'en' ? 'CNC Controller:' : 'کنٹرولر سسٹم:',
    langTitle: lang === 'en' ? 'Language Preferences' : lang === 'both' ? 'زبان کی ترجیح (Language)' : 'زبان کی ترجیح',
    langSub: lang === 'en' ? 'Instant dynamic translation across all workshop views' : 'ورکشاپ ہدایات اور اصطلاحات کا ڈسپلے',
    logoutDialogTitle: lang === 'en' ? 'Are you sure you want to switch account?' : 'کیا آپ واقعی لاگ آؤٹ کرنا چاہتے ہیں؟',
    logoutDialogDesc: lang === 'en'
      ? 'Switching account will require Gmail OTP verification. Your offline saved steps and checklist progress will remain safe.'
      : 'لاگ آؤٹ کرنے پر آپ کو دوبارہ Gmail OTP کی تصدیق کرنی ہوگی۔ محفوظ شدہ مراحل اور چیک لسٹ کا ڈیٹا ضائع نہیں ہوگا۔',
    cancel: lang === 'en' ? 'Cancel' : 'منسوخ کریں',
    confirmLogout: lang === 'en' ? 'Yes, Log Out' : 'ہاں، لاگ آؤٹ کریں',
    removeProfileBtn: lang === 'en' ? 'Remove / Cancel Profile Data' : 'پروفائل ڈیٹا ختم کریں (Remove)',
    uploadPhotoBtn: lang === 'en' ? 'Change Photo / Logo' : 'لوگو / تصویر اپ لوڈ کریں',
    editProfileBtn: lang === 'en' ? 'Edit Details' : 'تفصیلات تبدیل کریں',
    saveDetailsBtn: lang === 'en' ? 'Save Changes' : 'محفوظ کریں',
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6 pb-24 font-sans">
      {/* Prominent Success Notification Banner */}
      {successNotification && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 border border-emerald-500 text-emerald-200 text-xs sm:text-sm font-medium flex items-center justify-between gap-3 shadow-xl animate-fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{successNotification}</span>
          </div>
          <button
            onClick={() => setSuccessNotification('')}
            className="text-emerald-400 hover:text-white p-1 rounded-lg cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Hidden Avatar / Logo File Input */}
      <input
        ref={avatarInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleAvatarUpload}
      />

      {/* Header Profile Card */}
      <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-[#0a1528] to-slate-900 border border-cyan-900/60 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-right">
          {/* Avatar / Logo with quick action buttons right next to it */}
          <div className="relative shrink-0 flex flex-col items-center gap-2">
            <div className="relative w-24 h-24 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 p-0.5 shadow-xl shadow-cyan-500/20 group">
              <div className="w-full h-full bg-slate-950 rounded-2xl overflow-hidden flex items-center justify-center">
                {avatarUrl ? (
                  <img
                    src={avatarUrl}
                    alt="Workshop Logo"
                    className="w-full h-full object-cover rounded-2xl"
                  />
                ) : (
                  <div className="text-4xl">🪵</div>
                )}
              </div>
              <button
                onClick={() => avatarInputRef.current?.click()}
                title="Upload Photo / Logo"
                className="absolute inset-0 bg-black/60 rounded-2xl opacity-0 group-hover:opacity-100 flex items-center justify-center text-cyan-300 transition cursor-pointer"
              >
                <Camera className="w-6 h-6" />
              </button>
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-emerald-500 border-2 border-slate-950 flex items-center justify-center text-slate-950">
                <Check className="w-3.5 h-3.5 stroke-[3]" />
              </div>
            </div>

            {/* Quick Upload Button under avatar on mobile, next to it on larger screens */}
            <button
              onClick={() => avatarInputRef.current?.click()}
              className="px-2.5 py-1 rounded-lg bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-700/60 text-cyan-300 text-[11px] font-medium flex items-center gap-1 cursor-pointer transition"
            >
              <Camera className="w-3 h-3" />
              <span>{t.uploadPhotoBtn}</span>
            </button>
          </div>

          {/* User & Workshop Info */}
          <div className="flex-1 space-y-2 text-center sm:text-left">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h2 className="text-xl sm:text-2xl font-bold text-white font-sans">
                {displayName}
              </h2>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-600/60 text-emerald-300 text-[11px] font-medium">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{t.verifiedBadge}</span>
              </span>
            </div>

            <p className="text-sm text-cyan-400 font-mono flex items-center justify-center sm:justify-start gap-1.5">
              <Mail className="w-4 h-4 text-slate-400" />
              <span>{session.email}</span>
            </p>

            <p className="text-xs text-slate-300 font-sans">
              <span className="font-semibold text-amber-300">{workshopRole}</span> &bull; {workshopName}
            </p>

            {/* Action Buttons Row right next to profile data: Clear / Remove Profile Data button */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
              {/* CLEAR / REMOVE PROFILE DATA BUTTON */}
              <button
                onClick={handleRemoveProfileData}
                title="Reset profile picture and restore default data"
                className="px-3.5 py-1.5 rounded-xl bg-red-950/70 hover:bg-red-900 border border-red-700/80 hover:border-red-500 text-red-200 hover:text-white text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-red-950/50 transition cursor-pointer active:scale-95"
              >
                <Trash2 className="w-3.5 h-3.5 text-red-400" />
                <span>{t.removeProfileBtn}</span>
              </button>

              <button
                onClick={() => setIsEditingProfile(!isEditingProfile)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white text-xs font-medium flex items-center gap-1.5 transition cursor-pointer"
              >
                <Edit2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>{isEditingProfile ? t.cancel : t.editProfileBtn}</span>
              </button>
            </div>
          </div>

          {/* Switch / Logout Button */}
          <div className="sm:self-start">
            <button
              onClick={() => setShowLogoutConfirm(true)}
              className="px-3.5 py-2 rounded-xl bg-slate-900/90 hover:bg-red-950/60 border border-slate-700 hover:border-red-600/60 text-slate-300 hover:text-red-300 text-xs font-medium transition flex items-center gap-1.5 cursor-pointer font-sans"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{t.switchLogout}</span>
            </button>
          </div>
        </div>

        {/* Inline Profile Editor Drawer (When Edit Details clicked) */}
        {isEditingProfile && (
          <div className="mt-5 p-4 rounded-2xl bg-slate-950/90 border border-cyan-800/60 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-cyan-400 font-mono">
                {lang === 'en' ? 'Edit Workshop Profile Data' : 'ورکشاپ اور کاریگر کی تفصیلات'}
              </span>
              <button
                onClick={handleRemoveProfileData}
                className="text-[11px] text-red-400 hover:text-red-300 font-medium flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>{t.removeProfileBtn}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">
                  {lang === 'en' ? 'Craftsman / User Name:' : 'کاریگر / یوزر کا نام:'}
                </label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-white font-medium focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">
                  {lang === 'en' ? 'Workshop Name:' : 'ورکشاپ کا نام:'}
                </label>
                <input
                  type="text"
                  value={workshopName}
                  onChange={(e) => setWorkshopName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-white font-medium focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">
                  {lang === 'en' ? 'Designation / Role:' : 'عہدہ / کردار:'}
                </label>
                <input
                  type="text"
                  value={workshopRole}
                  onChange={(e) => setWorkshopRole(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-white font-medium focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">
                  {lang === 'en' ? 'Contact / WhatsApp:' : 'رابطہ نمبر / واٹس ایپ:'}
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+92 300 1234567"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-white font-medium focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setIsEditingProfile(false)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium cursor-pointer"
              >
                {t.cancel}
              </button>
              <button
                onClick={handleSaveProfileDetails}
                className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{t.saveDetailsBtn}</span>
              </button>
            </div>
          </div>
        )}

        {/* Assembly Completion Progress */}
        <div className="mt-6 pt-5 border-t border-slate-800/80">
          <div className="flex justify-between items-center text-xs mb-2">
            <span className="text-slate-300 font-medium font-sans">{t.progressTitle}</span>
            <span className="font-mono text-cyan-400 font-bold">
              {completedStepsCount} / {totalStepsCount} {t.stepsWord} ({progressPercent}%)
            </span>
          </div>
          <div className="h-2.5 w-full bg-slate-950 rounded-full border border-slate-800 overflow-hidden p-0.5">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 to-emerald-400 rounded-full transition-all duration-500 shadow-[0_0_10px_rgba(34,211,238,0.5)]"
              style={{ width: `${Math.max(5, progressPercent)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Offline Storage & Persistence Card */}
      <div className="bg-slate-900/90 border border-cyan-900/50 rounded-2xl p-5 sm:p-6 backdrop-blur-md space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-800 text-cyan-400 flex items-center justify-center">
              <HardDrive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white font-sans">{t.offlineTitle}</h3>
              <p className="text-xs text-slate-400 font-sans">{t.offlineSub}</p>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-700/60 text-emerald-300 text-xs font-mono">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{t.offlineReadyBadge}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 text-center sm:text-right">
            <span className="text-[11px] text-slate-400 block font-sans">{t.statStepsTitle}</span>
            <span className="text-lg font-bold text-white font-mono">30 / 30 {t.stepsWord}</span>
            <span className="text-[10px] text-emerald-400 block font-sans">{t.statStepsSub}</span>
          </div>

          <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 text-center sm:text-right">
            <span className="text-[11px] text-slate-400 block font-sans">{t.statNotesTitle}</span>
            <span className="text-lg font-bold text-cyan-300 font-mono">Permanent</span>
            <span className="text-[10px] text-slate-400 block font-sans">{t.statNotesSub}</span>
          </div>

          <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 text-center sm:text-right">
            <span className="text-[11px] text-slate-400 block font-sans">{t.statSessionTitle}</span>
            <span className="text-lg font-bold text-amber-300 font-mono">Forever</span>
            <span className="text-[10px] text-slate-400 block font-sans">{t.statSessionSub}</span>
          </div>
        </div>

        {offlineSyncMessage && (
          <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-700 text-emerald-200 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{offlineSyncMessage}</span>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={handleSyncOfflineData}
            disabled={isSyncingOffline}
            className="flex-1 py-2.5 px-4 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 font-sans"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncingOffline ? 'animate-spin' : ''}`} />
            <span>{t.syncOfflineBtn}</span>
          </button>

          <button
            onClick={onDownloadAllData}
            className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-medium text-xs transition flex items-center gap-2 cursor-pointer font-sans"
          >
            <FileDown className="w-4 h-4 text-cyan-400" />
            <span>{t.exportBackupBtn}</span>
          </button>
        </div>
      </div>

      {/* Kodular Standalone Single-File Deployment Card */}
      <div className="bg-gradient-to-r from-emerald-950/50 via-slate-900 to-cyan-950/50 border border-emerald-600/50 rounded-2xl p-5 sm:p-6 backdrop-blur-md space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-950 border border-emerald-700 text-emerald-400 flex items-center justify-center text-xl shrink-0">
              📱
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base font-bold text-white font-sans">
                  {lang === 'en' ? 'Kodular Standalone Single index.html' : lang === 'both' ? 'کوڈولر ایپ سنگل index.html (Kodular Single-File)' : 'کوڈولر ایپ سنگل index.html'}
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-mono font-bold">
                  Zero ZIP Needed
                </span>
              </div>
              <p className="text-xs text-slate-300 font-sans mt-0.5">
                {lang === 'en'
                  ? 'All scripts, styles, blueprints and offline code are compiled into 1 single standalone index.html file for Kodular WebViewer.'
                  : 'تمام کوڈ، اسٹائلز، اور اسکرپٹس ایک ہی فائل index.html میں پیک ہیں۔ اسے بغیر کسی زپ فائل کے کوڈولر کے WebViewer میں براہ راست اپلوڈ کر سکتے ہیں۔'}
              </p>
            </div>
          </div>
        </div>

        <div className="p-3.5 bg-slate-950/80 rounded-xl border border-emerald-900/60 text-xs text-slate-300 space-y-1.5 font-sans">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{lang === 'en' ? 'How to use in Kodular:' : 'کوڈولر (Kodular) میں استعمال کا طریقہ:'}</span>
          </div>
          <ol className="list-decimal list-inside space-y-1 text-slate-400 text-[11px] leading-relaxed">
            <li>{lang === 'en' ? 'Download the index.html file below.' : 'نیچے دیے گئے بٹن سے index.html فائل ڈاؤن لوڈ کریں۔'}</li>
            <li>{lang === 'en' ? 'Open Kodular Creator > Assets > Upload "index.html".' : 'کوڈولر میں جا کر Assets میں یہ "index.html" فائل اپلوڈ کریں۔'}</li>
            <li>{lang === 'en' ? 'In Screen Designer, add a WebViewer component and set HomeUrl to: http://localhost/index.html' : 'اسکرین پر WebViewer کمپوننٹ لگائیں اور اس کا HomeUrl رکھیں: http://localhost/index.html'}</li>
          </ol>
        </div>

        <div className="flex flex-wrap items-center gap-3 pt-1">
          <a
            href="/api/download-kodular-html"
            download="index.html"
            className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-emerald-500/25 font-sans"
          >
            <Download className="w-4 h-4" />
            <span>{lang === 'en' ? 'Download index.html for Kodular' : 'کوڈولر کے لیے index.html ڈاؤن لوڈ کریں'}</span>
          </a>

          <a
            href="/kodular_index.html"
            target="_blank"
            rel="noreferrer"
            className="py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 font-medium text-xs sm:text-sm transition flex items-center gap-2 cursor-pointer font-sans"
          >
            <Eye className="w-4 h-4" />
            <span>{lang === 'en' ? 'Test Standalone Preview' : 'پریویو چیک کریں'}</span>
          </a>
        </div>
      </div>

      {/* Workshop Machine Specifications Card */}
      <div className="bg-slate-900/90 border border-cyan-900/50 rounded-2xl p-5 sm:p-6 backdrop-blur-md space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-950 border border-blue-800 text-blue-400 flex items-center justify-center">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white font-sans">{t.machineSpecsTitle}</h3>
            <p className="text-xs text-slate-400 font-sans">{t.machineSpecsSub}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 bg-slate-950/70 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-400 font-mono text-[11px]">{t.workEnvelope}</span>
            <p className="font-bold text-white font-mono">1300 × 2500 × 200 mm (4×8 Feet Bed)</p>
          </div>

          <div className="p-3 bg-slate-950/70 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-400 font-mono text-[11px]">{t.spindleMotor}</span>
            <p className="font-bold text-white font-mono">2.2 kW Water-Cooled, 24,000 RPM, ER20</p>
          </div>

          <div className="p-3 bg-slate-950/70 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-400 font-mono text-[11px]">{t.driveMotion}</span>
            <p className="font-bold text-white font-mono">HGR20 Linear Rails + SFU1605 Ball Screws</p>
          </div>

          <div className="p-3 bg-slate-950/70 rounded-xl border border-slate-800 space-y-1">
            <span className="text-slate-400 font-mono text-[11px]">{t.cncController}</span>
            <p className="font-bold text-white font-mono">DSP RichAuto A11 / Mach3 USB Interface</p>
          </div>
        </div>
      </div>

      {/* Language Preferences Card */}
      <div className="bg-slate-900/90 border border-cyan-900/50 rounded-2xl p-5 sm:p-6 backdrop-blur-md">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-800 text-purple-400 flex items-center justify-center">
              <Languages className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white font-sans">{t.langTitle}</h3>
              <p className="text-xs text-slate-400 font-sans">{t.langSub}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => onLanguageChange('ur')}
            className={`py-3 px-3 rounded-xl border text-xs font-bold transition cursor-pointer font-sans ${
              lang === 'ur'
                ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md shadow-cyan-500/20'
                : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
            }`}
          >
            اردو (صرف اردو)
          </button>

          <button
            onClick={() => onLanguageChange('both')}
            className={`py-3 px-3 rounded-xl border text-xs font-bold transition cursor-pointer font-sans ${
              lang === 'both'
                ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md shadow-cyan-500/20'
                : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
            }`}
          >
            اردو + English
          </button>

          <button
            onClick={() => onLanguageChange('en')}
            className={`py-3 px-3 rounded-xl border text-xs font-bold transition cursor-pointer font-sans ${
              lang === 'en'
                ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md shadow-cyan-500/20'
                : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
            }`}
          >
            English Only
          </button>
        </div>
      </div>

      {/* Confirmation Modal for Logout */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-red-900/60 rounded-3xl max-w-sm w-full p-6 space-y-4 text-center font-sans">
            <div className="w-12 h-12 rounded-2xl bg-red-950 border border-red-800 text-red-400 flex items-center justify-center mx-auto text-xl">
              ⚠️
            </div>
            <h4 className="text-base font-bold text-white font-sans">{t.logoutDialogTitle}</h4>
            <p className="text-xs text-slate-400 font-sans leading-relaxed">
              {t.logoutDialogDesc}
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowLogoutConfirm(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer"
              >
                {t.cancel}
              </button>
              <button
                onClick={() => {
                  setShowLogoutConfirm(false);
                  clearUserSession();
                  onLogout();
                }}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs cursor-pointer"
              >
                {t.confirmLogout}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
