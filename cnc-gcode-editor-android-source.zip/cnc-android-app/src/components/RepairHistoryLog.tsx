import React, { useState } from 'react';
import { RepairLog } from '../types/repair';
import { AnimatedCADVideoPlayer } from './AnimatedCADVideoPlayer';
import { InteractiveSVGBlueprint } from './InteractiveSVGBlueprint';
import {
  Search,
  Filter,
  FileDown,
  Printer,
  Trash2,
  CheckCircle2,
  Clock,
  AlertTriangle,
  X,
  ExternalLink,
  Edit3,
  Save,
  Wrench,
  Camera,
  Film,
  FileText,
} from 'lucide-react';

interface RepairHistoryLogProps {
  logs: RepairLog[];
  onUpdateLog: (updated: RepairLog) => void;
  onDeleteLog: (id: string) => void;
  onClearAll: () => void;
  lang: 'ur' | 'en' | 'both';
  isOpen: boolean;
  onClose: () => void;
}

export const RepairHistoryLog: React.FC<RepairHistoryLogProps> = ({
  logs,
  onUpdateLog,
  onDeleteLog,
  onClearAll,
  lang,
  isOpen,
  onClose,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedLog, setSelectedLog] = useState<RepairLog | null>(null);
  const [editingNotes, setEditingNotes] = useState<string>('');
  const [editingStatus, setEditingStatus] = useState<RepairLog['status']>('Resolved');
  const [modalMediaError, setModalMediaError] = useState<boolean>(false);
  const [modalCadError, setModalCadError] = useState<boolean>(false);

  if (!isOpen) return null;

  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      !searchQuery.trim() ||
      log.ticketNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.symptoms.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.stepTitleEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.stepTitleUrdu.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (log.technicianNotes && log.technicianNotes.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesSeverity = severityFilter === 'all' || log.severity.toLowerCase() === severityFilter.toLowerCase();
    const matchesStatus = statusFilter === 'all' || log.status.toLowerCase() === statusFilter.toLowerCase();

    return matchesSearch && matchesSeverity && matchesStatus;
  });

  const handleOpenDetail = (log: RepairLog) => {
    setSelectedLog(log);
    setEditingNotes(log.technicianNotes || '');
    setEditingStatus(log.status);
    setModalMediaError(false);
    setModalCadError(false);
  };

  const handleSaveNotes = () => {
    if (!selectedLog) return;
    const updated: RepairLog = {
      ...selectedLog,
      technicianNotes: editingNotes,
      status: editingStatus,
    };
    onUpdateLog(updated);
    setSelectedLog(updated);
  };

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(logs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `CNC_Router_Repair_Logs_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handlePrintReport = (log: RepairLog) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>CNC Maintenance Report - ${log.ticketNumber}</title>
          <style>
            body { font-family: monospace, sans-serif; padding: 25px; color: #111; }
            h1 { font-size: 18px; border-bottom: 2px solid #000; padding-bottom: 6px; }
            .badge { display: inline-block; padding: 3px 8px; font-weight: bold; background: #eee; border: 1px solid #333; }
            .section { margin-top: 15px; }
            .label { font-weight: bold; }
            pre { background: #f4f4f4; padding: 10px; white-space: pre-wrap; font-size: 12px; }
          </style>
        </head>
        <body>
          <h1>CNC ROUTER FIELD SERVICE INSPECTION REPORT</h1>
          <p><span class="label">Ticket:</span> ${log.ticketNumber} | <span class="label">Date:</span> ${log.date}</p>
          <p><span class="label">Assembly Step:</span> #${log.stepId} - ${log.stepTitleEn} (${log.stepTitleUrdu})</p>
          <p><span class="label">Severity:</span> <span class="badge">${log.severity}</span> | <span class="label">Status:</span> <span class="badge">${log.status}</span></p>
          
          <div class="section">
            <span class="label">Reported Symptoms:</span>
            <p>${log.symptoms}</p>
          </div>

          <div class="section">
            <span class="label">Engineering Diagnosis & Remedial Action:</span>
            <pre>${log.diagnosisText}</pre>
          </div>

          <div class="section">
            <span class="label">Torque & Tolerance Specifications:</span>
            <p>Torque: ${log.torqueApplied || '9.0 N·m'} | Tolerance: ${log.toleranceVerified || '±0.02 mm'}</p>
          </div>

          <div class="section">
            <span class="label">Technician Repair Notes:</span>
            <p>${log.technicianNotes || 'Standard overhaul and verification completed.'}</p>
          </div>

          <br/><hr/>
          <p style="font-size: 10px; color: #666;">Certified by AI Studio Mechatronics Engineer Engine v3.8</p>
          <script>window.onload = function() { window.print(); };</script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-cyan-800/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-cyan-900/60 bg-slate-950/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-cyan-950 text-cyan-400 border border-cyan-700/60">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-100">
                  {lang === 'en' ? 'Repair History & Activity Log' : 'مرمت کی تاریخ اور ورکشاپ ریکارڈ'}
                </h3>
                <span className="text-xs font-mono bg-cyan-950 text-cyan-300 px-2 py-0.5 rounded border border-cyan-800">
                  {logs.length} Records
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {lang === 'en' ? 'Stored locally in browser database' : 'براؤزر ڈیٹا بیس میں محفوظ شدہ تاریخ'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportJSON}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono text-cyan-300 border border-slate-700 transition"
              title="Export all logs as JSON"
            >
              <FileDown className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Export JSON</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Search & Filters Bar */}
        <div className="p-4 bg-slate-950/40 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Search Box */}
          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                lang === 'en'
                  ? 'Search tickets, symptoms, or step...'
                  : lang === 'both'
                  ? 'سرچ کریں (Search tickets, symptoms, or step)...'
                  : 'سرچ کریں (ٹکٹ، علامات یا سٹیپ)...'
              }
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-500 font-sans"
            />
          </div>

          {/* Severity Filter */}
          <div className="flex items-center gap-1.5 font-sans">
            <span className="text-slate-400 font-mono text-[11px]">{lang === 'en' ? 'Severity:' : 'شدت:'}</span>
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg p-1.5 text-xs text-slate-300 focus:outline-none"
            >
              <option value="all">{lang === 'en' ? 'All' : lang === 'both' ? 'تمام (All)' : 'تمام'}</option>
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="moderate">Moderate</option>
              <option value="low">Low</option>
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5 font-sans">
            <span className="text-slate-400 font-mono text-[11px]">{lang === 'en' ? 'Status:' : 'کیفیت:'}</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg p-1.5 text-xs text-slate-300 focus:outline-none"
            >
              <option value="all">{lang === 'en' ? 'All' : lang === 'both' ? 'تمام (All)' : 'تمام'}</option>
              <option value="resolved">{lang === 'en' ? 'Resolved' : lang === 'both' ? 'حل شدہ (Resolved)' : 'حل شدہ'}</option>
              <option value="in progress">{lang === 'en' ? 'In Progress' : lang === 'both' ? 'جاری (In Progress)' : 'جاری'}</option>
              <option value="inspection required">{lang === 'en' ? 'Inspection Required' : 'معائنہ درکار'}</option>
            </select>
          </div>
        </div>

        {/* Log Entries List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {filteredLogs.length === 0 ? (
            <div className="text-center py-12 text-slate-500 font-mono text-xs">
              {lang === 'en' ? 'No repair logs matched.' : 'کوئی ریکارڈ نہیں ملا (No repair logs matched).'}
            </div>
          ) : (
            filteredLogs.map((log) => (
              <div
                key={log.id}
                onClick={() => handleOpenDetail(log)}
                className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/90 hover:border-cyan-700/80 hover:bg-slate-900/60 cursor-pointer transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-cyan-400">{log.ticketNumber}</span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                        log.severity === 'Critical'
                          ? 'bg-red-950 text-red-300 border border-red-800'
                          : log.severity === 'High'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      }`}
                    >
                      {log.severity}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">{log.date}</span>
                  </div>

                  <h4 className="text-xs font-semibold text-slate-200">
                    Step {log.stepId}: {lang === 'en' ? log.stepTitleEn : log.stepTitleUrdu}
                  </h4>
                  <p className="text-[11px] text-slate-400 line-clamp-1">{log.symptoms}</p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span
                    className={`text-[11px] font-mono px-2 py-0.5 rounded border ${
                      log.status === 'Resolved'
                        ? 'bg-emerald-950/70 text-emerald-300 border-emerald-800'
                        : 'bg-amber-950/70 text-amber-300 border-amber-800'
                    }`}
                  >
                    {log.status}
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteLog(log.id);
                    }}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-slate-800 transition"
                    title="Delete Record"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Detail Inspection Modal Overlay */}
        {selectedLog && (
          <div className="absolute inset-0 z-20 bg-slate-950/95 flex flex-col p-5 overflow-y-auto space-y-4 animate-in fade-in duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-cyan-950">
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-bold text-cyan-400">
                  {selectedLog.ticketNumber}
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  Step {selectedLog.stepId} - {selectedLog.stepTitleEn}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handlePrintReport(selectedLog)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{lang === 'en' ? 'Print Report' : 'پرنٹ رپورٹ'}</span>
                </button>
                <button
                  onClick={() => setSelectedLog(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Media & CAD side by side */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="bg-slate-900 rounded-xl p-3 border border-slate-800 text-xs space-y-1">
                <span className="font-mono text-slate-400">
                  {selectedLog.mediaUrl && !modalMediaError ? 'Uploaded Fault Media:' : 'Interactive SVG Fault Blueprint:'}
                </span>
                <div className="min-h-[176px] rounded bg-slate-950 flex items-center justify-center overflow-hidden">
                  {selectedLog.mediaUrl && !modalMediaError ? (
                    selectedLog.mediaUrl.endsWith('.mp4') || selectedLog.mediaUrl.endsWith('.webm') ? (
                      <video src={selectedLog.mediaUrl} controls className="max-h-full max-w-full object-contain" />
                    ) : (
                      <img
                        src={selectedLog.mediaUrl}
                        alt="Fault"
                        onError={() => setModalMediaError(true)}
                        className="max-h-full max-w-full object-contain"
                      />
                    )
                  ) : (
                    <InteractiveSVGBlueprint
                      stepNumber={selectedLog.stepId}
                      isDiagnosticMode={true}
                      showCanvasSimulation={true}
                      customOverlayText="FAULT LOG CAD BLUEPRINT"
                      className="w-full h-full min-h-[176px]"
                    />
                  )}
                </div>
              </div>

              <div className="bg-slate-900 rounded-xl p-3 border border-cyan-900 text-xs space-y-1">
                <span className="font-mono text-cyan-300">Diagnostic CAD Blueprint:</span>
                <div className="min-h-[176px] rounded bg-slate-950 flex items-center justify-center overflow-hidden">
                  {selectedLog.diagnosticImageUrl && !modalCadError ? (
                    <img
                      src={selectedLog.diagnosticImageUrl}
                      alt="Diagnostic CAD"
                      onError={() => setModalCadError(true)}
                      className="max-h-full max-w-full object-contain"
                    />
                  ) : (
                    <InteractiveSVGBlueprint
                      stepNumber={selectedLog.stepId}
                      isDiagnosticMode={true}
                      showCanvasSimulation={true}
                      customOverlayText="REPAIR SCHEMATIC DWG"
                      className="w-full h-full min-h-[176px]"
                    />
                  )}
                </div>
              </div>
            </div>

            {/* Diagnosis Text */}
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs space-y-1">
              <span className="font-bold text-cyan-300 font-mono">AI Engineering Diagnosis & Actions:</span>
              <div className="whitespace-pre-line text-slate-300 font-sans leading-relaxed">
                {selectedLog.diagnosisText}
              </div>
            </div>

            {/* Interactive Repair Video Guide Player if available */}
            {selectedLog.videoGuide && (
              <div className="space-y-1">
                <span className="font-bold text-cyan-300 font-mono text-xs flex items-center gap-1">
                  <Film className="w-3.5 h-3.5 text-cyan-400" />
                  <span>محفوظ شدہ ویڈیو گائیڈ اور CAD سمولیشن (Saved Video Guide & CAD Diagnostics):</span>
                </span>
                <AnimatedCADVideoPlayer
                  videoGuide={selectedLog.videoGuide}
                  diagnosticImageUrl={selectedLog.diagnosticImageUrl || selectedLog.mediaUrl || ''}
                  stepId={selectedLog.stepId}
                  stepTitleEn={selectedLog.stepTitleEn}
                  stepTitleUrdu={selectedLog.stepTitleUrdu}
                  torqueSpec={selectedLog.torqueApplied}
                  toleranceSpec={selectedLog.toleranceVerified}
                  lang={lang}
                />
              </div>
            )}

            {/* Edit Technician Notes & Status */}
            <div className="p-3.5 rounded-xl bg-slate-900 border border-cyan-900/60 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-300 font-mono text-xs flex items-center gap-1">
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>
                    {lang === 'en'
                      ? 'Technician Service Notes:'
                      : lang === 'both'
                      ? 'ٹیکنیشن کے نوٹس اور مرمتی کیفیت (Technician Service Notes):'
                      : 'ٹیکنیشن کے نوٹس اور مرمتی کیفیت:'}
                  </span>
                </span>
                <select
                  value={editingStatus}
                  onChange={(e) => setEditingStatus(e.target.value as any)}
                  className="bg-slate-950 border border-slate-700 rounded p-1 text-xs text-slate-200"
                >
                  <option value="Resolved">{lang === 'en' ? 'Resolved' : lang === 'both' ? 'Resolved (حل شدہ)' : 'حل شدہ'}</option>
                  <option value="In Progress">{lang === 'en' ? 'In Progress' : lang === 'both' ? 'In Progress (جاری)' : 'جاری'}</option>
                  <option value="Inspection Required">{lang === 'en' ? 'Inspection Required' : 'معائنہ درکار'}</option>
                </select>
              </div>

              <textarea
                rows={3}
                value={editingNotes}
                onChange={(e) => setEditingNotes(e.target.value)}
                placeholder={
                  lang === 'en'
                    ? 'Enter technician repair verification notes (e.g. Tightened M5 bolts to 9.2 N·m with Loctite 243, checked with dial indicator)...'
                    : 'مرمت کے بعد تصدیقی نوٹس لکھیں (مثلاً: بولٹس ٹائٹ کیے اور ڈائل انڈیکیٹر سے رن آؤٹ چیک کیا)...'
                }
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-cyan-500 font-sans"
              />

              <div className="flex justify-end">
                <button
                  onClick={handleSaveNotes}
                  className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs transition cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{lang === 'en' ? 'Save Notes' : 'نوٹس محفوظ کریں'}</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
