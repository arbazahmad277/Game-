# CNC G-Code Editor — Android APK بنانے کا طریقہ

## اہم بات
یہ پروجیکٹ React/Vite ایپ ہے، Android APK ابھی تیار شدہ بائنری فائل نہیں ہے۔ اس ZIP میں Android build setup اور GitHub Actions workflow شامل ہے جو APK بنا سکتا ہے۔ اس ماحول میں Android SDK موجود نہ ہونے اور dependency install/build مکمل نہ ہونے کی وجہ سے APK کو یہاں compile کرکے verify نہیں کیا گیا۔

## GitHub کے ذریعے APK بنائیں
1. اس ZIP کو اپنے کمپیوٹر پر extract کریں۔
2. GitHub پر نیا repository بنائیں اور تمام project files upload کریں۔
3. repository میں `main` branch استعمال کریں۔
4. GitHub میں **Actions** tab کھولیں اور **Build Android APK** workflow منتخب کریں۔
5. **Run workflow** دبائیں۔
6. مکمل ہونے کے بعد workflow run کے نیچے **Artifacts** میں `cnc-gcode-editor-debug-apk` ڈاؤن لوڈ کریں۔
7. ZIP کھولیں؛ اس کے اندر `app-debug.apk` ہوگا۔ اسے Android فون میں install کرنے کے لیے فون کی اجازت کے مطابق “Install unknown apps” فعال کرنا پڑ سکتا ہے۔

## فی الحال درکار چیزیں
- GitHub اکاؤنٹ
- انٹرنیٹ کنکشن
- اگر خود کمپیوٹر پر build کرنا ہو تو Node.js 22، Java 21، Android SDK/Android Studio

## Backend کے متعلق ضروری نوٹ
اصل ایپ میں `/api/...` والے server endpoints موجود ہیں، مثلاً AI CAD editing، audio transcription، OTP login اور video streaming۔ صرف static APK build کرنے سے یہ server features خود بخود کام نہیں کریں گے۔ ان کے لیے `server.ts` کو الگ backend پر deploy کرنا اور frontend میں API base URL/configuration جوڑنا ضروری ہے۔ بنیادی مقامی UI اور bundled assets پھر بھی app کے اندر شامل ہو سکتے ہیں، لیکن backend پر منحصر فیچرز backend deploy ہونے تک دستیاب نہیں ہوں گے۔

## CNC حفاظت
یہ ایپ G-Code دکھانے یا edit کرنے میں مدد دے سکتی ہے، لیکن کسی فائل کو مشین پر چلانے سے پہلے controller compatibility، G20/G21 units، work offsets، Z safe height، spindle/feed rates، limits اور workholding چیک کریں اور پہلے dry run کریں۔
